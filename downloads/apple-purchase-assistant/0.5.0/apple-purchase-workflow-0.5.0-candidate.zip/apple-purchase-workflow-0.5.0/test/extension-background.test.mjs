import {test} from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {DEFAULTS} from '../extension/core.js';

function event(){return {listeners:[],addListener(fn){this.listeners.push(fn);},emit(...args){for(const fn of this.listeners)fn(...args);}};}
function area(){const data={};return {data,async get(key){return {[key]:structuredClone(data[key])};},async set(values){Object.assign(data,structuredClone(values));},async setAccessLevel(){}};}
async function harness(){
 const id='unit-extension',local=area(),session=area();
 const events={message:event(),startup:event(),installed:event(),alarm:event(),removed:event(),updated:event()};
 const tabs=new Map([[2,{id:2,active:true,url:DEFAULTS.url}]]),injections=[];let nextTab=10;
 const chrome={
  runtime:{id,getURL:p=>`chrome-extension://${id}/${p}`,onMessage:events.message,onStartup:events.startup,onInstalled:events.installed},
  storage:{local,session},action:{async setBadgeText(){},async setBadgeBackgroundColor(){}},
  alarms:{onAlarm:events.alarm,async create(){},async clear(){}},permissions:{async contains(){return true;}},
  scripting:{async executeScript(info){injections.push(info);return [];}},
  tabs:{onRemoved:events.removed,onUpdated:events.updated,async get(tabId){if(!tabs.has(tabId))throw Error('closed');return {...tabs.get(tabId)};},async create(info){const t={id:nextTab++,active:true,...info};tabs.set(t.id,t);return {...t};},async update(tabId,info){Object.assign(tabs.get(tabId),info);return {...tabs.get(tabId)};},async sendMessage(){return {ok:true};}}
 };
 globalThis.chrome=chrome;
 const popup={id,url:chrome.runtime.getURL('popup.html')};
 async function load(){for(const value of Object.values(events))value.listeners=[];await import(`../extension/background.js?test=${randomUUID()}`);}
 await load();
 async function send(message,sender=popup){return new Promise(resolve=>{const listener=events.message.listeners.at(-1);listener(message,sender,resolve);});}
 const config={...DEFAULTS,storage:'TEST-256',color:'TEST-WHITE',maxTotal:200,countdownSeconds:3};
 const snapshot=(extra={})=>({observedAt:Date.now(),region:'CN',model:config.model,storage:config.storage,color:config.color,quantity:'1',currency:'CNY',delivery:config.delivery,totalMinor:10000,countdownPresent:true,countdownText:'00:00',buttonUnique:true,buttonEnabled:true,...extra});
 async function simulation(){const start=await send({type:'START',config});assert.equal(start.ok,true);const task=start.task,nonce=randomUUID(),sender={id,url:chrome.runtime.getURL(`simulator.html?task=${task.id}`),tab:{id:task.tabId}};const base={taskId:task.id,tabId:task.tabId,documentNonce:nonce};assert.equal((await send({...base,type:'SIM_CONFIG'},sender)).ok,true);return {task,sender,base};}
 return {chrome,events,local,session,tabs,injections,send,load,config,snapshot,simulation};
}

test('MV3 background lifecycle and submission boundary with fake Chrome APIs',async t=>{
 await t.test('single mock claim is durable before action; duplicate observations do not submit',async()=>{
  const h=await harness(),r=await h.simulation();
  const first=await h.send({...r.base,type:'OBSERVE',snapshot:h.snapshot()},r.sender);assert.equal(first.action,'mock-submit');assert.equal(h.local.data.currentTask.claim.status,'pending');
  const second=await h.send({...r.base,type:'OBSERVE',snapshot:h.snapshot()},r.sender);assert.equal(second.action,'none');
  const done=await h.send({...r.base,type:'MOCK_RESULT',outcome:'confirmed'},r.sender);assert.equal(done.state,'DONE');assert.equal((await h.send({...r.base,type:'OBSERVE',snapshot:h.snapshot()},r.sender)).ok,false);
 });
 await t.test('unknown outcome and stopping pending submission lock the intent',async()=>{
  const h=await harness(),r=await h.simulation();await h.send({...r.base,type:'OBSERVE',snapshot:h.snapshot()},r.sender);
  const stopped=await h.send({type:'STOP'});assert.equal(stopped.task.state,'UNKNOWN');assert.equal(stopped.task.claim.status,'unknown');
  assert.equal((await h.send({...r.base,type:'MOCK_RESULT',outcome:'confirmed'},r.sender)).ok,false);
 });
 await t.test('changed simulation document nonce cannot reset a running task',async()=>{
  const h=await harness(),r=await h.simulation();const reload=await h.send({...r.base,type:'SIM_CONFIG',documentNonce:randomUUID()},r.sender);assert.equal(reload.ok,false);assert.equal(h.local.data.currentTask.state,'PAUSED');
 });
 await t.test('tab navigation and tab close pause without resume',async()=>{
  const h=await harness(),r=await h.simulation();h.events.updated.emit(r.task.tabId,{status:'loading'});await h.send({type:'STATUS'});assert.equal(h.local.data.currentTask.state,'PAUSED');
  const next=await h.simulation();h.events.removed.emit(next.task.tabId);await h.send({type:'STATUS'});assert.equal(h.local.data.currentTask.state,'PAUSED');
 });
 await t.test('worker recreation preserves engine progress; stale heartbeat and browser restart pause',async()=>{
  const h=await harness(),r=await h.simulation();await h.send({...r.base,type:'OBSERVE',snapshot:h.snapshot({countdownText:'00:02'})},r.sender);
  await h.load();let status=await h.send({type:'STATUS'});assert.equal(status.task.state,'WAITING');
  const reset=await h.send({...r.base,type:'OBSERVE',snapshot:h.snapshot({countdownText:'00:10'})},r.sender);assert.equal(reset.state,'PAUSED');
  await h.simulation();h.local.data.currentTask.lastSeen=Date.now()-71000;status=await h.send({type:'STATUS'});assert.equal(status.task.state,'PAUSED');
  await h.simulation();h.events.startup.emit();status=await h.send({type:'STATUS'});assert.equal(status.task.state,'PAUSED');
 });
 await t.test('pending claim timeout becomes unknown and expired task pauses',async()=>{
  const h=await harness(),r=await h.simulation();await h.send({...r.base,type:'OBSERVE',snapshot:h.snapshot()},r.sender);h.local.data.currentTask.claim.time=Date.now()-11000;
  assert.equal((await h.send({type:'STATUS'})).task.state,'UNKNOWN');
  await h.simulation();h.local.data.currentTask.expiresAt=Date.now()-1;assert.equal((await h.send({type:'STATUS'})).task.state,'PAUSED');
 });
 await t.test('wrong tab and page control messages are rejected',async()=>{
  const h=await harness(),r=await h.simulation();assert.equal((await h.send({...r.base,type:'OBSERVE',snapshot:h.snapshot()},{...r.sender,tab:{id:999}})).ok,false);
  assert.equal((await h.send({type:'STOP'},{id:h.chrome.runtime.id,url:DEFAULTS.url,tab:{id:2}})).ok,false);
 });
 await t.test('official mode injects only current matching Apple page and returns preview',async()=>{
  const h=await harness();const config={...h.config,mode:'official-readonly',targetTime:new Date(Date.now()+60000).toISOString(),expiresAt:new Date(Date.now()+120000).toISOString()};
  const start=await h.send({type:'START',config,tabId:2});assert.equal(start.ok,true);assert.equal(h.injections.length,1);assert.deepEqual(h.injections[0],{target:{tabId:2},files:['dom-driver.js','apple-duo-readonly.js','content.js'],injectImmediately:true});
  const preview=await h.send({type:'OBSERVE',taskId:start.task.id,snapshot:h.snapshot()},{id:h.chrome.runtime.id,url:DEFAULTS.url,tab:{id:2}});assert.equal(preview.action,'preview');assert.equal(preview.state,'DONE');assert.equal(h.local.data.currentTask.claim,null);
  assert.equal((await h.send({type:'START',config:{...config,url:'https://evil.test/shop'},tabId:2})).ok,false);assert.equal(h.injections.length,1);
 });
 await t.test('pending durable claim survives worker recreation and never returns another action',async()=>{
  const h=await harness(),r=await h.simulation();
  assert.equal((await h.send({...r.base,type:'OBSERVE',snapshot:h.snapshot()},r.sender)).action,'mock-submit');
  const before=structuredClone(h.local.data.currentTask.claim);
  await h.load();
  assert.equal((await h.send({...r.base,type:'OBSERVE',snapshot:h.snapshot()},r.sender)).action,'none');
  assert.deepEqual(h.local.data.currentTask.claim,before);
  assert.equal((await h.send({...r.base,type:'MOCK_RESULT',outcome:'confirmed'},r.sender)).state,'DONE');
  await h.load();
  assert.equal((await h.send({...r.base,type:'OBSERVE',snapshot:h.snapshot()},r.sender)).ok,false);
  assert.equal(h.local.data.currentTask.claim.status,'confirmed');
 });
 await t.test('concurrent observations issue one action and stopped state persists across worker and browser restart',async()=>{
  const h=await harness(),r=await h.simulation();
  const results=await Promise.all(Array.from({length:20},()=>h.send({...r.base,type:'OBSERVE',snapshot:h.snapshot()},r.sender)));
  assert.equal(results.filter(x=>x.action==='mock-submit').length,1);
  await h.send({type:'STOP'});await h.load();h.events.startup.emit();
  assert.equal((await h.send({type:'STATUS'})).task.state,'UNKNOWN');
  assert.equal(h.local.data.currentTask.claim.status,'unknown');
  assert.equal((await h.send({...r.base,type:'MOCK_RESULT',outcome:'confirmed'},r.sender)).ok,false);
  const next=await h.simulation();await h.send({type:'STOP'});await h.load();h.events.startup.emit();
  assert.equal((await h.send({type:'STATUS'})).task.state,'STOPPED');
  assert.equal((await h.send({...next.base,type:'OBSERVE',snapshot:h.snapshot()},next.sender)).ok,false);
 });
 await t.test('browser restart and extension update preserve pending claim as UNKNOWN',async()=>{
  for(const lifecycle of ['startup','installed']){
   const h=await harness(),r=await h.simulation();await h.send({...r.base,type:'OBSERVE',snapshot:h.snapshot()},r.sender);
   await h.load();h.events[lifecycle].emit();
   const status=await h.send({type:'STATUS'});
   assert.equal(status.task.state,'UNKNOWN',lifecycle);assert.equal(status.task.claim.status,'unknown',lifecycle);
   assert.equal((await h.send({...r.base,type:'MOCK_RESULT',outcome:'confirmed'},r.sender)).ok,false);
  }
 });
 await t.test('lost session config preserves uncertainty rather than ordinary pause',async()=>{
  const h=await harness(),r=await h.simulation();await h.send({...r.base,type:'OBSERVE',snapshot:h.snapshot()},r.sender);
  delete h.session.data[`config:${r.task.id}`];await h.load();
  assert.equal((await h.send({...r.base,type:'OBSERVE',snapshot:h.snapshot()},r.sender)).ok,false);
  assert.equal(h.local.data.currentTask.state,'UNKNOWN');assert.equal(h.local.data.currentTask.claim.status,'unknown');
 });
 await t.test('failed durable claim write never releases an action; reply loss cannot duplicate a persisted action',async()=>{
  const h=await harness(),r=await h.simulation(),save=h.local.set;
  h.local.set=async values=>{if(values.currentTask?.claim)throw Error('storage unavailable');return save(values);};
  const failed=await h.send({...r.base,type:'OBSERVE',snapshot:h.snapshot()},r.sender);
  assert.equal(failed.ok,false);assert.equal(failed.action,undefined);assert.equal(h.local.data.currentTask.claim,null);
  h.local.set=save;
  // The first successful response is deliberately ignored, as if the receiver vanished.
  await h.send({...r.base,type:'OBSERVE',snapshot:h.snapshot()},r.sender);await h.load();
  const retry=await h.send({...r.base,type:'OBSERVE',snapshot:h.snapshot()},r.sender);
  assert.equal(retry.action,'none');assert.equal(h.local.data.currentTask.claim.status,'pending');
 });
 await t.test('closing popup does not stop page-driven work; reopened popup reads saved settings and task',async()=>{
  const h=await harness(),r=await h.simulation();
  // There are no popup STATUS calls during this page-driven countdown.
  assert.equal((await h.send({...r.base,type:'OBSERVE',snapshot:h.snapshot({countdownText:'00:02'})},r.sender)).state,'WAITING');
  await h.load();
  assert.equal((await h.send({...r.base,type:'OBSERVE',snapshot:h.snapshot()},r.sender)).action,'mock-submit');
  const reopened=await h.send({type:'STATUS'});
  assert.equal(reopened.settings.storage,h.config.storage);assert.equal(reopened.task.id,r.task.id);
  assert.equal(reopened.task.state,'SUBMITTING');assert.equal(reopened.task.claim.status,'pending');
 });

 await t.test('legacy paused pending claim migrates to UNKNOWN with coherent persisted engine state',async()=>{
  const h=await harness(),r=await h.simulation();await h.send({...r.base,type:'OBSERVE',snapshot:h.snapshot()},r.sender);
  h.local.data.currentTask.state='PAUSED';
  await h.load();const status=await h.send({type:'STATUS'});
  assert.equal(status.task.state,'UNKNOWN');assert.equal(status.task.engine.state,'UNKNOWN');
  assert.equal(status.task.claim.status,'unknown');
  assert.equal((await h.send({...r.base,type:'OBSERVE',snapshot:h.snapshot()},r.sender)).ok,false);
 });
 await t.test('stopping a waiting task saves terminal state in both record and engine',async()=>{
  const h=await harness(),r=await h.simulation();await h.send({...r.base,type:'OBSERVE',snapshot:h.snapshot({countdownText:'00:02'})},r.sender);
  await h.send({type:'STOP'});await h.load();const status=await h.send({type:'STATUS'});
  assert.equal(status.task.state,'STOPPED');assert.equal(status.task.engine.state,'STOPPED');
  assert.equal(status.task.claim,null);
 });

 await t.test('official configuration evidence is retained as diagnostics and never creates a claim',async()=>{
  const h=await harness(),config={...h.config,mode:'official-readonly',targetTime:new Date(Date.now()+60000).toISOString(),expiresAt:new Date(Date.now()+120000).toISOString()};
  const started=await h.send({type:'START',config,tabId:2});
  const evidence={supported:true,pageKind:'product-configuration',model:'iPhone Duo',color:null,storage:null,summary:'iPhone Duo 256GB 夜空色',itemPriceMinor:1599900,itemCurrency:'CNY',releaseNotice:'暂未发售',
   options:{color:[{name:'星光白色',selected:false,enabled:true}],storage:[{name:'256GB',selected:false,enabled:false}]},
   continue:{status:'disabled',name:'继续',enabled:false},evidenceMissing:['selected-color','selected-storage','order-total'],ambiguity:[]};
  const observation=await h.send({type:'OBSERVE',taskId:started.task.id,snapshot:h.snapshot({blocker:'配置页：继续不是下单按钮',buttonUnique:false,buttonEnabled:false,totalMinor:null,pageEvidence:evidence})},{id:h.chrome.runtime.id,url:config.url,tab:{id:2}});
  assert.equal(observation.state,'PAUSED');assert.equal(observation.action,'none');
  const saved=(await h.send({type:'STATUS'})).task;assert.equal(saved.claim,null);assert.equal(saved.pageEvidence.continue.name,'继续');
  assert.equal(saved.pageEvidence.itemPriceMinor,1599900);assert.equal(saved.pageEvidence.releaseNotice,'暂未发售');assert.equal(saved.pageEvidence.storage,null);assert.equal(saved.pageEvidence.options.storage[0].enabled,false);
  await h.load();assert.equal((await h.send({type:'STATUS'})).task.pageEvidence.model,'iPhone Duo');
 });

 await t.test('official start permits observed same-product SKU and rejects unknown or foreign product routes',async()=>{
  const base='https://www.apple.com.cn/shop/buy-iphone/iphone-duo';
  for(const [url,allowed]of [[`${base}/mk2n4ch/a`,true],[`${base}/mk2u4ch/a`,true],[`${base}/unknown/a`,false],['https://www.apple.com.cn/shop/buy-iphone/other-phone/mk2n4ch/a',false],['https://www.apple.com.cn.evil.test/shop/buy-iphone/iphone-duo/mk2n4ch/a',false]]){
   const h=await harness();h.tabs.get(2).url=url;
   const config={...h.config,url:base,mode:'official-readonly',targetTime:new Date(Date.now()+60000).toISOString(),expiresAt:new Date(Date.now()+120000).toISOString()};
   const start=await h.send({type:'START',config,tabId:2});assert.equal(start.ok,allowed,url);
   assert.equal(h.injections.length,allowed?1:0);
  }
 });

 await t.test('assist plan injects the real-page runner only after explicit per-start consent',async()=>{
  const h=await harness(),config={...h.config,mode:'assist',confirmedAssist:true,color:'夜空色',storage:'1TB',maxTotal:30000,targetTime:new Date().toISOString(),expiresAt:new Date(Date.now()+300000).toISOString()};
  assert.equal((await h.send({type:'START',config:{...config,confirmedAssist:false},tabId:2})).ok,false);assert.equal(h.injections.length,0);
  const start=await h.send({type:'START',config,tabId:2});assert.equal(start.ok,true);assert.equal(start.task.mode,'assist');assert.equal(start.task.stepIndex,0);
  assert.deepEqual(h.injections[0].files,['dom-driver.js','apple-duo-readonly.js','assist-content.js']);
  const status=await h.send({type:'STATUS'});assert.equal(status.finalOrdersEnabled,false);assert.equal(status.assistedEnabled,true);
 });
 await t.test('assist durable step claim and one-use pre-click permit survive worker recreation',async()=>{
  const h=await harness(),r=await assistSetup(h);
  const [a,...rest]=await Promise.all(Array.from({length:10},()=>h.send({...r.base,type:'ASSIST_CLAIM',stepIndex:0,evidence:r.evidence()},r.sender)));
  assert.equal(a.action,'assist-click');assert.equal(rest.every(x=>x.action==='none'),true);assert.equal(h.local.data.currentTask.claim.status,'pending');
  const token=a.claimToken;await h.load();
  const check={...r.base,type:'ASSIST_CHECK',stepIndex:0,claimToken:token,evidence:r.evidence()};
  assert.equal((await h.send(check,r.sender)).allowed,true);await h.load();assert.equal((await h.send(check,r.sender)).allowed,false);
  const done=await h.send({...r.base,type:'ASSIST_RESULT',stepIndex:0,claimToken:token,outcome:'confirmed'},r.sender);
  assert.equal(done.state,'WAITING');assert.equal(done.stepIndex,1);assert.equal(h.local.data.currentTask.claims[0].status,'confirmed');
  const b=await h.send({...r.base,type:'ASSIST_CLAIM',stepIndex:1,evidence:r.evidence({color:r.config.color})},r.sender);assert.equal(b.action,'assist-click');
  assert.equal((await h.send({...r.base,type:'ASSIST_CHECK',stepIndex:1,claimToken:b.claimToken,evidence:r.evidence({color:r.config.color})},r.sender)).allowed,true);
  const finished=await h.send({...r.base,type:'ASSIST_RESULT',stepIndex:1,claimToken:b.claimToken,outcome:'confirmed'},r.sender);assert.equal(finished.state,'DONE');
  assert.match(finished.reason,/最终订单提交尚未实现/);
  assert.equal((await h.send({...r.base,type:'ASSIST_CLAIM',stepIndex:1,evidence:r.evidence()},r.sender)).ok,false);
 });
 await t.test('assist stop, restart, config loss and result timeout all preserve pending uncertainty',async()=>{
  for(const action of ['stop','restart','config-loss','timeout']){
   const h=await harness(),r=await assistSetup(h),claim=await h.send({...r.base,type:'ASSIST_CLAIM',stepIndex:0,evidence:r.evidence()},r.sender);
   if(action==='stop')await h.send({type:'STOP'});
   if(action==='restart'){await h.load();h.events.startup.emit();}
   if(action==='config-loss'){delete h.session.data[`config:${r.task.id}`];await h.send({...r.base,type:'ASSIST_CHECK',stepIndex:0,claimToken:claim.claimToken,evidence:r.evidence()},r.sender);}
   if(action==='timeout')h.local.data.currentTask.claim.deadline=Date.now()-1;
   const status=await h.send({type:'STATUS'});assert.equal(status.task.state,'UNKNOWN',action);assert.equal(status.task.claim.status,'unknown',action);
   assert.equal((await h.send({...r.base,type:'ASSIST_RESULT',stepIndex:0,claimToken:claim.claimToken,outcome:'confirmed'},r.sender)).ok,false);
  }
 });
 await t.test('assist storage failure or changed evidence does not issue a click permit',async()=>{
  const h=await harness(),r=await assistSetup(h),save=h.local.set;
  h.local.set=async v=>{if(v.currentTask?.claim)throw Error('disk failure');return save(v);};
  assert.equal((await h.send({...r.base,type:'ASSIST_CLAIM',stepIndex:0,evidence:r.evidence()},r.sender)).ok,false);assert.equal(h.local.data.currentTask.claim,null);
  h.local.set=save;const claim=await h.send({...r.base,type:'ASSIST_CLAIM',stepIndex:0,evidence:r.evidence()},r.sender);
  const denied=await h.send({...r.base,type:'ASSIST_CHECK',stepIndex:0,claimToken:claim.claimToken,evidence:r.evidence({itemPriceMinor:99999999})},r.sender);
  assert.equal(denied.ok,false);assert.equal(h.local.data.currentTask.state,'UNKNOWN');
 });
 await t.test('assist skip requires actual selected radio evidence and cannot skip arbitrary buttons',async()=>{
  const h=await harness(),r=await assistSetup(h);
  assert.equal((await h.send({...r.base,type:'ASSIST_SKIP',stepIndex:0,evidence:r.evidence()},r.sender)).ok,false);
  const skipped=await h.send({...r.base,type:'ASSIST_SKIP',stepIndex:0,evidence:r.evidence({color:r.config.color})},r.sender);assert.equal(skipped.stepIndex,1);
  const done=await h.send({...r.base,type:'ASSIST_SKIP',stepIndex:1,evidence:r.evidence({color:r.config.color,storage:r.config.storage})},r.sender);assert.equal(done.state,'DONE');assert.equal(h.local.data.currentTask.claim,null);
  assert.equal(h.local.data.currentTask.claims.every(x=>x.status==='skipped'),true);
 });
 await t.test('assist task cannot be controlled by a foreign tab or unconfigured step',async()=>{
  const h=await harness(),r=await assistSetup(h);
  assert.equal((await h.send({...r.base,type:'ASSIST_CLAIM',stepIndex:0,evidence:r.evidence()},{...r.sender,tab:{id:999}})).ok,false);
  assert.equal((await h.send({...r.base,type:'ASSIST_CLAIM',stepIndex:9,evidence:r.evidence()},r.sender)).ok,false);
  assert.equal(h.local.data.currentTask.claim,null);
 });

});

async function assistSetup(h){
 const config={...h.config,mode:'assist',confirmedAssist:true,color:'夜空色',storage:'1TB',maxTotal:30000,targetTime:new Date().toISOString(),expiresAt:new Date(Date.now()+300000).toISOString()};
 const start=await h.send({type:'START',config,tabId:2});assert.equal(start.ok,true);
 const sender={id:h.chrome.runtime.id,url:config.url,tab:{id:2}},base={taskId:start.task.id};
 const evidence=(extra={})=>({observedAt:Date.now(),url:config.url,model:config.model,color:null,storage:null,quantity:null,itemPriceMinor:2149900,itemCurrency:'CNY',...extra});
 return{config,task:start.task,sender,base,evidence};
}
