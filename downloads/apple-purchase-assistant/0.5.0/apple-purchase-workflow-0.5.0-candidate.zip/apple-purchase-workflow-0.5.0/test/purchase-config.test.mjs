import {test} from 'node:test';
import assert from 'node:assert/strict';
import {validatePurchase,validatePurchaseAddress,purchaseEvidenceFault,purchaseLocationMatches,purchaseURL,safePurchaseURL,positiveNoCharge,ADDRESS_AUTOCOMPLETE,createDuoSteps} from '../extension/purchase-config.js';
import {config,evidence,address,path,url} from './purchase-fixture.mjs';
const validated=()=>validatePurchase(config());
test('purchase configuration is canonical public data and requires explicit consent',()=>{
 const raw=config({addressMode:'existing',unrecognizedSecret:'not retained'}),c=validatePurchase(raw);assert.equal(c.unrecognizedSecret,undefined);assert.equal(c.address,undefined);assert.equal(c.steps.length,4);assert.throws(()=>validatePurchase({...raw,confirmedPurchase:false}));assert.throws(()=>validatePurchase({...raw,address}));
 assert.deepEqual(validatePurchase({...raw,purchasePlan:JSON.stringify(raw.steps)}).steps,c.steps);
});
test('exact configured paths and origins reject broad routes, credentials, fragments and query expansion',()=>{
 for(const wrong of ['https://evil.test/shop/test','https://www.apple.com.cn.evil.test/shop/test','https://secure7.www.apple.com.cn/shop/test',`${url}?token=secret`,`${url}#part`,'https://user@www.apple.com.cn/shop/test'])assert.throws(()=>validatePurchase(config({url:wrong})),wrong);
 for(const wrong of ['/shop/../account','/shop/%2fadmin','/shop//x','https://www.apple.com.cn/shop']){const c=config();c.steps[0].path=wrong;assert.throws(()=>validatePurchase(c),wrong);}
 const location={origin:'https://www.apple.com.cn',path,query:{product:'mjt74ch/a',step:'attach'}};
 assert.equal(purchaseLocationMatches(`${url}?product=mjt74ch/a&step=attach`,location),true);
 assert.equal(purchaseLocationMatches(`${url}?product=mjt74ch/a&step=attach&extra=1`,location),false);
 assert.equal(purchaseLocationMatches(`${url}?product=other12/a&step=attach`,location),false);
 const secure='https://secure6.www.apple.com.cn/shop/checkout?session=PRIVATE';assert.equal(purchaseURL(secure),true);assert.equal(safePurchaseURL(secure),'https://secure6.www.apple.com.cn/shop/checkout');assert.equal(purchaseLocationMatches(secure,{origin:'https://secure6.www.apple.com.cn',path:'/shop/checkout'}),true);
});
test('plan order, postconditions and final unpaid semantics fail closed',()=>{
 const mutate=fn=>{const c=config();fn(c);assert.throws(()=>validatePurchase(c));};
 mutate(c=>c.steps.splice(1,1));mutate(c=>c.steps[3].target.name='立即支付');mutate(c=>c.steps[3].confirm.text='订单已创建');mutate(c=>c.steps[3].noChargeText='暂未付款，稍后自动扣款');mutate(c=>c.steps[3].noChargeText='不会立即扣款，将自动支付');mutate(c=>c.steps[3].noChargeText='Order unpaid; payment will be charged later');mutate(c=>c.steps[2].totalIncludesTaxShipping.text='总价不含运费和税费');mutate(c=>c.steps[0].confirm.selector='#add');mutate(c=>c.steps[2].evidence.itemCount=undefined);mutate(c=>c.steps[3].confirm.allowAuthHandoff=true);
 assert.equal(positiveNoCharge('提交订单不会扣款，创建后自行付款'),true);assert.equal(positiveNoCharge('未付款并授权支付'),false);
});
test('new addresses require complete semantic fields and matching confirmation coverage',()=>{
 const c=config({addressMode:'new'}),ks=Object.keys(address);c.steps[1].fields=ks.map(key=>({key,selector:`#${key}`,name:key,autocomplete:ADDRESS_AUTOCOMPLETE[key]}));for(const s of c.steps)if(s.addressConfirmation)s.addressConfirmation.keys=ks;
 const canonical=validatePurchase(c);assert.deepEqual(validatePurchaseAddress(address,canonical),address);
 for(const value of [{...address,phone:'invalid'},{...address,postalCode:'123'}, {...address,password:'secret'}])assert.throws(()=>validatePurchaseAddress(value,canonical));
 const bad=structuredClone(c);bad.steps[3].addressConfirmation.keys=['fullName'];assert.throws(()=>validatePurchase(bad));
 const badFields=structuredClone(c);badFields.steps[1].fields=badFields.steps[1].fields.filter(x=>x.key!=='addressLine1');assert.throws(()=>validatePurchase(badFields));
});
test('each evidence gate requires exact complete facts, no extras and no payment commitment',()=>{
 const c=validated();assert.equal(purchaseEvidenceFault(c,0,evidence(c)),null);
 for(const extra of [{quantity:2},{itemCount:2},{model:'other'},{itemPriceMinor:100000},{ambiguity:['duplicate']},{observedAt:Date.now()-6000},{url:`${url}/other`},{paymentCommit:true},{blocker:'credential required'}])assert.ok(purchaseEvidenceFault(c,0,evidence(c,extra)));
 for(const extra of [{totalIncludesTaxShipping:false},{totalMinor:null},{totalMinor:30000},{noChargeText:'not verified'},{paymentCommit:undefined}])assert.ok(purchaseEvidenceFault(c,3,evidence(c,extra)));
});

test('native semantic address mapping may omit selectors and labels while keeping complete allowlisted fields',()=>{
 const c=config({addressMode:'new'}),ks=Object.keys(address);c.steps[1].fields=ks.map(key=>({key,autocomplete:ADDRESS_AUTOCOMPLETE[key]}));for(const step of c.steps)if(step.addressConfirmation)step.addressConfirmation.keys=ks;const checked=validatePurchase(c);assert.equal(checked.steps[1].fields[0].selector,undefined);assert.equal(checked.steps[1].fields[0].name,undefined);assert.deepEqual(validatePurchaseAddress(address,checked),address);
 c.steps[1].fields[0].autocomplete='password';assert.throws(()=>validatePurchase(c));
});
test('configure stages require exact desired radio names and prior application evidence mappings',()=>{
 const c=config(),radio={stage:'configure',kind:'radio',group:'dimensionColor',path,target:{role:'radio',name:c.color},evidence:{model:'#model',color:'#color'},confirm:{selector:'#color-applied',text:'颜色已应用'}};c.steps.unshift(radio);assert.equal(validatePurchase(c).steps[0].group,'dimensionColor');
 const second={...radio,group:'dimensionCapacity',target:{role:'radio',name:c.storage},evidence:{model:'#model',storage:'#storage'},confirm:{selector:'#capacity-applied',text:'容量已应用'}};c.steps.splice(1,0,second);assert.throws(()=>validatePurchase(c));second.evidence.color='#color';assert.equal(validatePurchase(c).steps.length,6);second.target.name='wrong';assert.throws(()=>validatePurchase(c));
});

test('final tax and shipping completeness rejects negated and prospective inclusion',()=>{
 for(const text of ['不包含税费和运费','尚未包含税费和运费','Tax and shipping not yet included','Total excludes tax and shipping','Tax and shipping will be included later','税费和配送费额外计入总价']){const c=config();c.steps[2].totalIncludesTaxShipping.text=text;assert.throws(()=>validatePurchase(c),text);}
});
test('known Duo configure helper uses only the recorded adapter and independent Apple-selection confirmation',()=>{
 const c=config({url:'https://www.apple.com.cn/shop/buy-iphone/iphone-duo/mk2u4ch/a',model:'iPhone Duo',color:'夜空色',storage:'1TB'});for(const step of c.steps)step.path=new URL(c.url).pathname;c.steps.unshift(...createDuoSteps(c));const canonical=validatePurchase(c);assert.equal(canonical.steps[0].adapter,'apple-duo');assert.deepEqual(canonical.steps[0].confirm,{kind:'apple-selection'});assert.equal(canonical.steps[1].group,'dimensionCapacity');
 assert.throws(()=>createDuoSteps({...c,url:'https://www.apple.com.cn/shop/buy-iphone/iphone-18-pro/mjt74ch/a'}));const bad=structuredClone(c);bad.steps[0].adapter='anything';assert.throws(()=>validatePurchase(bad));
});
