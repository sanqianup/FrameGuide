// Narrow, read-only evidence adapter for the observed Apple China configuration page.
// No element handles, control values, action targets, or inferred checkout state escape it.
(() => {
  'use strict';
  if (globalThis.AppleDuoReadonly) return;

  const normalize = text => String(text ?? '').normalize('NFKC').replace(/\s+/gu, ' ').trim();
  const missingFields = ['model', 'color', 'storage', 'continue', 'summary', 'itemPriceMinor', 'itemCurrency',
    'releaseNotice', 'countdown', 'region', 'quantity', 'currency', 'delivery', 'totalMinor', 'orderState', 'submissionTarget'];
  // Exact evidence allowlist, not a guessed format for future SKUs.
  // mk2n4ch/a: observed live DOM. mk2u4ch/a: user-provided URL with public
  // title/product-price text verified only; no checked/enabled DOM state inferred.
  const observedPaths = new Set(['/shop/buy-iphone/iphone-duo', '/shop/buy-iphone/iphone-duo/mk2n4ch/a', '/shop/buy-iphone/iphone-duo/mk2u4ch/a']);
  const docOf = root => root?.nodeType === 9 ? root : root?.ownerDocument;

  function supportedURL(url) {
    try {
      const parsed = new URL(url);
      return parsed.protocol === 'https:' && parsed.hostname === 'www.apple.com.cn' &&
        !parsed.username && !parsed.password && !parsed.port &&
        observedPaths.has(parsed.pathname);
    } catch { return false; }
  }

  function emptyResult(supported) {
    return {
      supported, pageKind: supported ? 'product-configuration' : null,
      model: null, color: null, storage: null, options: { color: [], storage: [] },
      continue: { status: 'missing', name: null, enabled: null },
      summary: null, itemPriceMinor: null, itemCurrency: null, releaseNotice: null,
      // This adapter has no verified countdown reader. Null is not a claim that a
      // countdown can never appear, nor permission to synthesize one from prose.
      countdown: null, countdownObserved: false,
      evidenceMissing: supported ? [...missingFields] : [], ambiguity: []
    };
  }

  function productPrice(text) {
    // Only the explicitly displayed RMB amount is parsed, with strict grouping.
    // A product's price is never an order total or a claim about all fees.
    const match = /^RMB\s*((?:[1-9]\d{0,2}(?:,\d{3})+|0|[1-9]\d*))(?:\.(\d{1,2}))?$/u.exec(normalize(text));
    if (!match) return null;
    const minor = Number(match[1].replace(/,/gu, '')) * 100 + Number((match[2] ?? '').padEnd(2, '0'));
    return Number.isSafeInteger(minor) && minor >= 0 ? minor : null;
  }

  function query(root, selector) {
    const elements = [...root.querySelectorAll(selector)];
    if (root.matches?.(selector)) elements.unshift(root);
    return [...new Set(elements)];
  }

  // A visually styled native radio may have a visible associated label. Never
  // use that alternative to revive a hidden or disconnected ancestor tree.
  function hiddenTree(element) {
    if (element.isConnected === false) return true;
    const view = element.ownerDocument?.defaultView;
    for (let current = element; current; current = current.parentElement) {
      if (current.hidden || current.hasAttribute?.('hidden') || current.getAttribute?.('aria-hidden') === 'true') return true;
      const style = view?.getComputedStyle?.(current);
      if (style && (style.display === 'none' || style.visibility === 'hidden' ||
        style.visibility === 'collapse' || style.contentVisibility === 'hidden' ||
        (current !== element && style.opacity === '0'))) return true;
    }
    return false;
  }

  function radioLabel(radio, labels, identified) {
    const id = radio.getAttribute('id');
    const associated = labels.filter(label => (id && label.getAttribute('for') === id) || label.contains?.(radio));
    const labelledBy = normalize(radio.getAttribute('aria-labelledby'));
    if (labelledBy) {
      const references = labelledBy.split(' ');
      const resolved = references.map(reference => identified.filter(element => element.getAttribute('id') === reference));
      if (new Set(references).size !== references.length || resolved.some(matches => matches.length > 1)) {
        return { name: null, labels: associated, fault: 'ambiguous-label-reference' };
      }
      if (resolved.some(matches => matches.length !== 1)) return { name: null, labels: associated, fault: 'missing-label-reference' };
      const elements = resolved.map(matches => matches[0]);
      const name = normalize(elements.map(element => element.textContent ?? '').join(' '));
      return { name: name || null, labels: [...associated, ...elements], fault: name ? null : 'missing-label' };
    }
    const ariaLabel = radio.getAttribute('aria-label');
    if (ariaLabel !== null) {
      const name = normalize(ariaLabel);
      return { name: name || null, labels: associated, fault: name ? null : 'missing-label' };
    }
    // More than one associated label is outside the observed page's contract.
    // Preserve uncertainty instead of choosing whichever happens to come first.
    if (associated.length > 1) return { name: null, labels: associated, fault: 'multiple-associated-labels' };
    const name = associated.length === 1 ? normalize(associated[0].textContent) : '';
    return { name: name || null, labels: associated, fault: name ? null : 'missing-label' };
  }

  function inspect(root, { url, driver = globalThis.AppleDOMDriver } = {}) {
    const result = emptyResult(supportedURL(url));
    // Unmatched URLs must not cause even a speculative document read.
    if (!result.supported) return result;
    const missing = new Set(result.evidenceMissing);
    if (!root?.querySelectorAll || !docOf(root)?.querySelectorAll ||
      !['isVisible', 'isEnabled', 'getName'].every(key => typeof driver?.[key] === 'function')) {
      missing.add('dom-reader');
      result.evidenceMissing = [...missing];
      return result;
    }
    try {
      const doc = docOf(root);
      const headings = query(root, 'h1').filter(element => driver.isVisible(element));
      if (headings.length > 1) result.ambiguity.push('model:multiple-headings');
      else if (headings.length === 1 && normalize(headings[0].textContent) === 'iPhone Duo') {
        result.model = 'iPhone Duo';
        missing.delete('model');
      }

      // Query fixed semantic selectors only. IDs are read solely to resolve a
      // current label relationship, never used as hardcoded identity selectors.
      const labels = query(doc, 'label');
      const identified = query(doc, '[id]');
      const radios = query(root, 'input[type="radio"]');
      for (const [key, groupName] of [['color', 'dimensionColor'], ['storage', 'dimensionCapacity']]) {
        const group = [];
        let uncertainLabel = false;
        for (const radio of radios) {
          if (radio.getAttribute('name') !== groupName || hiddenTree(radio)) continue;
          const label = radioLabel(radio, labels, identified);
          if (!driver.isVisible(radio) && !label.labels.some(element => driver.isVisible(element))) continue;
          if (label.fault) {
            uncertainLabel = true;
            missing.add(`${key}-option-label`);
            if (label.fault.startsWith('ambiguous-') || label.fault === 'multiple-associated-labels') {
              result.ambiguity.push(`${key}:${label.fault}`);
            }
          }
          group.push({ name: label.name, selected: radio.checked === true, enabled: driver.isEnabled(radio) === true });
        }
        result.options[key] = group;
        if (!group.length) missing.add(`${key}-options`);
        const names = group.map(option => option.name).filter(name => name !== null);
        const duplicateNames = new Set(names).size !== names.length;
        if (duplicateNames) result.ambiguity.push(`${key}:duplicate-option-labels`);
        const selected = group.filter(option => option.selected);
        if (selected.length > 1) result.ambiguity.push(`${key}:multiple-checked-options`);
        if (selected.length === 1 && selected[0].name && !uncertainLabel && !duplicateNames) {
          result[key] = selected[0].name;
          missing.delete(key);
        }
      }

      // Continue is only stage evidence, even when enabled. Never return the
      // element, a selector, a callback, or any purported order-submit target.
      const continues = query(root, 'button').filter(element => driver.isVisible(element) && driver.getName(element) === '继续');
      if (continues.length > 1) {
        result.continue = { status: 'ambiguous', name: '继续', enabled: null };
        result.ambiguity.push('continue:multiple-buttons');
      } else if (continues.length === 1) {
        const enabled = driver.isEnabled(continues[0]) === true;
        result.continue = { status: enabled ? 'enabled' : 'disabled', name: '继续', enabled };
        missing.delete('continue');
      }

      const summaries = query(root, '[data-autom="summary-productName"]').filter(element => driver.isVisible(element));
      if (summaries.length > 1) result.ambiguity.push('summary:multiple-elements');
      else if (summaries.length === 1) {
        const text = normalize(summaries[0].textContent);
        if (/^iPhone Duo(?:\s|$)/u.test(text)) {
          result.summary = text;
          missing.delete('summary');
        }
      }
      const prices = query(root, '[data-autom="full-price"]').filter(element => driver.isVisible(element));
      if (prices.length > 1) result.ambiguity.push('itemPrice:multiple-elements');
      else if (prices.length === 1) {
        const minor = productPrice(prices[0].textContent);
        if (minor !== null) {
          result.itemPriceMinor = minor;
          result.itemCurrency = 'CNY';
          missing.delete('itemPriceMinor');
          missing.delete('itemCurrency');
        }
      }
      // No stable notice selector was observed. Recognize only this exact
      // visible text on a leaf, without reading form values or guessing a cause
      // for disabled controls. A changed/split message remains unknown.
      const releaseNotice = query(root, '*').some(element => {
        if (element.children?.length || !driver.isVisible(element)) return false;
        for (let current = element; current; current = current.parentElement) {
          if (/^(?:INPUT|TEXTAREA|SELECT|OPTION|SCRIPT|STYLE)$/u.test(current.tagName ?? '') ||
            current.hasAttribute?.('contenteditable') || current.getAttribute?.('role') === 'textbox') return false;
        }
        return normalize(element.textContent) === '暂未发售';
      });
      if (releaseNotice) {
        result.releaseNotice = '暂未发售';
        missing.delete('releaseNotice');
      }
      result.ambiguity = [...new Set(result.ambiguity)];
      result.evidenceMissing = [...missing];
      return result;
    } catch {
      // A partial failed inspection is not a trustworthy selection snapshot.
      const failed = emptyResult(true);
      failed.evidenceMissing.push('dom-inspection');
      return failed;
    }
  }

  globalThis.AppleDuoReadonly = Object.freeze({ inspect, supportsURL: supportedURL });
})();
