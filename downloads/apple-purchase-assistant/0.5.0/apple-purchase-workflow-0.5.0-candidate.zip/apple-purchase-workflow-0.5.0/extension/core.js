// Browser-compatible copy of the original pure state-machine rules. No Node dependency.
export const DEFAULTS = Object.freeze({
  mode:'simulate', url:'https://www.apple.com.cn/shop/buy-iphone/iphone-duo',
  region:'CN', regionConfirmed:true, model:'iPhone Duo', storage:'', color:'', quantity:1,
  currency:'CNY', maxTotal:'', delivery:'国内配送',
  targetTime:'2026-10-16T20:00:00+08:00', timeZone:'Asia/Shanghai',
  expiresAt:'2026-10-16T20:10:00+08:00', pollMs:1000,
  countdownSeconds:5, scenario:'normal',
  selectors:{countdown:'',model:'',storage:'',color:'',quantity:'',total:'',currency:'',region:'',delivery:'',button:''}
});
export const TERMINAL=new Set(['PAUSED','STOPPED','DONE','UNKNOWN']);
export function appleUrl(value){
  try{const u=new URL(value);return u.protocol==='https:'&&!u.username&&!u.password&&!u.port&&!u.hash&&
    ['www.apple.com.cn','www.apple.com'].includes(u.hostname)&&/^\/(?:[a-z]{2}(?:-[a-z]{2})?\/)?shop(?:\/|$)/i.test(u.pathname);}catch{return false;}
}
export function validate(raw,now=Date.now()){
  const c={...DEFAULTS,...raw,selectors:{...DEFAULTS.selectors,...raw.selectors}};
  if(!['simulate','official-readonly'].includes(c.mode))throw Error('真实点击和提交尚未开放');
  if(!appleUrl(c.url))throw Error('仅允许 www.apple.com.cn 或 www.apple.com 的 HTTPS 商店链接');
  for(const key of ['region','model','storage','color','delivery'])if(typeof c[key]!=='string'||!c[key].trim()||c[key].length>160)throw Error(`请填写 ${key}`);
  if(!Number.isInteger(c.quantity)||c.quantity<1||c.quantity>10)throw Error('数量须为 1 至 10 的整数，不代表官网限购政策');
  const max=Number(c.maxTotal);
  if(!Number.isFinite(max)||max<=0||max>100000000||Math.abs(max*100-Math.round(max*100))>0.00001)throw Error('请设置含全部费用的最高总价，最多两位小数');
  if(!/^[A-Z]{3}$/.test(c.currency))throw Error('货币须为三位大写代码');
  for(const key of ['targetTime','expiresAt'])if(typeof c[key]!=='string'||!/(Z|[+-]\d{2}:\d{2})$/.test(c[key])||!Number.isFinite(Date.parse(c[key])))throw Error('时间须包含 UTC 偏移量，例如 +08:00');
  if(Date.parse(c.expiresAt)<=Date.parse(c.targetTime))throw Error('过期时间必须晚于开售时间');
  try{new Intl.DateTimeFormat('zh-CN',{timeZone:c.timeZone}).format(now);}catch{throw Error('IANA 时区无效');}
  if(c.mode==='official-readonly'&&(!c.regionConfirmed||Date.parse(c.targetTime)<=now||Date.parse(c.expiresAt)<=now))throw Error('地区未确认或正式开售时间已过期，请重新核对');
  if(!Number.isInteger(c.pollMs)||c.pollMs<1000||c.pollMs>60000)throw Error('检测间隔须为 1000 至 60000 毫秒');
  if(!Number.isInteger(c.countdownSeconds)||c.countdownSeconds<1||c.countdownSeconds>120)throw Error('模拟倒计时须为 1 至 120 秒');
  if(!['normal','reset','soldout','price','unknown','payment','mismatch','blocked'].includes(c.scenario))throw Error('模拟场景无效');
  if(Object.values(c.selectors).some(x=>typeof x!=='string'||x.length>300))throw Error('选择器无效或过长');
  return c;
}
export function parseCountdown(value){
  if(typeof value!=='string')return null;
  const s=value.trim();let m=/^(?:(\d{1,3}):)?([0-5]?\d):([0-5]\d)$/.exec(s);
  if(m)return (Number(m[1]||0)*3600+Number(m[2])*60+Number(m[3]))*1000;
  m=/^(?:(\d+)\s*天\s*)?(?:(\d+)\s*小时\s*)?(?:(\d+)\s*分(?:钟)?\s*)?(\d+)\s*秒$/.exec(s);
  return m?(Number(m[1]||0)*86400+Number(m[2]||0)*3600+Number(m[3]||0)*60+Number(m[4]))*1000:null;
}
export class Engine{
  constructor(config){this.config=config;this.state='READY';this.reason='准备就绪';this.remainingMs=null;this.source=null;this.lastRemaining=null;this.claimed=false;}
  pause(reason){if(['STOPPED','DONE','UNKNOWN'].includes(this.state))return{type:'none'};this.state='PAUSED';this.reason=reason;return{type:'none',reason};}
  stop(){this.state='STOPPED';this.reason='用户已停止，不会自动恢复';}
  observe(s,now=Date.now()){
    if(TERMINAL.has(this.state)||this.state==='SUBMITTING')return{type:'none'};
    const c=this.config;
    if(now>Date.parse(c.expiresAt))return this.pause('任务已过期');
    if(!s||!Number.isFinite(s.observedAt)||now-s.observedAt>5000||s.observedAt>now+1000)return this.pause('页面证据或电脑时钟异常');
    if(s.blocker)return this.pause(s.blocker);
    if(s.soldOut)return this.pause('商品售罄，请人工处理');
    for(const key of ['region','model','storage','color','quantity','currency','delivery'])if(String(s[key]??'')!==String(c[key]))return this.pause(`页面 ${key} 缺失或与配置不符`);
    if(!Number.isSafeInteger(s.totalMinor)||s.totalMinor<0)return this.pause('无法验证含税费及配送费的完整总价');
    if(s.totalMinor>Math.round(Number(c.maxTotal)*100))return this.pause('总价超过上限');
    if(this.lastPrice!==undefined&&this.lastPrice!==s.totalMinor)return this.pause('总价变化，需人工复核');
    this.lastPrice=s.totalMinor;
    let remaining;
    if(s.countdownPresent){remaining=parseCountdown(s.countdownText);this.source='页面可见倒计时';if(remaining===null)return this.pause('页面倒计时未知或不唯一');if(this.lastRemaining!==null&&remaining>this.lastRemaining+1500)return this.pause('倒计时重置或延长');}
    else{remaining=Math.max(0,Date.parse(c.targetTime)-now);this.source='本地计算，依赖电脑时钟';}
    this.lastRemaining=remaining;this.remainingMs=remaining;
    if(remaining>0){this.state='WAITING';this.reason='等待倒计时结束';return{type:'none'};}
    if(!s.buttonUnique)return this.pause('购买按钮缺失或不唯一');
    if(!s.buttonEnabled){this.state='WAITING';this.reason='已到点，等待按钮可用';return{type:'none'};}
    if(c.mode!=='simulate'){this.state='DONE';this.reason='预演条件满足，已停在动作前；真实点击和提交锁定';return{type:'preview'};}
    if(this.claimed)return this.pause('重复模拟提交已阻止');
    this.claimed=true;this.state='SUBMITTING';this.reason='仅本地模拟，记录一次提交';return{type:'mock-submit'};
  }
  result(outcome){if(this.state!=='SUBMITTING')return;this.state=outcome==='confirmed'?'DONE':'UNKNOWN';this.reason=outcome==='confirmed'?'模拟成功，没有真实订单':'模拟提交结果未知，已锁定且不重试';}
}
export function continuationFault(record,now=Date.now()){
  if(!record||TERMINAL.has(record.state))return null;
  if(record.state==='SUBMITTING'){
    const deadline=record.mode==='assist'&&Number.isFinite(record.claim?.deadline)?Math.min(record.claim.deadline,record.claim.time+35000):(record.claim?.time??0)+10000;
    if(!record.claim||now>deadline)return record.mode==='assist'?'点击结果未知，不会恢复或重试':'提交结果未知，不会恢复或重试';
  }
  if(now>record.expiresAt)return '任务已过期';
  if(!Number.isFinite(record.lastSeen)||now-record.lastSeen>70000||record.lastSeen>now+1000)return '后台或页面心跳中断，需要人工重新预检';
  return null;
}
