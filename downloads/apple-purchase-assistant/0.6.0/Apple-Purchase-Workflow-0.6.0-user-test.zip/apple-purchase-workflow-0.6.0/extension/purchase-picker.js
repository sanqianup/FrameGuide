// Isolated-world, user-started locator picker. It never activates merchant controls.
// The background must bind each request to the user, tab, frame and pending mapping.
(() => {
  'use strict';
  if (globalThis.__applePurchasePicker) return;
  const runtime = globalThis.chrome?.runtime;
  if (!runtime?.id || !runtime.onMessage?.addListener) return;
  const normalize = value => String(value ?? '').normalize('NFKC').replace(/\s+/gu, ' ').trim();
  const fields = Object.freeze({ fullName: 'name', givenName: 'given-name', familyName: 'family-name', phone: 'tel', email: 'email', addressLine1: 'address-line1', addressLine2: 'address-line2', province: 'address-level1', city: 'address-level2', district: 'address-level3', postalCode: 'postal-code' });
  const aliases = Object.freeze({ fullName: ['姓名', '收货人', '收件人', 'Full name', 'Name'], givenName: ['名', '名字', 'Given name', 'First name'], familyName: ['姓', '姓氏', 'Family name', 'Last name'], phone: ['手机', '手机号', '手机号码', '联系电话', 'Phone', 'Phone number', 'Mobile'], email: ['电子邮件', '电子邮箱', 'Email', 'Email address'], addressLine1: ['街道地址', '详细地址', '地址', 'Address line 1', 'Street address'], addressLine2: ['地址第二行', '地址补充', 'Address line 2'], province: ['省', '省份', 'Province', 'State'], city: ['市', '城市', 'City'], district: ['区', '区县', 'District'], postalCode: ['邮政编码', '邮编', 'Postal code', 'ZIP code'] });
  const forbidden = /password|passwd|(?:^|[\W_])(?:pwd|otp|pin|cvv|cvc|ssn|pan)(?:$|[\W_])|otp|cvv|cvc|ssn|pin.?code|one.?time|verification|captcha|credit.?card|card.?number|cc-(?:name|given-name|family-name|type|number|csc|exp)|national.?id|identity|id.?number|passport|social.?security|tax.?id|credential|auth.?token|session|csrf|nonce|secret|access.?token|api.?key|密码|验证码|身份证|护照|银行卡|信用卡/iu;
  const privateContext = /(?:address|recipient|contact|email|phone|full.?name|first.?name|last.?name|postal|zip.?code|billing|收货|收件|地址|姓名|手机|电话|邮编|邮箱)/iu;
  const unsafeCharacters = /[\\"'<>\u0000-\u001f\u007f-\u009f\u200b-\u200f\u202a-\u202e\u2060-\u206f]/u;
  const privateValue = /@|https?:|\b\d{7,}\b|\+\d[\d -]{7,}|\b[0-9a-f]{16,}\b|\b[0-9a-f]{8}-[0-9a-f-]{20,}\b|(?:省|市|县|区).{1,30}(?:路|街|巷|号|弄|栋|室)|\b\d+\s+.{1,35}\b(?:street|avenue|road|lane|drive|apt)\b/iu;
  const unsafeAction = value => globalThis.PurchasePolicy?.unsafeAction?.(value) ?? /password|sign\s*in|log\s*in|\bpay(?:ment)?\b|\bcharge\b|accept.{0,15}terms|登录|登陆|支付|扣款|付款|验证码|同意.{0,15}(?:条款|协议)/iu.test(value.replace(/unpaid|未付款|待付款|不扣款|不会扣款/giu, ''));
  const nonText = /^(?:INPUT|TEXTAREA|SELECT|OPTION|SCRIPT|STYLE|NOSCRIPT|IFRAME|OBJECT|EMBED)$/u;
  const listeners = [];
  const finished = new Set();
  let active = null;
  const attribute = (node, name) => node?.getAttribute?.(name) ?? '';
  const tag = node => String(node?.tagName ?? '').toLowerCase();
  function metadata(node) { return ['id', 'name', 'type', 'autocomplete', 'data-autom', 'role', 'aria-label'].map(key => attribute(node, key)).join(' ').replace(/([A-Z]+)([A-Z][a-z])/gu, '$1 $2').replace(/([a-z])([A-Z])/gu, '$1 $2'); }
  function safeLocation() {
    const url = new URL(location.href);
    if (globalThis.top !== globalThis.self || !['https://www.apple.com.cn', 'https://secure6.www.apple.com.cn'].includes(url.origin) || url.username || url.password || url.port || url.hash || !/^\/shop(?:\/|$)[a-z0-9/_-]*$/iu.test(url.pathname) || url.pathname.length > 200 || url.pathname.includes('//') || forbidden.test(url.pathname) || /\/(?:login|sign[-_]?in|log[-_]?in|auth|account)(?:\/|$)/iu.test(url.pathname) || privateValue.test(url.pathname)) throw Error('unsupported-page');
    return { origin: url.origin, path: url.pathname };
  }
  function visible(node) {
    if (!node?.isConnected || !node.getClientRects?.().length) return false;
    for (let item = node; item; item = item.parentElement) {
      const css = globalThis.getComputedStyle?.(item);
      if (item.hidden || attribute(item, 'aria-hidden') === 'true' || css && (css.display === 'none' || css.visibility === 'hidden' || css.opacity === '0')) return false;
    }
    return true;
  }
  function stableToken(raw) {
    return typeof raw === 'string' && /^[a-z][a-z0-9_-]{0,79}$/iu.test(raw) && !forbidden.test(raw) && !privateValue.test(raw) && !/\d{5,}|(?:^|[-_])[0-9a-f]{10,}(?:$|[-_])|^[a-z0-9]{24,}$/iu.test(raw);
  }
  function safeLabel(raw) {
    const value = normalize(raw);
    return value.length > 0 && value.length <= 100 && !unsafeCharacters.test(value) && !forbidden.test(value) && !privateValue.test(value) ? value : '';
  }
  function readableLabel(node) {
    if (!node || !visible(node)) return '';
    for (let item = node; item; item = item.parentElement) if (nonText.test(item.tagName) || item.hasAttribute?.('contenteditable') || attribute(item, 'role') === 'textbox') return '';
    for (const child of node.querySelectorAll('*')) if (nonText.test(child.tagName) || child.hasAttribute?.('contenteditable') || attribute(child, 'role') === 'textbox') return '';
    // Only action/approved field labels reach this reader; never public evidence.
    return safeLabel(node.textContent);
  }
  function semanticName(node) {
    const labelled = normalize(attribute(node, 'aria-labelledby'));
    if (labelled) {
      const ids = labelled.split(' ');
      if (new Set(ids).size !== ids.length || ids.some(id => !stableToken(id))) throw Error('unsafe-label');
      const names = ids.map(id => {
        const matches = [...document.querySelectorAll('[id]')].filter(item => attribute(item, 'id') === id);
        if (matches.length !== 1) throw Error('ambiguous-label');
        return readableLabel(matches[0]);
      });
      if (names.some(name => !name)) throw Error('unsafe-label');
      return safeLabel(names.join(' '));
    }
    const aria = attribute(node, 'aria-label');
    if (aria) return safeLabel(aria);
    if (['input', 'textarea', 'select'].includes(tag(node))) {
      const id = attribute(node, 'id');
      const labels = [...document.querySelectorAll('label')].filter(label => id && attribute(label, 'for') === id || label.contains(node));
      return labels.length === 1 ? readableLabel(labels[0]) : '';
    }
    return readableLabel(node);
  }
  function approvedFieldName(name, key) { return [...aliases[key], key, fields[key]].some(item => normalize(item).toLowerCase() === name.toLowerCase()); }
  function checkNode(node, request) {
    if (!visible(node) || active?.host.contains(node) || ['html', 'body', 'iframe', 'script', 'style', 'object', 'embed'].includes(tag(node))) throw Error('choose-specific-visible-element');
    for (let item = node; item && !['html', 'body'].includes(tag(item)); item = item.parentElement) {
      if (forbidden.test(metadata(item)) || item.hasAttribute?.('contenteditable') || ['iframe', 'object', 'embed'].includes(tag(item))) throw Error('sensitive-element');
    }
    if (request.kind === 'public-evidence') {
      if (nonText.test(node.tagName) || attribute(node, 'role') === 'textbox' || [...node.querySelectorAll('*')].some(item => nonText.test(item.tagName) || item.hasAttribute?.('contenteditable') || forbidden.test(metadata(item)))) throw Error('unsafe-public-evidence');
      return { role: 'evidence', name: '' };
    }
    const type = attribute(node, 'type').toLowerCase();
    if (request.kind === 'address-field') {
      if (!['input', 'textarea', 'select'].includes(tag(node)) || tag(node) === 'input' && !['', 'text', 'tel', 'email'].includes(type)) throw Error('not-address-field');
      const autocomplete = normalize(attribute(node, 'autocomplete')).toLowerCase();
      const tokens = autocomplete.split(' ').filter(Boolean);
      const standard = tokens.at(-1) === fields[request.fieldKey] && tokens.slice(0, -1).every(token => token === 'shipping' || /^section-[a-z0-9_-]+$/u.test(token));
      const found = semanticName(node), name = found && approvedFieldName(found, request.fieldKey) ? found : '';
      const nativeName = attribute(node, 'name');
      if (!standard && (autocomplete && !['off', 'on'].includes(autocomplete) || !name && !approvedFieldName(nativeName, request.fieldKey))) throw Error('address-field-semantics-mismatch');
      return { role: tag(node) === 'select' ? 'combobox' : 'textbox', name, autocomplete: fields[request.fieldKey] };
    }
    let role = '';
    if (tag(node) === 'input' && type === 'radio') role = 'radio';
    else if (tag(node) === 'button' && !['reset'].includes(type) || tag(node) === 'a' && node.hasAttribute('href') || attribute(node, 'role') === 'button' && !nonText.test(node.tagName) || tag(node) === 'input' && ['button', 'submit'].includes(type)) role = 'button';
    if (!role || attribute(node, 'role') && attribute(node, 'role') !== role) throw Error('not-supported-action');
    const name = semanticName(node);
    if (!name || unsafeAction(name) || unsafeAction(metadata(node)) || privateContext.test(name) && !/^(?:continue|review|edit|save|确认|保存|继续|编辑|核对).{0,15}(?:address|delivery|地址|配送)$/iu.test(name)) throw Error('unsafe-action-name');
    return { role, name };
  }
  function parts(node, request, info, anchor = false) {
    const name = tag(node), out = [];
    if (!/^[a-z][a-z0-9-]*$/u.test(name) || ['html', 'body'].includes(name)) return out;
    const id = attribute(node, 'id');
    if (stableToken(id)) out.push('#' + id);
    for (const key of ['data-autom', 'name']) { const value = attribute(node, key); if (stableToken(value)) out.push(`${name}[${key}="${value}"]`); }
    if (!anchor && request.kind === 'address-field') {
      const value = normalize(attribute(node, 'autocomplete'));
      if (value && value.length <= 100 && /^[a-z0-9 _-]+$/u.test(value) && !forbidden.test(value) && !privateValue.test(value)) out.push(`${name}[autocomplete="${value}"]`);
    }
    if (!anchor && request.kind !== 'public-evidence' && info.name && attribute(node, 'aria-label') === info.name) out.push(`${name}[aria-label="${info.name}"]`);
    const role = attribute(node, 'role');
    if (['button', 'radio', 'textbox', 'combobox', 'heading', 'status', 'region', 'group'].includes(role)) out.push(`${name}[role="${role}"]`);
    return [...new Set(out)];
  }
  function resolves(selector, node) {
    if (!selector || selector.length > 300) return false;
    try { const nodes = document.querySelectorAll(selector); return nodes.length === 1 && nodes[0] === node; } catch { return false; }
  }
  function locator(node, request) {
    const info = checkNode(node, request), choices = parts(node, request, info);
    for (const selector of choices) if (resolves(selector, node)) return { selector, ...info };
    // Only unique, unindexed structural paths. Never nth-child, class hashes or values.
    let suffixes = [...choices.filter(item => !item.startsWith('#')), tag(node)];
    for (let parent = node.parentElement, depth = 0; parent && depth < 4 && !['body', 'html'].includes(tag(parent)); parent = parent.parentElement, depth++) {
      for (const anchor of parts(parent, request, info, true)) {
        if (!resolves(anchor, parent)) continue;
        for (const suffix of suffixes) { const selector = `${anchor} > ${suffix}`; if (resolves(selector, node)) return { selector, ...info }; }
      }
      suffixes = suffixes.map(suffix => `${tag(parent)} > ${suffix}`).filter(suffix => suffix.length < 240);
    }
    // A semantic standalone tag is allowed only when globally unique, including hidden nodes.
    if (['button', 'a', 'input', 'textarea', 'select', 'h1', 'h2', 'h3', 'output'].includes(tag(node)) && resolves(tag(node), node)) return { selector: tag(node), ...info };
    throw Error('no-unique-stable-locator');
  }
  function chooseNode(node, request) {
    if (request.kind === 'action') {
      for (let item = node; item && !['html', 'body'].includes(tag(item)); item = item.parentElement) if (['button', 'input', 'a'].includes(tag(item)) || attribute(item, 'role') === 'button') return item;
    }
    if (request.kind === 'address-field' && tag(node) === 'label') {
      const id = attribute(node, 'for');
      const matches = [...document.querySelectorAll('input,textarea,select')].filter(item => id ? attribute(item, 'id') === id : node.contains(item));
      if (matches.length === 1) return matches[0];
    }
    return node;
  }
  function listen(target, type, callback, options = true) { target.addEventListener(type, callback, options); listeners.push(() => target.removeEventListener(type, callback, options)); }
  function send(message) { try { Promise.resolve(runtime.sendMessage(message)).catch(() => {}); } catch { /* Closing extension context must still clean up. */ } }
  function cleanup() {
    if (!active) return null;
    const old = active; active = null;
    for (const remove of listeners.splice(0)) remove();
    clearTimeout(old.timer); old.host.remove();
    finished.add(old.request.requestId);
    if (finished.size > 128) finished.delete(finished.values().next().value);
    return old;
  }
  function cancel(reason) { const old = cleanup(); if (old) send({ type: 'PURCHASE_PICK_CANCELLED', requestId: old.request.requestId, reason }); }
  function status(text) { if (active) active.status.textContent = text; }
  function resetSelection(reason) { if (!active) return; active.selection = null; active.confirm.disabled = true; active.highlight.style.display = 'none'; status(reason); }
  function contextStillValid() {
    if (!active) return false;
    try { safeLocation(); if (location.href !== active.href || document.visibilityState !== 'visible' || !active.host.isConnected) throw Error('page-changed'); return true; } catch { cancel('page-changed'); return false; }
  }
  function highlight(node) {
    const rect = node.getBoundingClientRect();
    Object.assign(active.highlight.style, { display: 'block', left: `${rect.left}px`, top: `${rect.top}px`, width: `${rect.width}px`, height: `${rect.height}px` });
  }
  function preview(node) {
    if (!contextStillValid()) return;
    try {
      node = chooseNode(node, active.request);
      const mapping = locator(node, active.request);
      active.selection = { node, locator: mapping }; active.confirm.disabled = false;
      highlight(node); status(`已定位：${mapping.name || (active.request.kind === 'public-evidence' ? '信息位置（不读取文字）' : '地址输入框')}。点击面板“确认选择”或按 Enter。`);
    } catch { resetSelection('此处不能安全、唯一地标记，请移动到具体的按钮、公开信息或地址字段。'); }
  }
  function confirm() {
    if (!contextStillValid() || !active.selection) return;
    const { node, locator: original } = active.selection;
    try {
      const checked = locator(node, active.request);
      if (JSON.stringify(checked) !== JSON.stringify(original) || !resolves(checked.selector, node)) throw Error('selection-changed');
      const where = safeLocation(), old = cleanup();
      send({ type: 'PURCHASE_PICK_RESULT', requestId: old.request.requestId, kind: old.request.kind, ...(old.request.fieldKey ? { fieldKey: old.request.fieldKey } : {}), locator: checked, ...where });
    } catch { resetSelection('页面元素已变化，未保存。请重新移动鼠标选择。'); }
  }
  function stopEvent(event) { event.preventDefault(); event.stopImmediatePropagation(); }
  function pathOf(event) {
    const path = typeof event.composedPath === 'function' ? event.composedPath() : [event.target];
    // Window listeners see only the host for a closed shadow tree. Resolve our
    // own controls inside that tree without exposing it or touching the page.
    if (active && path.includes(active.host) && Number.isFinite(event.clientX) && Number.isFinite(event.clientY)) {
      const inside = active.root.elementFromPoint?.(event.clientX, event.clientY);
      for (let item = inside; item && item !== active.host; item = item.parentElement) path.push(item);
    }
    return path;
  }
  function pointer(event) {
    if (!active) return;
    const path = pathOf(event), internal = path.includes(active.panel);
    stopEvent(event);
    if (!event.isTrusted || internal || !contextStillValid()) return;
    let target;
    // The full-window shield receives the event. Hit-testing never dispatches it
    // to the underlying merchant, and does not focus or click that element.
    active.host.style.setProperty('pointer-events', 'none', 'important');
    try { target = document.elementFromPoint(event.clientX, event.clientY); } finally { if (active) active.host.style.setProperty('pointer-events', 'auto', 'important'); }
    if (target) preview(target); else resetSelection('请把鼠标移到要标记的位置。');
  }
  function activation(event) {
    if (!active) return;
    const path = pathOf(event), accept = path.includes(active.confirm), abort = path.includes(active.cancel);
    stopEvent(event);
    if (!event.isTrusted || event.type !== 'click') return;
    if (abort) cancel('user-cancelled'); else if (accept) confirm();
  }
  function key(event) {
    if (!active) return;
    stopEvent(event);
    if (!event.isTrusted) return;
    const allowed = !event.repeat && !event.altKey && !event.ctrlKey && !event.metaKey && !event.shiftKey && ['Escape', 'Enter'].includes(event.key);
    if (event.type === 'keydown') { active.confirmKey = allowed ? event.key : null; return; }
    if (event.type !== 'keyup') return;
    const pressed = active.confirmKey; active.confirmKey = null;
    // Finish only after key release: never expose a trailing keyup to a merchant
    // button that had focus before the picker started.
    if (!allowed || pressed !== event.key) return;
    if (event.key === 'Escape') cancel('user-cancelled');
    else confirm();
  }
  function mount(request) {
    const host = document.createElement('div');
    host.setAttribute('data-apple-purchase-picker', '');
    host.style.cssText = 'all:initial!important;position:fixed!important;inset:0!important;z-index:2147483647!important;display:block!important;pointer-events:auto!important;';
    const root = host.attachShadow({ mode: 'closed' });
    const style = document.createElement('style');
    style.textContent = ':host{color-scheme:light}*{box-sizing:border-box}.shield{position:absolute;inset:0;background:transparent;cursor:crosshair}.highlight{position:fixed;display:none;border:3px solid #0071e3;background:#0071e318;pointer-events:none}.panel{position:fixed;right:20px;bottom:20px;width:min(460px,calc(100vw - 40px));padding:18px;border:2px solid #0071e3;border-radius:12px;background:#fff;color:#1d1d1f;font:15px/1.55 system-ui,sans-serif;box-shadow:0 4px 28px #0004}.panel p{margin:6px 0 12px}.warning{font-size:12px;color:#595959}button{font:inherit;padding:8px 14px;margin:8px 8px 0 0;border:1px solid #666;border-radius:7px;background:#f5f5f7;color:#111;cursor:pointer}button:disabled{opacity:.45;cursor:default}';
    const shield = document.createElement('div'); shield.setAttribute('class', 'shield');
    const mark = document.createElement('div'); mark.setAttribute('class', 'highlight');
    const panel = document.createElement('section'); panel.setAttribute('class', 'panel'); panel.setAttribute('role', 'dialog'); panel.setAttribute('aria-label', '标记页面位置');
    const intro = document.createElement('p'); intro.textContent = '移动鼠标选中网页位置，再点“确认选择”或按 Enter。Esc 可取消。';
    const note = document.createElement('p'); note.setAttribute('class', 'warning'); note.textContent = '不会点击网页控件。只保存定位信息，不读取输入值或地址摘要。网页先注册的事件处理器仍可能先执行，无法保证拦截所有页面代码。';
    const message = document.createElement('p'); message.setAttribute('role', 'status'); message.textContent = '请把鼠标移到要标记的位置。';
    const yes = document.createElement('button'); yes.setAttribute('type', 'button'); yes.textContent = '确认选择'; yes.disabled = true;
    const no = document.createElement('button'); no.setAttribute('type', 'button'); no.textContent = '取消';
    panel.append(intro, note, message, yes, no); root.append(style, shield, mark, panel);
    active = { request, href: location.href, host, root, panel, highlight: mark, status: message, confirm: yes, cancel: no, selection: null, confirmKey: null, timer: null };
    document.documentElement.append(host);
    for (const type of ['pointermove', 'mousemove']) listen(globalThis, type, pointer);
    for (const type of ['pointerdown', 'pointerup', 'mousedown', 'mouseup', 'click', 'dblclick', 'auxclick', 'contextmenu', 'touchstart', 'touchend']) listen(globalThis, type, activation, { capture: true, passive: false });
    for (const type of ['keydown', 'keyup', 'keypress']) listen(globalThis, type, key);
    for (const type of ['pagehide', 'popstate', 'hashchange']) listen(globalThis, type, () => cancel('page-changed'));
    listen(document, 'visibilitychange', () => { if (document.visibilityState !== 'visible') cancel('page-hidden'); });
    listen(globalThis, 'resize', () => resetSelection('窗口尺寸已变化，请重新选择。'));
    listen(document, 'scroll', () => resetSelection('页面已滚动，请重新选择。'));
    active.timer = setTimeout(() => cancel('picker-expired'), 5 * 60 * 1000);
  }
  runtime.onMessage.addListener((message, sender, respond) => {
    if (!['START_PICKER', 'CANCEL_PICKER'].includes(message?.type)) return false;
    if (sender?.id !== runtime.id || sender.tab || sender.url && !sender.url.startsWith(`chrome-extension://${runtime.id}/`)) { respond({ ok: false, error: 'unauthorized-sender' }); return false; }
    try {
      if (message.type === 'CANCEL_PICKER') {
        if (!active || active.request.requestId !== message.requestId) throw Error('request-not-active');
        cancel('extension-cancelled'); respond({ ok: true, requestId: message.requestId }); return false;
      }
      if (typeof message.requestId !== 'string' || !/^[a-z0-9_-]{8,100}$/iu.test(message.requestId) || !['action', 'public-evidence', 'address-field'].includes(message.kind) || Object.keys(message).some(key => !['type', 'requestId', 'kind', 'fieldKey'].includes(key)) || message.kind === 'address-field' && !Object.hasOwn(fields, message.fieldKey) || message.kind !== 'address-field' && message.fieldKey !== undefined) throw Error('invalid-request');
      safeLocation();
      if (document.visibilityState !== 'visible' || !document.documentElement) throw Error('page-not-visible');
      if (active?.request.requestId === message.requestId) {
        if (active.request.kind !== message.kind || active.request.fieldKey !== message.fieldKey) throw Error('request-conflict');
        respond({ ok: true, requestId: message.requestId }); return false;
      }
      if (finished.has(message.requestId)) throw Error('request-already-finished');
      if (active) cancel('replaced-by-new-request');
      mount({ requestId: message.requestId, kind: message.kind, ...(message.fieldKey ? { fieldKey: message.fieldKey } : {}) });
      respond({ ok: true, requestId: message.requestId });
    } catch (error) { if (active?.request.requestId === message.requestId) cancel('picker-start-failed'); respond({ ok: false, error: error.message }); }
    return false;
  });
  globalThis.__applePurchasePicker = Object.freeze({ version: 1 });
})();
