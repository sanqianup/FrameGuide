import { test } from 'node:test';
import assert from 'node:assert/strict';
import '../extension/dom-driver.js';
import '../extension/apple-duo-readonly.js';

const { inspect, supportsURL } = globalThis.AppleDuoReadonly;
const URL = 'https://www.apple.com.cn/shop/buy-iphone/iphone-duo';
const SKU_URL = `${URL}/mk2n4ch/a`;
const driver = globalThis.AppleDOMDriver;

// Small, dependency-free semantic DOM. It intentionally does not emulate an
// Apple checkout or expose input values. Fixtures model only observed evidence.
class Element {
  constructor(doc, tag, text = '', attrs = {}) {
    this.ownerDocument = doc;
    this.nodeType = 1;
    this.tagName = tag.toUpperCase();
    this.ownText = text;
    this.attributes = new Map(Object.entries(attrs));
    this.children = [];
    this.parentElement = null;
    this.checked = false;
    this.disabled = false;
    this.hidden = false;
    this.inert = false;
    this.style = { display: 'block', visibility: 'visible', opacity: '1', contentVisibility: 'visible' };
    Object.defineProperty(this, 'value', { get() { assert.fail('Input value must never be read'); } });
  }
  get textContent() { return this.ownText + this.children.map(child => child.textContent).join(''); }
  get innerText() { return this.textContent; }
  get isConnected() { return this.ownerDocument.contains(this); }
  getAttribute(name) {
    assert.notEqual(name, 'value', 'Input value attribute must never be read');
    return this.attributes.get(name) ?? null;
  }
  hasAttribute(name) { return this.attributes.has(name); }
  setAttribute(name, value) { this.attributes.set(name, String(value)); }
  removeAttribute(name) { this.attributes.delete(name); }
  append(...elements) {
    for (const element of elements) {
      element.remove();
      element.parentElement = this;
      this.children.push(element);
    }
  }
  remove() {
    if (this.parentElement) this.parentElement.children = this.parentElement.children.filter(child => child !== this);
    this.parentElement = null;
  }
  contains(element) { return element === this || this.children.some(child => child.contains(element)); }
  matches(selector) {
    if (selector === '*') return true;
    if (selector === ':disabled') {
      if (this.disabled) return true;
      for (let parent = this.parentElement; parent; parent = parent.parentElement) {
        if (parent.tagName === 'FIELDSET' && parent.disabled) return true;
      }
      return false;
    }
    const match = /^(\w+)?(?:\[([\w-]+)(?:="([^"]*)")?\])?$/.exec(selector);
    if (!match) throw Error(`Unsupported mock selector: ${selector}`);
    return (!match[1] || this.tagName.toLowerCase() === match[1]) &&
      (!match[2] || (this.hasAttribute(match[2]) && (match[3] === undefined || this.getAttribute(match[2]) === match[3])));
  }
  querySelectorAll(selector) {
    return this.children.flatMap(child => [ ...(child.matches(selector) ? [child] : []), ...child.querySelectorAll(selector) ]);
  }
  getClientRects() { return this.isConnected && !this.hidden && this.style.display !== 'none' ? [{}] : []; }
  click() { assert.fail('The adapter must never click'); }
  focus() { assert.fail('The adapter must never focus'); }
  dispatchEvent() { assert.fail('The adapter must never dispatch events'); }
}

class Document {
  constructor() {
    this.nodeType = 9;
    this.body = new Element(this, 'body');
    this.defaultView = { getComputedStyle: element => element.style };
  }
  element(tag, text = '', attrs = {}) { return new Element(this, tag, text, attrs); }
  contains(element) { return element === this || this.body.contains(element); }
  querySelectorAll(selector) { return this.body.querySelectorAll(selector); }
  getElementById(id) { return this.querySelectorAll('[id]').find(element => element.getAttribute('id') === id) ?? null; }
}

function fixture() {
  const doc = new Document();
  const main = doc.element('main');
  const heading = doc.element('h1', 'iPhone Duo');
  const colorGroup = doc.element('fieldset');
  const capacityGroup = doc.element('fieldset');
  const continueButton = doc.element('button', '继续');
  continueButton.disabled = true;
  doc.body.append(main);
  main.append(heading, colorGroup, capacityGroup, continueButton);
  function option(group, name, text, index, disabled = false) {
    const input = doc.element('input', '', { type: 'radio', name, id: `dynamic-${name}-${index}` });
    const label = doc.element('label', '', { for: input.getAttribute('id') });
    const labelText = doc.element('span', text, { id: `dynamic-label-${name}-${index}` });
    input.setAttribute('aria-labelledby', labelText.getAttribute('id'));
    label.append(labelText);
    input.disabled = disabled;
    group.append(input, label);
    return { input, label, labelText };
  }
  const colors = ['星光白色', '夜空色'].map((text, i) => option(colorGroup, 'dimensionColor', text, i));
  const capacities = ['256GB', '512GB', '1TB', '2TB'].map((text, i) => option(capacityGroup, 'dimensionCapacity', text, i, true));
  const read = options => inspect(doc, { url: URL, ...options });
  return { doc, main, heading, colorGroup, capacityGroup, continueButton, colors, capacities, read };
}

test('observed configuration reports unselected color and disabled unselected capacity without inventing a cause', () => {
  const { read } = fixture();
  const result = read();
  assert.equal(result.supported, true);
  assert.equal(result.pageKind, 'product-configuration');
  assert.equal(result.model, 'iPhone Duo');
  assert.equal(result.color, null);
  assert.equal(result.storage, null);
  assert.deepEqual(result.options.color, ['星光白色', '夜空色'].map(name => ({ name, selected: false, enabled: true })));
  assert.deepEqual(result.options.storage, ['256GB', '512GB', '1TB', '2TB'].map(name => ({ name, selected: false, enabled: false })));
  assert.deepEqual(result.continue, { status: 'disabled', name: '继续', enabled: false });
  assert.deepEqual(result.ambiguity, []);
  for (const key of ['color', 'storage', 'countdown', 'region', 'delivery', 'totalMinor', 'orderState', 'submissionTarget']) {
    assert.ok(result.evidenceMissing.includes(key), key);
  }
  assert.equal(result.countdown, null);
  assert.equal(result.countdownObserved, false);
  assert.deepEqual(JSON.parse(JSON.stringify(result)), result);
  assert.equal('disabledReason' in result.continue, false);
  for (const key of ['soldOut', 'totalMinor', 'region', 'delivery', 'orderState', 'buttonUnique', 'buttonEnabled', 'submitTarget']) {
    assert.equal(key in result, false, key);
  }
});

test('only live checked state establishes selections, including a checked disabled option', () => {
  const { read, colors, capacities } = fixture();
  colors[0].input.setAttribute('checked', '');
  colors[0].input.setAttribute('aria-checked', 'true');
  assert.equal(read().color, null, 'Attributes alone do not establish current native radio state');
  colors[1].input.checked = true;
  capacities[2].input.checked = true;
  let result = read();
  assert.equal(result.color, '夜空色');
  assert.equal(result.storage, '1TB');
  assert.equal(result.options.storage[2].enabled, false);
  assert.equal(result.evidenceMissing.includes('color'), false);
  assert.equal(result.evidenceMissing.includes('storage'), false);
  colors[1].input.checked = false;
  capacities[2].input.checked = false;
  result = read();
  assert.equal(result.color, null);
  assert.equal(result.storage, null);
});

test('dynamic identifiers, complete replacement and reordered controls preserve semantic evidence', () => {
  const { read, doc, colorGroup, colors, capacities } = fixture();
  colors[1].input.checked = true;
  capacities[1].input.checked = true;
  for (const [i, item] of [...colors, ...capacities].entries()) {
    item.input.setAttribute('id', `new-input-${i}-with:punctuation`);
    item.label.setAttribute('for', item.input.getAttribute('id'));
    item.labelText.setAttribute('id', `new-label-${i}-with:punctuation`);
    item.input.setAttribute('aria-labelledby', item.labelText.getAttribute('id'));
  }
  colorGroup.append(colors[0].input, colors[0].label);
  const replacement = doc.element('input', '', Object.fromEntries(colors[1].input.attributes));
  replacement.checked = true;
  colors[1].input.remove();
  colorGroup.append(replacement);
  const result = read();
  assert.equal(result.color, '夜空色');
  assert.equal(result.storage, '512GB');
  assert.deepEqual(result.ambiguity, []);
});

test('radio naming safely supports aria-labelledby, aria-label, explicit labels and wrapping labels', () => {
  const { read, doc, colors, capacities } = fixture();
  assert.equal(driver.getName(colors[0].input), '', 'Shared driver intentionally ignores native radio values/names');
  colors[0].input.removeAttribute('aria-labelledby');
  colors[0].input.setAttribute('aria-label', '星光白色');
  colors[1].input.removeAttribute('aria-labelledby');
  capacities[0].input.removeAttribute('aria-labelledby');
  capacities[0].label.removeAttribute('for');
  capacities[0].label.append(capacities[0].input);
  const suffix = doc.element('span', 'GB', { id: 'capacity-suffix' });
  capacities[1].labelText.ownText = '512';
  doc.body.append(suffix);
  capacities[1].input.setAttribute('aria-labelledby', `${capacities[1].labelText.getAttribute('id')} capacity-suffix`);
  const result = read();
  assert.deepEqual(result.options.color.map(option => option.name), ['星光白色', '夜空色']);
  assert.deepEqual(result.options.storage.map(option => option.name), ['256GB', '512 GB', '1TB', '2TB']);
  assert.deepEqual(result.ambiguity, []);
});

test('multiple checked radios cannot become an asserted selection', () => {
  const { read, colors, capacities } = fixture();
  colors.forEach(({ input }) => { input.checked = true; });
  capacities[0].input.checked = capacities[1].input.checked = true;
  const result = read();
  assert.equal(result.color, null);
  assert.equal(result.storage, null);
  assert.ok(result.ambiguity.includes('color:multiple-checked-options'));
  assert.ok(result.ambiguity.includes('storage:multiple-checked-options'));
  assert.equal(result.options.color.filter(option => option.selected).length, 2);
});

test('duplicate option names are ambiguous even when only one is checked and another is disabled', () => {
  const { read, colors } = fixture();
  colors[0].input.checked = true;
  colors[1].labelText.ownText = '星光白色';
  colors[1].input.disabled = true;
  const result = read();
  assert.equal(result.color, null);
  assert.ok(result.ambiguity.includes('color:duplicate-option-labels'));
});

test('duplicate label IDs and multiple associated labels fail closed', () => {
  const { read, doc, main, colors } = fixture();
  colors[0].input.checked = true;
  main.append(doc.element('span', 'Conflicting label', { id: colors[0].labelText.getAttribute('id') }));
  let result = read();
  assert.equal(result.options.color[0].name, null);
  assert.equal(result.color, null);
  assert.ok(result.ambiguity.includes('color:ambiguous-label-reference'));
  colors[0].input.removeAttribute('aria-labelledby');
  main.append(doc.element('label', 'Duplicate associated label', { for: colors[0].input.getAttribute('id') }));
  result = read();
  assert.equal(result.color, null);
  assert.ok(result.ambiguity.includes('color:multiple-associated-labels'));
});

test('broken ARIA reference does not fall through to a tempting label or value', () => {
  const { read, colors } = fixture();
  colors[0].input.checked = true;
  colors[0].input.setAttribute('aria-labelledby', 'nonexistent-current-render-label');
  colors[0].input.setAttribute('aria-label', '星光白色');
  const result = read();
  assert.equal(result.options.color[0].name, null);
  assert.equal(result.color, null);
  assert.ok(result.evidenceMissing.includes('color-option-label'));
});

test('visible associated labels can identify styled radios without reviving hidden ancestors', () => {
  const { read, colors, colorGroup } = fixture();
  colors[0].input.style.opacity = '0';
  colors[0].input.checked = true;
  assert.equal(read().color, '星光白色');
  for (const hide of [
    () => { colorGroup.hidden = true; },
    () => { colorGroup.setAttribute('aria-hidden', 'true'); },
    () => { colorGroup.style.display = 'none'; },
    () => { colorGroup.style.opacity = '0'; }
  ]) {
    hide();
    assert.deepEqual(read().options.color, []);
    assert.equal(read().color, null);
    colorGroup.hidden = false;
    colorGroup.removeAttribute('aria-hidden');
    colorGroup.style.display = 'block';
    colorGroup.style.opacity = '1';
  }
  colors[0].input.hidden = true;
  assert.equal(read().color, null);
});

test('disabled fieldsets, inert and ARIA-disabled controls report disabled without reasons', () => {
  const { read, colors, colorGroup, continueButton } = fixture();
  colorGroup.disabled = true;
  assert.equal(read().options.color.every(option => !option.enabled), true);
  colorGroup.disabled = false;
  colors[0].input.setAttribute('aria-disabled', 'true');
  colors[1].input.inert = true;
  continueButton.disabled = false;
  continueButton.setAttribute('aria-busy', 'true');
  const result = read();
  assert.equal(result.options.color.every(option => !option.enabled), true);
  assert.equal(result.continue.status, 'disabled');
  assert.equal('reason' in result.continue, false);
});

test('enabled Continue remains stage evidence and can never be a submission target', () => {
  const { read, continueButton, doc, main } = fixture();
  continueButton.disabled = false;
  continueButton.setAttribute('type', 'submit');
  const form = doc.element('form', '', { action: '/unverified-checkout' });
  main.append(form);
  form.append(continueButton);
  const result = read();
  assert.deepEqual(result.continue, { status: 'enabled', name: '继续', enabled: true });
  assert.deepEqual(Object.keys(result.continue), ['status', 'name', 'enabled']);
  assert.ok(result.evidenceMissing.includes('submissionTarget'));
  assert.equal(JSON.stringify(result).includes('unverified-checkout'), false);
});

test('duplicate Continue controls are ambiguous, with hidden duplicates excluded', () => {
  const { read, doc, main } = fixture();
  const duplicate = doc.element('button', '', { 'aria-label': '继续' });
  main.append(duplicate);
  assert.equal(read().continue.status, 'ambiguous');
  assert.ok(read().ambiguity.includes('continue:multiple-buttons'));
  duplicate.hidden = true;
  assert.equal(read().continue.status, 'disabled');
});

test('model is direct unique heading evidence, never inferred from URL or surrounding prose', () => {
  const { read, heading, doc, main } = fixture();
  heading.ownText = 'A different phone';
  main.append(doc.element('p', 'iPhone Duo 256GB 星光白色 总价 8999 元'));
  assert.equal(read().model, null);
  heading.ownText = 'iPhone Duo';
  main.append(doc.element('h1', 'iPhone Duo'));
  const result = read();
  assert.equal(result.model, null);
  assert.ok(result.ambiguity.includes('model:multiple-headings'));
});

test('launch-date prose and numeric text never produce a fabricated countdown or order evidence', () => {
  const { read, doc, main } = fixture();
  main.append(doc.element('p', '10 月 16 日 9:00 发售，倒计时信息请关注。256GB 起，人民币 8999 元。'));
  main.append(doc.element('div', '00:10', { role: 'timer' }));
  const result = read();
  assert.equal(result.countdown, null);
  assert.equal(result.countdownObserved, false, 'A future timer remains unverified by this narrow adapter');
  assert.ok(result.evidenceMissing.includes('countdown'));
  assert.equal('totalMinor' in result, false);
  assert.equal('orderState' in result, false);
});

test('display page, wrong hosts, protocols, paths and credentials are outside exact route scope', () => {
  const forbiddenRoot = { get querySelectorAll() { assert.fail('Unsupported routes must not read the DOM'); } };
  for (const url of [
    'https://www.apple.com.cn/iphone-duo/',
    'https://www.apple.com/shop/buy-iphone/iphone-duo',
    'https://www.apple.com.cn.attacker.invalid/shop/buy-iphone/iphone-duo',
    'https://apple.com.cn/shop/buy-iphone/iphone-duo',
    'http://www.apple.com.cn/shop/buy-iphone/iphone-duo',
    'https://www.apple.com.cn:444/shop/buy-iphone/iphone-duo',
    'https://user:pass@www.apple.com.cn/shop/buy-iphone/iphone-duo',
    `${URL}/`, `${URL}/checkout`, `${URL}-pro`, 'not a URL', undefined
  ]) {
    const result = inspect(forbiddenRoot, { url });
    assert.equal(result.supported, false, url);
    assert.equal(result.pageKind, null);
    assert.equal(result.model, null);
    assert.deepEqual(result.options, { color: [], storage: [] });
  }
});

test('non-state-changing query and fragment do not expand route scope or leak into evidence', () => {
  const { read } = fixture();
  const result = read({ url: `${URL}?campaign=example#configuration` });
  assert.equal(result.supported, true);
  assert.equal(JSON.stringify(result).includes('campaign'), false);
});

test('unrelated and sensitive inputs are ignored and inspection does not mutate the document', () => {
  const { read, doc, main, colors, capacities, continueButton } = fixture();
  for (const type of ['password', 'text', 'email', 'tel', 'hidden', 'submit']) {
    main.append(doc.element('input', '', { type, name: 'dimensionColor', role: 'button', 'aria-label': '继续' }));
  }
  main.append(doc.element('input', '', { type: 'radio', name: 'unrelated', 'aria-label': 'Do not collect me' }));
  colors[0].input.checked = true;
  capacities[0].input.checked = true;
  continueButton.disabled = false;
  const inputs = [...colors, ...capacities].map(item => item.input);
  const before = inputs.map(input => ({ checked: input.checked, attrs: [...input.attributes] }));
  const result = read();
  assert.equal(result.color, '星光白色');
  assert.equal(result.storage, '256GB');
  assert.equal(result.continue.status, 'enabled');
  assert.deepEqual(inputs.map(input => ({ checked: input.checked, attrs: [...input.attributes] })), before);
  assert.equal(JSON.stringify(result).includes('Do not collect me'), false);
  assert.equal(result.evidenceMissing.includes('dom-inspection'), false);
});

test('missing driver and failed document reads remain serializable unknown evidence', () => {
  const { read, doc } = fixture();
  const noDriver = read({ driver: null });
  assert.equal(noDriver.supported, true);
  assert.equal(noDriver.model, null);
  assert.ok(noDriver.evidenceMissing.includes('dom-reader'));
  doc.querySelectorAll = () => { throw Error('DOM changed'); };
  const failed = read();
  assert.equal(failed.color, null);
  assert.ok(failed.evidenceMissing.includes('dom-inspection'));
  assert.doesNotThrow(() => JSON.stringify(failed));
});

test('observed selected SKU route reports summary and product price, never complete order total', () => {
  const { read, doc, main, colors, capacities, continueButton } = fixture();
  colors[1].input.checked = true;
  capacities.forEach(({ input }) => { input.disabled = false; });
  capacities[0].input.checked = true;
  main.append(doc.element('div', 'iPhone Duo 256GB 夜空色', { 'data-autom': 'summary-productName' }));
  main.append(doc.element('span', 'RMB15,999', { 'data-autom': 'full-price' }));
  main.append(doc.element('p', '暂未发售'));
  continueButton.setAttribute('data-autom', 'continueButton');
  const result = read({ url: SKU_URL });
  assert.equal(result.supported, true);
  assert.equal(result.color, '夜空色');
  assert.equal(result.storage, '256GB');
  assert.equal(result.options.storage.every(option => option.enabled), true);
  assert.equal(result.summary, 'iPhone Duo 256GB 夜空色');
  assert.equal(result.itemPriceMinor, 1599900);
  assert.equal(result.itemCurrency, 'CNY');
  assert.equal(result.releaseNotice, '暂未发售');
  assert.equal(result.continue.status, 'disabled');
  assert.ok(result.evidenceMissing.includes('totalMinor'));
  assert.ok(result.evidenceMissing.includes('currency'), 'Order currency is not asserted from a product price');
  assert.equal('totalMinor' in result, false);
  assert.equal('soldOut' in result, false);
  assert.equal('releaseState' in result, false);
});

test('public URL scope helper allowlists only the base page and explicitly evidenced SKUs', () => {
  assert.equal(supportsURL(URL), true);
  assert.equal(supportsURL(SKU_URL), true);
  assert.equal(supportsURL(`${URL}/mk2u4ch/a`), true);
  assert.equal(supportsURL(`${URL}/mk2u4ch/a/checkout`), false);
  assert.equal(supportsURL(`${URL}/mk2u5ch/a`), false);
  assert.equal(supportsURL(`${SKU_URL}?campaign=example`), true);
  assert.equal(supportsURL(`${URL}/arbitrary-sku/a`), false);
  assert.equal(supportsURL(`${URL}/mk2n5ch/a`), false);
  assert.equal(supportsURL(`${SKU_URL}/checkout`), false);
  assert.equal(supportsURL(SKU_URL.replace('apple.com.cn', 'apple.com')), false);
  assert.equal(supportsURL('https://www.apple.com.cn/iphone-duo/'), false);
});

test('product price parsing is strict and never extracts a number from unrelated price prose', () => {
  const { read, doc, main } = fixture();
  const price = doc.element('span', 'RMB 15,999', { 'data-autom': 'full-price' });
  main.append(price);
  assert.equal(read().itemPriceMinor, 1599900);
  for (const invalid of ['15,999', 'RMB 15,99', 'RMB 15,999 起', 'RMB 15,999 或分期', 'USD 15,999',
    'RMB -1', 'RMB 1.999', 'RMB 9007199254740991', '含税总计 RMB15,999']) {
    price.ownText = invalid;
    const result = read();
    assert.equal(result.itemPriceMinor, null, invalid);
    assert.equal(result.itemCurrency, null, invalid);
    assert.ok(result.evidenceMissing.includes('itemPriceMinor'));
  }
  price.ownText = 'RMB15,999.50';
  assert.equal(read().itemPriceMinor, 1599950);
});

test('multiple visible summary or product-price elements are ambiguous instead of chosen by order', () => {
  const { read, doc, main } = fixture();
  for (let i = 0; i < 2; i++) {
    main.append(doc.element('div', 'iPhone Duo 256GB 夜空色', { 'data-autom': 'summary-productName' }));
    main.append(doc.element('span', 'RMB15,999', { 'data-autom': 'full-price' }));
  }
  const result = read();
  assert.equal(result.summary, null);
  assert.equal(result.itemPriceMinor, null);
  assert.equal(result.itemCurrency, null);
  assert.ok(result.ambiguity.includes('summary:multiple-elements'));
  assert.ok(result.ambiguity.includes('itemPrice:multiple-elements'));
});

test('summary does not replace unchecked native options as selection evidence', () => {
  const { read, doc, main } = fixture();
  main.append(doc.element('div', 'iPhone Duo 256GB 夜空色', { 'data-autom': 'summary-productName' }));
  const result = read();
  assert.equal(result.summary, 'iPhone Duo 256GB 夜空色');
  assert.equal(result.color, null);
  assert.equal(result.storage, null);
});

test('release notice requires exact visible literal evidence, independent of disabled controls', () => {
  const { read, doc, main, continueButton } = fixture();
  assert.equal(read().releaseNotice, null);
  const notice = doc.element('p', '暂未发售商品信息');
  main.append(notice);
  assert.equal(read().releaseNotice, null);
  notice.ownText = '暂未发售';
  notice.hidden = true;
  assert.equal(read().releaseNotice, null);
  notice.hidden = false;
  continueButton.disabled = false;
  assert.equal(read().releaseNotice, '暂未发售');
  notice.remove();
  main.append(doc.element('textarea', '暂未发售'));
  main.append(doc.element('div', '暂未发售', { contenteditable: 'true' }));
  assert.equal(read().releaseNotice, null, 'Editable values do not become release evidence');
});

test('new user-specified text-verified SKU does not inherit live DOM state from the prior SKU', () => {
  const { read, doc, main, heading, colorGroup, capacityGroup, continueButton } = fixture();
  heading.remove();colorGroup.remove();capacityGroup.remove();continueButton.remove();
  // These are public text facts only, not verified h1/summary/price control markup.
  main.append(doc.element('p', '购买 iPhone Duo 1TB 夜空色'));
  main.append(doc.element('p', 'RMB21499'));
  const result = read({url:`${URL}/mk2u4ch/a`});
  assert.equal(result.supported,true);
  assert.equal(result.model,null);assert.equal(result.color,null);assert.equal(result.storage,null);
  assert.deepEqual(result.options,{color:[],storage:[]});
  assert.deepEqual(result.continue,{status:'missing',name:null,enabled:null});
  assert.equal(result.summary,null);assert.equal(result.itemPriceMinor,null);
  assert.equal('totalMinor' in result,false);assert.equal('maxTotal' in result,false);
  assert.equal(result.releaseNotice,null);assert.equal(result.countdown,null);
});
