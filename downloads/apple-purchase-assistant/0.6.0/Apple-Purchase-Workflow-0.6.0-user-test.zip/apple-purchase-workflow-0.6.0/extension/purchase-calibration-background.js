import {purchaseURL,purchaseLoginPath,ADDRESS_AUTOCOMPLETE,validatePurchase,validatePurchaseDraft} from './purchase-config.js';
import {TERMINAL} from './core.js';
const KEY='purchasePicker',DRAFT='purchaseCalibrationDraft';
const controls=new Set(['PURCHASE_PICK_BEGIN','PURCHASE_PICK_STATUS','PURCHASE_PICK_ABORT','PURCHASE_PICK_TABS','PURCHASE_SAVE_PLAN','PURCHASE_SAVE_DRAFT','PURCHASE_LOAD_DRAFT']);
const results=new Set(['PURCHASE_PICK_RESULT','PURCHASE_PICK_CANCELLED']);
export const calibrationMessage=type=>controls.has(type)||results.has(type);
function location(value){if(!purchaseURL(value))throw Error('请选择已支持的 Apple 商店页面');const u=new URL(value);if(!/^\/shop(?:\/|$)[a-z0-9/_-]*$/iu.test(u.pathname)||u.pathname.length>200||/\d{7,}|[0-9a-f]{16,}|password|credential|token|session|csrf|nonce|secret/iu.test(u.pathname))throw Error('校准路径含私人信息或不受支持');if(purchaseLoginPath(u.pathname))throw Error('登录页面不能校准');return {origin:u.origin,path:u.pathname,...(u.origin==='https://www.apple.com.cn'&&u.search?{query:Object.fromEntries(u.searchParams)}:{})};}
function safeLocator(raw,kind,key){
 if(!raw||typeof raw!=='object'||Object.keys(raw).some(k=>!['selector','role','name','autocomplete'].includes(k)))throw Error('点选结果格式无效');
 const {selector,role,name}=raw;
 if(typeof selector!=='string'||!selector||selector.length>300||/[\\\x00-\x1f\x7f]/u.test(selector)||/^(?:\*|html|body|:root)$/iu.test(selector)||/\[\s*value\b/iu.test(selector)||/(?:password|passwd|one-time-code|cc-number|cardnumber|cvv|credential|token|session)/iu.test(selector))throw Error('点选位置不安全');
 if(typeof name!=='string'||name.length>160||/[\x00-\x1f\x7f]|\b\d{11,}\b|[^\s@]+@[^\s@]+\.[^\s@]+/u.test(name))throw Error('点选名称含私人信息或无效');
 if(kind==='public-evidence'&&(role!=='evidence'||name!==''))throw Error('证据只允许位置，不允许读取文字');
 if(kind==='action'&&(!['button','radio'].includes(role)||!name))throw Error('动作须为明确按钮或单选项');
 if(kind==='address-field'&&(!['textbox','combobox'].includes(role)||raw.autocomplete!==ADDRESS_AUTOCOMPLETE[key]))throw Error('地址字段不匹配');
 return {selector,role,name,...(kind==='address-field'?{autocomplete:raw.autocomplete}:{})};
}
export class PurchaseCalibrationController{
 constructor({chrome,read}){this.chrome=chrome;this.read=read;}
 async pending(){return (await this.chrome.storage.session.get(KEY))[KEY]||null;}
 async write(r){await this.chrome.storage.session.set({[KEY]:r});return r;}
 async reconcile(){const p=await this.pending();if(p?.status!=='pending')return p;let invalid=Date.now()>p.expiresAt;try{const current=location((await this.chrome.tabs.get(p.tabId)).url);invalid ||= current.origin!==p.origin||current.path!==p.path||JSON.stringify(current.query??{})!==JSON.stringify(p.query??{});}catch{invalid=true;}if(invalid)await this.abort('页面已离开或点选已超时');return this.pending();}
 async idle(){const r=await this.read();if(r&&!TERMINAL.has(r.state))throw Error('请先停止购买任务，再校准网页');}
 async abort(reason='用户取消校准'){const p=await this.pending();if(p?.status==='pending'){await this.write({...p,status:'cancelled',reason});await this.chrome.tabs.sendMessage(p.tabId,{type:'CANCEL_PICKER',requestId:p.requestId},(p.documentId?{documentId:p.documentId}:{frameId:0})).catch(()=>{});}return {cancelled:true};}
 async handle(m,sender){
 const c=this.chrome;if(sender.id!==c.runtime.id)throw Error('消息来源无效');
 if(controls.has(m.type)&&![c.runtime.getURL('purchase.html'),c.runtime.getURL('popup.html')].includes(sender.url?.split(/[?#]/u)[0]))throw Error('仅购买设置界面可校准');
 if(m.type==='PURCHASE_PICK_ABORT'){const p=await this.pending();if(m.requestId!==undefined&&p?.requestId!==m.requestId)throw Error('点选请求已失效');return this.abort();}
 if(m.type==='PURCHASE_LOAD_DRAFT')return {draft:(await c.storage.local.get(DRAFT))[DRAFT]||null};
 if(m.type==='PURCHASE_PICK_TABS'){const tabs=await c.tabs.query({currentWindow:true});return {tabs:tabs.flatMap(t=>{try{const {origin,path}=location(t.url);return [{id:t.id,origin,path}];}catch{return [];}})};}
 if(m.type==='PURCHASE_SAVE_PLAN'||m.type==='PURCHASE_SAVE_DRAFT'){
  await this.idle();if(m.confirmedCalibration!==true)throw Error('请确认保存校准');
  if(m.type==='PURCHASE_SAVE_DRAFT'){const draft=validatePurchaseDraft(m.config,m.steps);await c.storage.local.set({[DRAFT]:draft});return {draft};}
  const config=validatePurchase({...m.config,mode:'purchase',confirmedPurchase:true});config.confirmedPurchase=false;await c.storage.local.set({settings:config});return {settings:config};
 }
 if(m.type==='PURCHASE_PICK_BEGIN'){
  await this.idle();if(!Number.isInteger(m.tabId)||!['action','public-evidence','address-field'].includes(m.kind)||m.kind==='address-field'&&!Object.hasOwn(ADDRESS_AUTOCOMPLETE,m.fieldKey))throw Error('请选择有效的页面及点选类型');
  const tab=await c.tabs.get(m.tabId),loc=location(tab.url);if(!await c.permissions.contains({origins:[`${loc.origin}/*`]}))throw Error('请先授权当前 Apple 站点的点选权限');
  await this.abort('开始新的校准');const p={requestId:crypto.randomUUID(),status:'pending',tabId:m.tabId,kind:m.kind,...(m.kind==='address-field'?{fieldKey:m.fieldKey}:{}),...loc,expiresAt:Date.now()+120000};await this.write(p);
  try{await c.tabs.update(m.tabId,{active:true});const injected=await c.scripting.executeScript({target:{tabId:m.tabId,frameIds:[0]},files:['purchase-picker.js'],injectImmediately:true});if(typeof injected?.[0]?.documentId!=='string'||!injected[0].documentId)throw Error('浏览器未提供文档标识，不能安全点选');p.documentId=injected[0].documentId;await this.write(p);const reply=await c.tabs.sendMessage(m.tabId,{type:'START_PICKER',requestId:p.requestId,kind:p.kind,fieldKey:p.fieldKey},{documentId:p.documentId});if(reply?.ok!==true)throw Error('页面未启动点选');}catch(e){await this.write({...p,status:'error',error:'点选启动失败，请回到页面重试'});throw e;}return {requestId:p.requestId};
 }
 if(m.type==='PURCHASE_PICK_STATUS')await this.reconcile();
 const p=await this.pending();if(!p||m.requestId!==p.requestId)throw Error('点选请求不存在或已失效');
 if(p.status==='pending'&&Date.now()>p.expiresAt)await this.abort('点选已超时');
 if(m.type==='PURCHASE_PICK_STATUS'){const current=await this.pending();return {requestId:p.requestId,status:current.status,...(current.result?{result:current.result}:{}),...(current.error?{error:current.error}:{})};}
 if(!results.has(m.type)||p.status!=='pending'||Date.now()>p.expiresAt)throw Error('点选请求已结束');
 if(sender.tab?.id!==p.tabId||sender.frameId!==0||p.documentId&&sender.documentId!==p.documentId)throw Error('点选页面不匹配');
 const actual=location(sender.url),live=location((await c.tabs.get(p.tabId)).url);if([actual,live].some(x=>x.origin!==p.origin||x.path!==p.path||JSON.stringify(x.query??{})!==JSON.stringify(p.query??{})))throw Error('页面已变化，请重新校准');
 if(m.type==='PURCHASE_PICK_CANCELLED'){await this.write({...p,status:'cancelled'});return {cancelled:true};}
 if(m.kind!==p.kind||m.fieldKey!==p.fieldKey||m.origin!==p.origin||m.path!==p.path)throw Error('点选结果不匹配');
 const result={locator:safeLocator(m.locator,p.kind,p.fieldKey),origin:p.origin,path:p.path,...(p.query?{query:p.query}:{})};await this.write({...p,status:'selected',result});return {selected:true};
 }
}
