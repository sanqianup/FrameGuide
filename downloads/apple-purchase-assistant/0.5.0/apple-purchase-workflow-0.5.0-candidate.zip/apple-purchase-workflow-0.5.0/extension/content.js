// Explicitly started current Apple tab, isolated world. All real actions stay locked.
// Observe immediately: never await window.load or network idle.
(()=>{
  if(globalThis.__applePreviewController)return;
  const D=globalThis.AppleDOMDriver;
  let task=null,timer=null,observer=null,lastTick=0,busy=false,pending=false,queued=false,generation=0,lastEvidence='';
  const terminal=new Set(['PAUSED','STOPPED','DONE','UNKNOWN']);
  const visible=el=>!!el&&el.isConnected!==false&&el.getClientRects().length>0&&getComputedStyle(el).visibility!=='hidden'&&getComputedStyle(el).display!=='none'&&!el.closest('[hidden],[inert],[aria-hidden="true"]');
  function stop(){generation++;task=null;clearTimeout(timer);timer=null;observer?.disconnect();observer=null;pending=false;lastEvidence='';}
  async function send(message){const r=await chrome.runtime.sendMessage(message);if(!r?.ok)throw Error(r?.error||'后台连接中断');return r;}
  function one(selector,root=document){
    if(!selector)return null;
    const all=[...root.querySelectorAll(selector)].filter(visible);
    if(all.length>1)throw Error('多个可见元素，需人工确认');
    return all[0]||null;
  }
  const aliases={region:['地区','Region'],model:['型号','Model'],storage:['容量','Storage'],color:['颜色','Color','Colour'],quantity:['数量','Quantity'],currency:['货币','Currency'],delivery:['送达方式','Delivery'],total:['含全部费用总价','订单总计','Order total','Total including tax and shipping']};
  function field(key,c,root){
    if(c.selectors[key])return one(c.selectors[key]);
    // Exact labeled summaries only. Never infer selected specs from all page text.
    const labels=[...root.querySelectorAll('dt')].filter(el=>visible(el)&&aliases[key].includes(el.textContent.trim()));
    if(labels.length>1)throw Error('规格摘要标签不唯一');
    const value=labels[0]?.nextElementSibling;
    return value?.tagName==='DD'&&visible(value)?value:null;
  }
  function snapshot(c){
    const u=new URL(location.href),configured=new URL(c.url);
    const sameObservedProduct=globalThis.AppleDuoReadonly?.supportsURL?.(u.href)&&globalThis.AppleDuoReadonly?.supportsURL?.(configured.href);
    if(u.protocol!=='https:'||!['www.apple.com.cn','www.apple.com'].includes(u.hostname)||(u.href!==configured.href&&!sameObservedProduct))throw Error('页面地址变化');
    if(!document.body)return null;
    const root=one('main,[role="main"]')||document.body;
    const text=key=>field(key,c,root)?.innerText?.trim()??'';
    const body=document.body.innerText;
    if(body.length>250000)throw Error('页面状态过大，不能完整验证');
    const sensitive=[...document.querySelectorAll('input,iframe')].filter(visible).some(el=>/password|cc-number|cc-csc|one-time-code|captcha|cardnumber|verification|银行卡|信用卡/i.test([el.type,el.name,el.autocomplete,el.title,el.id].join(' ')));
    let blocker=sensitive?'需要登录、验证码或支付信息，请人工处理':
      /验证码|人机验证|排队中|等候室|请求过于频繁|access denied|captcha|waiting room|unusual activity/i.test(body)?'验证、排队或访问限制，请人工处理':
      /Apple Pay|生物验证|银行卡|信用卡|付款方式|支付方式|payment method|card number|Face ID|Touch ID/i.test(body)?'需要付款或身份验证，请人工处理':
      /同意.{0,12}(条款|协议)|accept.{0,20}(terms|conditions)/i.test(body)?'法律条款需要人工处理':null;
    const pageEvidence=globalThis.AppleDuoReadonly?.inspect(document,{url:location.href,driver:D});
    if(pageEvidence?.supported){
      // This observed page is a configuration stage, not an order summary.
      // Even a caller-supplied selector must never promote Continue to a submit target.
      return {observedAt:Date.now(),model:pageEvidence.model??'',color:pageEvidence.color??'',storage:pageEvidence.storage??'',
        blocker:blocker||(pageEvidence.ambiguity.length?'规格页面证据不唯一，需要人工核对':'已识别规格配置页；继续不是下单按钮，后续购物袋与订单流程尚未核验'),
        pageEvidence,buttonUnique:false,buttonEnabled:false,countdownPresent:null,countdownText:'',totalMinor:null};
    }
    let button=c.selectors.button?one(c.selectors.button):null;
    if(!c.selectors.button&&D){
      const match=D.resolveTarget(root,{names:['添加到购物袋','加入购物袋','Add to Bag','Add to bag']});
      if(match.status==='ambiguous')throw Error('购买按钮不唯一');
      button=match.element||null;
    }
    if(button&&/^(?:继续|continue)$/iu.test((D?D.getName(button):button.innerText??'').trim())){blocker=blocker||'继续不是最终下单按钮，需核验当前流程';button=null;}
    const countdown=c.selectors.countdown?one(c.selectors.countdown):one('[role="timer"]',root),amount=text('total');
    const fields=Object.fromEntries(['region','model','storage','color','quantity','currency','delivery'].map(key=>[key,text(key).slice(0,160)]));
    // Incomplete initial render waits for mutation, but never guesses or waits forever.
    if(!blocker&&(!button||Object.values(fields).some(x=>!x)||!amount)&&Date.now()-task.started<10000)return null;
    return {...fields,observedAt:Date.now(),blocker,soldOut:/已售罄|暂时无货|sold out|out of stock/i.test(body),
      totalMinor:/^\d+(?:\.\d{1,2})?$/.test(amount)?Math.round(Number(amount)*100):null,
      countdownPresent:!!c.selectors.countdown||!!countdown,countdownText:countdown?.innerText?.trim().slice(0,100)??'',
      buttonUnique:!!button,buttonEnabled:!!button&&(D?D.isEnabled(button):!button.disabled&&button.getAttribute('aria-disabled')!=='true'&&button.getAttribute('aria-busy')!=='true')};
  }
  async function disconnect(){const id=task?.id;stop();if(id)await send({type:'DISCONNECT',taskId:id}).catch(()=>{});}
  function wake(){
    if(!task)return;if(busy){pending=true;return;}if(queued)return;
    queued=true;queueMicrotask(()=>{queued=false;void tick();});
  }
  async function tick(){
    if(!task||busy)return;busy=true;const current=task,version=generation;
    clearTimeout(timer);
    try{
      const now=Date.now();
      if(document.visibilityState!=='visible'||(lastTick&&now-lastTick>Math.max(5000,current.config.pollMs*2.5)))throw Error('页面隐藏或计时中断');
      const s=snapshot(current.config);
      if(s){
        const evidence=JSON.stringify({...s,observedAt:0});
        // Mutation bursts with no relevant change do not flood storage/background.
        if(evidence!==lastEvidence||now-lastTick>=Math.min(current.config.pollMs,1000)){
          lastEvidence=evidence;lastTick=now;
          const r=await send({type:'OBSERVE',taskId:current.id,snapshot:s});
          if(version!==generation)return;
          if(r.action==='mock-submit')throw Error('官网页面禁止任何提交');
          if(terminal.has(r.state)){stop();return;}
        }
      }
      const until=Math.max(0,Date.parse(current.config.targetTime)-Date.now());
      timer=setTimeout(wake,until>0?Math.min(current.config.pollMs,until):current.config.pollMs);
    }catch{if(version===generation)await disconnect();}finally{busy=false;if(pending){pending=false;wake();}}
  }
  chrome.runtime.onMessage.addListener((message,sender,reply)=>{
    if(sender.id!==chrome.runtime.id)return;
    if(message.type==='HALT'&&task?.id===message.taskId){stop();reply({ok:true});}
    if(message.type==='START_OBSERVING'){
      stop();
      if(message.config?.mode!=='official-readonly'){reply({ok:false});return;}
      task={id:message.taskId,config:message.config,started:Date.now()};lastTick=0;
      observer=new MutationObserver(wake);
      observer.observe(document,{subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:['disabled','aria-disabled','aria-busy','aria-label','aria-labelledby','role','hidden','inert','class','style','checked','aria-checked','name']});
      wake();reply({ok:true});
    }
  });
  addEventListener('pagehide',()=>{void disconnect();});
  document.addEventListener('change',wake,true);
  document.addEventListener('input',wake,true);
  document.addEventListener('visibilitychange',()=>{if(document.visibilityState!=='visible')void disconnect();});
  globalThis.__applePreviewController={stop};
})();
