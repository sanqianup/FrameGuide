import { test } from 'node:test';
import assert from 'node:assert/strict';
import '../extension/apple-store-observed.js';

const { inspect, supportsURL } = globalThis.AppleStoreObserved;
const BASE = 'https://www.apple.com.cn/shop/buy-iphone/iphone-18-pro';
const BAG = 'https://www.apple.com.cn/shop/bag';
const ATTACH = `${BASE}?product=mjt74ch/a&step=attach`;
const EXPECTED = { model: 'iPhone 18 Pro', storage: '256GB', color: '黑色', quantity: 1 };
const SUMMARY = 'iPhone 18 Pro 256GB 黑色';

// Semantic reconstructions of the supplied live observations, not a saved Apple
// DOM capture. Container tags below are test scaffolding, not claimed selectors.
class Element {
  constructor(doc, tag, text = '', attributes = {}) {
    this.ownerDocument = doc;
    this.nodeType = 1;
    this.tagName = tag.toUpperCase();
    this.ownText = text;
    this.attributes = new Map(Object.entries(attributes));
    this.parentElement = null;
    this.children = [];
    this.checked = false;
    this.disabled = false;
    this.hidden = false;
    this.inert = false;
    this.style = { display: 'block', visibility: 'visible', opacity: '1', contentVisibility: 'visible' };
    this.selectValue = '1';
    this.valueReads = 0;
  }
  get value() {
    assert.equal(this.tagName, 'SELECT', 'No input, password, payment, or textarea value reads');
    this.valueReads++;
    return this.selectValue;
  }
  set value(_) { assert.fail('Read-only adapter cannot set a value'); }
  get textContent() {
    assert.ok(!/^(?:INPUT|TEXTAREA|SELECT|IFRAME)$/u.test(this.tagName), 'Control contents must not be read');
    return this.ownText + this.children.map(child => child.textContent).join('');
  }
  get isConnected() { return this.ownerDocument.contains(this); }
  getAttribute(name) {
    assert.ok(!['value', 'src', 'href', 'action', 'formaction'].includes(name), `Do not read sensitive attributes: ${name}`);
    return this.attributes.get(name) ?? null;
  }
  hasAttribute(name) { return this.attributes.has(name); }
  setAttribute(name, value) { this.attributes.set(name, String(value)); }
  append(...children) { for (const child of children) { child.parentElement = this; this.children.push(child); } }
  remove() {
    if (this.parentElement) this.parentElement.children = this.parentElement.children.filter(child => child !== this);
    this.parentElement = null;
  }
  contains(node) { return node === this || this.children.some(child => child.contains(node)); }
  matches(selector) {
    if (selector.includes(',')) return selector.split(',').some(part => this.matches(part));
    if (selector === '*') return true;
    if (selector === ':disabled') return this.disabled;
    const match = /^(\w+)?(?:\[([\w-]+)(?:="([^"]*)")?\])?$/u.exec(selector);
    if (!match) throw Error(`Unsupported test selector: ${selector}`);
    return (!match[1] || this.tagName.toLowerCase() === match[1]) &&
      (!match[2] || this.hasAttribute(match[2]) && (match[3] === undefined || this.getAttribute(match[2]) === match[3]));
  }
  querySelectorAll(selector) {
    return this.children.flatMap(child => [...(child.matches(selector) ? [child] : []), ...child.querySelectorAll(selector)]);
  }
  getClientRects() { return this.isConnected && !this.hidden && this.style.display !== 'none' ? [{}] : []; }
  click() { assert.fail('Read-only adapter cannot click'); }
  focus() { assert.fail('Read-only adapter cannot focus'); }
  dispatchEvent() { assert.fail('Read-only adapter cannot dispatch'); }
}
class Document {
  constructor() {
    this.nodeType = 9;
    this.defaultView = { getComputedStyle: node => node.style };
    this.body = new Element(this, 'body');
  }
  element(...args) { return new Element(this, ...args); }
  contains(node) { return this.body.contains(node); }
  querySelectorAll(selector) { return this.body.querySelectorAll(selector); }
}
function fixture(kind, suffix = 'dynamic-uuid-a') {
  const doc = new Document(), main = doc.element('main');
  doc.body.append(main);
  const refs = {};
  if (kind !== 'login') {
    refs.summary = doc.element('h2', SUMMARY);
    if (kind !== 'configuration') main.append(refs.summary);
  }
  if (kind === 'configuration') {
    const names = ['iPhone 18 Pro 6.3 英寸显示屏', '黑色', '256GB', '不折抵换购', '不加 AppleCare+ 服务计划'];
    refs.radios = names.map((name, index) => {
      const id = index === 3 ? 'noTradeIn' : `option-${suffix}-${index}`;
      const radio = doc.element('input', '', { type: 'radio', id });
      const label = doc.element('label', name, { for: id });
      radio.checked = true;
      main.append(radio, label);
      return radio;
    });
    refs.add = doc.element('button', '添加到购物袋');
    main.append(refs.add);
  }
  if (kind === 'attach') {
    refs.view = doc.element('button', '查看购物袋');
    main.append(refs.view);
  }
  if (kind === 'bag') {
    refs.quantity = doc.element('select', '', { id: suffix });
    refs.quantityLabel = doc.element('label', '数量', { for: suffix });
    main.append(refs.quantityLabel, refs.quantity);
    refs.totals = {};
    for (const [label, text] of [['小计', 'RMB 9,999'], ['运费', '免费'], ['总计', 'RMB 9,999']]) {
      const row = doc.element('div'), name = doc.element('span', label), value = doc.element('span', text);
      row.append(name, value);
      main.append(row);
      refs.totals[label] = { row, name, value };
    }
    refs.checkout = ['shoppingCart.actions.navCheckout', 'shoppingCart.actions.checkout'].map(id => {
      // The supplied evidence established IDs, not the complete accessible name.
      const node = doc.element('button', '', { id });
      main.append(node);
      return node;
    });
  }
  if (kind === 'login') {
    refs.frame = doc.element('iframe', '', { id: 'aid-auth-widget-iFrame', name: 'aid-auth-widget' });
    main.append(refs.frame, doc.element('input', '', { type: 'password', value: 'never-read' }));
  }
  const url = { configuration: BASE, attach: ATTACH, bag: BAG, login: 'https://secure6.www.apple.com.cn/shop/signIn?session=SECRET' }[kind];
  return { doc, main, refs, url, read: expected => inspect(doc, url, expected ?? EXPECTED) };
}

test('exact observed configuration exposes checked semantic choices and add descriptor only', () => {
  const { read, refs } = fixture('configuration');
  const result = read();
  assert.equal(result.pageKind, 'configuration');
  assert.equal(result.product.summary, null, 'Separate radios must not invent a combined summary');
  assert.deepEqual(Object.keys(result.selections), ['model', 'color', 'storage', 'tradeIn', 'appleCare']);
  for (const option of Object.values(result.selections)) assert.equal(option.selected, true);
  assert.deepEqual(result.actions.addToBag, { status: 'ready', candidates: [{ role: 'button', name: '添加到购物袋', enabled: true }] });
  refs.radios[1].checked = false;
  refs.radios[1].setAttribute('checked', '');
  assert.equal(read().selections.color.selected, false, 'Only live checked state establishes selection');
});

test('storage accepts observed accessible name containing 256GB without confusing 1256GB', () => {
  const { doc, read } = fixture('configuration');
  const labels = doc.querySelectorAll('label');
  labels[2].ownText = '256GB RMB 9,999';
  assert.equal(read().selections.storage.selected, true);
  labels[2].ownText = '1256GB';
  assert.equal(read().selections.storage.selected, null);
});

test('attach requires the exact complete product text and exposes only view-bag action', () => {
  const { read, refs } = fixture('attach');
  const result = read();
  assert.deepEqual(result.product, { summary: SUMMARY, model: 'iPhone 18 Pro', storage: '256GB', color: '黑色', matchesExpected: true });
  assert.deepEqual(Object.keys(result.actions), ['viewBag']);
  refs.summary.ownText = 'iPhone 18 Pro 512GB 黑色';
  assert.equal(read().product.summary, null);
});

test('combined product text never substring-matches another model, color, or storage', () => {
  const { read, refs } = fixture('bag');
  for (const text of ['iPhone 18 Pro Max 256GB 黑色', `${SUMMARY} 保护壳`, 'iPhone 18 Pro 256GB 白色', 'iPhone 18 Pro 1256GB 黑色']) {
    refs.summary.ownText = text;
    assert.equal(read().product.matchesExpected, null);
  }
  refs.summary.ownText = SUMMARY;
  assert.equal(read({ ...EXPECTED, storage: '512GB' }).product.matchesExpected, false);
});

test('observed bag reads unique semantic quantity and unique labelled totals without inferring tax or full inventory', () => {
  const { read, refs } = fixture('bag');
  const result = read();
  assert.equal(result.cart.quantity, 1);
  assert.equal(result.cart.quantityMatchesExpected, true);
  assert.equal(result.cart.quantityControlCount, 1);
  assert.equal(result.cart.subtotalMinor, 999900);
  assert.equal(result.cart.shippingMinor, 0);
  assert.equal(result.cart.totalMinor, 999900);
  assert.equal(result.cart.currency, 'CNY');
  assert.equal(result.cart.totalIncludesTaxShipping, null);
  assert.equal(result.cart.itemCount, null);
  assert.equal(result.cart.noExtraItems, null);
  assert.ok(result.evidenceMissing.includes('complete-cart-inventory'));
  assert.equal(refs.quantity.valueReads, 1);
});

test('quantity IDs may change entirely without becoming selectors or emitted data', () => {
  for (const id of ['7d9e00c4-4a2c-4f6e-a065-26551e9d9744', 'other-runtime-id']) {
    const result = fixture('bag', id).read();
    assert.equal(result.cart.quantity, 1);
    assert.equal(JSON.stringify(result).includes(id), false);
  }
});

test('two observed checkout IDs remain ambiguous rather than silently picking one', () => {
  const { read, refs } = fixture('bag');
  let result = read();
  assert.equal(result.actions.checkout.status, 'ambiguous');
  assert.equal(result.actions.checkout.candidates.length, 2);
  assert.ok(result.ambiguity.includes('checkout:multiple-controls'));
  assert.deepEqual(result.actions.checkout.candidates.map(candidate => candidate.selector), [
    'button[id="shoppingCart.actions.navCheckout"]', 'button[id="shoppingCart.actions.checkout"]'
  ]);
  refs.checkout[1].disabled = true;
  assert.equal(read().actions.checkout.status, 'ambiguous', 'A disabled duplicate does not disambiguate');
  refs.checkout[1].hidden = true;
  result = read();
  assert.equal(result.actions.checkout.status, 'ready');
});

test('duplicate checkout ID is also ambiguous, even with the second known control absent', () => {
  const { read, refs } = fixture('bag');
  refs.checkout[1].setAttribute('id', 'shoppingCart.actions.navCheckout');
  assert.equal(read().actions.checkout.status, 'ambiguous');
});

test('additional quantity controls block quantity reads and never establish a clean bag', () => {
  const { doc, main, read, refs } = fixture('bag');
  const extra = doc.element('select', '', { 'aria-label': '数量' });
  main.append(extra);
  const result = read();
  assert.equal(result.cart.quantityControlCount, 2);
  assert.equal(result.cart.quantity, null);
  assert.equal(refs.quantity.valueReads, 0);
  assert.equal(extra.valueReads, 0);
  assert.equal(result.cart.noExtraItems, null);
  assert.ok(result.ambiguity.includes('quantity:multiple-controls'));
});

test('duplicate quantity label references fail closed before any select value read', () => {
  const { doc, main, refs, read } = fixture('bag');
  refs.quantity.setAttribute('aria-labelledby', 'quantity-name');
  main.append(doc.element('span', '数量', { id: 'quantity-name' }), doc.element('span', '数量', { id: 'quantity-name' }));
  assert.equal(read().cart.quantity, null);
  assert.equal(refs.quantity.valueReads, 0);
});

test('unrelated selects and credential fields are never read', () => {
  const { doc, main, read } = fixture('bag');
  const unrelated = doc.element('select', '', { 'aria-label': '付款方式' });
  main.append(unrelated, doc.element('input', '', { type: 'password' }), doc.element('input', '', { autocomplete: 'cc-number' }));
  assert.equal(read().cart.quantity, 1);
  assert.equal(unrelated.valueReads, 0);
});

test('invalid quantity is unknown, and a valid changed quantity is an explicit mismatch', () => {
  const { refs, read } = fixture('bag');
  for (const value of ['0', '-1', '1.0', '1abc', '9007199254740992', '']) {
    refs.quantity.selectValue = value;
    assert.equal(read().cart.quantity, null);
  }
  refs.quantity.selectValue = '2';
  assert.equal(read().cart.quantity, 2);
  assert.equal(read().cart.quantityMatchesExpected, false);
});

test('duplicate total labels, including disabled-looking copies, remain ambiguous', () => {
  const { doc, main, read } = fixture('bag');
  const row = doc.element('div'), label = doc.element('span', '总计'), amount = doc.element('span', 'RMB 9,999');
  row.append(label, amount);
  main.append(row);
  const result = read();
  assert.equal(result.cart.totalMinor, null);
  assert.ok(result.ambiguity.includes('totalMinor:multiple-labels'));
});

test('unlabelled amounts and loose neighboring prices cannot establish totals', () => {
  const { refs, doc, main, read } = fixture('bag');
  refs.totals['总计'].value.remove();
  main.append(doc.element('span', 'RMB 9,999'));
  assert.equal(read().cart.totalMinor, null);
  refs.totals['小计'].row.append(doc.element('span', 'discount'));
  assert.equal(read().cart.subtotalMinor, null);
});

test('strict money parser rejects malformed or alternative-currency values', () => {
  const { refs, read } = fixture('bag');
  for (const text of ['RMB 9,99', 'RMB 9,999.999', '$9,999', 'USD 9,999', '9999 or 10999', '-9999']) {
    refs.totals['总计'].value.ownText = text;
    assert.equal(read().cart.totalMinor, null, text);
  }
  refs.totals['总计'].value.ownText = '￥9,999.50';
  assert.equal(read().cart.totalMinor, 999950);
});

test('hidden evidence does not create a second match or revive hidden ancestor controls', () => {
  const { doc, main, read, refs } = fixture('configuration');
  const hidden = doc.element('section');
  hidden.hidden = true;
  hidden.append(doc.element('button', '添加到购物袋'));
  main.append(hidden);
  assert.equal(read().actions.addToBag.status, 'ready');
  refs.add.style.opacity = '0';
  assert.equal(read().actions.addToBag.status, 'missing');
});

test('duplicate product headings do not establish a unique product summary', () => {
  const { doc, main, read } = fixture('bag');
  main.append(doc.element('h2', SUMMARY));
  const result = read();
  assert.equal(result.product.summary, null);
  assert.ok(result.ambiguity.includes('product:multiple-summaries'));
});

test('exact sign-in endpoint stops at widget metadata without reading credentials or retaining session query', () => {
  const { read } = fixture('login');
  const result = read();
  assert.equal(result.supported, true);
  assert.equal(result.pageKind, 'sign-in');
  assert.equal(result.authenticationRequired, true);
  assert.equal(result.loginWidgetObserved, true);
  assert.deepEqual(result.actions, {});
  const output = JSON.stringify(result);
  for (const text of ['SECRET', 'session', 'secure6', 'never-read']) assert.equal(output.includes(text), false);
});

test('lookalike hosts, unrelated secure hosts and paths are rejected before touching the document', () => {
  const doc = { nodeType: 9, querySelectorAll() { assert.fail('Unsupported URL must not touch DOM'); } };
  const bad = [
    'http://www.apple.com.cn/shop/bag', 'https://www.apple.com.cn.evil.test/shop/bag',
    'https://apple.com.cn/shop/bag', 'https://www.apple.com.cn:444/shop/bag',
    'https://user@www.apple.com.cn/shop/bag', 'https://www.apple.com.cn/shop/bag#fragment',
    'https://secure7.www.apple.com.cn/shop/signIn?session=private',
    'https://secure6.www.apple.com.cn.evil.test/shop/signIn',
    'https://secure6.www.apple.com.cn/shop/unknown', `${BASE}/other-sku/a`,
    `${BASE}?product=other/a&step=attach`, `${BASE}?product=mjt74ch/a&step=attach&session=private`,
    `${ATTACH}&product=mjt74ch/a`, `${BAG}?session=private`, 'not a url'
  ];
  for (const url of bad) {
    assert.equal(supportsURL(url), false, url);
    assert.equal(inspect(doc, url, EXPECTED).supported, false);
  }
});

test('both observed product paths and only the exact attach parameter set are supported', () => {
  for (const url of [BASE, `${BASE}/mjt74ch/a`, ATTACH, `${BASE}?step=attach&product=mjt74ch%2Fa`, BAG]) assert.equal(supportsURL(url), true);
});

test('returned facts serialize without DOM handles, callbacks, raw URLs, or capabilities', () => {
  for (const kind of ['configuration', 'attach', 'bag', 'login']) {
    const result = fixture(kind).read();
    assert.deepEqual(JSON.parse(JSON.stringify(result)), result);
    const serialized = JSON.stringify(result);
    for (const key of ['ownerDocument', 'textContent', 'https://', 'click', 'submitTarget', 'addressValues']) assert.equal(serialized.includes(key), false);
  }
  assert.deepEqual(Object.keys(globalThis.AppleStoreObserved), ['inspect', 'supportsURL']);
});


test('a deceptive quantity label cannot permit a payment or authentication select value read', () => {
  const { refs, read } = fixture('bag');
  refs.quantity.setAttribute('autocomplete', 'cc-exp-month');
  let result = read();
  assert.equal(result.cart.quantity, null);
  assert.ok(result.ambiguity.includes('quantity:sensitive-control'));
  assert.equal(refs.quantity.valueReads, 0);
  refs.quantity.setAttribute('autocomplete', 'one-time-code');
  result = read();
  assert.equal(result.cart.quantity, null);
  assert.equal(refs.quantity.valueReads, 0);
});

test('public product text mixed with editable or sensitive descendants is not read', () => {
  const { doc, refs, read } = fixture('bag');
  refs.summary.append(doc.element('input', '', { type: 'password' }));
  assert.equal(read().product.summary, null);
});

test('unrecognized quantity-adjacent line items cannot be asserted absent', () => {
  const { doc, main, read } = fixture('bag');
  main.append(doc.element('h2', 'USB-C 充电线'));
  const result = read();
  assert.equal(result.cart.quantity, 1);
  assert.equal(result.cart.noExtraItems, null);
  assert.equal(result.cart.itemCount, null);
});

test('malformed label and reader failures produce no partial trustworthy snapshot', () => {
  const { doc, url } = fixture('bag');
  doc.querySelectorAll = () => { throw Error('reader failed'); };
  const result = inspect(doc, url, EXPECTED);
  assert.equal(result.cart.totalMinor, null);
  assert.equal(result.product.summary, null);
  assert.ok(result.evidenceMissing.includes('dom-inspection'));
});


test('observed maintenance notice blocks evidence/actions without inferring a countdown or release date', () => {
  const { doc, main, read } = fixture('bag');
  main.append(doc.element('p', '来得早，来得好。即将与你见面。北京时间晚8点接受预购。一会儿见。'));
  const result = read();
  assert.equal(result.blocker, 'maintenance-preorder-paused');
  assert.equal(result.preorderNoticeObserved, true);
  assert.deepEqual(result.actions, {});
  assert.equal(result.cart.quantity, null);
  assert.equal(result.cart.totalMinor, null);
  for (const key of ['countdown', 'releaseAt', 'nextActionAt']) assert.equal(key in result, false);
});

test('split maintenance copy is recognized, but an isolated 8pm phrase is not a countdown', () => {
  const { doc, main, read } = fixture('configuration');
  const copy = ['来得早，来得好。', '即将与你见面。', '北京时间晚 8 点接受预购。', '一会儿见。'];
  const nodes = copy.map(text => doc.element('p', text));
  main.append(...nodes);
  assert.equal(read().blocker, 'maintenance-preorder-paused');
  nodes[0].remove();
  nodes[1].remove();
  nodes[3].remove();
  assert.equal(read().blocker, null);
});


test('verified secure checkout route reads maintenance only and never maps address/payment actions', () => {
  const { doc, main } = fixture('bag');
  main.append(doc.element('input', '', { autocomplete: 'street-address' }), doc.element('input', '', { autocomplete: 'cc-number' }));
  const url = 'https://secure6.www.apple.com.cn/shop/checkout?session=SECRET';
  let result = inspect(doc, url, EXPECTED);
  assert.equal(result.supported, true);
  assert.equal(result.pageKind, 'checkout-observation');
  assert.equal(result.product.summary, null);
  assert.equal(result.cart.totalMinor, null);
  assert.deepEqual(result.actions, {});
  assert.ok(result.evidenceMissing.includes('checkout-stage-not-mapped'));
  assert.equal(JSON.stringify(result).includes('SECRET'), false);
  main.append(doc.element('p', '来得早，来得好。即将与你见面。北京时间晚8点接受预购。一会儿见。'));
  result = inspect(doc, url, EXPECTED);
  assert.equal(result.blocker, 'maintenance-preorder-paused');
  assert.deepEqual(result.actions, {});
});
