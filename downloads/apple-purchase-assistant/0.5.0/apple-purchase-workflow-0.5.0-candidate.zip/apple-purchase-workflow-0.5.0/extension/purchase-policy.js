// Shared conservative text policy. These helpers only corroborate exact mapped
// statements; their presence never grants permission or substitutes for totals.
(() => {
  'use strict';
  if (globalThis.PurchasePolicy) return;
  const normalize = value => String(value ?? '').normalize('NFKC').replace(/\s+/gu, ' ').trim();
  const noCharge = /\b(?:no\s+(?:immediate\s+)?(?:charges?|payment)|will\s+not\s+(?:be\s+)?(?:charged?|pay)|(?:will|is)\s+not\s+(?:be\s+)?(?:charged|debited)|without\s+(?:charging|payment))\b|不会(?:立即)?(?:扣款|收款|付款|支付)|不(?:会)?(?:扣款|收费)|无[需须](?:立即)?(?:付款|支付)/iu;
  function withoutSafePhrases(value) {
    return normalize(value).replace(/\b(?:unpaid|no\s+(?:immediate\s+)?(?:charges?|payment)|will\s+not\s+(?:be\s+)?(?:charged?|pay)|(?:will|is)\s+not\s+(?:be\s+)?(?:charged|debited)|without\s+(?:charging|payment))\b|不会(?:立即)?(?:扣款|收款|付款|支付)|不(?:会)?(?:扣款|收费)|无[需须](?:立即)?(?:付款|支付)|未付款|待付款|未支付|待支付/giu, '');
  }
  function paymentCommitment(value) {
    const original = normalize(value), text = withoutSafePhrases(original);
    if (/\b(?:not\s+(?:without\s+(?:payment|charging)|(?:a\s+)?no\s+charge)|no\s+no\s+charge|cannot\s+guarantee.{0,30}(?:no\s+charge|not\s+(?:be\s+)?charged))\b|(?:并非|不是|不保证|无法保证|不能保证).{0,15}(?:不会|不扣|无需|无须)|不(?:是|保证).{0,15}未付/iu.test(original)) return true;
    if (/\b(?:not\s+(?:an?\s+)?unpaid|no\s+longer\s+unpaid)\b|不是未付|并非未付/iu.test(original)) return true;
    if (/\b(?:card|account|payment\s+method|balance)\b.{0,60}\b(?:charg(?:e|ed|es|ing)|debit(?:ed|s|ing)?)\b|\b(?:charg(?:e|ed|es|ing)|debit(?:ed|s|ing)?)\b.{0,24}\b(?:upon|when|after)\b|(?:发货|配送|送达|签收|出库|交付).{0,12}(?:扣款|收款|付款|支付|收费)/iu.test(text)) return true;
    return /\b(?:will|would|shall|may|might|can|could|is|are|automatic(?:ally)?|authorize|authorise|authorization|consent|agree|accept|later|subsequently)\b.{0,80}\b(?:charg(?:e|ed|es|ing)|debit(?:ed)?|payment|pay)\b|\b(?:charg(?:e|ed|es|ing)|pay)\s+(?:now|later|immediately)\b|\b(?:payment|charge|debit)\b.{0,30}\b(?:will|automatic(?:ally)?)\b.{0,30}\b(?:collected|processed|taken|occur)\b|(?:自动|随后|稍后|将|会|授权|委托|同意|承诺).{0,20}(?:扣款|收款|付款|支付|收费)|(?:立即|现在|马上)(?:付款|支付|扣款)/iu.test(text);
  }
  function positiveNoCharge(value) { const text = normalize(value); return noCharge.test(text) && !paymentCommitment(text); }
  function unpaidOrderResult(value) {
    const text = normalize(value);
    // A mapped result is evidence of completed creation, not a promise, failure,
    // or negated success. Keep legitimate unpaid/payment-pending wording while
    // refusing contradictory clauses anywhere in the selected result text.
    const proof = withoutSafePhrases(text).replace(/\b(?:payment\s+pending|pending\s+payment|awaiting\s+payment)\b/giu, '');
    if (/\b(?:not|never|cannot|can[’']t|couldn[’']t|didn[’']t|hasn[’']t|haven[’']t|wasn[’']t|weren[’']t|isn[’']t|aren[’']t|fail(?:ed|ure)?|error|unsuccessful|unable|rejected|cancell?ed|declined|pending|processing|awaiting|retry|unknown|being)\b|\bno(?:\s+\w+){0,6}\s+orders?\b|(?:失败|出错|错误|异常|取消|拒绝|尚未|未能|未完成|未成功|并未|没有|正在|即将|等待|待确认|待创建)|(?:未|不).{0,12}(?:创建|生成|下单|提交|完成)|(?:创建|生成|下单|提交|处理)中/iu.test(proof)) return false;
    if (/\b(?:will|would|shall|may|might|can|could|should|going\s+to|about\s+to|to\s+be)\b.{0,60}\b(?:created?|placed?|receiv(?:e|ed))\b|将.{0,12}(?:创建|生成|下单|提交)/iu.test(proof)) return false;
    return /\bunpaid\b|未付款|待付款|未支付|待支付/iu.test(text) && /\border\b|订单/iu.test(text) &&
      /\b(?:created|placed|received)\b|创建|生成|(?:下单|提交)成功/iu.test(text) && !paymentCommitment(text);
  }
  function unsafeAction(value) {
    return /(?:\b(?:pay\s*(?:now|with)?|payment|charge|charged|charging|authorize|authorise|sign\s*in|log\s*in|captcha)\b|(?:accept|agree).{0,24}(?:terms|conditions)|付款|支付|扣款|登录|登陆|验证码|人机验证|同意.{0,16}(?:条款|协议))/iu.test(withoutSafePhrases(value));
  }
  globalThis.PurchasePolicy = Object.freeze({ positiveNoCharge, paymentCommitment, unpaidOrderResult, unsafeAction });
})();
