// Shared semantic reads; the only action helper is locked to this extension's local fixture.
// Classic script so it can also be injected into the isolated, read-only content world.
(() => {
  'use strict';
  if (globalThis.AppleDOMDriver) return;

  const interactive = 'button,input[type="button"],input[type="submit"],input[type="reset"],a[href],[role="button"],[role="link"]';
  const specKeys = ['region', 'model', 'storage', 'color', 'quantity', 'currency', 'delivery'];
  const documentClaims = new WeakMap();
  const normalize = value => String(value ?? '').normalize('NFKC').replace(/\s+/gu, ' ').trim();
  const docOf = root => root?.nodeType === 9 ? root : root?.ownerDocument;
  const contains = (root, node) => root === node || !!root?.contains?.(node);

  function isVisible(element) {
    if (!element || element.isConnected === false || !element.getClientRects?.().length) return false;
    const view = element.ownerDocument?.defaultView;
    for (let current = element; current; current = current.parentElement) {
      if (current.hidden || current.getAttribute?.('aria-hidden') === 'true') return false;
      const style = view?.getComputedStyle?.(current);
      if (style && (style.display === 'none' || style.visibility === 'hidden' ||
        style.visibility === 'collapse' || style.opacity === '0' || style.contentVisibility === 'hidden')) return false;
    }
    return true;
  }

  function isEnabled(element) {
    if (!element || element.disabled || element.matches?.(':disabled')) return false;
    for (let current = element; current; current = current.parentElement) {
      if (current.inert || current.hasAttribute?.('inert') || current.getAttribute?.('aria-disabled') === 'true' ||
        current.getAttribute?.('aria-busy') === 'true') return false;
    }
    return true;
  }

  function getName(element) {
    const input = element.tagName?.toLowerCase() === 'input';
    // A misleading role must never cause password, payment or other form values to be read.
    if (input && !['button', 'submit', 'reset'].includes((element.getAttribute?.('type') ?? '').toLowerCase())) return '';
    const labelledBy = normalize(element.getAttribute?.('aria-labelledby'));
    if (labelledBy) {
      const labels = labelledBy.split(' ').map(id => element.ownerDocument?.getElementById?.(id));
      // Broken label references are unsafe to guess around.
      if (labels.some(label => !label)) return '';
      return normalize(labels.map(label => label.textContent ?? '').join(' '));
    }
    const ariaLabel = element.getAttribute?.('aria-label');
    if (ariaLabel !== null && ariaLabel !== undefined) return normalize(ariaLabel);
    if (input) return normalize(element.getAttribute?.('value') ?? '');
    return normalize(element.innerText ?? element.textContent ?? '');
  }

  function inContext(element, context, root) {
    if (!context) return true;
    if (typeof context === 'function') return context(element) === true;
    if (typeof context.contains === 'function') return contains(context, element);
    if (typeof context === 'string') context = { selector: context };
    if (typeof context !== 'object' || (!context.selector && !context.text)) return false;
    for (let current = element; current && contains(root, current); current = current.parentElement) {
      if (context.selector && !current.matches?.(context.selector)) continue;
      if (context.text && !normalize(current.innerText ?? current.textContent).includes(normalize(context.text))) continue;
      return true;
    }
    return false;
  }

  /** Freshly resolves exact accessible names. Hidden matches are ignored; disabled duplicates are ambiguous. */
  function resolveTarget(root, { names, context } = {}) {
    const wanted = new Set((Array.isArray(names) ? names : [names]).map(normalize).filter(Boolean));
    if (!root?.querySelectorAll || wanted.size === 0) return { status: 'missing', element: null, matches: [] };
    try {
      const candidates = [...root.querySelectorAll(interactive)];
      if (root.matches?.(interactive)) candidates.unshift(root);
      const matches = [...new Set(candidates)].filter(element => contains(root, element) && isVisible(element) &&
        wanted.has(getName(element)) && inContext(element, context, root));
      if (matches.length > 1) return { status: 'ambiguous', element: null, matches };
      if (matches.length === 0) return { status: 'missing', element: null, matches };
      if (!isEnabled(matches[0])) return { status: 'disabled', element: matches[0], matches };
      return { status: 'ready', element: matches[0], matches };
    } catch {
      return { status: 'invalid-context', element: null, matches: [] };
    }
  }

  /** Observe first, scan immediately on a microtask, then coalesce wakes without overlapping async scans. */
  function createObserverLoop({ root, scan, MutationObserverCtor = docOf(root)?.defaultView?.MutationObserver ?? globalThis.MutationObserver,
    schedule = callback => queueMicrotask(callback), cancel = () => {}, onError = () => {}, ignoreMutations,
    observerOptions = { subtree: true, childList: true, attributes: true, characterData: true } } = {}) {
    if (!root || typeof scan !== 'function' || typeof MutationObserverCtor !== 'function') throw Error('Observer root, scan and MutationObserver are required');
    let stopped = false, queued = false, running = false, dirty = false, handle;
    const reasons = new Set();
    const observer = new MutationObserverCtor(records => {
      if (!ignoreMutations || !ignoreMutations(records)) wake('mutation');
    });
    function stop() {
      if (stopped) return;
      stopped = true;
      observer.disconnect();
      if (queued) cancel(handle);
      queued = false;
      dirty = false;
      reasons.clear();
    }
    function wake(reason = 'manual') {
      if (stopped) return;
      dirty = true;
      reasons.add(reason);
      if (queued || running) return;
      queued = true;
      handle = schedule(run);
    }
    async function run() {
      queued = false;
      if (stopped || running || !dirty) return;
      running = true;
      dirty = false;
      const currentReasons = [...reasons];
      reasons.clear();
      try { await scan({ root, reasons: currentReasons }); }
      catch (error) { stop(); try { await onError(error); } catch { /* stopped and fail-closed */ } }
      finally { running = false; if (dirty && !stopped) wake('dirty'); }
    }
    observer.observe(root, observerOptions);
    wake('initial');
    return Object.freeze({ wake, stop, get stopped() { return stopped; }, get running() { return running; } });
  }

  function localDocument({ root, scope, runtime, location, expected }) {
    const doc = docOf(root);
    if (!doc || !scope || !contains(root, scope) || scope.ownerDocument !== doc || scope.isConnected === false ||
      scope.getAttribute?.('data-local-fixture') !== 'purchase' || expected?.mode !== 'simulate') return null;
    try {
      const actual = new URL(doc.defaultView?.location?.href ?? doc.location?.href ?? location?.href);
      const provided = location?.href ? new URL(location.href) : actual;
      const allowed = new URL(runtime.getURL('simulator.html'));
      if (allowed.protocol !== 'chrome-extension:' || !/^[a-p]{32}$/.test(allowed.hostname) || allowed.hostname !== runtime.id ||
        allowed.pathname !== '/simulator.html' || actual.protocol !== allowed.protocol || actual.hostname !== allowed.hostname ||
        actual.pathname !== '/simulator.html' || actual.username || actual.password || actual.port || actual.hash ||
        actual.href !== provided.href) return null;
      return doc;
    } catch { return null; }
  }

  function validateSnapshot(snapshot, expected) {
    if (!snapshot || typeof snapshot.then === 'function') return 'synchronous-snapshot-required';
    if (snapshot.blocker || snapshot.soldOut) return 'fixture-blocked';
    for (const key of specKeys) {
      if (expected[key] === undefined || expected[key] === null || normalize(expected[key]) === '' ||
        String(snapshot[key] ?? '') !== String(expected[key])) return `spec-mismatch:${key}`;
    }
    if (!Number.isSafeInteger(expected.totalMinor) || expected.totalMinor < 0 ||
      !Number.isSafeInteger(expected.maxTotalMinor) || expected.maxTotalMinor < 0 ||
      !Number.isSafeInteger(snapshot.totalMinor) || snapshot.totalMinor < 0) return 'invalid-price';
    if (snapshot.totalMinor !== expected.totalMinor) return 'price-changed';
    if (snapshot.totalMinor > expected.maxTotalMinor) return 'price-over-limit';
    return null;
  }

  /**
   * One local virtual action per document, including after target/scope replacement.
   * The caller must also keep its durable task claim; this is the DOM-side guard only.
   * data-fixture-ready is emitted by the fixture after its handlers are attached.
   * data-fixture-result must transition from pending/empty to confirmed or unknown.
   * A supplied confirmer can also be async; a hung promise never suppresses the timeout.
   */
  async function clickLocalFixture(options = {}) {
    const { root, scope, target, runtime = globalThis.chrome?.runtime, location = globalThis.location, expected,
      readSnapshot, lock, confirmationTimeoutMs = 1000,
      MutationObserverCtor = docOf(root)?.defaultView?.MutationObserver ?? globalThis.MutationObserver,
      confirmTransition = () => scope.getAttribute('data-fixture-result'), signal } = options;
    const reply = (outcome, reason, clicked = false, extra = {}) => ({ outcome, reason, clicked, ...extra });
    const doc = localDocument({ root, scope, runtime, location, expected });
    if (!doc) return reply('blocked', 'extension-local-fixture-required');
    if (!lock || typeof lock !== 'object' || typeof readSnapshot !== 'function' || typeof confirmTransition !== 'function' ||
      typeof MutationObserverCtor !== 'function' || !Number.isFinite(confirmationTimeoutMs) || confirmationTimeoutMs < 1 ||
      confirmationTimeoutMs > 10000) return reply('blocked', 'invalid-action-options');
    const previous = documentClaims.get(doc);
    if (previous || lock.attempted) {
      const result = previous?.result ?? lock.result;
      return reply(result?.outcome ?? 'unknown', result?.reason ?? 'already-attempted', false, { reused: true });
    }
    if (signal?.aborted) return reply('blocked', 'aborted');
    if (scope.getAttribute('data-fixture-ready') !== 'true') return reply('waiting', 'fixture-not-ready');
    const resolution = resolveTarget(root, target);
    if (resolution.status !== 'ready') return reply(resolution.status === 'missing' || resolution.status === 'disabled' ? 'waiting' : 'blocked', `target-${resolution.status}`);
    const element = resolution.element;
    if (!contains(scope, element)) return reply('blocked', 'target-outside-fixture');
    if (element.tagName?.toLowerCase() !== 'button' || element.form || element.closest?.('form') ||
      element.hasAttribute?.('formaction')) return reply('blocked', 'local-button-required');
    const before = scope.getAttribute('data-fixture-result');
    if (before && before !== 'pending') return reply('blocked', 'preexisting-transition');
    let fault;
    try { fault = validateSnapshot(readSnapshot(), expected); }
    catch { fault = 'snapshot-error'; }
    if (fault) return reply('blocked', fault);
    // A snapshot callback must not cause stale-element use or change readiness/context.
    if (!localDocument({ root, scope, runtime, location, expected }) || scope.getAttribute('data-fixture-ready') !== 'true' ||
      scope.getAttribute('data-fixture-result') !== before) return reply('blocked', 'preflight-changed');
    const fresh = resolveTarget(root, target);
    if (fresh.status !== 'ready' || fresh.element !== element || !contains(scope, element)) return reply('blocked', 'target-changed-during-preflight');

    return new Promise(resolve => {
      let finished = false, clicked = false, checking = false, dirty = false, timer, observer;
      const claim = { result: null };
      const finish = (outcome, reason) => {
        if (finished) return;
        finished = true;
        clearTimeout(timer);
        observer?.disconnect();
        signal?.removeEventListener?.('abort', aborted);
        const result = reply(outcome, reason, clicked);
        claim.result = result;
        lock.result = result;
        lock.status = outcome;
        resolve(result);
      };
      const aborted = () => finish('unknown', 'aborted-after-claim');
      async function check() {
        if (finished || !clicked) return;
        if (checking) { dirty = true; return; }
        checking = true;
        dirty = false;
        try {
          const transition = await confirmTransition({ before, scope, element });
          if (finished) return;
          if (!localDocument({ root, scope, runtime, location, expected })) finish('unknown', 'fixture-context-lost');
          else if ((transition === true || transition === 'confirmed') && scope.getAttribute('data-fixture-result') === 'confirmed') finish('confirmed', 'local-transition-confirmed');
          else if (transition === 'unknown') finish('unknown', 'local-transition-unknown');
        } catch { finish('unknown', 'transition-error'); }
        finally { checking = false; if (dirty && !finished) void check(); }
      }
      try {
        observer = new MutationObserverCtor(() => { void check(); });
        observer.observe(root, { subtree: true, childList: true, attributes: true, characterData: true });
        timer = setTimeout(() => finish('unknown', 'transition-timeout'), confirmationTimeoutMs);
        // Set both guards synchronously before invoking any click handler.
        lock.attempted = true;
        lock.status = 'pending';
        documentClaims.set(doc, claim);
        signal?.addEventListener?.('abort', aborted, { once: true });
        clicked = true;
        element.click();
        void check();
      } catch {
        // Even a throwing handler can have performed an action; never retry it.
        if (lock.attempted) finish('unknown', 'click-or-observer-error');
        else { observer?.disconnect(); clearTimeout(timer); resolve(reply('blocked', 'observer-unavailable')); }
      }
    });
  }

  globalThis.AppleDOMDriver = Object.freeze({ normalize, isVisible, isEnabled, getName, resolveTarget, createObserverLoop, clickLocalFixture });
})();
