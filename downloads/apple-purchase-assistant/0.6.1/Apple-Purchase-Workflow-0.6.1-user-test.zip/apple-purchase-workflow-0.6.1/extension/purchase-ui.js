import {validatePurchase, validatePurchaseAddress, createDuoSteps} from './purchase-config.js';
import {mountPurchaseEditor} from './purchase-editor.js';
import {mountPurchaseCalibration} from './purchase-calibration.js';

export const ADDRESS_KEYS = Object.freeze(['fullName', 'givenName', 'familyName', 'phone', 'email', 'addressLine1', 'addressLine2', 'city', 'district', 'province', 'postalCode']);
const TERMINAL = new Set(['DONE', 'PAUSED', 'STOPPED', 'UNKNOWN', 'HANDOFF', 'FAILED']);
const PUBLIC_FIELDS = ['url', 'model', 'storage', 'color', 'quantity', 'maxTotal', 'addressMode'];
const STATE_NAMES = {READY:'准备就绪', WAITING_START:'等待指定开始时间', WAITING:'等待页面证据', RUNNING:'流程执行中', SUBMITTING:'动作执行中，等待确认', AWAITING_USER:'等待你手动完成登录或验证', PAUSED:'已暂停，请人工检查', STOPPED:'已停止', DONE:'流程已结束', UNKNOWN:'结果未知，请先检查订单', HANDOFF:'请手动处理', FAILED:'无法继续'};
const CONNECTION_ERROR = '扩展后台不可用。不要重复开始；请先检查网页实际结果。';
const value = (form, name) => String(form.elements[name]?.value ?? '').trim();

export function knownTargetMetadata(url) {
  const known = {
    'https://www.apple.com.cn/shop/buy-iphone/iphone-duo/mk2u4ch/a':{model:'iPhone Duo',color:'夜空色',storage:'1TB'},
    'https://www.apple.com.cn/shop/buy-iphone/iphone-18-pro/mjt74ch/a':{model:'iPhone 18 Pro',color:'黑色',storage:'256GB'},
  };
  return Object.hasOwn(known,url) ? {...known[url]} : null;
}

export function parseCalibration(raw) {
  if (typeof raw !== 'string' || !raw.trim()) throw Error('请先完成页面校准；这里没有可直接使用的 Apple 预设。');
  if (raw.length > 64000) throw Error('校准 JSON 过长，请缩小页面映射。');
  let steps;
  try { steps = JSON.parse(raw); } catch { throw Error('校准 JSON 格式无效，请检查括号、引号和逗号。'); }
  if (!Array.isArray(steps)) throw Error('校准 JSON 须为步骤数组。');
  return steps;
}

export function calibrationExample(addressMode = 'existing') {
  const evidence = {model:'#fiction-model', storage:'#fiction-storage', color:'#fiction-color', quantity:'#fiction-quantity', currency:'#fiction-currency', region:'#fiction-region', delivery:'#fiction-delivery', itemCount:'#fiction-item-count'};
  const addressKeys = ['fullName','phone','province','city','district','addressLine1','postalCode'];
  const addressConfirmation = addressMode === 'new'
    ? {selector:'#fiction-address-summary', keys:addressKeys}
    : {selector:'#fiction-user-confirmed-selected-address'};
  const fees = {selector:'#fiction-fees-included', text:'最终总额已包含全部税费和配送费'};
  return [
    {stage:'add-to-bag', kind:'button', path:'/shop/fictitious-product', target:{role:'button',name:'虚构示例：加入购物袋',selector:'#fiction-add-button'}, evidence:{...evidence,itemPrice:'#fiction-item-price'}, confirm:{selector:'#fiction-bag-added',text:'虚构示例：已加入购物袋',nextPath:'/shop/fictitious-address'}},
    {stage:'address', kind:'address', path:'/shop/fictitious-address', ...(addressMode === 'new' ? {fields:[
      {key:'fullName',selector:'#fiction-recipient',name:'虚构收货人',autocomplete:'name'},
      {key:'phone',selector:'#fiction-phone',name:'虚构联系电话',autocomplete:'tel'},
      {key:'province',selector:'#fiction-province',name:'虚构省份',autocomplete:'address-level1'},
      {key:'city',selector:'#fiction-city',name:'虚构城市',autocomplete:'address-level2'},
      {key:'district',selector:'#fiction-district',name:'虚构区县',autocomplete:'address-level3'},
      {key:'addressLine1',selector:'#fiction-street',name:'虚构详细地址',autocomplete:'address-line1'},
      {key:'postalCode',selector:'#fiction-postal',name:'虚构邮编',autocomplete:'postal-code'}
    ]} : {}), evidence:{...evidence,itemPrice:'#fiction-item-price'}, addressConfirmation, confirm:{selector:'#fiction-address-ready',text:'虚构示例：地址已确认'}},
    {stage:'review', kind:'button', path:'/shop/fictitious-address', target:{role:'button',name:'虚构示例：核对订单',selector:'#fiction-review-button'}, evidence:{...evidence,total:'#fiction-final-total'}, totalIncludesTaxShipping:fees, addressConfirmation, confirm:{selector:'#fiction-review-ready',text:'虚构示例：订单待提交',nextPath:'/shop/fictitious-review'}},
    {stage:'submit-unpaid', kind:'button', path:'/shop/fictitious-review', target:{role:'button',name:'虚构示例：创建未付款订单',selector:'#fiction-submit-unpaid'}, evidence:{...evidence,total:'#fiction-final-total',noCharge:'#fiction-no-charge'}, totalIncludesTaxShipping:fees, addressConfirmation, noChargeText:'创建未付款订单，不扣款', confirm:{selector:'#fiction-unpaid-created',text:'未付款订单已创建'}}
  ];
}

export function buildSubmission(form, now = Date.now(), {requireConsent = true} = {}) {
  if (requireConsent && form.elements.confirmedPurchase.checked !== true) throw Error('请核对精确目标并勾选本次购买流程授权。');
  const addressMode = value(form, 'addressMode');
  if (requireConsent && addressMode === 'existing' && form.elements.confirmedExistingAddress.checked !== true) {
    throw Error('请先核对网页已选地址，再勾选“使用页面已选择且我已核对的默认地址”。');
  }
  const targetTime = purchaseStartTime(value(form,'targetTime'), now);
  const config = validatePurchase({
    mode:'purchase', confirmedPurchase:true, url:value(form,'url'),
    model:value(form,'model'), storage:value(form,'storage'), color:value(form,'color'),
    quantity:Number(value(form,'quantity')), maxTotal:Number(value(form,'maxTotal')),
    currency:'CNY', region:'CN', regionConfirmed:true, delivery:'国内配送',
    pollMs:1000, targetTime, expiresAt:new Date(Math.max(now,Date.parse(targetTime)) + 15 * 60 * 1000).toISOString(),
    addressMode, steps:parseCalibration(value(form,'calibration')),
  }, now);
  if (!requireConsent || addressMode !== 'new') return {config};
  const keys = [...new Set(config.steps.flatMap(step => [...(step.fields || []).map(field => field.key), ...(step.addressConfirmation?.keys || [])]))];
  const address = {};
  for (const key of keys) {
    if (!ADDRESS_KEYS.includes(key)) throw Error('校准配置含界面不支持的地址字段。');
    const entered = value(form, `address_${key}`);
    if (!entered) throw Error('请填写校准配置引用的全部临时地址字段，或改用网页中已选地址。');
    address[key] = entered;
  }
  return {config, address:validatePurchaseAddress(address, config)};
}

export function purchaseStartTime(localTime, now = Date.now()) {
  if (!localTime) return new Date(now).toISOString();
  if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(?::\d{2})?$/u.test(localTime)) throw Error('请选择有效的北京时间，或留空立即开始。');
  const parsed = Date.parse(`${localTime}+08:00`);
  if (!Number.isFinite(parsed)) throw Error('开始时间无效。');
  const normalized = new Date(parsed + 8 * 3600000).toISOString().slice(0,localTime.length);
  if (normalized !== localTime) throw Error('开始日期或时间无效。');
  return new Date(parsed).toISOString();
}

export function clearAddressFields(form) {
  for (const key of ADDRESS_KEYS) if (form.elements[`address_${key}`]) form.elements[`address_${key}`].value = '';
  form.elements.confirmedPurchase.checked = false;
  form.elements.confirmedExistingAddress.checked = false;
  if (form.elements.confirmedProfileStorage) form.elements.confirmedProfileStorage.checked = false;
}

export function confirmationSummary(form) {
  const target = value(form,'url') || '商品链接待填写';
  const amount = Number(value(form,'maxTotal'));
  const budget = Number.isFinite(amount) && amount > 0 ? `CNY ${amount.toFixed(2)}（包含全部税费、配送费）` : '最终总额上限待填写';
  let usesCheckout = false;
  try { usesCheckout = parseCalibration(value(form,'calibration')).some(step => step.origin === 'https://secure6.www.apple.com.cn' || step.confirm?.nextOrigin === 'https://secure6.www.apple.com.cn'); } catch { /* Invalid plans are rejected before permission or execution. */ }
  return `Apple 中国大陆${usesCheckout ? '（含 secure6 结账页）' : ''} · 国内配送 · ${value(form,'addressMode') === 'new' ? '向 Apple 填写本次地址' : '使用你已核对的网页地址'}
${value(form,'model') || '型号待填'} / ${value(form,'color') || '颜色待填'} / ${value(form,'storage') || '容量待填'} × ${value(form,'quantity') || '?'} · 最高 ${budget}
${value(form,'targetTime') ? `${value(form,'targetTime').replace('T',' ')}（北京时间 UTC+08:00）` : '立即开始'} · 只创建未付款订单，付款手动完成
${target}`;
}

export function purchasePermissions(config) {
  const origins = new Set(['https://www.apple.com.cn']);
  for (const step of config.steps || []) { if (step.origin) origins.add(step.origin); if (step.confirm?.nextOrigin) origins.add(step.confirm.nextOrigin); }
  if ([...origins].some(origin => !['https://www.apple.com.cn','https://secure6.www.apple.com.cn'].includes(origin))) throw Error('购买计划包含未授权站点。');
  return {origins:[...origins].map(origin => `${origin}/*`)};
}

// No address, calibration, page text, or runtime message is logged or put in a URL.
// Chrome storage is exclusively managed by the background's validated schema.
export async function createPurchaseUI({document, chrome, mountEditor = mountPurchaseEditor, mountCalibration = mountPurchaseCalibration, setInterval = globalThis.setInterval, clearInterval = globalThis.clearInterval, setTimeout = globalThis.setTimeout, now = Date.now, addEventListener = globalThis.addEventListener?.bind(globalThis)}) {
  const $ = selector => document.querySelector(selector);
  const form = $('#purchase-settings');
  const fields = $('#purchase-fields'), start = $('#purchase-start'), stop = $('#purchase-stop');
  const error = $('#purchase-error'), calibrationResult = $('#calibration-result');
  let pending = false, generation = 0, currentTask = null, timer = null, disposed = false, guide = null, planSource = 'none', pickerTabs = new Map(), readyPlan = false;
  const editor = mountEditor($('#purchase-editor'), {onChange(plan) {
    form.elements.calibration.value = JSON.stringify(plan, null, 2);
    form.elements.confirmedPurchase.checked = false;
    form.elements.confirmedExistingAddress.checked = false;
    planSource = 'edited';
    calibrationResult.textContent = '流程已修改。请检查设置并重新确认本次授权。';
    updateSummary();
  }});
  async function send(message) {
    const response = await chrome.runtime.sendMessage(message);
    if (!response?.ok) throw Error(response?.error || '扩展后台未响应。');
    return response;
  }
  function publicConfig() {
    const targetTime = purchaseStartTime(value(form,'targetTime'),now());
    return {mode:'purchase', confirmedPurchase:true, url:value(form,'url'), model:value(form,'model'), color:value(form,'color'), storage:value(form,'storage'), quantity:Number(value(form,'quantity')), maxTotal:Number(value(form,'maxTotal')), addressMode:value(form,'addressMode'), currency:'CNY', region:'CN', regionConfirmed:true, delivery:'国内配送', pollMs:1000, targetTime, expiresAt:new Date(Math.max(now(),Date.parse(targetTime)) + 15 * 60000).toISOString()};
  }
  function currentPlan() { try { return parseCalibration(value(form,'calibration')); } catch { return []; } }
  function updateReadiness() {
    const plan = currentPlan();
    let ready = false;
    if (plan.length) {
      try {
        const config = publicConfig();
        validatePurchase({...config,quantity:1,maxTotal:100000000,targetTime:new Date(now()).toISOString(),expiresAt:new Date(now()+15*60000).toISOString(),steps:plan},now());
        ready = true;
      } catch { /* An incomplete or stale mapping is never a ready checkout. */ }
    }
    readyPlan = ready;
    $('#calibration-state').textContent = ready ? (planSource === 'saved' ? '已保存流程，可开始' : '流程格式完整，运行时逐步核对') : plan.length ? '流程还需标记或检查' : '先标记一次页面';
    $('#calibration-note').textContent = ready ? '无法核对规格、地址、总价或不扣款证据时，会停止。' : '按提示点选网页目标，保存后直接复用；无需填写代码。';
    $('#guided-setup').textContent = ready ? '重新标记' : '标记页面';
  }
  function updateSummary() { $('#confirmation-summary').textContent = confirmationSummary(form); updateReadiness(); }
  function acceptPlan(plan, source = 'saved') {
    form.elements.calibration.value = JSON.stringify(plan,null,2);
    editor.setPlan(plan);
    planSource = source;
    form.elements.confirmedPurchase.checked = false;
    form.elements.confirmedExistingAddress.checked = false;
    updateSummary();
  }
  async function refreshPickerTabs() {
    try {
      const response = await send({type:'PURCHASE_PICK_TABS'});
      if (disposed) return;
      pickerTabs = new Map((response.tabs || []).filter(tab => Number.isInteger(tab.id) && ['https://www.apple.com.cn','https://secure6.www.apple.com.cn'].includes(tab.origin)).map(tab => [String(tab.id),tab]));
      const selected = value(form,'pickerTab');
      const options = [document.createElement('option')];
      options[0].value = ''; options[0].textContent = '选择已打开的 Apple 页面';
      for (const [id,tab] of pickerTabs) {
        const option = document.createElement('option'); option.value = id; option.textContent = `${new URL(tab.origin).host}${tab.path}`; options.push(option);
      }
      form.elements.pickerTab.replaceChildren(...options);
      form.elements.pickerTab.value = pickerTabs.has(selected) ? selected : pickerTabs.size === 1 ? [...pickerTabs.keys()][0] : '';
      $('#guided-setup-result').textContent = pickerTabs.size ? '切换购物页面后，刷新列表并选择正在标记的页面。' : '请先打开商品或结账页，再刷新列表。';
    } catch (failure) { $('#guided-setup-result').textContent = failure.message; }
  }
  async function setupTargetTab() {
    const tab = pickerTabs.get(value(form,'pickerTab'));
    if (!tab) throw Error('请先选择要标记的 Apple 页面。');
    // Only this explicit marking click requests permission for the chosen host.
    if (!await chrome.permissions.request({origins:[`${tab.origin}/*`]})) throw Error('未获得当前 Apple 站点权限，未开始标记。');
    if (disposed) throw Error('设置页已关闭，标记已取消。');
    const current = await chrome.tabs.get(tab.id);
    let origin;
    try { origin = new URL(current.url).origin; } catch { throw Error('页面已关闭或无法访问，请刷新列表。'); }
    if (origin !== tab.origin) throw Error('页面站点已改变，请刷新列表后重新选择。');
    if (current.status === 'loading') throw Error('页面仍在加载，请稍后再标记。');
    await chrome.tabs.update(tab.id,{active:true});
    return tab.id;
  }
  $('#refresh-picker-tabs').onclick = refreshPickerTabs;
  $('#authorize-picker-tabs').onclick = async () => {
    if (pending || fields.disabled) return;
    const button = $('#authorize-picker-tabs');
    if (button.disabled) return;
    button.disabled = true;
    try {
      const granted = await chrome.permissions.request({origins:['https://www.apple.com.cn/*','https://secure6.www.apple.com.cn/*']});
      if (disposed) return;
      if (!granted) { $('#guided-setup-result').textContent = '未授权页面访问。没有开始标记或购买。'; return; }
      await refreshPickerTabs();
    } catch { if (!disposed) $('#guided-setup-result').textContent = '无法取得页面权限，请检查扩展设置后重试。'; }
    finally { button.disabled = false; }
  };
  function refreshGuide() {
    try { guide?.refresh?.(); } catch (failure) { $('#guided-setup-result').textContent = failure.message; }
  }
  function closeGuide() {
    guide?.destroy?.(); guide = null;
    form.elements.confirmedPurchase.checked = false;
    form.elements.confirmedExistingAddress.checked = false;
    $('#guided-setup-panel').hidden = true;
    lock(!!currentTask && !TERMINAL.has(currentTask.state));
  }
  $('#close-guided-setup').onclick = closeGuide;
  $('#guided-setup').onclick = async () => {
    if (pending || fields.disabled) return;
    $('#guided-setup-panel').hidden = false;
    lock(!!currentTask && !TERMINAL.has(currentTask.state));
    try {
      if (!guide) guide = mountCalibration($('#guided-setup-host'),{getConfig:publicConfig,getPlan:currentPlan,onPlanChange:plan => { acceptPlan(plan); $('#guided-setup-panel').hidden = true; lock(!!currentTask && !TERMINAL.has(currentTask.state)); },send,getTargetTabId:setupTargetTab});
      else refreshGuide();
      $('#guided-setup-panel').scrollIntoView?.({behavior:'smooth',block:'nearest'});
      await refreshPickerTabs();
    } catch (failure) { $('#guided-setup-result').textContent = failure.message; }
  };
  function addressModeChanged() {
    ++generation;
    const useNew = value(form,'addressMode') === 'new';
    $('#address-fields').hidden = !useNew;
    $('#existing-address-note').hidden = useNew;
    $('#existing-address-confirmation').hidden = true;
    form.elements.confirmedExistingAddress.checked = false;
    if (!useNew) for (const key of ADDRESS_KEYS) form.elements[`address_${key}`].value = '';
    if (guide && !$('#guided-setup-panel').hidden) refreshGuide();
  }
  function lock(running, unavailable = false) {
    fields.disabled = pending || running || unavailable;
    start.disabled = pending || running || unavailable || !$('#guided-setup-panel').hidden;
    stop.disabled = unavailable || !(pending || running);
    $('#clear-address').disabled = false;
  }
  function render(response) {
    currentTask = response.task || null;
    const purchase = currentTask?.mode === 'purchase';
    const active = currentTask && !TERMINAL.has(currentTask.state);
    $('#purchase-state').textContent = currentTask
      ? `${purchase ? '' : '其他模式任务 · '}${STATE_NAMES[currentTask.state] || '正在检查状态'}` : '尚未启动';
    // Backend emits bounded, address-free reason codes/messages; never render any
    // arbitrary stored config, raw evidence, address object, or event payload.
    $('#purchase-reason').textContent = currentTask?.reason || '检查配置不会点击网页。没有自动恢复或自动重试订单。';
    $('#resume-panel').hidden = !(purchase && currentTask.state === 'AWAITING_USER');
    $('#purchase-resume').disabled = pending;
    lock(active);
  }
  async function poll() {
    if (disposed) return;
    try { render(await send({type:'STATUS'})); if (error.textContent === CONNECTION_ERROR) error.textContent = ''; }
    catch { error.textContent = CONNECTION_ERROR; lock(false, true); }
  }
  function restore(settings) {
    if (settings?.mode === 'purchase') {
      for (const key of PUBLIC_FIELDS) if (settings[key] !== undefined) form.elements[key].value = String(settings[key]);
      if (Number.isFinite(Date.parse(settings.targetTime)) && Date.parse(settings.targetTime) > now()) form.elements.targetTime.value = new Date(Date.parse(settings.targetTime) + 8 * 3600000).toISOString().slice(0,19);
      if (Array.isArray(settings.steps)) { form.elements.calibration.value = JSON.stringify(settings.steps, null, 2); editor.setPlan(settings.steps); planSource = 'saved'; }
      form.elements.productPreset.value = knownTargetMetadata(value(form,'url')) ? value(form,'url') : 'custom';
    }
    clearAddressFields(form);
    addressModeChanged();
    updateSummary();
  }
  function invalidateConsent(event) {
    if (['url','model','color','storage'].includes(event?.target?.name)) planSource = 'edited';
    if (event?.target?.name === 'url') form.elements.productPreset.value = knownTargetMetadata(value(form,'url')) ? value(form,'url') : 'custom';
    if (event?.target?.name?.startsWith('address_')) ++generation;
    if (event?.target?.name !== 'confirmedPurchase' && event?.target?.name !== 'confirmedExistingAddress') {
      form.elements.confirmedPurchase.checked = false;
      if (['addressMode', 'calibration', 'url'].includes(event?.target?.name)) form.elements.confirmedExistingAddress.checked = false;
    }
    updateSummary();
    if (guide && !$('#guided-setup-panel').hidden && ['url','model','storage','color','addressMode'].includes(event?.target?.name)) refreshGuide();
  }
  form.addEventListener('input', invalidateConsent);
  form.addEventListener('change', invalidateConsent);
  form.elements.addressMode.addEventListener('change', () => { addressModeChanged(); updateSummary(); });
  form.elements.confirmedPurchase.addEventListener('change', () => {
    // One visible consent covers the exact summary, including the selected address.
    form.elements.confirmedExistingAddress.checked = value(form,'addressMode') === 'existing' && form.elements.confirmedPurchase.checked === true;
  });
  form.elements.productPreset.addEventListener('change', () => {
    const selected = value(form,'productPreset');
    if (selected === 'custom') { form.elements.url.focus?.(); return; }
    const metadata = knownTargetMetadata(selected);
    if (!metadata) return;
    if (value(form,'url') !== selected) acceptPlan([],'none');
    form.elements.url.value = selected;
    for (const [key,entry] of Object.entries(metadata)) form.elements[key].value = entry;
    form.elements.confirmedPurchase.checked = false;
    form.elements.confirmedExistingAddress.checked = false;
    $('#target-metadata-result').textContent = '已填入记录中的规格，请按当前网页核对。预算由你填写。';
    updateSummary();
    if (guide && !$('#guided-setup-panel').hidden) refreshGuide();
  });
  $('#load-target-metadata').onclick = () => {
    const metadata = knownTargetMetadata(value(form,'url'));
    if (!metadata) { $('#target-metadata-result').textContent = '这个精确链接没有已记录规格。请按当前页面填写，金额上限由你决定。'; return; }
    for (const [key,entry] of Object.entries(metadata)) form.elements[key].value = entry;
    form.elements.confirmedPurchase.checked = false;
    form.elements.confirmedExistingAddress.checked = false;
    $('#target-metadata-result').textContent = '已载入过去记录的型号、颜色与容量，请当场核对。没有填写预算，也没有生成结账预设。';
    updateSummary();
  };
  $('#load-duo-steps').onclick = () => {
    error.textContent = '';
    try {
      const configured = createDuoSteps({url:value(form,'url'),model:value(form,'model'),color:value(form,'color'),storage:value(form,'storage')});
      const prior = value(form,'calibration') ? parseCalibration(value(form,'calibration')) : [];
      const plan = [...configured,...prior.filter(step => step.stage !== 'configure')];
      editor.setPlan(plan);
      form.elements.calibration.value = JSON.stringify(plan,null,2);
      form.elements.confirmedPurchase.checked = false;
      form.elements.confirmedExistingAddress.checked = false;
      calibrationResult.textContent = '已载入已观察的 Duo 颜色与容量选择。购物袋、地址、复核和未付款提交仍须完整校准；没有生成后续页面预设。';
      updateSummary();
    } catch (failure) { error.textContent = failure.message; }
  };
  $('#validate-calibration').onclick = () => {
    error.textContent = '';
    try { buildSubmission(form, now(), {requireConsent:false}); calibrationResult.textContent = '配置格式通过。尚未验证实际页面；未点击任何页面。'; }
    catch (failure) { calibrationResult.textContent = ''; error.textContent = failure.message; }
  };
  $('#load-example').onclick = () => {
    const plan = calibrationExample(value(form,'addressMode'));
    form.elements.calibration.value = JSON.stringify(plan, null, 2);
    editor.setPlan(plan);
    form.elements.confirmedPurchase.checked = false;
    form.elements.confirmedExistingAddress.checked = false;
    calibrationResult.textContent = '已载入虚构格式示例：所有 fiction 选择器、按钮名称及页面路径都不是 Apple 官网预设。必须换成你核验过的真实页面映射。';
    error.textContent = '';
    updateSummary();
  };
  $('#apply-calibration-json').onclick = () => {
    error.textContent = '';
    try {
      editor.setPlan(parseCalibration(value(form,'calibration')));
      form.elements.confirmedPurchase.checked = false;
      form.elements.confirmedExistingAddress.checked = false;
      calibrationResult.textContent = '已载入逐步表单。请检查各步骤；尚未验证网页，也未执行任何动作。';
    } catch (failure) { error.textContent = failure.message; }
  };
  async function targetTab(config, attempt) {
    const permission = purchasePermissions(config);
    // Called directly from the start click. Permission denial never opens a tab.
    if (!await chrome.permissions.request(permission)) throw Error('未获得 Apple 中国大陆站点权限，任务未启动。');
    if (attempt !== generation) return null;
    let tab;
    if (value(form,'targetMode') === 'new') {
      tab = await chrome.tabs.create({url:config.url, active:true});
      // A newly opened tab may initially still be about:blank. Do not inject into
      // that old document. Resource loading is not a start gate; the background
      // independently verifies and binds the exact current document.
      const deadline = now() + 30000;
      while (attempt === generation && (tab.url !== config.url || tab.pendingUrl)) {
        if (now() >= deadline) throw Error('商品页尚未就绪。请自行检查该页面，再使用“已打开的相同商品页”开始。');
        await new Promise(resolve => setTimeout(resolve, 200));
        tab = await chrome.tabs.get(tab.id);
      }
    } else {
      const tabs = await chrome.tabs.query({url:config.url});
      const exact = tabs.filter(item => item.url === config.url);
      if (!exact.length) throw Error('未找到相同链接的商品页。请先打开该链接，或选择在新标签页打开。');
      if (exact.length !== 1) throw Error('有多个相同商品页。请关闭多余页面，只保留你要操作的一页。');
      tab = exact[0];
      if (tab.pendingUrl) throw Error('该页导航尚未提交，请在新文档出现后重试；无需等待图片等资源加载。');
      if (attempt === generation) await chrome.tabs.update(tab.id, {active:true});
    }
    if (attempt !== generation) return null;
    return tab;
  }
  form.onsubmit = async event => {
    event.preventDefault();
    if (pending || start.disabled) return;
    error.textContent = '';
    updateReadiness();
    if (!readyPlan) {
      error.textContent = '先标记并保存完整流程，再开始。';
      await $('#guided-setup').onclick();
      return;
    }
    let submission;
    try { submission = buildSubmission(form, now()); } catch (failure) { error.textContent = failure.message; return; }
    const attempt = ++generation;
    form.elements.confirmedPurchase.checked = false;
    form.elements.confirmedExistingAddress.checked = false;
    pending = true; lock(true);
    try {
      const tab = await targetTab(submission.config, attempt);
      if (!tab || attempt !== generation) return;
      render(await send({type:'START', ...submission, tabId:tab.id}));
      // Keep private data only in the background's short-lived session after
      // successful start. Nothing is restored into this page by STATUS.
      clearAddressFields(form);
    } catch (failure) { error.textContent = failure.message; }
    finally { submission = null; pending = false; await poll(); }
  };
  stop.onclick = async () => {
    ++generation;
    form.elements.confirmedPurchase.checked = false;
    form.elements.confirmedExistingAddress.checked = false;
    error.textContent = '';
    try { render(await send({type:'STOP'})); } catch { error.textContent = CONNECTION_ERROR; }
  };
  $('#clear-address').onclick = async () => {
    ++generation;
    clearAddressFields(form);
    error.textContent = '';
    try { render(await send({type:'PURCHASE_CLEAR_ADDRESS'})); calibrationResult.textContent = '临时地址已清除；当前购买流程已停止，需重新检查并授权。'; }
    catch { error.textContent = '本页地址已清除，但未确认后台会话清除成功。请停止任务并检查扩展状态。'; }
  };
  $('#save-address-profile').onclick = async () => {
    if (fields.disabled) return;
    error.textContent = '';
    if (value(form,'addressMode') !== 'new') { error.textContent = '保存预设前，请选择“本次临时填写地址”并填写收货信息。'; return; }
    if (form.elements.confirmedProfileStorage.checked !== true) { error.textContent = '请先勾选仅在此浏览器非加密保存地址的确认。'; return; }
    form.elements.confirmedProfileStorage.checked = false;
    const attempt = ++generation;
    const address = Object.fromEntries(ADDRESS_KEYS.map(key => [key,value(form,`address_${key}`)]).filter(([,entry]) => entry));
    $('#save-address-profile').disabled = true;
    try {
      await send({type:'PURCHASE_SAVE_ADDRESS_PROFILE',confirmedLocalSave:true,address});
      if (attempt !== generation || disposed) return;
      $('#address-profile-result').textContent = '地址预设已保存在此浏览器。下次需要时请主动载入；不会自动用于购买。';
    } catch (failure) { if (attempt === generation && !disposed) error.textContent = failure.message; }
    finally { $('#save-address-profile').disabled = false; }
  };
  $('#load-address-profile').onclick = async () => {
    if (fields.disabled) return;
    const attempt = ++generation;
    error.textContent = '';
    try {
      const response = await send({type:'PURCHASE_LOAD_ADDRESS_PROFILE'});
      if (attempt !== generation || disposed) return;
      if (!response.profile?.address) { $('#address-profile-result').textContent = '此浏览器没有保存的地址预设。'; return; }
      clearAddressFields(form);
      form.elements.addressMode.value = 'new'; addressModeChanged();
      for (const key of ADDRESS_KEYS) if (typeof response.profile.address[key] === 'string') form.elements[`address_${key}`].value = response.profile.address[key];
      updateSummary();
      $('#address-profile-result').textContent = '已载入本机地址预设。请检查是否仍正确，并重新授权本次购买。';
    } catch (failure) { if (attempt === generation && !disposed) error.textContent = failure.message; }
  };
  $('#clear-address-profile').onclick = async () => {
    if (fields.disabled) return;
    ++generation;
    error.textContent = '';
    clearAddressFields(form);
    try {
      render(await send({type:'PURCHASE_CLEAR_ADDRESS_PROFILE'}));
      $('#address-profile-result').textContent = '本机地址预设已删除，临时地址已清除，当前购买流程已停止。';
    } catch (failure) { error.textContent = failure.message; }
  };
  $('#purchase-resume').onclick = async () => {
    if (pending || currentTask?.mode !== 'purchase' || currentTask?.state !== 'AWAITING_USER') return;
    if ($('#confirmed-resume').checked !== true) { error.textContent = '请先手动完成登录并勾选本次继续确认。'; return; }
    $('#confirmed-resume').checked = false;
    pending = true; lock(true); $('#purchase-resume').disabled = true;
    error.textContent = '';
    const attempt = ++generation;
    try {
      if (Number.isInteger(currentTask.tabId)) await chrome.tabs.update(currentTask.tabId, {active:true});
      if (attempt === generation) render(await send({type:'PURCHASE_RESUME',confirmedResume:true}));
    } catch (failure) { error.textContent = failure.message; }
    finally { pending = false; await poll(); }
  };
  const dispose = () => { disposed = true; ++generation; guide?.destroy?.(); if (timer !== null) clearInterval(timer); clearAddressFields(form); };
  addEventListener?.('pagehide', dispose);
  try {
    const response = await send({type:'STATUS'});
    restore(response.settings);
    render(response);
    timer = setInterval(poll, 1000);
  } catch { clearAddressFields(form); addressModeChanged(); updateSummary(); error.textContent = CONNECTION_ERROR; lock(false, true); }
  return {poll, dispose, acceptPlan};
}

if (typeof document !== 'undefined' && globalThis.chrome?.runtime && document.querySelector('#purchase-settings')) {
  void createPurchaseUI({document, chrome:globalThis.chrome});
}
