import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {DEFAULTS, validate, TERMINAL} from '../extension/core.js';
import {validateAssist, assistStepEvidenceFault} from '../extension/assist-config.js';

const now = Date.parse('2026-10-16T05:00:00Z');
const raw = (overrides = {}) => ({
  ...DEFAULTS, mode: 'assist', confirmedAssist: true,
  url: 'https://www.apple.com.cn/shop/buy-iphone/iphone-duo/mk2u4ch/a',
  model: 'iPhone Duo', color: '测试白色', storage: '测试 256GB', quantity: 1, maxTotal: 10000,
  targetTime: '2026-10-15T20:00:00+08:00', expiresAt: '2026-10-16T06:00:00Z', ...overrides,
});
const button = (overrides = {}) => ({kind: 'button', name: '继续', selector: '#continue-configuration',
  confirm: {kind: 'visible', selector: '#configuration-result'}, ...overrides});
const evidence = (overrides = {}) => ({observedAt: now, url: raw().url, model: 'iPhone Duo',
  color: '测试白色', storage: '测试 256GB', quantity: 1, itemPriceMinor: 100000, itemCurrency: 'CNY', ambiguity: [], ...overrides});

test('assist requires an explicit mode, per-start checkbox, exact desired specifications and supported target', () => {
  const config = validateAssist(raw(), now);
  assert.equal(config.mode, 'assist');
  assert.equal(config.url, raw().url);
  assert.equal(config.maxTotal, 10000);
  assert.deepEqual(config.steps, [
    {kind: 'radio', group: 'dimensionColor', name: '测试白色', confirm: {kind: 'checked'}, timeoutMs: 10000},
    {kind: 'radio', group: 'dimensionCapacity', name: '测试 256GB', confirm: {kind: 'checked'}, timeoutMs: 10000},
  ]);
  for (const overrides of [{mode: 'simulate'}, {confirmedAssist: false}, {confirmedAssist: 'true'},
    {confirmedAssist: undefined}, {color: ''}, {storage: ''}, {model: ''}, {url: undefined}]) {
    assert.throws(() => validateAssist(raw(overrides), now));
  }
  assert.equal(DEFAULTS.mode, 'simulate');
  assert.throws(() => validate(raw()), /尚未开放/);
});

test('assist accepts only observed exact Apple China product paths, without host aliases or fragments', () => {
  for (const url of [
    'https://apple.com.cn/shop/buy-iphone/iphone-duo',
    'https://www.apple.com/shop/buy-iphone/iphone-duo',
    'https://www.apple.com.cn.evil.test/shop/buy-iphone/iphone-duo',
    'https://user:pass@www.apple.com.cn/shop/buy-iphone/iphone-duo',
    'https://www.apple.com.cn:444/shop/buy-iphone/iphone-duo',
    'http://www.apple.com.cn/shop/buy-iphone/iphone-duo',
    'https://www.apple.com.cn/shop/buy-iphone/iphone-duo/unknown-sku/a',
    'https://www.apple.com.cn/shop/buy-iphone/iphone-duo#checkout',
    'https://www.apple.com.cn/shop/bag',
  ]) assert.throws(() => validateAssist(raw({url}), now), undefined, url);
  for (const suffix of ['', '/mk2n4ch/a', '/mk2u4ch/a']) {
    const url = `https://www.apple.com.cn/shop/buy-iphone/iphone-duo${suffix}`;
    assert.equal(validateAssist(raw({url}), now).url, url);
  }
});

test('assist starts on user click: past sale time is accepted, optional times receive bounded defaults', () => {
  assert.equal(validateAssist(raw(), now).targetTime, raw().targetTime);
  const config = validateAssist(raw({targetTime: '', expiresAt: ''}), now);
  assert.equal(Date.parse(config.targetTime), now);
  assert.equal(Date.parse(config.expiresAt), now + 30 * 60 * 1000);
  assert.throws(() => validateAssist(raw({expiresAt: new Date(now).toISOString()}), now), /过期/);
  assert.throws(() => validateAssist(raw({targetTime: '2026-10-16T04:00:00'}), now), /UTC 偏移/);
  const futureTarget = '2026-10-17T04:00:00Z';
  assert.equal(validateAssist(raw({targetTime: futureTarget}), now).targetTime, futureTarget,
    'a future reference sale time does not schedule or delay immediate assist work');
  const inherited = validateAssist(raw({targetTime: futureTarget, expiresAt: ''}), now);
  assert.equal(inherited.targetTime, futureTarget);
  assert.equal(Date.parse(inherited.expiresAt), now + 30 * 60 * 1000,
    'cleared expiry is bounded from the user click even when a future readonly sale time is retained');
  for (const targetTime of [false, 0, 'not-a-time']) {
    assert.throws(() => validateAssist(raw({targetTime}), now), /UTC 偏移/);
  }
});

test('assist quantity, product-price ceiling, region and currency remain explicit and valid', () => {
  for (const quantity of [0, -1, 11, 1.5, '1', null]) assert.throws(() => validateAssist(raw({quantity}), now), /数量/);
  for (const maxTotal of [0, -1, 1.001, '', 'bad', Infinity]) assert.throws(() => validateAssist(raw({maxTotal}), now), /最高总价/);
  for (const overrides of [{region: 'US'}, {currency: 'USD'}, {regionConfirmed: false}]) {
    assert.throws(() => validateAssist(raw(overrides), now), /中国大陆/);
  }
});

test('custom steps are explicit bounded JSON; malformed, sparse and unsupported fields are rejected', () => {
  for (const assistSteps of ['{', '{}', 'null', '[]', '"radio"', '[null]', '[1]', JSON.stringify(new Array(9).fill(button()))]) {
    assert.throws(() => validateAssist(raw({assistSteps}), now), undefined, assistSteps);
  }
  for (const steps of [new Array(2), [button({kind: 'script'})], [button({clickCount: 2})]]) {
    assert.throws(() => validateAssist(raw({steps}), now));
  }
  assert.throws(() => validateAssist(raw({assistSteps: []}), now), /JSON 文字/);
  const config = validateAssist(raw({assistSteps: JSON.stringify([button()])}), now);
  assert.deepEqual(config.steps, [{...button(), timeoutMs: 10000}]);
  assert.equal(config.assistSteps, undefined);
  assert.equal(validateAssist({...config}, now).steps.length, 1, 'canonical plans are stable on background revalidation');
  assert.equal(validateAssist(raw({steps: [button()], assistSteps: ' '}), now).steps.length, 2, 'explicitly clearing the textarea restores only default radio steps');
});

test('radio steps use observed groups, exact desired option names and checked confirmation only', () => {
  const step = {kind: 'radio', group: 'dimensionColor', name: raw().color};
  for (const change of [{group: 'quantity'}, {group: 'toString'}, {group: '__proto__'}, {name: 'other'},
    {confirm: {kind: 'visible', selector: '#x'}}, {confirm: {kind: 'checked', selector: '#x'}}]) {
    assert.throws(() => validateAssist(raw({steps: [{...step, ...change}]}), now));
  }
  for (const timeoutMs of [999, 30001, 1.5, '10000', null]) assert.throws(() => validateAssist(raw({steps: [{...step, timeoutMs}]}), now), /超时/);
  assert.equal(validateAssist(raw({steps: [{...step, timeoutMs: 1000}]}), now).steps[0].timeoutMs, 1000);
  assert.equal(validateAssist(raw({steps: [{...step, timeoutMs: 30000}]}), now).steps[0].timeoutMs, 30000);
});

test('transaction button names, selectors, and state confirmations cannot be configured', () => {
  for (const name of ['加入购物袋', '添加到购物袋', '下单', '提交订单', '付款', '支付', '结算', '购买',
    'Buy Now', 'Add to bag', 'Add to cart', 'Checkout', 'Pay', 'Place order', 'Submit']) {
    assert.throws(() => validateAssist(raw({steps: [button({name})]}), now), undefined, name);
  }
  for (const actionSelector of ['#checkout', '[data-autom="add-to-bag"]', '#place-order', '.payment', '#\\70 ay', 'body', '*']) {
    assert.throws(() => validateAssist(raw({steps: [button({selector: actionSelector})]}), now), undefined, actionSelector);
  }
  assert.throws(() => validateAssist(raw({steps: [button({confirm: {kind: 'text', selector: '#result', text: '订单成功'}})]}), now));
});

test('Continue requires an independent concrete postcondition, never just its own continued visibility', () => {
  for (const confirm of [undefined, null, {}, {kind: 'checked'}, {kind: 'visible'}, {kind: 'visible', selector: 'body'},
    {kind: 'visible', selector: '#continue-configuration'}, {kind: 'text', selector: '#result'},
    {kind: 'text', selector: '#result', text: '继续'}, {kind: 'visible', selector: '#result', text: 'done'}]) {
    assert.throws(() => validateAssist(raw({steps: [button({confirm})]}), now));
  }
  assert.equal(validateAssist(raw({steps: [button({confirm: {kind: 'text', selector: '#result', text: '配置完成'}})]}), now).steps[0].confirm.text, '配置完成');
  assert.throws(() => validateAssist(raw({steps: [button({group: 'dimensionColor'})]}), now));
});

test('quantitySelector is optional and cannot refer to transaction or broad document selectors', () => {
  assert.equal(validateAssist(raw(), now).quantitySelector, '');
  assert.equal(validateAssist(raw({quantitySelector: '#quantity-summary'}), now).quantitySelector, '#quantity-summary');
  for (const quantitySelector of [true, 'body', '#cart-quantity', 'x'.repeat(301)]) assert.throws(() => validateAssist(raw({quantitySelector}), now));
});

test('radio evidence may have unknown price and quantity, but never known wrong price, currency or quantity', () => {
  const config = validateAssist(raw(), now);
  assert.equal(assistStepEvidenceFault(config, 0, evidence({quantity: null, itemPriceMinor: null, itemCurrency: null}), now), null);
  for (const overrides of [{quantity: 2}, {quantity: '1'}, {itemPriceMinor: 0}, {itemPriceMinor: -1},
    {itemPriceMinor: 1.5}, {itemCurrency: 'USD'}, {itemCurrency: null}, {itemPriceMinor: 1000001}]) {
    assert.ok(assistStepEvidenceFault(config, 0, evidence(overrides), now));
  }
  const two = validateAssist(raw({quantity: 2, maxTotal: 2000}), now);
  assert.equal(assistStepEvidenceFault(two, 0, evidence({quantity: null, itemPriceMinor: 100000}), now), null);
  assert.match(assistStepEvidenceFault(two, 0, evidence({quantity: null, itemPriceMinor: 100001}), now), /标价乘数量超过/);
});

test('completed radio selections must remain checked before the next step', () => {
  const config = validateAssist(raw(), now);
  assert.equal(assistStepEvidenceFault(config, 0, evidence({color: 'other'}), now), null, 'current color step can change an existing selection');
  assert.equal(assistStepEvidenceFault(config, 1, evidence({storage: 'other'}), now), null, 'current capacity step can change capacity');
  assert.match(assistStepEvidenceFault(config, 1, evidence({color: 'other'}), now), /此前已选 color/);
  assert.match(assistStepEvidenceFault(config, 1, evidence({color: null}), now), /此前已选 color/);
});

test('any button requires both selected specs, independently observed quantity, price and currency', () => {
  const config = validateAssist(raw({steps: [button()]}), now);
  assert.equal(assistStepEvidenceFault(config, 0, evidence(), now), null);
  for (const overrides of [{quantity: null}, {quantity: undefined}, {quantity: 2}, {itemPriceMinor: null},
    {itemPriceMinor: undefined}, {color: null}, {color: 'other'}, {storage: null}, {storage: 'other'}]) {
    assert.ok(assistStepEvidenceFault(config, 0, evidence(overrides), now), JSON.stringify(overrides));
  }
});

test('evidence must be fresh, unambiguous, for the authorized supported product and exact model', () => {
  const config = validateAssist(raw(), now);
  for (const overrides of [{observedAt: now - 5001}, {observedAt: now + 1001}, {observedAt: null},
    {model: 'iPhone Other'}, {model: null}, {url: 'https://www.apple.com.cn/shop/bag'},
    {url: 'https://apple.com.cn/shop/buy-iphone/iphone-duo'}, {ambiguity: ['model']}, {blocker: 'captcha'}]) {
    assert.ok(assistStepEvidenceFault(config, 0, evidence(overrides), now));
  }
  assert.equal(assistStepEvidenceFault(config, 0, evidence({url: 'https://www.apple.com.cn/shop/buy-iphone/iphone-duo/mk2n4ch/a'}), now), null,
    'observed supported SKU variants remain inside this same product family');
  assert.match(assistStepEvidenceFault(config, 0, evidence(), Date.parse(config.expiresAt)), /过期/);
  assert.match(assistStepEvidenceFault(config, -1, evidence(), now), /计划或授权/);
});

// Deterministic popup controller coverage. This does not emulate or claim live Apple DOM compatibility.
const popupSource = fs.readFileSync(new URL('../extension/popup.js', import.meta.url), 'utf8');
const html = fs.readFileSync(new URL('../extension/popup.html', import.meta.url), 'utf8');
function element(tagName) {return {tagName: tagName.toUpperCase(), name: '', value: '', checked: false, textContent: '', disabled: false,
  children: [], listeners: new Map(), append(...nodes) {this.children.push(...nodes);}, replaceChildren(...nodes) {this.children = nodes;},
  addEventListener(type, callback) {this.listeners.set(type, callback);}};}
async function popup({settings = raw({targetTime: '', expiresAt: ''}), grant = true, task = null} = {}) {
  const form = element('form'); form.elements = [];
  const nodes = new Map([['form', form], ['fieldset', element('fieldset')]]);
  const add = control => {form.elements.push(control); form.elements[control.name] = control;};
  for (const match of html.matchAll(/<([\w-]+)\b([^>]*\bid="([^"]+)"[^>]*)>/g)) {
    nodes.set(`#${match[3]}`, match[1] === 'form' ? form : match[1] === 'fieldset' ? nodes.get('fieldset') : element(match[1]));
  }
  for (const match of html.matchAll(/<(input|select|textarea)\b[^>]*\bname="([^"]+)"[^>]*>/g)) {
    const control = element(match[1]); control.name = match[2]; add(control);
  }
  nodes.get('#selectors').append = (...labels) => {for (const label of labels) for (const input of label.children) add(input);};
  const messages = [], permissions = [], queries = [], timers = [];
  const document = {querySelector: key => nodes.get(key), createElement: element};
  const chrome = {
    runtime: {async sendMessage(message) {messages.push(structuredClone(message)); return {ok: true, settings, task};}},
    permissions: {async request(request) {permissions.push(structuredClone(request)); return grant;}},
    tabs: {async query(query) {queries.push(structuredClone(query)); return [{id: 27}];}},
  };
  const context = vm.createContext({document, chrome, DEFAULTS, validate, validateAssist, TERMINAL, URL,
    setInterval: callback => timers.push(callback), fetch() {throw Error('network forbidden');}});
  await vm.runInContext(`(async()=>{${popupSource.replace(/^import[^\n]*\n/gm, '')}\n})()`, context);
  return {form, messages, permissions, queries, nodes, async submit() {await form.onsubmit({preventDefault() {}});}};
}

test('assist popup never auto-starts or restores persisted approval and cannot request permission unchecked', async () => {
  const h = await popup();
  assert.equal(h.form.elements.confirmedAssist.checked, false);
  assert.equal(h.nodes.get('#start').textContent, '开始配置点击');
  assert.equal(h.nodes.get('#assist-settings').hidden, false);
  assert.match(h.nodes.get('#budget-label').textContent, /商品标价/);
  assert.match(h.nodes.get('#time-label').textContent, /立即执行/);
  assert.deepEqual(h.messages.map(message => message.type), ['STATUS']);
  await h.submit();
  assert.match(h.nodes.get('#error').textContent, /勾选授权/);
  assert.equal(h.permissions.length, 0);
  assert.equal(h.queries.length, 0);
  assert.equal(h.messages.some(message => message.type === 'START'), false);
});

test('assist popup explicit approval sends default radio plan once and requests only the target origin', async () => {
  const h = await popup();
  h.form.elements.confirmedAssist.checked = true;
  await h.submit();
  const start = h.messages.find(message => message.type === 'START');
  assert.equal(start.config.confirmedAssist, true);
  assert.equal(start.config.steps.length, 2);
  assert.ok(start.config.steps.every(step => step.kind === 'radio'));
  assert.equal(start.tabId, 27);
  assert.deepEqual(h.permissions, [{origins: ['https://www.apple.com.cn/*']}]);
  assert.equal(h.form.elements.confirmedAssist.checked, false);
  await h.submit();
  assert.equal(h.messages.filter(message => message.type === 'START').length, 1, 'a new start must be explicitly authorized again');
});

test('restoring the default plan keeps targets linked to the editable specification fields', async () => {
  const settings = validateAssist(raw({targetTime: '', expiresAt: ''}));
  const h = await popup({settings});
  assert.equal(h.form.elements.assistSteps.value, '');
  h.form.elements.color.value = '新测试颜色';
  h.form.elements.storage.value = '新测试容量';
  h.form.elements.confirmedAssist.checked = true;
  await h.submit();
  const start = h.messages.find(message => message.type === 'START');
  assert.equal(start.config.steps[0].name, '新测试颜色');
  assert.equal(start.config.steps[1].name, '新测试容量');
});

test('assist popup preserves an explicit custom plan, rejects invalid JSON before permissions, and clears approval after denial', async () => {
  const h = await popup({settings: raw({targetTime: '', expiresAt: '', steps: [button()]})});
  assert.equal(JSON.parse(h.form.elements.assistSteps.value)[0].name, '继续');
  h.form.elements.assistSteps.value = '{';
  h.form.elements.confirmedAssist.checked = true;
  await h.submit();
  assert.match(h.nodes.get('#error').textContent, /JSON/);
  assert.equal(h.permissions.length, 0);
  const denied = await popup({grant: false});
  denied.form.elements.confirmedAssist.checked = true;
  await denied.submit();
  assert.equal(denied.form.elements.confirmedAssist.checked, false);
  assert.match(denied.nodes.get('#error').textContent, /未授权/);
  assert.equal(denied.queries.length, 0);
  assert.equal(denied.messages.some(message => message.type === 'START'), false);
});

test('assist active state is described as a real step, while the final-order warning remains prominent', async () => {
  const h = await popup({task: {mode: 'assist', state: 'SUBMITTING'}});
  assert.equal(h.nodes.get('#state').textContent, '步骤执行中');
  assert.match(html, /本弹窗的配置辅助不提交订单/);
  assert.match(html, /独立购买工作流须另外校准/);
  assert.match(html, /最终含费总价未核验/);
  assert.match(html, /官网配置自动点击·订单手动/);
  h.form.elements.confirmedAssist.checked = true;
  h.form.elements.mode.value = 'simulate';
  h.form.elements.mode.listeners.get('change')();
  assert.equal(h.form.elements.confirmedAssist.checked, false);
  assert.equal(h.nodes.get('#assist-settings').hidden, true);
});
