import { test } from 'node:test';
import assert from 'node:assert/strict';
import '../extension/dom-driver.js';

const { resolveTarget, getName, createObserverLoop, clickLocalFixture } = globalThis.AppleDOMDriver;
const extensionId = 'abcdefghijklmnopabcdefghijklmnop';
const extensionURL = `chrome-extension://${extensionId}/simulator.html?task=local-task`;
const flush = async () => { for (let i = 0; i < 8; i++) await Promise.resolve(); };

// Only Node builtins: this deliberately small DOM models semantic lookup, tree replacement,
// computed visibility, disabled controls, MutationObserver delivery and click effects.
class Element {
  constructor(doc, tagName = 'div', text = '', attributes = {}) {
    this.ownerDocument = doc;
    this.tagName = tagName.toUpperCase();
    this.nodeType = 1;
    this.children = [];
    this.parentElement = null;
    this.attributes = new Map(Object.entries(attributes));
    this.ownText = text;
    this.disabled = false;
    this.hidden = false;
    this.inert = false;
    this.style = { display: 'block', visibility: 'visible', opacity: '1', contentVisibility: 'visible' };
    this.clicks = 0;
  }
  get textContent() { return this.ownText + this.children.map(child => child.textContent).join(''); }
  set textContent(text) { this.ownText = text; for (const child of this.children) child.parentElement = null; this.children = []; }
  get innerText() { return this.textContent; }
  get isConnected() { return this.ownerDocument.contains(this); }
  getAttribute(name) { return this.attributes.has(name) ? this.attributes.get(name) : null; }
  hasAttribute(name) { return this.attributes.has(name); }
  setAttribute(name, value) { this.attributes.set(name, String(value)); }
  removeAttribute(name) { this.attributes.delete(name); }
  append(...elements) {
    for (const element of elements) {
      element.remove();
      this.children.push(element);
      element.parentElement = this;
    }
  }
  remove() {
    if (this.parentElement) this.parentElement.children = this.parentElement.children.filter(child => child !== this);
    this.parentElement = null;
  }
  contains(element) { return element === this || this.children.some(child => child.contains(element)); }
  getClientRects() { return this.isConnected && !this.hidden && this.style.display !== 'none' ? [{}] : []; }
  matches(selector) {
    if (selector.includes(',')) return selector.split(',').some(part => this.matches(part.trim()));
    if (selector === ':disabled') {
      if (this.disabled) return true;
      for (let parent = this.parentElement; parent; parent = parent.parentElement) if (parent.tagName === 'FIELDSET' && parent.disabled) return true;
      return false;
    }
    if (selector.startsWith('#')) return this.getAttribute('id') === selector.slice(1);
    if (selector.startsWith('.')) return (this.getAttribute('class') ?? '').split(' ').includes(selector.slice(1));
    const match = /^(\w+)?(?:\[([\w-]+)(?:="([^"]*)")?\])?$/.exec(selector);
    if (!match) throw Error(`Unsupported test selector: ${selector}`);
    return (!match[1] || this.tagName.toLowerCase() === match[1]) &&
      (!match[2] || (this.hasAttribute(match[2]) && (match[3] === undefined || this.getAttribute(match[2]) === match[3])));
  }
  closest(selector) { for (let node = this; node; node = node.parentElement) if (node.matches(selector)) return node; return null; }
  querySelectorAll(selector) {
    const found = [];
    for (const child of this.children) { if (child.matches(selector)) found.push(child); found.push(...child.querySelectorAll(selector)); }
    return found;
  }
  click() { this.clicks++; this.onClick?.(); }
}

class Document {
  constructor(href = extensionURL) {
    this.nodeType = 9;
    this.body = new Element(this, 'body');
    this.observers = [];
    const doc = this;
    this.defaultView = {
      location: { href },
      getComputedStyle: element => element.style,
      MutationObserver: class {
        constructor(callback) { this.callback = callback; this.active = false; doc.observers.push(this); }
        observe(root, options) { this.root = root; this.options = options; this.active = true; }
        disconnect() { this.active = false; }
      }
    };
  }
  contains(element) { return element === this || this.body.contains(element); }
  querySelectorAll(selector) { return this.body.querySelectorAll(selector); }
  getElementById(id) { return this.querySelectorAll(`[id="${id}"]`)[0] ?? null; }
  element(tag, text, attrs) { return new Element(this, tag, text, attrs); }
  emit(records = [{ type: 'childList' }]) { for (const observer of [...this.observers]) if (observer.active) observer.callback(records); }
}

const specs = { region: 'CN', model: 'Fixture Phone', storage: '256 GB', color: 'White', quantity: 1, currency: 'CNY', delivery: 'Local only' };
function fixture() {
  const doc = new Document();
  const scope = doc.element('main', '', { 'data-local-fixture': 'purchase', 'data-fixture-ready': 'true', 'data-fixture-result': 'pending' });
  const button = doc.element('button', 'Place local order', { class: 'unstable-render-1' });
  doc.body.append(scope);
  scope.append(button);
  const snapshot = { ...specs, totalMinor: 10000 };
  const lock = {};
  const options = {
    root: doc, scope, target: { names: ['Place local order'], context: scope },
    runtime: { id: extensionId, getURL: path => `chrome-extension://${extensionId}/${path}` },
    location: doc.defaultView.location,
    expected: { ...specs, mode: 'simulate', totalMinor: 10000, maxTotalMinor: 20000 },
    readSnapshot: () => snapshot, lock, confirmationTimeoutMs: 25
  };
  button.onClick = () => { scope.setAttribute('data-fixture-result', 'confirmed'); doc.emit(); };
  return { doc, scope, button, snapshot, lock, options };
}

test('semantic re-identification survives class changes, complete replacement and movement', () => {
  const { doc, scope, button } = fixture();
  assert.equal(resolveTarget(doc, { names: 'Place local order', context: scope }).element, button);
  const replacement = doc.element('button', '  Place\n local   order ', { class: 'entirely-new' });
  button.remove();
  const wrapper = doc.element('section');
  scope.append(wrapper);
  wrapper.append(replacement);
  assert.equal(resolveTarget(doc, { names: ['Place local order'], context: scope }).element, replacement);
  replacement.setAttribute('class', 'changed-again');
  scope.append(replacement);
  assert.equal(resolveTarget(doc, { names: 'Place local order' }).element, replacement);
  assert.equal(button.clicks, 0);
});

test('accessible names use labels, aria-label and exact normalized text', () => {
  const { doc, button } = fixture();
  const label = doc.element('span', 'Confirm\n fixture', { id: 'button-label' });
  doc.body.append(label);
  button.setAttribute('aria-label', 'Do not choose text content');
  assert.equal(getName(button), 'Do not choose text content');
  button.setAttribute('aria-labelledby', 'button-label');
  assert.equal(getName(button), 'Confirm fixture');
  assert.equal(resolveTarget(doc, { names: ['Confirm fixture'] }).element, button);
  assert.equal(resolveTarget(doc, { names: ['Confirm'] }).status, 'missing');
  button.setAttribute('aria-labelledby', 'missing-label');
  assert.equal(resolveTarget(doc, { names: ['Do not choose text content', 'Place local order'] }).status, 'missing');
});

test('misleading input roles cannot expose password or other form values', () => {
  const { doc } = fixture();
  for (const type of ['password', 'text', 'email', 'tel']) {
    const input = doc.element('input', '', { type, role: 'button', 'aria-label': 'Place local order' });
    const nativeGetAttribute = input.getAttribute.bind(input);
    input.getAttribute = name => { assert.notEqual(name, 'value'); return nativeGetAttribute(name); };
    Object.defineProperty(input, 'value', { get() { assert.fail('A sensitive input value was read'); } });
    doc.body.append(input);
    assert.equal(getName(input), '');
  }
  assert.equal(resolveTarget(doc, { names: 'Place local order' }).status, 'ready');
});

test('visible duplicate decoys are ambiguous, including disabled duplicates', () => {
  const { doc, scope, button } = fixture();
  const decoy = doc.element('button', button.textContent);
  scope.append(decoy);
  assert.equal(resolveTarget(doc, { names: button.textContent }).status, 'ambiguous');
  decoy.disabled = true;
  assert.equal(resolveTarget(doc, { names: button.textContent }).status, 'ambiguous');
  decoy.hidden = true;
  assert.equal(resolveTarget(doc, { names: button.textContent }).element, button);
  button.disabled = true;
  assert.equal(resolveTarget(doc, { names: button.textContent }).status, 'disabled');
  assert.equal(resolveTarget(doc, { names: button.textContent }).element, button);
});

test('context excludes outside decoys and accepts ancestor selector/text or predicates', () => {
  const { doc, scope, button } = fixture();
  scope.setAttribute('aria-label', 'Correct model');
  scope.setAttribute('id', 'product');
  scope.append(doc.element('h2', 'Fixture Phone'));
  doc.body.append(doc.element('button', button.textContent));
  assert.equal(resolveTarget(doc, { names: button.textContent }).status, 'ambiguous');
  for (const context of [scope, '#product', { selector: 'main', text: 'Fixture Phone' }, element => scope.contains(element)]) {
    assert.equal(resolveTarget(doc, { names: button.textContent, context }).element, button);
  }
  assert.equal(resolveTarget(doc, { names: button.textContent, context: { selector: 'main', text: 'Wrong model' } }).status, 'missing');
  assert.equal(resolveTarget(doc, { names: button.textContent, context: { selector: '!invalid' } }).status, 'invalid-context');
});

test('hidden ancestors, inert controls and disabled fieldsets are not actionable', () => {
  const { doc, scope, button } = fixture();
  scope.style.opacity = '0';
  assert.equal(resolveTarget(doc, { names: button.textContent }).status, 'missing');
  scope.style.opacity = '1';
  scope.setAttribute('aria-hidden', 'true');
  assert.equal(resolveTarget(doc, { names: button.textContent }).status, 'missing');
  scope.removeAttribute('aria-hidden');
  scope.inert = true;
  assert.equal(resolveTarget(doc, { names: button.textContent }).status, 'disabled');
  scope.inert = false;
  scope.setAttribute('aria-busy', 'true');
  assert.equal(resolveTarget(doc, { names: button.textContent }).status, 'disabled');
  scope.removeAttribute('aria-busy');
  const fieldset = doc.element('fieldset');
  scope.append(fieldset);
  fieldset.append(button);
  fieldset.disabled = true;
  assert.equal(resolveTarget(doc, { names: button.textContent }).status, 'disabled');
});

test('observer starts without page load and coalesces burst wakes into one fresh scan', async () => {
  const { doc } = fixture();
  const tasks = [], scans = [];
  const loop = createObserverLoop({ root: doc, schedule: fn => tasks.push(fn), scan: input => scans.push(input.reasons) });
  assert.equal(doc.observers[0].active, true);
  doc.emit(); doc.emit(); loop.wake('timer');
  assert.equal(tasks.length, 1);
  tasks.shift()(); await flush();
  assert.deepEqual(scans, [['initial', 'mutation', 'timer']]);
  doc.emit(); doc.emit();
  assert.equal(tasks.length, 1);
  tasks.shift()(); await flush();
  assert.equal(scans.length, 2);
  loop.stop();
  doc.emit(); loop.wake();
  assert.equal(tasks.length, 0);
});

test('async scans never overlap and mutations during a scan trigger one rescan', async () => {
  const { doc } = fixture();
  let release, scans = 0, active = 0, maxActive = 0;
  const loop = createObserverLoop({ root: doc, scan: async () => {
    scans++; active++; maxActive = Math.max(maxActive, active);
    if (scans === 1) await new Promise(resolve => { release = resolve; });
    active--;
  } });
  await flush();
  doc.emit(); doc.emit(); doc.emit();
  await flush();
  assert.equal(scans, 1);
  release(); await flush();
  assert.equal(scans, 2);
  assert.equal(maxActive, 1);
  loop.stop();
});

test('stopping cancels queued work and scan errors disconnect fail-closed', async () => {
  const { doc } = fixture();
  let scans = 0, errors = 0;
  const stopped = createObserverLoop({ root: doc, scan: () => scans++ });
  stopped.stop(); await flush();
  assert.equal(scans, 0);
  const failed = createObserverLoop({ root: doc, scan: () => { throw Error('snapshot invalid'); }, onError: () => errors++ });
  await flush();
  assert.equal(errors, 1);
  assert.equal(failed.stopped, true);
  assert.ok(doc.observers.every(observer => !observer.active));
});

test('a confirmed local fixture action records its claim before the click and cannot repeat', async () => {
  const { doc, scope, button, lock, options } = fixture();
  button.onClick = () => {
    assert.equal(lock.attempted, true);
    scope.setAttribute('data-fixture-result', 'confirmed'); doc.emit();
  };
  const result = await clickLocalFixture(options);
  assert.equal(result.outcome, 'confirmed');
  assert.equal(result.clicked, true);
  assert.equal(button.clicks, 1);
  const repeat = await clickLocalFixture({ ...options, lock: {} });
  assert.equal(repeat.reused, true);
  assert.equal(repeat.clicked, false);
  assert.equal(button.clicks, 1);
});

test('real origins, wrong extension IDs, wrong paths, fabricated locations and non-simulate modes are blocked', async () => {
  const cases = [
    f => { f.doc.defaultView.location.href = 'https://www.apple.com.cn/shop/buy-iphone'; },
    f => { f.doc.defaultView.location.href = `chrome-extension://${'a'.repeat(32)}/simulator.html`; },
    f => { f.doc.defaultView.location.href = `chrome-extension://${extensionId}/popup.html`; },
    f => { f.options.location = { href: 'https://www.apple.com.cn/shop' }; },
    f => { f.options.expected.mode = 'official-readonly'; },
    f => { f.scope.removeAttribute('data-local-fixture'); },
    f => { f.options.runtime.id = 'a'.repeat(32); }
  ];
  for (const alter of cases) {
    const f = fixture(); alter(f);
    assert.equal((await clickLocalFixture(f.options)).reason, 'extension-local-fixture-required');
    assert.equal(f.button.clicks, 0);
    assert.equal(f.lock.attempted, undefined);
  }
});

test('targets outside the explicit fixture, navigational links and form buttons cannot be clicked', async () => {
  for (const alter of [
    f => { f.doc.body.append(f.button); delete f.options.target.context; },
    f => { f.button.tagName = 'A'; f.button.setAttribute('href', 'https://example.invalid'); },
    f => { const form = f.doc.element('form'); f.scope.append(form); form.append(f.button); },
    f => f.button.setAttribute('formaction', 'https://example.invalid')
  ]) {
    const f = fixture(); alter(f);
    assert.equal((await clickLocalFixture(f.options)).outcome, 'blocked');
    assert.equal(f.button.clicks, 0);
  }
});

test('every spec and exact price/cap are revalidated before any local click', async () => {
  const alterations = Object.keys(specs).map(key => f => { f.snapshot[key] = 'WRONG'; });
  alterations.push(
    f => { f.snapshot.totalMinor = 10100; },
    f => { f.options.expected.maxTotalMinor = 9999; },
    f => { f.snapshot.totalMinor = NaN; },
    f => { delete f.options.expected.totalMinor; },
    f => { f.snapshot.soldOut = true; },
    f => { f.snapshot.blocker = 'payment'; }
  );
  for (const alter of alterations) {
    const f = fixture(); alter(f);
    assert.equal((await clickLocalFixture(f.options)).outcome, 'blocked');
    assert.equal(f.button.clicks, 0);
    assert.equal(f.lock.attempted, undefined);
  }
});

test('duplicate decoys and disabled targets cause no action', async () => {
  const f = fixture();
  const decoy = f.doc.element('button', f.button.textContent);
  decoy.disabled = true;
  f.scope.append(decoy);
  assert.equal((await clickLocalFixture(f.options)).reason, 'target-ambiguous');
  assert.equal(f.button.clicks, 0);
  decoy.remove(); f.button.disabled = true;
  assert.equal((await clickLocalFixture(f.options)).reason, 'target-disabled');
  assert.equal(f.lock.attempted, undefined);
});

test('replacement during preflight is rejected; a later fresh call clicks only the new target', async () => {
  const f = fixture();
  const replacement = f.doc.element('button', f.button.textContent);
  replacement.onClick = f.button.onClick;
  f.options.readSnapshot = () => { f.button.remove(); f.scope.append(replacement); return f.snapshot; };
  assert.equal((await clickLocalFixture(f.options)).reason, 'target-changed-during-preflight');
  assert.equal(f.button.clicks, 0);
  assert.equal(replacement.clicks, 0);
  f.options.readSnapshot = () => f.snapshot;
  assert.equal((await clickLocalFixture(f.options)).outcome, 'confirmed');
  assert.equal(replacement.clicks, 1);
});

test('late hydration readiness wakes a local action immediately and never duplicates on notification bursts', async () => {
  const f = fixture();
  f.scope.setAttribute('data-fixture-ready', 'false');
  const boundHandler = f.button.onClick;
  delete f.button.onClick;
  let attempts = 0, result;
  const loop = createObserverLoop({ root: f.doc, scan: async () => { attempts++; result = await clickLocalFixture(f.options); } });
  await flush();
  assert.equal(result.reason, 'fixture-not-ready');
  assert.equal(f.button.clicks, 0);
  f.button.onClick = boundHandler;
  f.scope.setAttribute('data-fixture-ready', 'true');
  f.doc.emit(); f.doc.emit(); f.doc.emit();
  await flush();
  assert.equal(result.outcome, 'confirmed');
  assert.equal(f.button.clicks, 1);
  assert.ok(attempts >= 2);
  f.doc.emit(); f.doc.emit(); await flush();
  assert.equal(f.button.clicks, 1);
  loop.stop();
});

test('post-click confirmation is observed after DOM mutation rather than assumed from click completion', async () => {
  const f = fixture();
  f.button.onClick = () => {};
  let completed = false;
  const pending = clickLocalFixture(f.options).then(result => { completed = true; return result; });
  await flush();
  assert.equal(f.button.clicks, 1);
  assert.equal(completed, false);
  f.scope.setAttribute('data-fixture-result', 'confirmed'); f.doc.emit();
  assert.equal((await pending).outcome, 'confirmed');
});

test('unknown results lock the whole document even after scope replacement and a new caller lock', async () => {
  const f = fixture();
  f.button.onClick = () => { f.scope.setAttribute('data-fixture-result', 'unknown'); f.doc.emit(); };
  assert.equal((await clickLocalFixture(f.options)).outcome, 'unknown');
  const scope = f.doc.element('main', '', { 'data-local-fixture': 'purchase', 'data-fixture-ready': 'true' });
  const newButton = f.doc.element('button', f.button.textContent);
  scope.append(newButton); f.scope.remove(); f.doc.body.append(scope);
  const repeat = await clickLocalFixture({ ...f.options, scope, target: { names: newButton.textContent, context: scope }, lock: {} });
  assert.equal(repeat.outcome, 'unknown');
  assert.equal(repeat.reused, true);
  assert.equal(f.button.clicks, 1);
  assert.equal(newButton.clicks, 0);
});

test('hung async confirmation is bounded, cleans up observers, and permanently prevents retry', async () => {
  const f = fixture();
  f.button.onClick = () => {};
  f.options.confirmTransition = () => new Promise(() => {});
  f.options.confirmationTimeoutMs = 10;
  const result = await clickLocalFixture(f.options);
  assert.equal(result.reason, 'transition-timeout');
  assert.equal(result.outcome, 'unknown');
  assert.equal(f.button.clicks, 1);
  assert.ok(f.doc.observers.every(observer => !observer.active));
  f.scope.setAttribute('data-fixture-result', 'confirmed');
  assert.equal((await clickLocalFixture(f.options)).outcome, 'unknown');
  assert.equal(f.button.clicks, 1);
});

test('preexisting success and custom confirmer without a new observable transition cannot fake success', async () => {
  const f = fixture();
  f.scope.setAttribute('data-fixture-result', 'confirmed');
  assert.equal((await clickLocalFixture(f.options)).reason, 'preexisting-transition');
  assert.equal(f.button.clicks, 0);
  f.scope.setAttribute('data-fixture-result', 'pending');
  f.button.onClick = () => {};
  const result = await clickLocalFixture({ ...f.options, confirmTransition: () => true, confirmationTimeoutMs: 5 });
  assert.equal(result.outcome, 'unknown');
  assert.equal(result.reason, 'transition-timeout');
});

test('throwing click handlers and aborted in-flight actions remain unknown and never retry', async () => {
  const f = fixture();
  f.button.onClick = () => { throw Error('handler threw after side effect'); };
  assert.equal((await clickLocalFixture(f.options)).outcome, 'unknown');
  assert.equal((await clickLocalFixture(f.options)).reused, true);
  assert.equal(f.button.clicks, 1);
  const g = fixture(), controller = new AbortController();
  g.button.onClick = () => controller.abort();
  assert.equal((await clickLocalFixture({ ...g.options, signal: controller.signal })).outcome, 'unknown');
  assert.equal(g.button.clicks, 1);
});
