import {validatePurchase,validatePurchaseAddress,validateAddressProfile,purchaseURL,purchaseLocationMatches,nextPurchaseLocation,purchaseLoginPath,safePurchaseURL,purchaseEvidenceFault,normalizePurchaseText} from './purchase-config.js';
const FINAL_BARRIER='purchaseFinalBarrier',TEST_FINAL_BARRIER='purchaseFixtureFinalBarrier',FIXTURE_VIRTUAL='https://www.apple.com.cn/shop/fixture';
const ended=r=>!r||['DONE','STOPPED','PAUSED','UNKNOWN'].includes(r.state);
const fingerprint=x=>typeof x==='string'&&/^[a-f0-9]{64}$/u.test(x);
export async function sendFixtureControl(chrome,message,timeoutMs=3000){let timer;try{return await Promise.race([chrome.runtime.sendMessage(message),new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('本地演练页面没有确认控制消息')),timeoutMs);})]);}finally{clearTimeout(timer);}}
export class PurchaseController {
 constructor({chrome,read,save,halt,paint,event}){Object.assign(this,{chrome,read,save,halt,paint,event});}
 async session(key){return (await this.chrome.storage.session.get(key))[key];}
 async remove(key){if(this.chrome.storage.session.remove)await this.chrome.storage.session.remove(key);else await this.chrome.storage.session.set({[key]:null});}
 async clearPrivate(id){if(id){await this.remove(`address:${id}`);await this.remove(`selected-address:${id}`);}}
 async stop(reason,state='PAUSED'){const r=await this.read();const stopped=await this.halt(r?.testMode?`本地演练（没有真实订单）：${reason}`:reason,state);if(r?.mode==='purchase')await this.clearPrivate(r.id);return stopped;}
 async profile(message){
  const key='purchaseAddressProfile';
  if(message.type==='PURCHASE_SAVE_ADDRESS_PROFILE'){
   if(message.confirmedLocalSave!==true)throw Error('保存地址前须明确同意本机非加密存储');
   const address=validateAddressProfile(message.address);await this.chrome.storage.local.set({[key]:{version:1,region:'CN',address}});return{saved:true};
  }
  if(message.type==='PURCHASE_LOAD_ADDRESS_PROFILE'){
   const profile=(await this.chrome.storage.local.get(key))[key];if(!profile)return{profile:null};
   return{profile:{region:'CN',address:validateAddressProfile(profile.address)}};
  }
  if(message.type!=='PURCHASE_CLEAR_ADDRESS_PROFILE')throw Error('未知地址预设命令');
  const r=await this.read();if(r?.mode==='purchase'){if(!ended(r))await this.stop('用户请求清除地址，购买任务已停止','STOPPED');else await this.clearPrivate(r.id);}
  if(this.chrome.storage.local.remove)await this.chrome.storage.local.remove(key);else await this.chrome.storage.local.set({[key]:null});
  return{cleared:true,task:await this.read()};
 }
 fixtureSender(sender){return sender?.url===this.chrome.runtime.getURL('workflow-fixture.html')&&sender.frameId===0&&Number.isInteger(sender.tab?.id);}
 async resetFixture(message,sender){
  if(!this.fixtureSender(sender)||message.confirmedReset!==true)throw Error('只有固定测试页面可明确重置本地演练');
  const r=await this.read();if(r?.mode==='purchase'&&r.testMode===true){await this.stop('本地演练已重置，没有真实订单','STOPPED');await this.clearPrivate(r.id);}
  if(this.chrome.storage.local.remove)await this.chrome.storage.local.remove(TEST_FINAL_BARRIER);else await this.chrome.storage.local.set({[TEST_FINAL_BARRIER]:null});return{reset:true};
 }
 async start(message,sender,fixture=false){
  if(fixture&&(!this.fixtureSender(sender)||sender.tab.id!==message.tabId))throw Error('演练只能从固定扩展测试页面启动');
  const existing=await this.read();if(!ended(existing))throw Error('已有任务，请先停止');
  const barrier=fixture?TEST_FINAL_BARRIER:FINAL_BARRIER;
  if((await this.chrome.storage.local.get(barrier))[barrier])throw Error(fixture?'本地演练已有最终动作记录，请在测试页明确重置演练':'已有最终订单提交记录；请在官网人工核对。本版本不解除重复下单保护');
  const c=validatePurchase(message.config),address=validatePurchaseAddress(message.address,c),tab=await this.chrome.tabs.get(message.tabId);
  if(fixture){if(c.url!==FIXTURE_VIRTUAL||c.steps.some(step=>step.origin!=='https://www.apple.com.cn'||step.path!=='/shop/fixture'||step.query||step.adapter||step.confirm.nextPath||step.confirm.nextOrigin||step.confirm.nextQuery||step.confirm.allowAuthHandoff))throw Error('本地演练只允许固定虚拟页面的同页步骤');c.testMode=true;c.fixtureURL=this.chrome.runtime.getURL('workflow-fixture.html');}
  if(!tab.active||tab.url!==(fixture?c.fixtureURL:c.url))throw Error('请先在当前标签页打开配置中精确的 Apple 中国大陆链接');
  const origins=[...new Set(c.steps.flatMap(s=>[s.origin,s.confirm.nextOrigin??s.origin]))].map(host=>`${host}/*`);
  if(!fixture&&!await this.chrome.permissions.contains({origins}))throw Error('未获得 Apple 中国大陆站点权限');
  const id=crypto.randomUUID(),now=Date.now(),r={id,mode:'purchase',...(fixture?{testMode:true}:{}),tabId:tab.id,state:now<Date.parse(c.targetTime)?'WAITING_START':'READY',reason:now<Date.parse(c.targetTime)?'等待配置的开始时间':'准备执行已配置购买步骤',targetTime:Date.parse(c.targetTime),stepIndex:0,claims:[],claim:null,lastSeen:now,expiresAt:Date.parse(c.expiresAt),events:[]};
  if(fixture)r.reason=`本地演练：${r.reason}`;
  if(existing?.mode==='purchase')await this.clearPrivate(existing.id);
  await this.chrome.storage.session.set({[`config:${id}`]:c,...(address?{[`address:${id}`]:address}:{})});
  // Only canonical public configuration is ever written to local storage.
  if(!fixture)await this.chrome.storage.local.set({settings:c});this.event(r,fixture?'本地演练启动；不连接官网、不创建真实订单':'用户启动购买流程；仅允许经核验的未付款订单创建');await this.save(r);await this.paint(r);await this.chrome.alarms.create('watchdog',{periodInMinutes:1});
  try{await this.inject(r,c);}catch{await this.stop('无法启动购买页面，请人工检查');throw Error('无法启动购买页面，任务已暂停');}
  return {task:await this.read()};
 }
 async inject(r,c){
  let response;
  if(r.testMode)response=await sendFixtureControl(this.chrome,{type:'START_PURCHASE_FIXTURE',targetTabId:r.tabId,taskId:r.id,config:c});
  else{await this.chrome.scripting.executeScript({target:{tabId:r.tabId,frameIds:[0]},files:['dom-driver.js','apple-duo-readonly.js','purchase-policy.js','purchase-content.js'],injectImmediately:true});response=await this.chrome.tabs.sendMessage(r.tabId,{type:'START_PURCHASE',taskId:r.id,config:c},{frameId:0});}
  if(!response?.ok)throw Error('购买脚本未就绪');
 }

 async recover(workerRestart=false){
  const r=await this.read();if(r?.mode!=='purchase')return;
  if(r.claim?.status==='pending'&&['PAUSED','STOPPED'].includes(r.state)){await this.stop('恢复未确认的购买动作，结果未知','UNKNOWN');return;}
  if(ended(r))return;
  if(workerRestart&&r.claim?.status==='pending'&&r.claim.final){await this.stop('最终订单提交期间后台重启，结果未知，请人工核对且不要重试','UNKNOWN');return;}
  if(!await this.session(`config:${r.id}`)){await this.stop('购买会话配置丢失，请人工核对');return;}
  if(r.state!=='AWAITING_USER'&&r.claim?.status==='pending'&&(!Number.isFinite(r.claim.deadline)||Date.now()>r.claim.deadline)){await this.stop('购买动作结果超时未知，请人工核对','UNKNOWN');return;}
  if(Date.now()>r.expiresAt||!Number.isFinite(r.lastSeen)||r.state!=='AWAITING_USER'&&Date.now()-r.lastSeen>70000||r.lastSeen>Date.now()+1000){await this.stop('购买任务过期或页面心跳中断，请人工核对');return;}
  await this.chrome.alarms.create('watchdog',{periodInMinutes:1});
 }
 async navigation(tabId,change){
  const r=await this.read();if(r?.mode!=='purchase'||r.tabId!==tabId||ended(r))return;
  if(r.testMode){if(change.url||change.status==='loading')await this.stop('本地演练页面导航或重载，已停止');return;}
  const c=await this.session(`config:${r.id}`),step=c?.steps?.[r.stepIndex];
  if(!step){await this.stop('购买会话配置丢失，请人工核对');return;}
  const candidate=change.url??(change.status==='complete'?(await this.chrome.tabs.get(tabId)).url:null);
  if(change.status==='loading'){
   if(!step?.confirm.nextPath||r.claim?.status!=='pending'||r.claim.checked!==true){await this.stop('未经配置的导航或重载，请人工检查');return;}
   r.navigating=true;r.lastSeen=Date.now();await this.save(r);
  }
  if(candidate&&r.claim?.checked&&r.claim.status==='pending'&&step?.confirm.nextPath){r.navigating=true;await this.save(r);}
  if(candidate&&r.navigating&&!purchaseLocationMatches(candidate,nextPurchaseLocation(step))){
   let u;try{u=new URL(candidate);}catch{await this.stop('导航地址无效，动作结果未知','UNKNOWN');return;}if(step.confirm.allowAuthHandoff&&r.claim?.checked&&!r.claim.final&&u.origin==='https://secure6.www.apple.com.cn'&&u.pathname==='/shop/signIn'){r.state='AWAITING_USER';r.authHandoff=true;r.reason='请在官网手动完成登录，再明确检查当前页面后继续';r.lastSeen=Date.now();this.event(r,r.reason);await this.save(r);await this.paint(r);return;}
   if(r.state!=='AWAITING_USER'){await this.stop('导航离开精确授权路径，动作结果未知','UNKNOWN');return;}
  }
  if(r.state==='AWAITING_USER')return;
  if(change.status==='complete'&&r.navigating){
   const tab=await this.chrome.tabs.get(tabId);if(!purchaseLocationMatches(tab.url,nextPurchaseLocation(step))){await this.stop('导航结果与配置不符，动作结果未知','UNKNOWN');return;}
   try{await this.inject(r,c);}catch{await this.stop('后续页面无法验证，动作结果未知','UNKNOWN');}
  }
 }
 async resume(message){
  const r=await this.read();if(message.confirmedResume!==true||r?.mode!=='purchase'||r.state!=='AWAITING_USER'||!r.authHandoff||r.claim?.status!=='pending'||!r.claim.checked||r.claim.final)throw Error('没有可人工确认恢复的非最终步骤');
  if(Date.now()>r.expiresAt){await this.stop('会话已过期，请在官网人工完成后续流程');throw Error('购买会话已过期');}
  const c=await this.session(`config:${r.id}`),step=c?.steps[r.stepIndex],tab=await this.chrome.tabs.get(r.tabId);
  if(!step||!step.confirm.allowAuthHandoff||!purchaseLocationMatches(tab.url,nextPurchaseLocation(step))||purchaseLoginPath(new URL(tab.url).pathname))throw Error('当前页尚未到达已配置的登录后路径，请手动完成登录后核对');
  r.state='SUBMITTING';r.navigating=true;r.authHandoff=false;r.lastSeen=Date.now();r.claim.deadline=Date.now()+step.timeoutMs+5000;r.reason='已请求检查登录后页面，仅验证先前动作结果';await this.save(r);await this.inject(r,c);return{task:await this.read()};
 }
 async bind(message,sender,r,c){
  const nonce=message.documentNonce;if(typeof nonce!=='string'||!nonce||nonce.length>100)throw Error('购买文档标识无效');
  const path=new URL(sender.url).pathname,step=c.steps[r.stepIndex];
  const same=r.document?.nonce===nonce&&r.document?.id===sender.documentId;
  if(r.document&&!same){
   if(!r.navigating||r.claim?.status!=='pending'||!r.claim.checked||!step.confirm.nextPath||!purchaseLocationMatches(sender.url,nextPurchaseLocation(step))){await this.stop('购买页面文档发生未授权变化');throw Error('购买页面文档不匹配');}
  }else if(!r.document&&!purchaseLocationMatches(sender.url,step))throw Error('首个购买页面路径不匹配');
  if(same&&!purchaseLocationMatches(sender.url,step)&&!(r.claim?.status==='pending'&&r.claim.checked&&purchaseLocationMatches(sender.url,nextPurchaseLocation(step))))throw Error('购买步骤页面路径不匹配');
  if(message.url!==undefined&&message.url!==safePurchaseURL(sender.url))throw Error('购买页面地址不匹配');
  r.document={nonce,id:sender.documentId,path,origin:new URL(sender.url).origin};r.lastSeen=Date.now();await this.save(r);
  const response={config:c,state:r.state,stepIndex:r.stepIndex};
  if(r.claim?.status==='pending')response.pendingClaim={claimToken:r.claim.token,token:r.claim.token,deadline:r.claim.deadline,checked:r.claim.checked,stepIndex:r.claim.stepIndex,final:r.claim.final};
  if(c.addressMode==='new'&&['address','review','submit-unpaid'].includes(step.stage)&&(!r.navigating||purchaseLocationMatches(sender.url,step))){
   const address=await this.session(`address:${r.id}`);if(!address){await this.stop('本次会话地址已清除，请人工检查');throw Error('本次会话地址不存在');}response.address=address;
  }
  return response;
 }
 async addressFault(c,r,e){
  const step=c.steps[r.stepIndex];if(c.addressMode!=='existing'||!['address','review','submit-unpaid'].includes(step.stage))return null;
  const expected=await this.session(`selected-address:${r.id}`);if(!fingerprint(expected)||e.addressFingerprint!==expected)return '已选配送地址未经本地确认或发生变化';return null;
 }
 async result(message,r,c,sender){
  if(r.state!=='SUBMITTING'||r.claim?.status!=='pending'||r.claim.token!==message.claimToken||!r.claim.checked)throw Error('没有匹配的已检查待确认动作');
  const e=message.evidence,step=c.steps[r.stepIndex];
  if(message.outcome!=='confirmed'){await this.stop('购买动作结果未知，请人工核对且不要重试','UNKNOWN');return{state:'UNKNOWN',stepIndex:r.stepIndex};}
  const current=Date.now();
  if(!e||!Number.isFinite(e.observedAt)||current-e.observedAt>5000||e.observedAt>current+1000||e.url!==safePurchaseURL(sender.url)||!purchaseURL(e.url)||!purchaseLocationMatches(e.url,nextPurchaseLocation(step))||e.blocker||e.paymentCommit===true||!Array.isArray(e.ambiguity)||e.ambiguity.length||e.confirmation?.matched!==true||(step.adapter==='apple-duo'?e.confirmation.kind!=='apple-selection':e.confirmation.selector!==step.confirm.selector||normalizePurchaseText(e.confirmation.text)!==step.confirm.text)){await this.stop('购买动作后置条件未明确确认，结果未知','UNKNOWN');return{state:'UNKNOWN',stepIndex:r.stepIndex};}
  if(step.kind==='radio'){const field=step.group==='dimensionColor'?'color':'storage';if(e.radioChecked!==true||e.selectionApplied!==true||normalizePurchaseText(e[field])!==c[field]){await this.stop('规格选择未由独立页面证据确认，结果未知','UNKNOWN');return{state:'UNKNOWN',stepIndex:r.stepIndex};}}
  if(step.kind==='address'&&(e.addressComplete!==true||c.addressMode==='new'&&e.addressMatches!==true||await this.addressFault(c,r,e))){await this.stop('配送地址填写或核对结果未知','UNKNOWN');return{state:'UNKNOWN',stepIndex:r.stepIndex};}
  if(step.stage==='submit-unpaid'&&(e.unpaidOrder!==true||e.paymentCommit!==false)){await this.stop('订单是否未付款无法确认，请人工核对','UNKNOWN');return{state:'UNKNOWN',stepIndex:r.stepIndex};}
  r.claim.status='confirmed';r.claim.confirmedAt=current;r.claims.push({...r.claim});r.claim=null;r.stepIndex++;r.navigating=false;r.lastSeen=current;r.state=r.stepIndex===c.steps.length?'DONE':'WAITING';r.reason=r.state==='DONE'?(r.testMode?'本地演练已完成，没有真实订单或付款':'未付款订单已按配置的页面证据确认；请在官网人工核对，未执行付款'):`${r.testMode?'本地演练：':''}第 ${r.stepIndex} 步结果已确认`;
  this.event(r,r.reason);await this.save(r);await this.paint(r);if(r.state==='DONE'){await this.clearPrivate(r.id);await this.chrome.alarms.clear('watchdog');}return{state:r.state,stepIndex:r.stepIndex,reason:r.reason};
 }
 async handle(message,sender,r){
  if(r.testMode){if(!this.fixtureSender(sender))throw Error('本地演练消息不来自固定扩展测试页面');sender={...sender,url:FIXTURE_VIRTUAL};}
  if(sender.tab?.id!==r.tabId||sender.frameId!==0||typeof sender.documentId!=='string'||!sender.documentId||!purchaseURL(sender.url))throw Error('购买消息必须来自同一标签页顶层文档');
  await this.recover();r=await this.read();if(ended(r)||r.state==='AWAITING_USER')throw Error('购买任务已结束');
  const c=await this.session(`config:${r.id}`);if(!c)throw Error('购买会话已结束');
  if(purchaseLoginPath(new URL(sender.url).pathname)){await this.stop('登录或身份验证页面必须由用户处理');throw Error('请手动处理身份验证');}
  if(message.type==='PURCHASE_BIND')return this.bind(message,sender,r,c);
  if(r.document&&message.documentNonce===r.document.nonce&&sender.documentId===r.document.id&&r.claim?.checked&&r.claim.status==='pending'&&c.steps[r.stepIndex].confirm.nextPath&&purchaseLocationMatches(sender.url,nextPurchaseLocation(c.steps[r.stepIndex]))){r.document.path=new URL(sender.url).pathname;r.document.origin=new URL(sender.url).origin;r.navigating=true;await this.save(r);}
  if(!r.document||message.documentNonce!==r.document.nonce||sender.documentId!==r.document.id||new URL(sender.url).pathname!==r.document.path||new URL(sender.url).origin!==r.document.origin)throw Error('购买文档与任务不匹配');
  if(['PURCHASE_STOP','PURCHASE_DISCONNECT','DISCONNECT'].includes(message.type)){
   const step=c.steps[r.stepIndex];if(['DISCONNECT','PURCHASE_DISCONNECT'].includes(message.type)&&r.claim?.checked&&r.claim.status==='pending'&&step.confirm.nextPath){r.navigating=true;r.lastSeen=Date.now();await this.save(r);return{state:r.state,stepIndex:r.stepIndex};}
   return{task:await this.stop('用户停止或购买页面中断，请人工核对','STOPPED')};
  }
  if(message.type==='PURCHASE_HEARTBEAT'){r.lastSeen=Date.now();await this.save(r);return{state:r.state,stepIndex:r.stepIndex};}
  if(!Number.isInteger(message.stepIndex)||message.stepIndex!==r.stepIndex||!c.steps[r.stepIndex])throw Error('购买步骤不匹配');
  const step=c.steps[r.stepIndex];
  if(message.type==='PURCHASE_CONFIRM_ADDRESS'){
   if(c.addressMode!=='existing'||step.kind!=='address'||r.claim||message.addressConfirmed!==true||!fingerprint(message.addressFingerprint))throw Error('已选地址确认无效');
   const previous=await this.session(`selected-address:${r.id}`);if(previous&&previous!==message.addressFingerprint){await this.stop('已确认地址发生变化，请重新人工检查');throw Error('已选地址发生变化');}
   await this.chrome.storage.session.set({[`selected-address:${r.id}`]:message.addressFingerprint});return{addressConfirmed:true,state:r.state,stepIndex:r.stepIndex};
  }
  if(message.type==='PURCHASE_RESULT')return this.result(message,r,c,sender);
  if(!['PURCHASE_CLAIM','PURCHASE_CHECK'].includes(message.type))throw Error('未知购买消息');
  if(Date.now()<Date.parse(c.targetTime)){r.state='WAITING_START';r.lastSeen=Date.now();await this.save(r);return{action:'none',allowed:false,state:r.state,stepIndex:r.stepIndex,targetTime:c.targetTime};}
  if(message.evidence?.url!==safePurchaseURL(sender.url))throw Error('页面证据地址与发送文档不符');
  const fault=purchaseEvidenceFault(c,r.stepIndex,message.evidence)||await this.addressFault(c,r,message.evidence);if(fault){await this.stop(fault);throw Error(fault);}
  if(r.reviewTotal!==undefined&&['review','submit-unpaid'].includes(step.stage)&&r.reviewTotal!==message.evidence.totalMinor){await this.stop('已核对的完整订单总价发生变化');throw Error('完整订单总价发生变化');}
  if(message.type==='PURCHASE_CLAIM'){
   if(r.claim||r.state==='SUBMITTING')return{action:'none',state:r.state,stepIndex:r.stepIndex};
   const now=Date.now();r.claim={stepIndex:r.stepIndex,token:crypto.randomUUID(),time:now,deadline:now+step.timeoutMs+5000,status:'pending',checked:false,final:step.stage==='submit-unpaid'};
   r.state='SUBMITTING';r.reason=`${r.testMode?'本地演练：':''}正在执行购买第 ${r.stepIndex+1} 步`;r.lastSeen=now;if(['review','submit-unpaid'].includes(step.stage))r.reviewTotal=message.evidence.totalMinor;this.event(r,r.reason);
   if(r.claim.final){const barrier=r.testMode?TEST_FINAL_BARRIER:FINAL_BARRIER;if((await this.chrome.storage.local.get(barrier))[barrier])throw Error('最终订单动作已永久锁定，不能重复提交');await this.chrome.storage.local.set({currentTask:r,[barrier]:{taskId:r.id,claimedAt:now,status:'attempted'}});}else await this.save(r);
   await this.paint(r);return{action:'purchase-act',claimToken:r.claim.token,deadline:r.claim.deadline,state:r.state,stepIndex:r.stepIndex};
  }
  if(r.state!=='SUBMITTING'||r.claim?.status!=='pending'||r.claim.token!==message.claimToken||r.claim.checked)return{allowed:false,state:r.state,stepIndex:r.stepIndex};
  let address;if(c.addressMode==='new'&&['address','review','submit-unpaid'].includes(step.stage)){address=await this.session(`address:${r.id}`);if(!address){await this.stop('本次会话地址已清除');throw Error('本次会话地址已清除');}}
  r.claim.checked=true;r.lastSeen=Date.now();await this.save(r);return{allowed:true,deadline:r.claim.deadline,state:r.state,stepIndex:r.stepIndex,...(address?{address}:{})};
 }
}
