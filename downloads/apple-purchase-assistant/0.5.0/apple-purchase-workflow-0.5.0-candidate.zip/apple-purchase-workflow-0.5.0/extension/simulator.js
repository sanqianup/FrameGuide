import {TERMINAL} from './core.js';
import './dom-driver.js';
const D=globalThis.AppleDOMDriver,scope=document.querySelector('main'),actionLock={};
const target={names:['提交本地模拟订单'],context:scope};
scope.setAttribute('data-local-fixture','purchase');
const write=(el,value)=>{if(el.textContent!==value)el.textContent=value;};
const taskId=new URL(location.href).searchParams.get('task'),documentNonce=crypto.randomUUID();
const button=document.querySelector('#mock'),state=document.querySelector('#state'),clock=document.querySelector('#clock'),notice=document.querySelector('#notice'),result=document.querySelector('#result');
let tabId,config,timer,observer,busy=false,pending=false,lastFingerprint='',lastTick=0,end=0,reset=false,stopped=false,clicked=false,armed=false,virtualOrders=0;
const values={};
async function send(message){const r=await chrome.runtime.sendMessage({...message,taskId,tabId,documentNonce});if(!r?.ok)throw Error(r?.error||'后台连接中断');return r;}
function stopLocal(reason){stopped=true;clearTimeout(timer);observer?.disconnect();button.disabled=true;scope.setAttribute('data-fixture-ready','false');write(state,reason);}
async function disconnect(){stopLocal('页面离开或运行中断，任务已暂停');await send({type:'DISCONNECT'}).catch(()=>{});}
function text(key){return values[key]?.textContent??'';}
function snapshot(){
  const remain=Math.max(0,Math.ceil((end-Date.now())/1000));
  if(config.scenario==='reset'&&!reset&&remain<=1){end+=10000;reset=true;}
  const seconds=Math.max(0,Math.ceil((end-Date.now())/1000));
  write(clock,`${String(Math.floor(seconds/60)).padStart(2,'0')}:${String(seconds%60).padStart(2,'0')}`);
  if(config.scenario==='price'&&seconds<=1)write(values.total,'120.00');
  if(config.scenario==='soldout'&&seconds<=1)write(notice,'已售罄');
  const resolved=D.resolveTarget(scope,target),current=resolved.element;
  if(current&&current.disabled!==(seconds>0||clicked))current.disabled=seconds>0||clicked;
  return {...Object.fromEntries(['region','model','storage','color','quantity','currency','delivery'].map(key=>[key,text(key)])),
    observedAt:Date.now(),blocker:config.scenario==='payment'?'需要付款方式，请人工处理':config.scenario==='blocked'?'排队或访问限制，请人工处理':null,
    soldOut:config.scenario==='soldout'&&seconds<=1,totalMinor:Math.round(Number(text('total'))*100),countdownPresent:true,countdownText:clock.textContent,buttonUnique:resolved.status!=='ambiguous'&&!!current,buttonEnabled:!!current&&D.isEnabled(current)};
}
// Only this extension-owned button can create a virtual record. No fetch or real page click.
scope.addEventListener('click',event=>{
  const current=D.resolveTarget(scope,target).element;if(!current||!(event.target===current||current.contains(event.target)))return;
  if(!armed||clicked||stopped||location.origin!==chrome.runtime.getURL('').slice(0,-1)||location.pathname!=='/simulator.html')return;
  clicked=true;armed=false;current.disabled=true;virtualOrders+=1;
  if(virtualOrders!==1){stopLocal('重复模拟点击已阻止');return;}
  result.textContent=config.scenario==='unknown'?'模拟响应未知；没有真实订单':'模拟订单已确认；没有真实订单';
  scope.setAttribute('data-fixture-result',config.scenario==='unknown'?'unknown':'confirmed');
});
function nextDelay(){const remaining=end-Date.now();return remaining>0?Math.min(1000,remaining):1000;}
function wake(){if(stopped)return;if(busy){pending=true;return;}queueMicrotask(()=>void tick());}
async function tick(){
  if(stopped||busy)return;busy=true;clearTimeout(timer);
  try{
    const now=Date.now();if(document.visibilityState!=='visible'||(lastTick&&now-lastTick>Math.max(5000,config.pollMs*2.5)))throw Error('页面隐藏或计时中断');const s=snapshot(),fingerprint=JSON.stringify({...s,observedAt:0});
    if(fingerprint===lastFingerprint&&now-lastTick<1000){timer=setTimeout(wake,nextDelay());return;}
    lastTick=now;lastFingerprint=fingerprint;
    const r=await send({type:'OBSERVE',snapshot:s});
    if(stopped)return;write(state,r.reason);
    if(r.action==='mock-submit'){
      // Background writes the durable claim before returning this single action.
      const current=await send({type:'STATUS'});
      if(stopped||current.task?.id!==taskId||current.task.state!=='SUBMITTING')throw Error('模拟提交已取消');
      armed=true;
      const execution=await D.clickLocalFixture({root:document,scope,target,runtime:chrome.runtime,location,
        expected:{...config,totalMinor:s.totalMinor,maxTotalMinor:Math.round(Number(config.maxTotal)*100)},
        readSnapshot:snapshot,lock:actionLock,confirmTransition:()=>scope.getAttribute('data-fixture-result')||'pending'});
      armed=false;
      const outcome=execution.outcome==='confirmed'?'confirmed':'unknown';
      const done=await send({type:'MOCK_RESULT',outcome});stopLocal(done.reason);return;
    }
    if(TERMINAL.has(r.state)){stopLocal(r.reason);return;}
    timer=setTimeout(wake,nextDelay());
  }catch(e){stopLocal(e.message);await send({type:'DISCONNECT'}).catch(()=>{});}finally{busy=false;if(pending){pending=false;wake();}}
}
document.querySelector('#stop').onclick=async()=>{stopLocal('已停止，不会自动恢复');await send({type:'STOP'}).catch(()=>{});};
chrome.runtime.onMessage.addListener((message,sender,reply)=>{if(sender.id===chrome.runtime.id&&message.type==='HALT'&&message.taskId===taskId){stopLocal(message.reason);reply({ok:true});}});
addEventListener('pagehide',()=>{void disconnect();});
document.addEventListener('visibilitychange',()=>{if(document.visibilityState!=='visible')void disconnect();});
try{
  const tab=await chrome.tabs.getCurrent();tabId=tab.id;
  const r=await send({type:'SIM_CONFIG'});config=r.config;if(!config||config.mode!=='simulate')throw Error('模拟配置丢失，请重新预检');
  const labels={region:'地区',model:'型号',storage:'容量',color:'颜色',quantity:'数量',currency:'货币',delivery:'送达方式',total:'虚构含费用总价'};
  for(const[key,label]of Object.entries(labels)){const dt=document.createElement('dt'),dd=document.createElement('dd');dt.textContent=label;dd.textContent=String(key==='total'?'100.00':config[key]);values[key]=dd;document.querySelector('#fields').append(dt,dd);}
  if(config.scenario==='mismatch')values.color.textContent='与配置不符的模拟颜色';
  end=Date.parse(config.targetTime);
  scope.setAttribute('data-fixture-ready','true');
  observer=new MutationObserver(records=>{if(records.some(r=>!['state','result','clock'].includes(r.target.id)&&!['state','result','clock'].includes(r.target.parentElement?.id)))wake();});
  observer.observe(scope,{subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:['disabled','aria-disabled','aria-label','aria-labelledby','class','style','hidden']});
  wake();
}catch(e){stopLocal(e.message);await send({type:'DISCONNECT'}).catch(()=>{});}
