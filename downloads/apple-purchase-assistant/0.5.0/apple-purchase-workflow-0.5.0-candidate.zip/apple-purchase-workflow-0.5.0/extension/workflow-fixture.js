// An inert, self-contained fake shop. There are no network APIs or real orders.
// Extension mode uses the real purchase runner and service-worker protocol.
// HTTP mode is a separate DOM-only demonstration and never emulates chrome.runtime.
(() => {
  'use strict';
  const SCENARIOS = Object.freeze(['normal', 'rerender', 'cascade', 'stopped', 'unknown', 'delayed-final']);
  const ADDRESS = Object.freeze({ fullName: '测试收件人', phone: '13800000000', province: '测试省', city: '测试市', district: '测试区', addressLine1: '虚构路 1 号' });
  const FIELD_TYPES = Object.freeze({ fullName: 'name', phone: 'tel', province: 'address-level1', city: 'address-level2', district: 'address-level3', addressLine1: 'address-line1' });
  const FIELD_NAMES = Object.freeze({ fullName: '姓名', phone: '手机', province: '省份', city: '城市', district: '区县', addressLine1: '街道地址' });
  const EXPECTED_ACTIONS = Object.freeze(['color', 'storage', 'add', ...Object.keys(ADDRESS).map(key => `field:${key}`), 'review', 'submit']);
  function buildConfig(url, scenario = 'normal', now = Date.now()) {
    if (!SCENARIOS.includes(scenario)) throw Error('Unknown fixture scenario');
    const parsed = new URL(url);
    if (parsed.protocol !== 'chrome-extension:' || parsed.pathname !== '/workflow-fixture.html' || parsed.search || parsed.hash || parsed.username || parsed.password) throw Error('Fixture configuration requires its exact extension page');
    const evidence = { model: '#fixture-model', storage: '#fixture-storage', color: '#fixture-color', quantity: '#fixture-quantity', currency: '#fixture-currency', region: '#fixture-region', delivery: '#fixture-delivery', itemCount: '#fixture-item-count', itemPrice: '#fixture-item-price', total: '#fixture-total', noCharge: '#fixture-no-charge' };
    const common = { origin: 'https://www.apple.com.cn', path: '/shop/fixture', timeoutMs: 7000, evidence };
    const addressConfirmation = { selector: '#fixture-destination', keys: Object.keys(ADDRESS) };
    const totalIncludesTaxShipping = { selector: '#fixture-complete-total', text: '总价包含税费和配送费' };
    return { mode: 'purchase', confirmedPurchase: true, addressMode: 'new', url: 'https://www.apple.com.cn/shop/fixture', region: 'CN', regionConfirmed: true, model: 'Fixture Phone', storage: '256GB', color: '测试绿色', quantity: 1, currency: 'CNY', delivery: '测试配送', maxTotal: 99, pollMs: 1000, targetTime: new Date(now).toISOString(), expiresAt: new Date(now + 5 * 60000).toISOString(), steps: [
      { ...common, stage: 'configure', kind: 'radio', group: 'dimensionColor', target: { role: 'radio', name: '测试绿色', selector: '#fixture-color-choice' }, evidence: { model: evidence.model, color: evidence.color }, confirm: { selector: '#fixture-color-done', text: '测试颜色已应用' } },
      { ...common, stage: 'configure', kind: 'radio', group: 'dimensionCapacity', target: { role: 'radio', name: '256GB', selector: '#fixture-storage-choice' }, evidence: { model: evidence.model, color: evidence.color, storage: evidence.storage }, confirm: { selector: '#fixture-storage-done', text: '测试容量已应用' } },
      { ...common, stage: 'add-to-bag', kind: 'button', target: { role: 'button', name: '加入测试购物袋', selector: '#fixture-add' }, confirm: { selector: '#fixture-bag-done', text: '测试商品已加入购物袋' } },
      { ...common, stage: 'address', kind: 'address', fields: Object.entries(FIELD_TYPES).map(([key, autocomplete]) => ({ key, autocomplete, name: FIELD_NAMES[key], selector: `#fixture-field-${key}` })), addressConfirmation, confirm: { selector: '#fixture-address-done', text: '测试地址已核对' } },
      { ...common, stage: 'review', kind: 'button', target: { role: 'button', name: '核对测试信息', selector: '#fixture-review' }, addressConfirmation, totalIncludesTaxShipping, confirm: { selector: '#fixture-review-done', text: '测试信息核对完成' } },
      { ...common, timeoutMs: scenario === 'unknown' ? 1500 : 7000, stage: 'submit-unpaid', kind: 'button', target: { role: 'button', name: '创建测试未付款订单', selector: '#fixture-submit' }, addressConfirmation, totalIncludesTaxShipping, noChargeText: '创建未付款订单，不扣款', confirm: { selector: '#fixture-order-created', text: '测试订单已创建，待付款' } }
    ] };
  }
  const round = n => Number.isFinite(n) ? Math.round(n * 100) / 100 : null;
  function sanitizedMetrics(run) {
    if (!run) return { schemaVersion: 1, status: 'NOT_RUN', installedExtensionVerified: false };
    const actions = EXPECTED_ACTIONS.map(key => {
      const entry = run.actions[key] || {};
      return { action: key, readyMs: round(entry.ready), reactionMs: round(entry.reaction), readinessToReactionMs: Number.isFinite(entry.ready) && Number.isFinite(entry.reaction) ? round(entry.reaction - entry.ready) : null, completedMs: round(entry.completed), count: entry.count || 0, duplicates: Math.max(0, (entry.count || 0) - 1) };
    });
    return { schemaVersion: 1, scenario: run.scenario, execution: run.execution, installedExtensionVerified: run.execution === 'extension-runtime' && run.runtimeSeen === true, measuredIn: 'current browser performance.now()', status: run.status, backendState: run.backendState || null, elapsedMs: round((run.ended ?? run.clock()) - run.started), expectedActions: EXPECTED_ACTIONS.length, observedActions: actions.filter(row => row.count).length, duplicateActions: actions.reduce((sum, row) => sum + row.duplicates, 0), orderSubmissions: run.actions.submit?.count || 0, orderResults: run.orderResults, addressCompleteMs: round(run.addressCompleteMs), replacements: run.replacements, actions, events: run.events.map(event => ({ event: event.event, atMs: round(event.atMs) })), limitations: run.execution === 'extension-runtime' ? ['虚构页面结果不代表真实商店已验证。'] : ['未安装扩展，仅模拟网页交互。', '本结果不能证明扩展注入、后台授权、实际购买链路或真实网站可用。'] };
  }
  globalThis.WorkflowFixture = Object.freeze({ SCENARIOS, ADDRESS, FIELD_TYPES, EXPECTED_ACTIONS, buildConfig, sanitizedMetrics });
  if (typeof document === 'undefined') return;
  const $ = id => document.getElementById(id);
  const exactExtension = globalThis.chrome?.runtime?.id && typeof chrome.runtime.getURL === 'function' && location.href === chrome.runtime.getURL('workflow-fixture.html');
  let run = null, serial = 0, runnerReady = null;
  $('fixture-mode').textContent = exactExtension ? '扩展内置虚构商店。启动后使用实际购买脚本与后台；仅测试本页面。' : '未安装扩展，仅模拟网页交互。此处的演示结果不代表扩展已通过浏览器安装测试。';
  $('fixture-run').textContent = exactExtension ? '运行完整扩展测试' : '运行完整网页演示';
  function elapsed(r = run) { return r.clock() - r.started; }
  function later(fn, ms, r = run) { const id = setTimeout(() => { r.timers.delete(id); if (run === r && r.active) fn(); }, ms); r.timers.add(id); return id; }
  function event(name, r = run) { r.events.push({ event: name, atMs: elapsed(r) }); renderMetrics(); }
  function actionReady(key, r = run) { const item = r.actions[key] ??= { count: 0 }; item.ready ??= elapsed(r); event(`ready:${key}`, r); }
  function actionReact(key, r = run) { const item = r.actions[key] ??= { count: 0 }; item.reaction ??= elapsed(r); item.count++; event(`reaction:${key}`, r); }
  function actionComplete(key, r = run) { const item = r.actions[key] ??= { count: 0 }; item.completed ??= elapsed(r); event(`completed:${key}`, r); }
  function status(text) { $('fixture-status').textContent = text; }
  function renderMetrics() {
    const result = sanitizedMetrics(run); $('fixture-metrics').textContent = JSON.stringify(result, null, 2);
    $('fixture-metrics-summary').textContent = run ? `${result.status} · 动作 ${result.observedActions}/${result.expectedActions} · 重复 ${result.duplicateActions} · 提交 ${result.orderSubmissions} · ${result.elapsedMs} ms` : '尚无测量。';
  }
  function node(tag, props = {}, text = '') { const element = document.createElement(tag); for (const [key, value] of Object.entries(props)) { if (key === 'class') element.className = value; else element.setAttribute(key, String(value)); } element.textContent = text; return element; }
  function message(id, text, parent = $('fixture-store')) { const element = node('p', { id, class: 'stage-message' }, text); parent.append(element); return element; }
  function makeRadio(key, label, group, r) {
    const wrap = node('div', { class: 'radio-option' }), input = node('input', { id: `fixture-${key}-choice`, type: 'radio', name: group, 'aria-label': label });
    input.disabled = true; wrap.append(input, node('label', { for: input.id }, label));
    input.addEventListener('change', () => {
      if (!r.active || !input.checked) return; actionReact(key, r); $('fixture-' + key).textContent = label;
      later(() => { message(`fixture-${key}-done`, key === 'color' ? '测试颜色已应用' : '测试容量已应用'); actionComplete(key, r); if (key === 'color') showStorage(r); else showAdd(r); }, 90, r);
    });
    return { wrap, input };
  }
  function revealRadio(key, label, group, r) {
    const box = node('fieldset'); box.append(node('legend', {}, key === 'color' ? '选择测试颜色' : '选择测试容量'));
    let choice = makeRadio(key, label, group, r); box.append(choice.wrap); $('fixture-store').append(box);
    if (r.scenario === 'rerender') later(() => { const replacement = makeRadio(key, label, group, r); choice.wrap.replaceWith(replacement.wrap); choice = replacement; r.replacements++; event(`replace:${key}`, r); }, 70, r);
    later(() => { choice.input.disabled = false; actionReady(key, r); }, 190, r);
  }
  function showStorage(r) { later(() => revealRadio('storage', '256GB', 'dimensionCapacity', r), 150, r); }
  function makeAction(key, label, handler, r) { const button = node('button', { id: `fixture-${key}`, type: 'button' }, label); button.disabled = true; button.addEventListener('click', () => { if (!r.active || button.disabled) return; actionReact(key, r); button.disabled = true; handler(); }); return button; }
  function delayedAction(key, label, handler, r, delay = 190) {
    let button = makeAction(key, label, handler, r); $('fixture-store').append(button);
    if (r.scenario === 'rerender') later(() => { const replacement = makeAction(key, label, handler, r); button.replaceWith(replacement); button = replacement; r.replacements++; event(`replace:${key}`, r); }, 70, r);
    later(() => { button.disabled = false; actionReady(key, r); }, delay, r);
  }
  function showAdd(r) {
    later(() => {
      if (r.scenario === 'stopped') { void stopRun('scenario'); return; }
      delayedAction('add', '加入测试购物袋', () => later(() => { message('fixture-bag-done', '测试商品已加入购物袋'); actionComplete('add', r); showAddress(r); }, 180, r), r);
    }, 180, r);
  }
  function createField(key, r) {
    const isSelect = ['province', 'city', 'district'].includes(key), wrapper = node('div', { class: 'address-field', id: `fixture-wrap-${key}` });
    const control = node(isSelect ? 'select' : 'input', { id: `fixture-field-${key}`, name: key, autocomplete: FIELD_TYPES[key], 'aria-label': FIELD_NAMES[key], ...(isSelect ? {} : { type: key === 'phone' ? 'tel' : 'text' }) });
    wrapper.append(node('label', { for: control.id }, FIELD_NAMES[key]), control);
    if (isSelect) { control.append(node('option', { value: '' }, `请选择${FIELD_NAMES[key]}`)); control.disabled = true; }
    control.addEventListener('input', () => { if (!r.active) return; actionReact(`field:${key}`, r); });
    control.addEventListener('change', () => {
      if (!r.active) return; event(`change:${key}`, r);
      if (readField(key) === ADDRESS[key]) actionComplete(`field:${key}`, r);
      if (key === 'province') cascade('city', r); if (key === 'city') cascade('district', r);
      checkAddress(r);
    });
    return { wrapper, control };
  }
  function optionReady(key, r) {
    const control = $(`fixture-field-${key}`); if (!control || !r.active) return;
    control.append(node('option', { value: `test-${key}` }, ADDRESS[key])); control.disabled = false; actionReady(`field:${key}`, r);
  }
  function cascade(key, r) {
    const control = $(`fixture-field-${key}`); if (!control) return;
    control.disabled = true; while (control.options.length > 1) control.remove(1); control.value = '';
    const delay = r.scenario === 'cascade' ? 850 : 280;
    if (r.scenario === 'rerender' || r.scenario === 'cascade') later(() => { const replacement = createField(key, r); $(`fixture-wrap-${key}`).replaceWith(replacement.wrapper); r.replacements++; event(`replace:field:${key}`, r); }, Math.min(100, delay / 2), r);
    later(() => optionReady(key, r), delay, r);
  }
  function readField(key) { const control = $(`fixture-field-${key}`); if (!control) return ''; return control.tagName === 'SELECT' ? control.selectedOptions[0]?.textContent || '' : control.value; }
  function showAddress(r) {
    const box = node('fieldset'); box.append(node('legend', {}, '填写虚构地址'));
    box.append(node('p', { class: 'muted' }, '虚构地址示例：测试收件人 · 13800000000 · 测试省 / 测试市 / 测试区 · 虚构路 1 号'));
    const fields = node('div', { id: 'fixture-address-fields' }); box.append(fields); $('fixture-store').append(box);
    message('fixture-destination', '地址尚未完成');
    for (const key of Object.keys(ADDRESS).filter(key => key !== 'addressLine1')) {
      const field = createField(key, r); fields.append(field.wrapper);
      if (!['province', 'city', 'district'].includes(key)) actionReady(`field:${key}`, r);
    }
    later(() => optionReady('province', r), 210, r);
    later(() => { const field = createField('addressLine1', r); fields.append(field.wrapper); actionReady('field:addressLine1', r); }, 350, r);
    event('address:mounted', r);
  }
  function checkAddress(r) {
    if (r.addressDone || !Object.keys(ADDRESS).every(key => readField(key) === ADDRESS[key])) return;
    r.addressDone = true; r.addressCompleteMs = elapsed(r); $('fixture-destination').textContent = Object.keys(ADDRESS).map(key => readField(key)).join(' ');
    later(() => { message('fixture-address-done', '测试地址已核对'); event('address:confirmed', r); delayedAction('review', '核对测试信息', () => later(() => { message('fixture-review-done', '测试信息核对完成'); actionComplete('review', r); showSubmit(r); }, 170, r), r); }, 100, r);
  }
  function showSubmit(r) {
    delayedAction('submit', '创建测试未付款订单', () => {
      event('order:requested', r);
      if (r.scenario === 'unknown') { if (r.execution !== 'extension-runtime') later(() => finish('UNKNOWN', '测试结果未知；提交次数保持为 1，不自动重试。', r), 1500, r); return; }
      later(() => {
        message('fixture-order-created', '测试订单已创建，待付款'); r.orderResults++; actionComplete('submit', r);
        if (r.execution !== 'extension-runtime') finish('DONE', '网页演示已完成。该结果只验证本页交互。', r);
      }, r.scenario === 'delayed-final' ? 2500 : 350, r);
    }, r, 240);
  }
  function finish(state, text, r = run) { if (run !== r) return; r.status = state; r.ended ??= r.clock(); r.active = false; for (const timer of r.timers) clearTimeout(timer); r.timers.clear(); $('fixture-stop').disabled = true; $('fixture-run').disabled = false; $('fixture-manual').disabled = false; $('fixture-scenario').disabled = false; status(text); renderMetrics(); }
  async function stopRun(reason = 'user') {
    const r = run; if (!r?.active) return;
    if (r.execution === 'extension-runtime') { try { const reply = await chrome.runtime.sendMessage({ type: 'STOP' }); if (!reply?.ok) throw Error(); r.backendState = reply.task?.state || 'STOPPED'; } catch { finish('ERROR', '停止请求未获后台确认，请关闭测试页面。', r); return; } }
    event(`stop:${reason}`, r); finish(r.backendState || 'STOPPED', '测试已停止；不会继续后续动作。', r);
  }
  function prepare(execution) {
    if (run?.active) throw Error('已有演示正在运行');
    const scenario = $('fixture-scenario').value; if (!SCENARIOS.includes(scenario)) throw Error('无效场景');
    run = { id: ++serial, scenario, execution, started: performance.now(), clock: () => performance.now(), active: true, status: 'RUNNING', actions: {}, events: [], timers: new Set(), replacements: 0, orderResults: 0, runtimeSeen: false, addressDone: false };
    $('fixture-store').replaceChildren(); $('fixture-color').textContent = '未选择'; $('fixture-storage').textContent = '未选择';
    $('fixture-run').disabled = true; $('fixture-manual').disabled = true; $('fixture-scenario').disabled = true; $('fixture-stop').disabled = false;
    status(execution === 'extension-runtime' ? '扩展测试运行中；等待真实后台确认。' : '网页演示运行中；未验证扩展安装。'); renderMetrics();
    const r = run; later(() => revealRadio('color', '测试绿色', 'dimensionColor', r), 220, r); return r;
  }
  function loadRunner() {
    if (!exactExtension) return Promise.reject(Error('仅扩展页面可载入实际购买脚本'));
    if (!runnerReady) runnerReady = new Promise((resolve, reject) => { const script = node('script', { src: 'purchase-content.js' }); script.onload = resolve; script.onerror = () => reject(Error('实际购买脚本未加载')); document.head.append(script); });
    return runnerReady;
  }
  async function pollBackend(r) {
    if (!r.active || run !== r) return;
    try {
      const reply = await chrome.runtime.sendMessage({ type: 'STATUS' });
      if (!reply?.ok || reply.task?.id !== r.taskId || reply.task?.testMode !== true) throw Error('后台测试任务不匹配');
      r.backendState = reply.task.state; r.runtimeSeen = true; renderMetrics();
      if (['DONE', 'STOPPED', 'UNKNOWN', 'PAUSED'].includes(r.backendState)) { finish(r.backendState, `扩展后台状态：${r.backendState}。提交 ${r.actions.submit?.count || 0} 次。`, r); return; }
    } catch (error) { finish('ERROR', `无法核验实际后台：${error.message}`, r); return; }
    later(() => void pollBackend(r), 250, r);
  }
  async function startExtension() {
    await loadRunner();
    const tab = await chrome.tabs.getCurrent(); if (!Number.isInteger(tab?.id)) throw Error('请在独立扩展标签页打开测试台');
    const r = prepare('extension-runtime');
    try {
      const reset = await chrome.runtime.sendMessage({ type: 'PURCHASE_FIXTURE_RESET', confirmedReset: true });
      if (!reset?.ok) throw Error(reset?.error || '无法重置隔离测试记录');
      const response = await chrome.runtime.sendMessage({ type: 'PURCHASE_FIXTURE_START', tabId: tab.id, config: buildConfig(location.href, r.scenario), address: { ...ADDRESS } });
      if (!response?.ok || response.task?.testMode !== true) throw Error(response?.error || '后台没有确认隔离测试任务');
      r.taskId = response.task.id; r.backendState = response.task.state; r.runtimeSeen = true; void pollBackend(r);
    } catch (error) { finish('ERROR', `测试未启动：${error.message}`, r); }
  }
  // This driver is deliberately separate from purchase-content. It demonstrates
  // the fake page in a browser when installation is unavailable, with honest labels.
  function startPageDemo() {
    const r = prepare('standalone-page-demo');
    function tick() {
      if (!r.active || run !== r) return;
      for (const key of ['color', 'storage']) { const input = $(`fixture-${key}-choice`); if (input && !input.disabled && !input.checked) { input.click(); return later(tick, 30, r); } }
      const add = $('fixture-add'); if (add && !add.disabled && !r.actions.add?.count) { add.click(); return later(tick, 30, r); }
      for (const key of Object.keys(ADDRESS)) {
        const control = $(`fixture-field-${key}`); if (!control || control.disabled || r.actions[`field:${key}`]?.count) continue;
        let value = ADDRESS[key];
        if (control.tagName === 'SELECT') { const option = [...control.options].find(option => option.textContent === value); if (!option) continue; value = option.value; }
        const prototype = control.tagName === 'SELECT' ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
        Object.getOwnPropertyDescriptor(prototype, 'value').set.call(control, value); control.dispatchEvent(new Event('input', { bubbles: true })); control.dispatchEvent(new Event('change', { bubbles: true }));
        return later(tick, 30, r);
      }
      for (const key of ['review', 'submit']) { const button = $(`fixture-${key}`); if (button && !button.disabled && !r.actions[key]?.count) { button.click(); return later(tick, 30, r); } }
      later(tick, 30, r);
    }
    tick();
  }
  $('fixture-run').addEventListener('click', () => { void (async () => { try { if (exactExtension) await startExtension(); else startPageDemo(); } catch (error) { if (run?.active) finish('ERROR', error.message); else status(error.message); } })(); });
  $('fixture-manual').addEventListener('click', () => { try { prepare('manual-page-demo'); status('手动网页演示：请选择测试颜色与容量，再依次操作。只使用页面列出的虚构地址。'); } catch (error) { status(error.message); } });
  $('fixture-stop').addEventListener('click', () => void stopRun());
  $('fixture-copy').addEventListener('click', async () => { try { await navigator.clipboard.writeText(JSON.stringify(sanitizedMetrics(run), null, 2)); status('已复制脱敏测量 JSON。'); } catch { status('浏览器未允许剪贴板写入，请选择下方 JSON 复制或下载。'); } });
  $('fixture-download').addEventListener('click', () => { const blob = new Blob([JSON.stringify(sanitizedMetrics(run), null, 2)], { type: 'application/json' }), url = URL.createObjectURL(blob), link = node('a', { href: url, download: `workflow-fixture-${run?.scenario || 'not-run'}-metrics.json` }); document.body.append(link); link.click(); link.remove(); setTimeout(() => URL.revokeObjectURL(url), 1000); });
})();
