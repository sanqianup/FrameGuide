import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {ADDRESS_KEYS, parseCalibration, calibrationExample, buildSubmission, clearAddressFields, confirmationSummary, purchasePermissions, purchaseStartTime, knownTargetMetadata, createPurchaseUI} from '../extension/purchase-ui.js';
import {validatePurchase} from '../extension/purchase-config.js';

// Shipped-controller tests with deterministic Node DOM/Chrome mocks. These do
// not open Apple pages, install an extension, or claim browser acceptance.
const html = fs.readFileSync(new URL('../extension/purchase.html', import.meta.url), 'utf8');
const source = fs.readFileSync(new URL('../extension/purchase-ui.js', import.meta.url), 'utf8');
const productURL = 'https://www.apple.com.cn/shop/fictitious-product';
function element() {
  return {value:'',checked:false,disabled:false,hidden:false,textContent:'',listeners:new Map(),
    children:[],replaceChildren(...children) {this.children=children;},addEventListener(type, callback) { this.listeners.set(type, callback); }};
}
function dom() {
  const form = element(); form.elements = {};
  const nodes = new Map([['#purchase-settings',form]]);
  for (const [,tag,attrs,id] of html.matchAll(/<([\w-]+)\b([^>]*\bid="([^"]+)"[^>]*)>/g)) {
    const node = id === 'purchase-settings' ? form : element();
    node.hidden = /\bhidden\b/.test(attrs); node.disabled = /\bdisabled\b/.test(attrs);
    nodes.set(`#${id}`,node);
  }
  for (const [,tag,attrs,name] of html.matchAll(/<(input|select|textarea)\b([^>]*\bname="([^"]+)"[^>]*)>/g)) {
    const node = element(); node.name = name; node.value = /\bvalue="([^"]*)"/.exec(attrs)?.[1] || '';
    form.elements[name] = node;
  }
  form.elements.addressMode.value = 'existing'; form.elements.targetMode.value = 'existing';
  return {form,nodes,document:{querySelector:selector => nodes.get(selector) || null,createElement:() => element()}};
}
function fill(form, {mode='existing',consent=true} = {}) {
  const values = {url:productURL,model:'虚构型号',storage:'虚构容量',color:'虚构颜色',quantity:'1',maxTotal:'200',addressMode:mode,calibration:JSON.stringify(calibrationExample(mode)),targetMode:'existing'};
  for (const [key,value] of Object.entries(values)) form.elements[key].value = value;
  form.elements.confirmedPurchase.checked = consent;
  form.elements.confirmedExistingAddress.checked = consent;
  for (const key of ADDRESS_KEYS) form.elements[`address_${key}`].value = `PRIVATE-${key}`;
  form.elements.address_phone.value = '13800000000';
  form.elements.address_postalCode.value = '000000';
  return form;
}
async function harness(options = {}) {
  const view = dom(), messages = [], permissionRequests = [], tabCalls = [], timers = new Map(), lifecycle = new Map();
  const backend = {settings:options.settings || null,task:options.task || null,profile:options.profile || null,failure:null,
    async send(message) {
      if (message.type === 'PURCHASE_PICK_TABS') return {ok:true,tabs:options.pickerTabs || []};
      if (message.type === 'STATUS') { if (this.failure) throw Error('offline'); return {ok:true,settings:this.settings,task:this.task}; }
      if (message.type === 'PURCHASE_SAVE_ADDRESS_PROFILE') { this.profile = structuredClone(message.address); if (options.profileSaveWait) await options.profileSaveWait; return {ok:true,saved:true}; }
      if (message.type === 'PURCHASE_LOAD_ADDRESS_PROFILE') { const profile = this.profile ? {region:'CN',address:structuredClone(this.profile)} : null; if (options.profileLoadWait) await options.profileLoadWait; return {ok:true,profile}; }
      if (message.type === 'PURCHASE_CLEAR_ADDRESS_PROFILE') { this.profile = null; if (this.task) this.task = {...this.task,state:'STOPPED'}; return {ok:true,cleared:true,task:this.task}; }
      if (message.type === 'START') { this.settings = structuredClone(message.config); this.task = {id:'task-1',mode:'purchase',state:'WAITING',tabId:7,reason:'等待页面证据'}; }
      else if (message.type === 'STOP' || message.type === 'PURCHASE_CLEAR_ADDRESS') { if (this.task) this.task = {...this.task,state:'STOPPED',reason:'已停止'}; }
      else if (message.type === 'PURCHASE_RESUME') this.task = {...this.task,state:'WAITING',reason:'检查页面结果'};
      else throw Error('Unexpected message');
      return {ok:true,task:this.task};
    }};
  const tabs = options.tabs || [{id:7,url:productURL,status:'complete',active:false}];
  const chrome = {
    runtime:{async sendMessage(message) { messages.push(structuredClone(message)); return backend.send(message); }},
    permissions:{async request(request) { permissionRequests.push(request); if (options.permissionWait) await options.permissionWait; return options.granted !== false; }},
    storage:new Proxy({}, {get() { throw Error('The setup UI may not access storage'); }}),
    tabs:{async query(request) { tabCalls.push(['query',request]); return tabs; },
      async create(request) { tabCalls.push(['create',request]); return {id:8,status:'complete',...request}; },
      async update(id,request) { tabCalls.push(['update',id,request]); return {id,...request}; },
      async get(id) { tabCalls.push(['get',id]); return options.currentTab || {id,url:productURL,status:'complete'}; }},
  };
  let editorPlan = [], editorChange;
  const mountEditor = (host,{onChange}) => { assert.equal(host,view.nodes.get('#purchase-editor')); editorChange = onChange; return {setPlan:plan => {editorPlan = structuredClone(plan);},getPlan:() => structuredClone(editorPlan)}; };
  let guideOptions = null,guideMounted = 0,guideDestroyed = false;
  const mountCalibration = (host,callbacks) => { assert.equal(host,view.nodes.get('#guided-setup-host')); guideOptions=callbacks; ++guideMounted; return {refresh(){},destroy(){guideDestroyed=true;}}; };
  const ui = await createPurchaseUI({...view,chrome,mountEditor,mountCalibration,setInterval:(callback,delay) => { timers.set(1,{callback,delay}); return 1; },clearInterval:id => timers.delete(id),setTimeout:callback => callback(),addEventListener:(type,callback) => lifecycle.set(type,callback)});
  return {...view,chrome,ui,backend,messages,permissionRequests,tabCalls,timers,lifecycle,guide:()=>guideOptions,guideMounted:()=>guideMounted,guideDestroyed:()=>guideDestroyed,node:selector => view.nodes.get(selector),editorPlan:() => editorPlan,editPlan:plan => {editorPlan=structuredClone(plan);editorChange(plan);},
    async submit() { let prevented = false; await view.form.onsubmit({preventDefault(){prevented=true;}}); assert.equal(prevented,true); }};
}

test('the compact purchase UI is Chinese, explicit about verification limits, and preserves its linked entry', () => {
  const popup = fs.readFileSync(new URL('../extension/popup.html', import.meta.url),'utf8');
  assert.match(html,/lang="zh-CN"/); assert.match(popup,/href="purchase.html" target="_blank" rel="noopener"/);
  assert.match(html,/虚构名称和选择器/); assert.match(html,/自行登录/); assert.match(html,/最终含费总价/);
  assert.doesNotMatch(source,/(?:localStorage|sessionStorage|console\.|fetch\(|XMLHttpRequest|innerHTML)/);
  assert.doesNotMatch(html,/<script[^>]*>\s*[^<\s]/);
});

test('fictitious calibration examples validate for both address modes and make no real Apple selector claim', () => {
  for (const mode of ['existing','new']) {
    const form = fill(dom().form,{mode}); const {config} = buildSubmission(form);
    assert.equal(config.steps.length,4); assert.equal(config.addressMode,mode);
    assert.ok(config.steps.every(step => step.path.includes('/fictitious-')));
    assert.match(JSON.stringify(config.steps),/fiction-/);
  }
});

test('JSON parsing errors never echo pasted address, password, or malformed raw content', () => {
  assert.throws(() => parseCalibration('{PRIVATE-ADDRESS'), error => !error.message.includes('PRIVATE'));
  assert.throws(() => parseCalibration('{}'),/数组/);
  assert.throws(() => parseCalibration(''),/没有可直接使用/);
});

test('every start requires fresh explicit consent and existing-address acknowledgement', () => {
  const form = fill(dom().form,{consent:false});
  assert.throws(() => buildSubmission(form),/本次购买流程授权/);
  form.elements.confirmedPurchase.checked = true;
  assert.throws(() => buildSubmission(form),/核对网页已选地址/);
  form.elements.confirmedExistingAddress.checked = true;
  const submission = buildSubmission(form);
  assert.equal(submission.address,undefined);
  assert.equal(submission.config.region,'CN'); assert.equal(submission.config.currency,'CNY');
  assert.equal(submission.config.delivery,'国内配送');
});

test('new address values are separate from canonical config and only mapped fields are transmitted', () => {
  const form = fill(dom().form,{mode:'new'}); const submission = buildSubmission(form);
  assert.equal(submission.address.fullName,'PRIVATE-fullName');
  assert.equal(submission.address.email,undefined);
  assert.equal(JSON.stringify(submission.config).includes('PRIVATE'),false);
  form.elements.address_phone.value = '';
  assert.throws(() => buildSubmission(form),error => /临时地址字段/.test(error.message) && !error.message.includes('PRIVATE'));
});

test('confirmation displays exact target and inclusive CNY limit but no address values', () => {
  const form = fill(dom().form,{mode:'new'}); const summary = confirmationSummary(form);
  for (const text of [productURL,'虚构型号','虚构容量','虚构颜色','× 1','CNY 200.00','税费','配送费','Apple 中国大陆']) assert.ok(summary.includes(text),text);
  assert.equal(summary.includes('PRIVATE'),false);
  clearAddressFields(form);
  assert.ok(ADDRESS_KEYS.every(key => form.elements[`address_${key}`].value === ''));
  assert.equal(form.elements.confirmedPurchase.checked,false);
});

test('permissions include only explicit canonical Apple origins, not arbitrary subdomains', () => {
  assert.deepEqual(purchasePermissions({steps:[]}),{origins:['https://www.apple.com.cn/*']});
  assert.deepEqual(purchasePermissions({steps:[{origin:'https://www.apple.com.cn',confirm:{nextOrigin:'https://secure6.www.apple.com.cn'}}]}),{origins:['https://www.apple.com.cn/*','https://secure6.www.apple.com.cn/*']});
  assert.throws(() => purchasePermissions({steps:[{origin:'https://evil.apple.com.cn'}]}),/未授权/);
});

test('STATUS restores only public purchase settings and resets all consent and address fields', async () => {
  const config = buildSubmission(fill(dom().form)).config;
  const h = await harness({settings:{...config,address:{fullName:'PRIVATE'},address_phone:'PRIVATE',confirmedPurchase:true}});
  assert.equal(h.form.elements.url.value,productURL);
  assert.equal(h.form.elements.confirmedPurchase.checked,false);
  assert.ok(ADDRESS_KEYS.every(key => h.form.elements[`address_${key}`].value === ''));
  assert.equal(h.messages.length,1); assert.equal(h.messages[0].type,'STATUS');
  assert.equal(h.permissionRequests.length,0); assert.equal(h.tabCalls.length,0);
});

test('old-mode settings never become a purchase authorization or purchase preset', async () => {
  const h = await harness({settings:{mode:'assist',url:productURL,model:'old'},task:{mode:'assist',state:'WAITING'}});
  assert.equal(h.form.elements.url.value,''); assert.equal(h.node('#purchase-start').disabled,true);
  assert.match(h.node('#purchase-state').textContent,/其他模式任务/);
});

test('format check validates without asking permission, sending address, or executing START', async () => {
  const h = await harness(); fill(h.form,{mode:'new',consent:false});
  h.node('#validate-calibration').onclick();
  assert.match(h.node('#calibration-result').textContent,/格式通过.*尚未验证/);
  assert.equal(h.permissionRequests.length,0); assert.equal(h.messages.length,1);
});

test('target changes revoke per-start consent and mode changes clear hidden address data', async () => {
  const h = await harness(); fill(h.form,{mode:'new'});
  h.form.listeners.get('input')({target:h.form.elements.maxTotal});
  assert.equal(h.form.elements.confirmedPurchase.checked,false);
  h.form.elements.addressMode.value = 'existing'; h.form.elements.addressMode.listeners.get('change')();
  assert.ok(ADDRESS_KEYS.every(key => h.form.elements[`address_${key}`].value === ''));
  assert.equal(h.node('#address-fields').hidden,true);
});

test('successful existing-page START activates only the unique exact URL and never sends address', async () => {
  const h = await harness(); fill(h.form);
  await h.submit();
  const started = h.messages.find(message => message.type === 'START');
  assert.equal(started.tabId,7); assert.equal(started.address,undefined); assert.equal(started.config.confirmedPurchase,true);
  assert.deepEqual(h.tabCalls,[['query',{url:productURL}],['update',7,{active:true}]]);
  assert.equal(h.form.elements.confirmedPurchase.checked,false); assert.equal(h.node('#purchase-start').disabled,true);
  assert.equal(h.node('#purchase-stop').disabled,false);
});

test('successful new-address START clears page inputs after passing separate address once', async () => {
  const h = await harness(); fill(h.form,{mode:'new'}); await h.submit();
  const started = h.messages.find(message => message.type === 'START');
  assert.equal(started.address.fullName,'PRIVATE-fullName');
  assert.equal(JSON.stringify(started.config).includes('PRIVATE'),false);
  assert.ok(ADDRESS_KEYS.every(key => h.form.elements[`address_${key}`].value === ''));
  assert.equal(JSON.stringify(h.messages.filter(message => message.type !== 'START')).includes('PRIVATE'),false);
});

test('permission refusal, zero exact pages, duplicates, and wrong URLs never START', async () => {
  for (const options of [{granted:false},{tabs:[]},{tabs:[{id:1,url:productURL},{id:2,url:productURL}]},{tabs:[{id:1,url:`${productURL}?session=PRIVATE`}]}]) {
    const h = await harness(options); fill(h.form); await h.submit();
    assert.equal(h.messages.some(message => message.type === 'START'),false);
    assert.ok(h.node('#purchase-error').textContent); assert.equal(h.form.elements.confirmedPurchase.checked,false);
    assert.equal(h.tabCalls.some(call => call[0] === 'create'),false);
  }
});

test('new-page mode opens only validated URL, then starts once without putting private fields in URL', async () => {
  const h = await harness(); fill(h.form,{mode:'new'}); h.form.elements.targetMode.value = 'new'; await h.submit();
  assert.deepEqual(h.tabCalls,[['create',{url:productURL,active:true}]]);
  assert.equal(h.messages.filter(message => message.type === 'START').length,1);
  assert.equal(JSON.stringify(h.tabCalls).includes('PRIVATE'),false);
});

test('clear-address cancels a pending start before permission returns and clears both UI and session', async () => {
  let release; const permissionWait = new Promise(resolve => {release=resolve;});
  const h = await harness({permissionWait}); fill(h.form,{mode:'new'});
  const pending = h.submit(); await Promise.resolve();
  await h.node('#clear-address').onclick(); release(); await pending;
  assert.ok(h.messages.some(message => message.type === 'PURCHASE_CLEAR_ADDRESS'));
  assert.equal(h.messages.some(message => message.type === 'START'),false);
  assert.ok(ADDRESS_KEYS.every(key => h.form.elements[`address_${key}`].value === ''));
});

test('double clicks cannot start twice and STOP cancels a pending start', async () => {
  let release; const permissionWait = new Promise(resolve => {release=resolve;});
  const h = await harness({permissionWait}); fill(h.form);
  const first = h.submit(); await h.submit(); await h.node('#purchase-stop').onclick(); release(); await first;
  assert.equal(h.permissionRequests.length,1);
  assert.equal(h.messages.filter(message => message.type === 'START').length,0);
  assert.ok(h.messages.some(message => message.type === 'STOP'));
});

test('closing setup clears local inputs and timer without stopping independently running task', async () => {
  const h = await harness(); fill(h.form,{mode:'new'}); h.lifecycle.get('pagehide')();
  assert.equal(h.timers.size,0); assert.ok(ADDRESS_KEYS.every(key => h.form.elements[`address_${key}`].value === ''));
  assert.deepEqual(h.messages.map(message => message.type),['STATUS']);
  await h.ui.poll(); assert.equal(h.messages.length,1);
});

test('manual-login resume is visible only for AWAITING_USER and requires fresh click consent', async () => {
  const h = await harness({task:{mode:'purchase',state:'AWAITING_USER',tabId:7}});
  assert.equal(h.node('#resume-panel').hidden,false);
  await h.node('#purchase-resume').onclick(); assert.equal(h.messages.some(message => message.type === 'PURCHASE_RESUME'),false);
  h.node('#confirmed-resume').checked = true; await h.node('#purchase-resume').onclick();
  assert.deepEqual(h.messages.find(message => message.type === 'PURCHASE_RESUME'),{type:'PURCHASE_RESUME',confirmedResume:true});
  assert.equal(h.node('#confirmed-resume').checked,false); assert.equal(h.node('#resume-panel').hidden,true);
  assert.equal(h.messages.some(message => message.type === 'START'),false);
});

test('lost background connection locks execution without retrying or assuming completion', async () => {
  const h = await harness(); h.backend.failure = true; await h.ui.poll();
  assert.equal(h.node('#purchase-start').disabled,true); assert.equal(h.node('#purchase-stop').disabled,true);
  assert.match(h.node('#purchase-error').textContent,/后台不可用/);
  assert.ok(h.messages.every(message => message.type === 'STATUS'));
});

test('fictitious example button revokes all prior consent and labels the example unverified', async () => {
  const h = await harness(); fill(h.form); h.node('#load-example').onclick();
  assert.equal(h.form.elements.confirmedPurchase.checked,false); assert.equal(h.form.elements.confirmedExistingAddress.checked,false);
  assert.match(h.node('#calibration-result').textContent,/不是 Apple 官网预设/);
  assert.equal(h.messages.length,1);
});

test('address profile save is separate from START, default off, and requires explicit storage consent', async () => {
  const h = await harness(); fill(h.form,{mode:'new'});
  assert.equal(h.form.elements.confirmedProfileStorage.checked,false);
  await h.node('#save-address-profile').onclick();
  assert.equal(h.messages.some(message => message.type === 'PURCHASE_SAVE_ADDRESS_PROFILE'),false);
  assert.match(h.node('#purchase-error').textContent,/非加密保存/);
  h.form.elements.confirmedProfileStorage.checked = true;
  await h.node('#save-address-profile').onclick();
  const message = h.messages.find(message => message.type === 'PURCHASE_SAVE_ADDRESS_PROFILE');
  assert.equal(message.confirmedLocalSave,true); assert.equal(message.address.fullName,'PRIVATE-fullName');
  assert.equal(h.form.elements.confirmedProfileStorage.checked,false);
  assert.equal(h.messages.some(message => message.type === 'START'),false);
  assert.equal(h.permissionRequests.length,0);
});

test('stored address profile never auto-loads via STATUS and explicit load resets purchase consent', async () => {
  const h = await harness({profile:{fullName:'PRIVATE-SAVED',phone:'13800000000',unknownSecret:'must-ignore'}});
  assert.equal(h.form.elements.address_fullName.value,'');
  fill(h.form); await h.node('#load-address-profile').onclick();
  assert.equal(h.form.elements.addressMode.value,'new');
  assert.equal(h.form.elements.address_fullName.value,'PRIVATE-SAVED');
  assert.equal(h.form.elements.confirmedPurchase.checked,false);
  assert.equal(h.form.elements.unknownSecret,undefined);
  assert.equal(h.node('#confirmation-summary').textContent.includes('PRIVATE'),false);
  assert.equal(h.messages.filter(message => message.type === 'PURCHASE_LOAD_ADDRESS_PROFILE').length,1);
});

test('deleting local address profile is explicit, clears local inputs, and uses the dedicated delete command', async () => {
  const h = await harness({profile:{fullName:'PRIVATE-SAVED'}});
  fill(h.form,{mode:'new'});
  await h.node('#clear-address-profile').onclick();
  assert.equal(h.backend.profile,null);
  assert.ok(h.messages.some(message => message.type === 'PURCHASE_CLEAR_ADDRESS_PROFILE'));
  assert.equal(h.messages.some(message => message.type === 'PURCHASE_CLEAR_ADDRESS'),false);
  assert.match(h.node('#address-profile-result').textContent,/预设已删除/);
  assert.equal(h.form.elements.address_fullName.value,'');
});

test('ordinary START never stores an address preset even if storage consent was checked', async () => {
  const h = await harness(); fill(h.form,{mode:'new'}); h.form.elements.confirmedProfileStorage.checked = true;
  await h.submit();
  assert.ok(h.messages.some(message => message.type === 'START'));
  assert.equal(h.messages.some(message => message.type === 'PURCHASE_SAVE_ADDRESS_PROFILE'),false);
  assert.equal(h.backend.profile,null);
});

test('late profile load cannot restore private values after clear, delete, close, address mode change, or later field edits', async () => {
  for (const action of ['clear','delete','close','mode','edit']) {
    let release; const profileLoadWait = new Promise(resolve => {release=resolve;});
    const h = await harness({profile:{fullName:'PRIVATE-SAVED'},profileLoadWait});
    const loading = h.node('#load-address-profile').onclick(); await Promise.resolve();
    if (action === 'clear') await h.node('#clear-address').onclick();
    else if (action === 'delete') await h.node('#clear-address-profile').onclick();
    else if (action === 'close') h.lifecycle.get('pagehide')();
    else if (action === 'mode') { h.form.elements.addressMode.value = 'existing'; h.form.elements.addressMode.listeners.get('change')(); }
    else { h.form.elements.address_fullName.value = 'USER-NEW-INPUT'; h.form.listeners.get('input')({target:h.form.elements.address_fullName}); }
    release(); await loading;
    assert.notEqual(h.form.elements.address_fullName.value,'PRIVATE-SAVED',action);
    if (action === 'edit') assert.equal(h.form.elements.address_fullName.value,'USER-NEW-INPUT');
  }
});

test('late profile-save reply cannot overwrite a newer deletion result', async () => {
  let release; const profileSaveWait = new Promise(resolve => {release=resolve;});
  const h = await harness({profileSaveWait}); fill(h.form,{mode:'new'}); h.form.elements.confirmedProfileStorage.checked = true;
  const saving = h.node('#save-address-profile').onclick(); await Promise.resolve();
  await h.node('#clear-address-profile').onclick();
  release(); await saving;
  assert.equal(h.backend.profile,null);
  assert.match(h.node('#address-profile-result').textContent,/已删除/);
});

test('date picker uses explicit Beijing time, rejects invalid dates, and defaults to immediate start', () => {
  const now = Date.parse('2026-10-16T00:00:00Z');
  assert.equal(purchaseStartTime('',now),'2026-10-16T00:00:00.000Z');
  assert.equal(purchaseStartTime('2026-10-16T10:30:20',now),'2026-10-16T02:30:20.000Z');
  assert.throws(() => purchaseStartTime('2026-02-31T12:00',now),/无效/);
  assert.throws(() => purchaseStartTime('tomorrow',now),/有效的北京时间/);
});

test('scheduled start extends session expiry from the selected start and appears in confirmation', () => {
  const form = fill(dom().form); const now = Date.parse('2026-10-16T00:00:00Z');
  form.elements.targetTime.value = '2026-10-16T10:00';
  const {config} = buildSubmission(form,now);
  assert.equal(config.targetTime,'2026-10-16T02:00:00.000Z');
  assert.equal(config.expiresAt,'2026-10-16T02:15:00.000Z');
  assert.match(confirmationSummary(form),/2026-10-16 10:00（北京时间 UTC\+08:00）/);
});

test('visual editor changes serialize the plan and revoke consent without executing work', async () => {
  const h = await harness(); fill(h.form); const plan = calibrationExample();
  h.editPlan(plan);
  assert.deepEqual(JSON.parse(h.form.elements.calibration.value),plan);
  assert.equal(h.form.elements.confirmedPurchase.checked,false);
  assert.equal(h.form.elements.confirmedExistingAddress.checked,false);
  assert.equal(h.messages.length,1);
});

test('restore, explicit advanced JSON import, and fictitious example keep the visual editor in sync', async () => {
  const config = buildSubmission(fill(dom().form)).config;
  const h = await harness({settings:config});
  assert.deepEqual(h.editorPlan(),config.steps);
  const changed = calibrationExample('new');
  h.form.elements.calibration.value = JSON.stringify(changed);
  h.node('#apply-calibration-json').onclick(); assert.deepEqual(h.editorPlan(),changed);
  h.form.elements.addressMode.value = 'existing'; h.node('#load-example').onclick();
  assert.deepEqual(h.editorPlan(),calibrationExample('existing'));
  assert.equal(h.messages.length,1);
});

test('scheduled background waiting status is localized and does not issue an early START', async () => {
  const h = await harness({task:{mode:'purchase',state:'WAITING_START',reason:'等待用户指定时间'}});
  assert.equal(h.node('#purchase-state').textContent,'等待指定开始时间');
  assert.equal(h.node('#purchase-start').disabled,true);
  assert.equal(h.node('#purchase-stop').disabled,false);
  assert.deepEqual(h.messages.map(message => message.type),['STATUS']);
});

test('known metadata fills only exact observed target names and never decides budget or checkout mappings', async () => {
  assert.equal(knownTargetMetadata('https://www.apple.com.cn/shop/unknown'),null);
  assert.deepEqual(knownTargetMetadata('https://www.apple.com.cn/shop/buy-iphone/iphone-duo/mk2u4ch/a'),{model:'iPhone Duo',color:'夜空色',storage:'1TB'});
  const h = await harness();
  h.form.elements.url.value = 'https://www.apple.com.cn/shop/buy-iphone/iphone-18-pro/mjt74ch/a';
  h.form.elements.confirmedPurchase.checked = true;
  h.node('#load-target-metadata').onclick();
  assert.equal(h.form.elements.model.value,'iPhone 18 Pro'); assert.equal(h.form.elements.color.value,'黑色'); assert.equal(h.form.elements.storage.value,'256GB');
  assert.equal(h.form.elements.maxTotal.value,''); assert.equal(h.form.elements.calibration.value,'');
  assert.equal(h.form.elements.confirmedPurchase.checked,false); assert.equal(h.messages.length,1);
});

test('Duo helper adds observed radio adaptation only; missing checkout still cannot START', async () => {
  const h = await harness();
  h.form.elements.url.value = 'https://www.apple.com.cn/shop/buy-iphone/iphone-duo/mk2u4ch/a';
  h.node('#load-target-metadata').onclick(); h.node('#load-duo-steps').onclick();
  const plan = JSON.parse(h.form.elements.calibration.value);
  assert.equal(plan.length,2);
  assert.deepEqual(plan.map(step => step.group),['dimensionColor','dimensionCapacity']);
  assert.ok(plan.every(step => step.adapter === 'apple-duo' && step.kind === 'radio' && step.confirm.kind === 'apple-selection'));
  assert.ok(plan.every(step => !step.target.selector && !step.confirm.selector));
  assert.deepEqual(h.editorPlan(),plan);
  h.form.elements.maxTotal.value = '25000'; h.form.elements.confirmedPurchase.checked = true; h.form.elements.confirmedExistingAddress.checked = true;
  await h.submit();
  assert.equal(h.messages.some(message => message.type === 'START'),false);
  assert.match(h.node('#purchase-error').textContent,/标记并保存完整流程/);
  assert.equal(h.node('#guided-setup-panel').hidden,false);
  assert.equal(h.permissionRequests.length,0);
});

test('Duo helper never silently applies to a different model', async () => {
  const h = await harness();
  h.form.elements.url.value = 'https://www.apple.com.cn/shop/buy-iphone/iphone-18-pro/mjt74ch/a';
  h.node('#load-target-metadata').onclick(); h.node('#load-duo-steps').onclick();
  assert.equal(h.form.elements.calibration.value,'');
  assert.ok(h.node('#purchase-error').textContent);
  assert.equal(h.messages.length,1);
});


test('normal main view keeps technical mapping, JSON and test links in closed advanced controls', () => {
  const advanced=html.indexOf('<details id="advanced-settings"');
  const normal=html.slice(0,advanced);
  assert.match(normal,/name="productPreset"/);
  for (const name of ['url','model','color','storage','addressMode','maxTotal','targetTime']) assert.match(normal,new RegExp(`name="${name}"`));
  assert.doesNotMatch(normal,/<textarea\b|id="purchase-editor"|workflow-fixture/);
  assert.doesNotMatch(html,/<details id="advanced-settings"[^>]*\bopen\b/);
  assert.match(html,/<input[^>]*name="confirmedExistingAddress"[^>]*\bhidden\b/);
  assert.ok(html.indexOf('id="clear-address"') > html.indexOf('</fieldset>'),'clear remains operable while fields are locked');
});

test('product presets fill recorded specs without budget or checkout shortcuts', async () => {
  const h=await harness();
  h.form.elements.productPreset.value='https://www.apple.com.cn/shop/buy-iphone/iphone-duo/mk2u4ch/a';
  h.form.elements.productPreset.listeners.get('change')();
  assert.equal(h.form.elements.model.value,'iPhone Duo');
  assert.equal(h.form.elements.storage.value,'1TB');
  assert.equal(h.form.elements.maxTotal.value,'');
  assert.deepEqual(JSON.parse(h.form.elements.calibration.value),[]);
  assert.match(h.node('#calibration-state').textContent,/先标记/);
  assert.deepEqual(h.messages,[{type:'STATUS'}]);
});

test('one visible purchase consent explicitly acknowledges the selected webpage address and is never restored', async () => {
  const h=await harness();fill(h.form,{consent:false});
  h.form.elements.confirmedPurchase.checked=true;
  h.form.elements.confirmedPurchase.listeners.get('change')();
  assert.equal(h.form.elements.confirmedExistingAddress.checked,true);
  await h.submit();
  assert.ok(h.messages.some(message=>message.type==='START'));
  assert.equal(h.form.elements.confirmedPurchase.checked,false);
  assert.equal(h.form.elements.confirmedExistingAddress.checked,false);
});

test('stored validated complete plan starts from ordinary fields without opening advanced or guide', async () => {
  const config=buildSubmission(fill(dom().form)).config;
  const h=await harness({settings:{...config,confirmedPurchase:false}});
  assert.match(h.node('#calibration-state').textContent,/已保存流程/);
  assert.equal(h.guideMounted(),0);
  assert.equal(h.node('#guided-setup-panel').hidden,true);
  h.form.elements.confirmedPurchase.checked=true;
  h.form.elements.confirmedPurchase.listeners.get('change')();
  await h.submit();
  assert.equal(h.messages.filter(message=>message.type==='START').length,1);
  assert.equal(h.guideMounted(),0);
  assert.deepEqual(h.messages.find(message=>message.type==='START').config.steps,config.steps);
});

test('missing complete plan routes to guided marking without requesting permission or START', async () => {
  const h=await harness();fill(h.form);h.form.elements.calibration.value='';
  await h.submit();
  assert.equal(h.node('#guided-setup-panel').hidden,false);
  assert.equal(h.guideMounted(),1);
  assert.equal(h.messages.some(message=>message.type==='START'),false);
  assert.equal(h.permissionRequests.length,0);
  assert.deepEqual(h.messages.map(message=>message.type),['STATUS','PURCHASE_PICK_TABS']);
});

test('guided marking mounts once, lists pages without permission, and requests only selected checkout host on click', async () => {
  const origin='https://secure6.www.apple.com.cn';
  const h=await harness({pickerTabs:[{id:9,origin,path:'/shop/checkout'}],currentTab:{id:9,url:`${origin}/shop/checkout`,status:'complete'}});
  await h.node('#guided-setup').onclick();
  await h.node('#guided-setup').onclick();
  assert.equal(h.guideMounted(),1);
  assert.equal(h.permissionRequests.length,0);
  const id=await h.guide().getTargetTabId({isResult:true});
  assert.equal(id,9);
  assert.deepEqual(h.permissionRequests,[{origins:[`${origin}/*`]}]);
  assert.ok(h.tabCalls.some(call=>call[0]==='update'&&call[1]===9));
  assert.equal(h.messages.some(message=>message.type==='START'),false);
});

test('guided marking requires explicit tab choice for multiple pages and never activates an unapproved changed origin', async () => {
  const origin='https://www.apple.com.cn';
  const h=await harness({pickerTabs:[{id:8,origin,path:'/shop/a'},{id:9,origin,path:'/shop/b'}],currentTab:{id:8,url:'https://other.example/',status:'complete'}});
  await h.node('#guided-setup').onclick();
  await assert.rejects(h.guide().getTargetTabId(),/先选择/);
  assert.equal(h.permissionRequests.length,0);
  h.form.elements.pickerTab.value='8';
  await assert.rejects(h.guide().getTargetTabId(),/站点已改变/);
  assert.equal(h.tabCalls.some(call=>call[0]==='update'),false);
});

test('saving a guided plan updates normal readiness and revokes consent; private addresses never enter guide config', async () => {
  const h=await harness();fill(h.form,{mode:'new'});
  await h.node('#guided-setup').onclick();
  assert.equal(JSON.stringify(h.guide().getConfig()).includes('PRIVATE'),false);
  h.guide().onPlanChange(calibrationExample('new'));
  assert.match(h.node('#calibration-state').textContent,/已保存流程/);
  assert.equal(h.form.elements.confirmedPurchase.checked,false);
  assert.deepEqual(h.editorPlan(),calibrationExample('new'));
  h.lifecycle.get('pagehide')();assert.equal(h.guideDestroyed(),true);
});


test('page discovery requests only the two known optional Apple hosts after a separate explicit click', async () => {
  const h=await harness();
  await h.node('#guided-setup').onclick();
  assert.equal(h.permissionRequests.length,0);
  await h.node('#authorize-picker-tabs').onclick();
  assert.deepEqual(h.permissionRequests,[{origins:['https://www.apple.com.cn/*','https://secure6.www.apple.com.cn/*']}]);
  assert.deepEqual(h.messages.map(message=>message.type),['STATUS','PURCHASE_PICK_TABS','PURCHASE_PICK_TABS']);
  assert.equal(h.messages.some(message=>message.type==='START'),false);
  const denied=await harness({granted:false});await denied.node('#guided-setup').onclick();
  await denied.node('#authorize-picker-tabs').onclick();
  assert.deepEqual(denied.messages.map(message=>message.type),['STATUS','PURCHASE_PICK_TABS']);
  assert.match(denied.node('#guided-setup-result').textContent,/未授权/);
});


test('open guided editing cannot run an older saved plan and close returns to ordinary settings', async () => {
  const config=buildSubmission(fill(dom().form)).config;
  const h=await harness({settings:config});
  await h.node('#guided-setup').onclick();
  assert.equal(h.node('#purchase-start').disabled,true);
  h.form.elements.confirmedPurchase.checked=true;
  h.form.elements.confirmedPurchase.listeners.get('change')();
  await h.submit();
  assert.equal(h.messages.some(message=>message.type==='START'),false);
  h.node('#close-guided-setup').onclick();
  assert.equal(h.guideDestroyed(),true);
  assert.equal(h.node('#guided-setup-panel').hidden,true);
  assert.equal(h.node('#purchase-start').disabled,false);
  assert.equal(h.form.elements.confirmedPurchase.checked,false);
  h.form.elements.confirmedPurchase.checked=true;
  h.form.elements.confirmedPurchase.listeners.get('change')();
  await h.submit();
  assert.equal(h.messages.filter(message=>message.type==='START').length,1);
});


test('editing a saved target removes the saved-ready label and invalidates purchase consent', async () => {
  const config=buildSubmission(fill(dom().form)).config;
  const h=await harness({settings:config});
  assert.match(h.node('#calibration-state').textContent,/已保存流程/);
  h.form.elements.color.value='新颜色';
  h.form.listeners.get('input')({target:h.form.elements.color});
  assert.doesNotMatch(h.node('#calibration-state').textContent,/已保存流程/);
  assert.equal(h.form.elements.confirmedPurchase.checked,false);
});

test('existing exact product page may start while resources are still loading',async()=>{
 const h=await harness({tabs:[{id:7,url:productURL,status:'loading'}]});fill(h.form);await h.submit();
 assert.equal(h.messages.filter(m=>m.type==='START').length,1);assert.equal(h.node('#purchase-error').textContent,'');
});
test('new exact product page does not wait for load-complete before requesting document-bound START',async()=>{
 const h=await harness();h.chrome.tabs.create=async request=>({id:8,status:'loading',...request});fill(h.form);h.form.elements.targetMode.value='new';await h.submit();
 assert.equal(h.messages.filter(m=>m.type==='START').length,1);assert.equal(h.tabCalls.some(c=>c[0]==='get'),false);
});
