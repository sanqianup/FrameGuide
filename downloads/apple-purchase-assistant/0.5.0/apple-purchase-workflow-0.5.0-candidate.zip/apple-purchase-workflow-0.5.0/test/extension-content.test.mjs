import {test} from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import fs from 'node:fs';
const source=fs.readFileSync(new URL('../extension/content.js',import.meta.url),'utf8');
function harness(){
 let listener,mutation,now=1000,respond;const sent=[],timers=new Map();let tid=0;
 const docEvents={};const els={}; const el=text=>({innerText:text,textContent:text,isConnected:true,disabled:false,getClientRects:()=>[{}],closest:()=>null,getAttribute:()=>null});
 for(const [key,val]of Object.entries({region:'CN',model:'Model',storage:'256GB',color:'White',quantity:'1',currency:'CNY',delivery:'Delivery',total:'100.00',button:'Add to Bag'}))els['#'+key]=el(val);
 const document={body:{innerText:'Product summary',querySelectorAll:()=>[]},visibilityState:'visible',querySelectorAll:s=>els[s]?[els[s]]:[],addEventListener:(name,handler)=>docEvents[name]=handler};
 const config={mode:'official-readonly',url:'https://www.apple.com.cn/shop/test',targetTime:new Date(1100).toISOString(),pollMs:1000,selectors:Object.fromEntries(Object.keys(els).map(k=>[k.slice(1),k]))};
 const context={URL,Date:class extends Date{static now(){return now;}},document,location:{href:config.url},getComputedStyle:()=>({visibility:'visible',display:'block'}),MutationObserver:class{constructor(cb){mutation=cb;}observe(){}disconnect(){mutation=null;}},queueMicrotask,setTimeout:(f,ms)=>{timers.set(++tid,{f,ms});return tid;},clearTimeout:id=>timers.delete(id),addEventListener(){},chrome:{runtime:{id:'test',onMessage:{addListener:f=>listener=f},sendMessage:async msg=>{sent.push(msg);if(respond)return respond(msg);return{ok:true,state:'WAITING',action:'none'};}}}};
 vm.runInNewContext(source,context);
 const start=()=>listener({type:'START_OBSERVING',taskId:'task',config},{id:'test'},()=>{});
 const settle=async()=>{for(let i=0;i<8;i++)await Promise.resolve();};
 return{docEvents,context,sent,els,document,config,timers,start,settle,mutate:()=>mutation?.([]),halt:()=>listener({type:'HALT',taskId:'task'},{id:'test'},()=>{}),setNow:n=>now=n,setRespond:fn=>respond=fn};
}
test('content observer starts before load and coalesces equivalent mutation bursts',async()=>{
 const h=harness();h.start();for(let i=0;i<30;i++)h.mutate();await h.settle();assert.equal(h.sent.length,1);assert.equal(h.sent[0].type,'OBSERVE');
 for(let i=0;i<30;i++)h.mutate();await h.settle();assert.equal(h.sent.length,1);
});
test('changed enabled state is observed immediately without waiting fallback poll',async()=>{
 const h=harness();h.els['#button'].disabled=true;h.start();await h.settle();assert.equal(h.sent[0].snapshot.buttonEnabled,false);
 h.els['#button'].disabled=false;h.mutate();await h.settle();assert.equal(h.sent[1].snapshot.buttonEnabled,true);
 assert.ok([...h.timers.values()].some(t=>t.ms===100),'target-time boundary scheduled');
});
test('DOM replacement is re-read; no stale button reference',async()=>{
 const h=harness();h.start();await h.settle();h.els['#button']={...h.els['#button'],disabled:true};h.mutate();await h.settle();assert.equal(h.sent.at(-1).snapshot.buttonEnabled,false);
});
test('partial initial page waits for mutations without window.load',async()=>{
 const h=harness();const total=h.els['#total'];delete h.els['#total'];h.start();await h.settle();assert.equal(h.sent.length,0);
 h.els['#total']=total;h.mutate();await h.settle();assert.equal(h.sent.length,1);
});
test('stop disconnects observer and stale async response cannot resume timer',async()=>{
 const h=harness();let done;h.setRespond(()=>new Promise(r=>done=r));h.start();await h.settle();h.halt();done({ok:true,state:'WAITING'});await h.settle();h.mutate();await h.settle();assert.equal(h.sent.length,1);assert.equal(h.timers.size,0);
});
test('readonly refuses a mock-submit response and reports disconnect',async()=>{
 const h=harness();h.setRespond(msg=>({ok:true,state:'WAITING',action:msg.type==='OBSERVE'?'mock-submit':'none'}));h.start();await h.settle();assert.deepEqual(h.sent.map(x=>x.type),['OBSERVE','DISCONNECT']);assert.equal(h.timers.size,0);
});

test('explicit Continue selector can never become a final-order target',async()=>{
 const h=harness();h.els['#button'].innerText='继续';h.start();await h.settle();
 const s=h.sent[0].snapshot;assert.equal(s.buttonUnique,false);assert.equal(s.buttonEnabled,false);assert.match(s.blocker,/继续不是最终下单/);
});
test('known configuration adapter evidence overrides caller button and price selectors fail-closed',async()=>{
 const h=harness();let clicks=0;h.els['#button'].click=()=>clicks++;
 const evidence={supported:true,pageKind:'product-configuration',model:'iPhone Duo',color:null,storage:null,
  options:{color:[{name:'星光白色',selected:false,enabled:true}],storage:[{name:'256GB',selected:false,enabled:false}]},
  continue:{status:'disabled',name:'继续',enabled:false},evidenceMissing:['selected-color','selected-storage','order-total'],ambiguity:[]};
 h.context.AppleDuoReadonly={inspect:()=>evidence};h.start();await h.settle();
 const s=h.sent[0].snapshot;assert.equal(s.model,'iPhone Duo');assert.equal(s.color,'');assert.equal(s.storage,'');
 assert.equal(s.buttonUnique,false);assert.equal(s.buttonEnabled,false);assert.equal(s.totalMinor,null);
 assert.match(s.blocker,/继续不是下单/);assert.equal(s.pageEvidence,evidence);assert.equal(clicks,0);
});

test('native input/change events wake observation when selection property changes without a mutation',async()=>{
 const h=harness();h.els['#button'].disabled=true;h.start();await h.settle();
 h.els['#button'].disabled=false;h.docEvents.change();await h.settle();
 assert.equal(h.sent.at(-1).snapshot.buttonEnabled,true);
 h.els['#button'].disabled=true;h.docEvents.input();await h.settle();
 assert.equal(h.sent.at(-1).snapshot.buttonEnabled,false);
});

test('same observed product SKU URL is accepted without treating item price as final total',async()=>{
 const h=harness(),base='https://www.apple.com.cn/shop/buy-iphone/iphone-duo',sku=`${base}/mk2n4ch/a`;
 h.config.url=base;h.context.location.href=sku;
 h.context.AppleDuoReadonly={supportsURL:url=>[base,sku].includes(url),inspect:()=>({supported:true,model:'iPhone Duo',color:'夜空色',storage:'256GB',summary:'iPhone Duo 256GB 夜空色',itemPriceMinor:1599900,itemCurrency:'CNY',releaseNotice:'暂未发售',ambiguity:[]})};
 h.start();await h.settle();const s=h.sent[0].snapshot;
 assert.equal(s.pageEvidence.itemPriceMinor,1599900);assert.equal(s.totalMinor,null);assert.equal(s.buttonUnique,false);assert.equal(s.storage,'256GB');
});
test('unobserved SKU or other-product URL is rejected before configuration inspection',async()=>{
 const h=harness(),base='https://www.apple.com.cn/shop/buy-iphone/iphone-duo';let inspected=false;
 h.config.url=base;h.context.location.href=base+'/unknown/a';h.context.AppleDuoReadonly={supportsURL:url=>url===base,inspect:()=>{inspected=true;return{supported:true};}};
 h.start();await h.settle();assert.equal(inspected,false);assert.deepEqual(h.sent.map(x=>x.type),['DISCONNECT']);
});
