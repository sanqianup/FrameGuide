import {test} from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID,webcrypto} from 'node:crypto';
import vm from 'node:vm';
import fs from 'node:fs';
import {config,evidence,selectedFingerprint,address,url} from './purchase-fixture.mjs';
import {sendFixtureControl} from '../extension/purchase-background.js';
import {ADDRESS_AUTOCOMPLETE} from '../extension/purchase-config.js';
function event(){return{listeners:[],addListener(fn){this.listeners.push(fn)},emit(...a){for(const fn of this.listeners)fn(...a)}}}
function area(){const data={};return{data,async get(k){return{[k]:structuredClone(data[k])}},async set(v){Object.assign(data,structuredClone(v))},async remove(k){delete data[k]},async setAccessLevel(){}}}
async function harness(c=config()){
 const local=area(),session=area(),events={message:event(),startup:event(),installed:event(),alarm:event(),removed:event(),updated:event()},tab={id:4,url:c.url,active:true},injections=[],id='purchase-test';
 const chrome={runtime:{id,getURL:p=>`chrome-extension://${id}/${p}`,onMessage:events.message,onStartup:events.startup,onInstalled:events.installed,async sendMessage(){return{ok:true}}},storage:{local,session},action:{async setBadgeText(){},async setBadgeBackgroundColor(){}},permissions:{async contains(){return true}},alarms:{onAlarm:events.alarm,async create(){},async clear(){}},scripting:{async executeScript(i){injections.push(i);return [{frameId:0,documentId:sender.documentId,result:{url:sender.url}}]}},tabs:{onRemoved:events.removed,onUpdated:events.updated,async get(){return{...tab}},async sendMessage(){return{ok:true}}}};
 const popup={id,url:chrome.runtime.getURL('purchase.html')};let sender={id,url:c.url,tab:{id:4},frameId:0,documentId:'document-a'},base={documentNonce:'nonce-a'};
 globalThis.chrome=chrome;async function load(){Object.values(events).forEach(x=>x.listeners=[]);await import(`../extension/background.js?purchase-test=${randomUUID()}`)}await load();
 async function send(m,s=popup){return new Promise(resolve=>events.message.listeners.at(-1)(m,s,resolve))}
 async function start(privateAddress){const result=await send({type:'START',config:c,tabId:4,...(privateAddress?{address:privateAddress}:{})});if(result.ok)base.taskId=result.task.id;return result;}
 async function page(type,data={},s=sender){return send({...base,stepIndex:local.data.currentTask?.stepIndex,type,...data},s)}
 async function bind(){return page('PURCHASE_BIND',{url:sender.url.startsWith('https://secure6.')?new URL(sender.url).origin+new URL(sender.url).pathname:sender.url})}
 async function begin(privateAddress){const result=await start(privateAddress);assert.equal(result.ok,true,result.error);assert.equal((await bind()).ok,true);return result;}
 async function claim(extra={}){return page('PURCHASE_CLAIM',{evidence:evidence(c,{url:sender.url,...extra})})}
 async function check(token,extra={}){return page('PURCHASE_CHECK',{claimToken:token,evidence:evidence(c,{url:sender.url,...extra})})}
 async function result(token,extra={}){const step=c.steps[local.data.currentTask.stepIndex];return page('PURCHASE_RESULT',{claimToken:token,outcome:'confirmed',evidence:evidence(c,{url:sender.url,confirmation:{matched:true,...step.confirm},unpaidOrder:true,...extra})})}
 async function advance(){if(c.steps[local.data.currentTask.stepIndex].kind==='address'&&c.addressMode==='existing')assert.equal((await page('PURCHASE_CONFIRM_ADDRESS',{addressConfirmed:true,addressFingerprint:selectedFingerprint})).ok,true);const a=await claim();assert.equal(a.action,'purchase-act',JSON.stringify(a));const b=await check(a.claimToken);assert.equal(b.allowed,true,JSON.stringify(b));const d=await result(a.claimToken);assert.equal(d.ok,true,JSON.stringify(d));return d;}
 return{c,chrome,local,session,events,tab,injections,load,send,page,start,begin,bind,claim,check,result,advance,get sender(){return sender},get base(){return base},setDocument(nextUrl,id='document-b'){sender={...sender,url:nextUrl,documentId:id};base.documentNonce=`nonce-${id}`;tab.url=nextUrl}};
}
test('purchase background issues durable one-use claims and gates all four stages',async()=>{
 const h=await harness();await h.begin();const claims=await Promise.all(Array.from({length:8},()=>h.claim()));assert.equal(claims.filter(x=>x.action==='purchase-act').length,1);const token=claims[0].claimToken;assert.equal(h.local.data.currentTask.claim.checked,false);assert.equal((await h.check(token)).allowed,true);assert.equal((await h.check(token)).allowed,false);assert.equal((await h.result(token)).stepIndex,1);await h.advance();await h.advance();const final=await h.advance();assert.equal(final.state,'DONE');assert.ok(h.local.data.purchaseFinalBarrier);assert.equal(h.session.data[`selected-address:${h.base.taskId}`],undefined);assert.equal((await h.start()).ok,false);
});
test('final claim restart, STOP and timeout remain unknown and block fresh START',async()=>{
 for(const action of ['reload','stop','timeout']){const h=await harness();await h.begin();await h.advance();await h.advance();await h.advance();const a=await h.claim();assert.equal(a.action,'purchase-act');if(action==='reload')await h.load();if(action==='stop')await h.send({type:'STOP'});if(action==='timeout')h.local.data.currentTask.claim.deadline=Date.now()-1;const status=await h.send({type:'STATUS'});assert.equal(status.task.state,'UNKNOWN',action);assert.equal((await h.start()).ok,false);assert.equal((await h.check(a.claimToken)).ok,false);}
});
test('normal watchdog is not a worker restart and nonfinal durable checked claim cannot replay',async()=>{
 const h=await harness();await h.begin();const a=await h.claim();await h.check(a.claimToken);await h.load();assert.equal((await h.check(a.claimToken)).allowed,false);assert.equal((await h.result(a.claimToken)).stepIndex,1);await h.advance();await h.advance();const b=await h.claim();h.events.alarm.emit({name:'watchdog'});assert.equal((await h.send({type:'STATUS'})).task.state,'SUBMITTING');assert.equal((await h.check(b.claimToken)).allowed,true);
});
test('configuration and status never contain session address; clear removes private values and halts',async()=>{
 const c=config({addressMode:'new'}),ks=Object.keys(address);c.steps[1].fields=ks.map(key=>({key,selector:`#${key}`,name:key,autocomplete:ADDRESS_AUTOCOMPLETE[key]}));for(const s of c.steps)if(s.addressConfirmation)s.addressConfirmation.keys=ks;
 const h=await harness(c);await h.begin(address);assert.deepEqual(h.session.data[`address:${h.base.taskId}`],address);assert.equal(JSON.stringify(h.local.data).includes(address.phone),false);assert.equal(JSON.stringify(await h.send({type:'STATUS'})).includes(address.addressLine1),false);await h.advance();const bound=await h.bind();assert.deepEqual(bound.address,address);assert.equal(bound.config.address,undefined);await h.send({type:'PURCHASE_CLEAR_ADDRESS'});assert.equal(h.session.data[`address:${h.base.taskId}`],undefined);assert.equal(h.local.data.currentTask.state,'STOPPED');
});
test('exact tab, top frame, document identity and popup control authority are enforced',async()=>{
 const h=await harness();await h.begin();for(const sender of [{...h.sender,tab:{id:99}},{...h.sender,frameId:1},{...h.sender,documentId:'different'},{...h.sender,url:'https://evil.test/shop/test'}])assert.equal((await h.page('PURCHASE_CLAIM',{evidence:evidence(h.c)},sender)).ok,false);
 assert.equal((await h.send({type:'PURCHASE_RESUME',confirmedResume:true},h.sender)).ok,false);assert.equal((await h.send({type:'PURCHASE_CLEAR_ADDRESS'},h.sender)).ok,false);assert.equal(h.local.data.currentTask.claim,null);
});
test('changed total, extra cart item and unverified postcondition cannot complete actions',async()=>{
 for(const bad of [{itemCount:2},{totalMinor:999999},{totalIncludesTaxShipping:false}]){const h=await harness();await h.begin();await h.advance();await h.advance();const denied=await h.claim(bad);assert.equal(denied.ok,false);assert.equal(h.local.data.currentTask.state,'PAUSED');}
 const h=await harness();await h.begin();const a=await h.claim();await h.check(a.claimToken);const result=await h.result(a.claimToken,{confirmation:{matched:true,selector:'#wrong',text:'wrong'}});assert.equal(result.state,'UNKNOWN');assert.equal(h.local.data.currentTask.claim.status,'unknown');
});
test('only exact configured navigation keeps a pending claim; new document can confirm without replay',async()=>{
 const c=config();c.steps[0].confirm.nextPath='/shop/bag';for(const s of c.steps.slice(1))s.path='/shop/bag';const h=await harness(c);await h.begin();const a=await h.claim();await h.check(a.claimToken);h.setDocument('https://www.apple.com.cn/shop/bag');h.events.updated.emit(4,{status:'loading',url:h.tab.url});await h.send({type:'STATUS'});assert.equal(h.local.data.currentTask.claim.status,'pending');h.events.updated.emit(4,{status:'complete'});await h.send({type:'STATUS'});h.setDocument(h.tab.url);const bind=await h.bind();assert.equal(bind.pendingClaim.checked,true);assert.equal(bind.pendingClaim.claimToken,a.claimToken);const result=await h.result(a.claimToken);assert.equal(result.stepIndex,1);assert.equal(h.local.data.currentTask.claim,null);
 const bad=await harness(c);await bad.begin();const b=await bad.claim();await bad.check(b.claimToken);bad.events.updated.emit(4,{status:'loading',url:'https://www.apple.com.cn/shop/other'});assert.equal((await bad.send({type:'STATUS'})).task.state,'UNKNOWN');
});
test('approved login handoff retains nonfinal claim and explicit resume verifies exact target without query leakage',async()=>{
 const c=config();c.steps[0].confirm={...c.steps[0].confirm,nextPath:'/shop/checkout',nextOrigin:'https://secure6.www.apple.com.cn',allowAuthHandoff:true};for(const s of c.steps.slice(1)){s.origin='https://secure6.www.apple.com.cn';s.path='/shop/checkout';}
 const h=await harness(c);await h.begin();const a=await h.claim();await h.check(a.claimToken);h.tab.url='https://secure6.www.apple.com.cn/shop/signIn?session=PRIVATE_SESSION';h.events.updated.emit(4,{status:'loading',url:h.tab.url});const paused=await h.send({type:'STATUS'});assert.equal(paused.task.state,'AWAITING_USER');assert.equal(h.local.data.currentTask.claim.token,a.claimToken);assert.equal(JSON.stringify(h.local.data).includes('PRIVATE_SESSION'),false);assert.equal((await h.send({type:'PURCHASE_RESUME',confirmedResume:true})).ok,false);
 h.setDocument('https://secure6.www.apple.com.cn/shop/checkout?session=PRIVATE_SESSION');h.events.updated.emit(4,{status:'loading',url:h.tab.url});assert.equal((await h.send({type:'STATUS'})).task.state,'AWAITING_USER');assert.equal((await h.send({type:'PURCHASE_RESUME',confirmedResume:true})).ok,true);h.setDocument(h.tab.url);assert.equal((await h.bind()).pendingClaim.claimToken,a.claimToken);const e=evidence(c,{url:'https://secure6.www.apple.com.cn/shop/checkout',confirmation:{matched:true,...c.steps[0].confirm}});assert.equal((await h.page('PURCHASE_RESULT',{claimToken:a.claimToken,outcome:'confirmed',evidence:e})).stepIndex,1);assert.equal(JSON.stringify(h.local.data).includes('PRIVATE_SESSION'),false);
});
test('failed durable claim/check writes never release action permits',async()=>{
 const h=await harness();await h.begin();const set=h.local.set;h.local.set=async v=>{if(v.currentTask?.claim)throw Error('unavailable');return set(v)};assert.equal((await h.claim()).ok,false);assert.equal(h.local.data.currentTask.claim,null);h.local.set=set;const a=await h.claim();h.local.set=async v=>{if(v.currentTask?.claim?.checked)throw Error('unavailable');return set(v)};assert.equal((await h.check(a.claimToken)).ok,false);assert.equal(h.local.data.currentTask.claim.checked,false);
});

test('actual content START and navigation BIND complete across the serialized background queue',async()=>{
 const c=config();c.steps[0].confirm.nextPath='/shop/bag';for(const step of c.steps.slice(1))step.path='/shop/bag';
 const h=await harness(c);let pageListener,bindCount=0;
 const node=()=>({style:{},setAttribute(){},append(){},remove(){},contains(){return false},addEventListener(){}});
 h.chrome.scripting.executeScript=async(i)=>{
  if(i.func)return [{frameId:0,documentId:h.sender.documentId,result:{url:h.tab.url}}];
  const doc={visibilityState:'visible',createElement:node,documentElement:node(),body:node(),addEventListener(){},querySelectorAll(){return[]}};
  const sender={...h.sender,url:h.tab.url};
  const runtime={id:h.chrome.runtime.id,onMessage:{addListener(fn){pageListener=fn}},sendMessage(message){if(message.type==='PURCHASE_BIND'){bindCount++;h.base.documentNonce=message.documentNonce;}return h.send(message,sender)}};
  const context=vm.createContext({chrome:{runtime},document:doc,location:{href:h.tab.url},URL,TextEncoder,Uint8Array,crypto:{randomUUID,subtle:webcrypto.subtle},Date,setTimeout,clearTimeout,queueMicrotask(){},addEventListener(){},MutationObserver:class{observe(){}disconnect(){}}});
  for(const file of ['dom-driver.js','purchase-policy.js','purchase-content.js'])vm.runInContext(fs.readFileSync(new URL(`../extension/${file}`,import.meta.url),'utf8'),context);
  return [{frameId:0,documentId:h.sender.documentId}];
 };
 h.chrome.tabs.sendMessage=async(_tab,message)=>new Promise(resolve=>pageListener(message,{id:h.chrome.runtime.id},resolve));
 const timeout=new Promise((_,reject)=>{const timer=setTimeout(()=>reject(Error('Serialized START/BIND handshake deadlocked')),1000);timer.unref()});
 const started=await Promise.race([h.start(),timeout]);assert.equal(started.ok,true);await h.send({type:'STATUS'});assert.equal(bindCount,1);assert.equal(h.local.data.currentTask.document.id,'document-a');
 const claim=await h.claim();assert.equal(claim.action,'purchase-act');assert.equal((await h.check(claim.claimToken)).allowed,true);
 h.setDocument('https://www.apple.com.cn/shop/bag');h.events.updated.emit(4,{status:'loading',url:h.tab.url});await h.send({type:'STATUS'});h.events.updated.emit(4,{status:'complete'});await Promise.race([h.send({type:'STATUS'}),timeout]);await h.send({type:'STATUS'});assert.equal(bindCount,2);assert.equal(h.local.data.currentTask.document.id,'document-b');assert.equal(h.local.data.currentTask.claim.token,claim.claimToken);assert.equal((await h.result(claim.claimToken)).stepIndex,1);
});
test('optional local address profile requires explicit UI save and never appears in STATUS',async()=>{
 const h=await harness();assert.equal((await h.send({type:'PURCHASE_SAVE_ADDRESS_PROFILE',address})).ok,false);assert.equal(h.local.data.purchaseAddressProfile,undefined);
 for(const type of ['PURCHASE_SAVE_ADDRESS_PROFILE','PURCHASE_LOAD_ADDRESS_PROFILE','PURCHASE_CLEAR_ADDRESS_PROFILE'])assert.equal((await h.send({type,address,confirmedLocalSave:true},h.sender)).ok,false);
 assert.equal((await h.send({type:'PURCHASE_SAVE_ADDRESS_PROFILE',address,confirmedLocalSave:true})).saved,true);assert.deepEqual((await h.send({type:'PURCHASE_LOAD_ADDRESS_PROFILE'})).profile.address,address);assert.equal(JSON.stringify(await h.send({type:'STATUS'})).includes(address.phone),false);
 await h.begin();await h.send({type:'PURCHASE_CLEAR_ADDRESS_PROFILE'});assert.equal(h.local.data.purchaseAddressProfile,undefined);assert.equal((await h.send({type:'PURCHASE_LOAD_ADDRESS_PROFILE'})).profile,null);assert.equal(h.local.data.currentTask.state,'STOPPED');
});
test('scheduled unified purchase denies claims before target time and permits them only after it',async()=>{
 const c=config({targetTime:new Date(Date.now()+60000).toISOString()}),h=await harness(c);await h.begin();assert.equal(h.local.data.currentTask.state,'WAITING_START');const blocked=await h.claim();assert.equal(blocked.action,'none');assert.equal(h.local.data.currentTask.claim,null);
 const key=`config:${h.base.taskId}`;h.session.data[key].targetTime=new Date(Date.now()-1000).toISOString();assert.equal((await h.claim()).action,'purchase-act');
});
test('unified configure radio result requires checked, application selection and independent confirmation',async()=>{
 const c=config();c.steps.unshift({stage:'configure',kind:'radio',group:'dimensionColor',path:new URL(c.url).pathname,target:{role:'radio',name:c.color,selector:'#radio-color'},evidence:{model:'#model',color:'#selected-color'},confirm:{selector:'#selected-color-confirmation',text:'页面颜色选择已应用'},timeoutMs:15000});
 const h=await harness(c);await h.begin();const a=await h.claim({color:null,storage:null,itemPriceMinor:null,currency:null});assert.equal(a.action,'purchase-act');assert.equal((await h.check(a.claimToken,{color:null,itemPriceMinor:null,currency:null})).allowed,true);assert.equal((await h.result(a.claimToken,{radioChecked:true,selectionApplied:true,color:c.color})).stepIndex,1);assert.equal((await h.advance()).stepIndex,2);assert.equal(h.local.data.currentTask.claims.length,2);
 const denied=await harness(c);await denied.begin();const b=await denied.claim({color:null});await denied.check(b.claimToken,{color:null});assert.equal((await denied.result(b.claimToken,{radioChecked:true,selectionApplied:false,color:c.color})).state,'UNKNOWN');
});

test('login handoff is detected when Chrome reports only loading and completion, with no URL-change event',async()=>{
 const c=config();c.steps[0].confirm={...c.steps[0].confirm,nextPath:'/shop/checkout',nextOrigin:'https://secure6.www.apple.com.cn',allowAuthHandoff:true};for(const step of c.steps.slice(1)){step.origin='https://secure6.www.apple.com.cn';step.path='/shop/checkout';}
 const h=await harness(c);await h.begin();const claim=await h.claim();await h.check(claim.claimToken);h.events.updated.emit(4,{status:'loading'});await h.send({type:'STATUS'});h.tab.url='https://secure6.www.apple.com.cn/shop/signIn?opaque=PRIVATE';h.events.updated.emit(4,{status:'complete'});const status=await h.send({type:'STATUS'});assert.equal(status.task.state,'AWAITING_USER');assert.equal(status.task.claim.token,claim.claimToken);assert.equal(JSON.stringify(status).includes('PRIVATE'),false);
});

test('bundled fixture uses real purchase state engine without permissions, scripts, settings or production barrier',async()=>{
 const c=config({url:'https://www.apple.com.cn/shop/fixture'});for(const step of c.steps)step.path='/shop/fixture';const h=await harness(c),fixtureURL=h.chrome.runtime.getURL('workflow-fixture.html');h.setDocument(fixtureURL,'fixture-document');const fixtureSender=h.sender;
 const runtimeDeliveries=[];h.chrome.runtime.sendMessage=async message=>{runtimeDeliveries.push(message);return{ok:true}};h.chrome.tabs.sendMessage=async()=>{throw Error('Extension pages are not content scripts')};
 let permissionCalls=0;h.chrome.permissions.contains=async()=>{permissionCalls++;return false};h.local.data.settings={sentinel:'preserved'};
 const started=await h.send({type:'PURCHASE_FIXTURE_START',config:c,tabId:4},fixtureSender);assert.equal(started.ok,true,started.error);h.base.taskId=started.task.id;assert.equal(started.task.testMode,true);assert.match(started.task.reason,/本地演练/);assert.equal(permissionCalls,0);assert.equal(h.injections.length,0);assert.equal(runtimeDeliveries[0].type,'START_PURCHASE_FIXTURE');assert.equal(runtimeDeliveries[0].targetTabId,4);assert.deepEqual(h.local.data.settings,{sentinel:'preserved'});
 const binding=await h.page('PURCHASE_BIND',{url:c.url});assert.equal(binding.config.testMode,true);assert.equal(binding.config.fixtureURL,fixtureURL);
 for(let index=0;index<c.steps.length;index++){
  if(c.steps[index].kind==='address')assert.equal((await h.page('PURCHASE_CONFIRM_ADDRESS',{addressConfirmed:true,addressFingerprint:selectedFingerprint})).ok,true);
  const ev=evidence(c),claim=await h.page('PURCHASE_CLAIM',{evidence:ev});assert.equal(claim.action,'purchase-act',claim.error);assert.equal((await h.page('PURCHASE_CHECK',{claimToken:claim.claimToken,evidence:ev})).allowed,true);
  const result=await h.page('PURCHASE_RESULT',{claimToken:claim.claimToken,outcome:'confirmed',evidence:{...ev,unpaidOrder:true,confirmation:{matched:true,...c.steps[index].confirm}}});assert.equal(result.ok,true,result.error);
 }
 assert.equal(h.local.data.currentTask.state,'DONE');assert.match(h.local.data.currentTask.reason,/本地演练/);assert.equal(h.local.data.currentTask.events.every(event=>event.message.includes('本地演练')),true);assert.equal(h.local.data.purchaseFinalBarrier,undefined);assert.ok(h.local.data.purchaseFixtureFinalBarrier);
 assert.equal((await h.send({type:'PURCHASE_FIXTURE_RESET',confirmedReset:true})).ok,false);assert.equal((await h.send({type:'PURCHASE_FIXTURE_RESET',confirmedReset:true},fixtureSender)).reset,true);assert.equal(h.local.data.purchaseFixtureFinalBarrier,undefined);assert.equal(h.local.data.purchaseFinalBarrier,undefined);const restarted=await h.send({type:'PURCHASE_FIXTURE_START',config:c,tabId:4},fixtureSender);assert.equal(restarted.ok,true);await h.send({type:'STOP'});assert.equal(runtimeDeliveries.at(-1).type,'HALT_PURCHASE_FIXTURE');assert.equal(runtimeDeliveries.at(-1).targetTabId,4);
});
test('fixture authorization cannot widen production origins or override an active production task',async()=>{
 const h=await harness(),c=config(),fixtureURL=h.chrome.runtime.getURL('workflow-fixture.html'),sender={...h.sender,url:fixtureURL};
 assert.equal((await h.send({type:'START',config:{...c,testMode:true},tabId:4})).ok,false);assert.equal((await h.send({type:'PURCHASE_FIXTURE_START',config:c,tabId:4},sender)).ok,false);assert.equal((await h.send({type:'PURCHASE_FIXTURE_START',config:c,tabId:4})).ok,false);
 await h.begin();const original=h.local.data.currentTask.id;h.tab.url=fixtureURL;const fake=config({url:'https://www.apple.com.cn/shop/fixture'});for(const step of fake.steps)step.path='/shop/fixture';assert.equal((await h.send({type:'PURCHASE_FIXTURE_START',config:fake,tabId:4},sender)).ok,false);assert.equal(h.local.data.currentTask.id,original);
});

test('unavailable fixture recipients cannot hold the serialized worker queue indefinitely',async()=>{
 const chrome={runtime:{sendMessage:()=>new Promise(()=>{})}};await assert.rejects(sendFixtureControl(chrome,{type:'START_PURCHASE_FIXTURE'},5),/本地演练页面没有确认/);
});
test('pending page calibration blocks run until STOP cancels the picker',async()=>{const h=await harness();h.session.data.purchasePicker={requestId:'pending-calibration',status:'pending',tabId:4,documentId:'document-a',origin:new URL(h.c.url).origin,path:new URL(h.c.url).pathname,expiresAt:Date.now()+120000};const denied=await h.start();assert.equal(denied.ok,false);assert.match(denied.error,/结束网页点选/);assert.equal(h.local.data.currentTask,undefined);await h.send({type:'STOP'});assert.equal(h.session.data.purchasePicker.status,'cancelled');assert.equal((await h.start()).ok,true);});
test('expired or navigated picker is reconciled and does not permanently block START',async()=>{for(const cause of ['expired','navigation','closed']){const h=await harness();h.session.data.purchasePicker={requestId:'pending-calibration',status:'pending',tabId:4,documentId:'document-a',origin:new URL(h.c.url).origin,path:new URL(h.c.url).pathname,expiresAt:Date.now()+(cause==='expired'?-1:120000)};if(cause==='navigation')h.events.updated.emit(4,{status:'loading'});if(cause==='closed')h.events.removed.emit(4);const started=await h.start();assert.equal(started.ok,true,started.error);assert.equal(h.session.data.purchasePicker.status,'cancelled');}});

test('loading document is identity-bound immediately without a complete event; repeated events never START twice',async()=>{
 const c=config();c.steps[0].confirm.nextPath='/shop/bag';for(const s of c.steps.slice(1))s.path='/shop/bag';
 const h=await harness(c);const starts=[];h.chrome.tabs.sendMessage=async(tabId,message,options)=>{if(message.type==='START_PURCHASE')starts.push({tabId,options});return{ok:true}};
 await h.begin();const claim=await h.claim();await h.check(claim.claimToken);
 h.setDocument('https://www.apple.com.cn/shop/bag');h.tab.status='loading';
 h.events.updated.emit(4,{status:'loading',url:h.tab.url});await h.send({type:'STATUS'});
 assert.equal(starts.length,2);assert.deepEqual(starts[1].options,{documentId:'document-b'});
 assert.equal(h.local.data.currentTask.claim.token,claim.claimToken);assert.equal((await h.bind()).pendingClaim.checked,true);
 for(let i=0;i<10;i++)h.events.updated.emit(4,{url:h.tab.url});await h.send({type:'STATUS'});
 assert.equal(starts.length,2);assert.equal(h.injections.filter(i=>i.files).length,2);
 assert.equal((await h.result(claim.claimToken)).stepIndex,1);
 assert.notEqual((await h.check(claim.claimToken)).allowed,true);
});
test('old document during loading receives no START; later committed URL binds without waiting for load',async()=>{
 const c=config();c.steps[0].confirm.nextPath='/shop/bag';for(const s of c.steps.slice(1))s.path='/shop/bag';
 const h=await harness(c);await h.begin();const a=await h.claim();await h.check(a.claimToken);
 h.tab.url='https://www.apple.com.cn/shop/bag';h.events.updated.emit(4,{status:'loading',url:h.tab.url});await h.send({type:'STATUS'});
 assert.equal(h.injections.filter(i=>i.files).length,1);assert.equal(h.local.data.currentTask.injectedDocumentId,'document-a');
 h.setDocument(h.tab.url);h.events.updated.emit(4,{url:h.tab.url});await h.send({type:'STATUS'});
 assert.equal(h.injections.filter(i=>i.files).length,2);assert.equal(h.local.data.currentTask.injectedDocumentId,'document-b');
});
test('probe-to-injection document race fails closed and never sends START to replacement frame',async()=>{
 const h=await harness();let starts=0;h.chrome.tabs.sendMessage=async(_tab,m)=>{if(m.type==='START_PURCHASE')starts++;return{ok:true}};
 h.chrome.scripting.executeScript=async i=>i.func?[{frameId:0,documentId:'document-a',result:{url:h.tab.url}}]:[{frameId:0,documentId:'document-b'}];
 assert.equal((await h.start()).ok,false);assert.equal(starts,0);assert.equal(h.local.data.currentTask.state,'PAUSED');
});
test('missing document identity fails closed and same-origin wrong path never starts',async()=>{
 for(const probe of [{frameId:0,result:{url}}, {frameId:1,documentId:'document-a',result:{url}}, {frameId:0,documentId:'document-a',result:{url:'https://www.apple.com.cn/shop/wrong'}}]){
  const h=await harness();let starts=0;h.chrome.scripting.executeScript=async()=>[probe];h.chrome.tabs.sendMessage=async(_tab,m)=>{if(m.type==='START_PURCHASE')starts++;return{ok:true}};
  assert.equal((await h.start()).ok,false);assert.equal(starts,0);
 }
});
test('messages from superseded document cannot bind or confirm a pending action',async()=>{
 const c=config();c.steps[0].confirm.nextPath='/shop/bag';for(const s of c.steps.slice(1))s.path='/shop/bag';
 const h=await harness(c);await h.begin();const previous={...h.sender};const a=await h.claim();await h.check(a.claimToken);
 h.setDocument('https://www.apple.com.cn/shop/bag');h.events.updated.emit(4,{url:h.tab.url,status:'loading'});await h.send({type:'STATUS'});
 assert.equal((await h.page('PURCHASE_BIND',{url:previous.url},previous)).ok,false);
 assert.equal((await h.page('PURCHASE_RESULT',{claimToken:a.claimToken,outcome:'confirmed',evidence:evidence(c)},previous)).ok,false);
 assert.equal(h.local.data.currentTask.claim.token,a.claimToken);assert.equal((await h.bind()).ok,true);
});
test('same-document authorized history transition keeps observer and does not restart task',async()=>{
 const c=config();c.steps[0].confirm.nextPath='/shop/bag';for(const s of c.steps.slice(1))s.path='/shop/bag';
 const h=await harness(c);await h.begin();const a=await h.claim();await h.check(a.claimToken);h.setDocument('https://www.apple.com.cn/shop/bag','document-a');
 h.events.updated.emit(4,{url:h.tab.url});await h.send({type:'STATUS'});assert.equal(h.injections.filter(i=>i.files).length,1);
});

test('one loading event followed by silent document commit is reprobed before load-complete',async()=>{
 const c=config();c.steps[0].confirm.nextPath='/shop/bag';for(const s of c.steps.slice(1))s.path='/shop/bag';
 const h=await harness(c);await h.begin();const a=await h.claim();await h.check(a.claimToken);
 h.tab.url='https://www.apple.com.cn/shop/bag';h.events.updated.emit(4,{status:'loading',url:h.tab.url});await h.send({type:'STATUS'});
 assert.equal(h.injections.filter(i=>i.files).length,1);
 h.setDocument(h.tab.url);h.tab.status='loading'; // No more browser events: images/analytics never finish.
 await new Promise(resolve=>setTimeout(resolve,170));await h.send({type:'STATUS'});
 assert.equal(h.injections.filter(i=>i.files).length,2);assert.equal(h.local.data.currentTask.injectedDocumentId,'document-b');
 assert.equal(h.local.data.currentTask.claim.token,a.claimToken);assert.equal((await h.bind()).ok,true);assert.equal((await h.result(a.claimToken)).stepIndex,1);
});
test('stop cancels delayed document probe, and later commit cannot restart stopped task',async()=>{
 const c=config();c.steps[0].confirm.nextPath='/shop/bag';for(const s of c.steps.slice(1))s.path='/shop/bag';
 const h=await harness(c);await h.begin();const a=await h.claim();await h.check(a.claimToken);
 h.tab.url='https://www.apple.com.cn/shop/bag';h.events.updated.emit(4,{status:'loading',url:h.tab.url});await h.send({type:'STATUS'});
 await h.send({type:'STOP'});h.setDocument(h.tab.url);await new Promise(resolve=>setTimeout(resolve,170));await h.send({type:'STATUS'});
 assert.equal(h.injections.filter(i=>i.files).length,1);assert.equal(h.local.data.currentTask.state,'UNKNOWN');
});
test('uncommitted initial navigation cannot start against matching old page',async()=>{
 const h=await harness();h.tab.pendingUrl=h.tab.url;const result=await h.start();assert.equal(result.ok,false);assert.equal(h.injections.length,0);
});
test('navigation hash or unexpected static query never starts a new document',async()=>{
 for(const suffix of ['#other','?unexpected=1']){
  const c=config();c.steps[0].confirm.nextPath='/shop/bag';for(const s of c.steps.slice(1))s.path='/shop/bag';
  const h=await harness(c);await h.begin();const a=await h.claim();await h.check(a.claimToken);h.setDocument('https://www.apple.com.cn/shop/bag'+suffix);
  h.events.updated.emit(4,{url:h.tab.url,status:'loading'});await h.send({type:'STATUS'});
  assert.equal(h.local.data.currentTask.state,'UNKNOWN');assert.equal(h.injections.filter(i=>i.files).length,1);
 }
});

test('late probe result after its deadline cannot inject or overwrite stopped state',async()=>{
 const h=await harness();let release,files=0;h.chrome.scripting.executeScript=async i=>{if(i.files){files++;return[{frameId:0,documentId:'document-a'}];}return new Promise(resolve=>{release=resolve});};
 const starting=h.start();await new Promise(resolve=>setTimeout(resolve,10));const stopping=h.send({type:'STOP'});
 assert.equal((await starting).ok,false);await stopping;const before=structuredClone(h.local.data.currentTask);
 release([{frameId:0,documentId:'document-a',result:{url:h.tab.url}}]);await new Promise(resolve=>setTimeout(resolve,20));
 assert.equal(files,0);assert.deepEqual(h.local.data.currentTask,before);
});
test('bounded reprobing times out without replaying pending claim',async()=>{
 const c=config();c.steps[0].confirm.nextPath='/shop/bag';for(const s of c.steps.slice(1))s.path='/shop/bag';
 const h=await harness(c);await h.begin();const a=await h.claim();await h.check(a.claimToken);h.local.data.currentTask.claim.deadline=Date.now()+50;
 h.tab.url='https://www.apple.com.cn/shop/bag';h.events.updated.emit(4,{status:'loading',url:h.tab.url});await h.send({type:'STATUS'});
 await new Promise(resolve=>setTimeout(resolve,150));await h.send({type:'STATUS'});assert.equal(h.local.data.currentTask.state,'UNKNOWN');
 assert.equal(h.injections.filter(i=>i.files).length,1);assert.equal(h.local.data.currentTask.claim.token,a.claimToken);
});
