import { createHash } from 'node:crypto';

export const DEFAULTS = Object.freeze({
  mode: 'simulate', url: 'https://www.apple.com.cn/shop/buy-iphone/iphone-duo',
  region: 'CN', regionConfirmed: true, model: 'iPhone Duo', storage: '', color: '',
  quantity: 1, currency: 'CNY', maxTotal: '', delivery: '',
  targetTime: '2026-10-16T20:00:00+08:00', timeZone: 'Asia/Shanghai',
  expiresAt: '2026-10-16T20:10:00+08:00', pollMs: 1000,
  scenario: 'normal', countdownSeconds: 5,
  selectors: { countdown: '', model: '', storage: '', color: '', quantity: '', total: '', currency: '', region: '', delivery: '', button: '' }
});

export function appleUrl(value) {
  try {
    const u = new URL(value);
    return u.protocol === 'https:' && !u.username && !u.password && !u.port &&
      ['www.apple.com', 'www.apple.com.cn', 'secure.store.apple.com', 'secure.store.apple.com.cn'].includes(u.hostname) &&
      !u.hash && /^\/(?:[a-z]{2}(?:-[a-z]{2})?\/)?shop(?:\/|$)/i.test(u.pathname);
  } catch { return false; }
}

export function validate(raw, now = Date.now()) {
  const c = { ...DEFAULTS, ...raw, selectors: { ...DEFAULTS.selectors, ...raw.selectors } };
  if (!['simulate', 'dryrun', 'official-readonly'].includes(c.mode)) throw Error('模式无效；本版本未开放真实点击或提交');
  if (!appleUrl(c.url)) throw Error('购买链接仅允许白名单 Apple HTTPS 商店地址');
  if (!Number.isInteger(c.quantity) || c.quantity < 1 || c.quantity > 10) throw Error('数量必须为 1 至 10 的整数；不代表 Apple 限购政策');
  if (!Number.isFinite(Number(c.maxTotal)) || Number(c.maxTotal) <= 0 || Number(c.maxTotal)>100000000 || Math.abs(Number(c.maxTotal)*100-Math.round(Number(c.maxTotal)*100))>0.00001) throw Error('请设置最高总价，包含税费及配送费，最多两位小数');
  if (!/^[A-Z]{3}$/.test(c.currency)) throw Error('货币必须为三位大写代码');
  for (const key of ['region','model','storage','color','delivery']) if (typeof c[key] !== 'string' || !c[key].trim() || c[key].length > 160) throw Error(`请填写 ${key}`);
  if (c.mode === 'official-readonly' && c.regionConfirmed !== true) throw Error('须先确认购买地区；目前地区待确认');
  for (const key of ['targetTime','expiresAt']) {
    if (typeof c[key] !== 'string' || !/(Z|[+-]\d{2}:\d{2})$/.test(c[key]) || !Number.isFinite(Date.parse(c[key]))) throw Error('时间须包含 UTC 偏移量，例如 +08:00');
  }
  try { new Intl.DateTimeFormat('zh-CN', { timeZone: c.timeZone }).format(now); } catch { throw Error('IANA 时区无效'); }
  if (Date.parse(c.expiresAt) <= Date.parse(c.targetTime)) throw Error('过期时间必须晚于开抢时间');
  if (c.mode === 'official-readonly' && (Date.parse(c.targetTime) <= now || Date.parse(c.expiresAt) <= now)) throw Error('开抢时间或任务已过期，请重新确认');
  if (!Number.isInteger(c.pollMs) || c.pollMs < 1000 || c.pollMs > 60000) throw Error('检测间隔须为 1000 至 60000 毫秒');
  if (!['normal','reset','soldout','price','unknown','payment','mismatch','blocked'].includes(c.scenario)) throw Error('模拟场景无效');
  if (!Number.isInteger(c.countdownSeconds) || c.countdownSeconds < 1 || c.countdownSeconds > 120) throw Error('模拟倒计时须为 1 至 120 秒');
  if (Object.values(c.selectors).some(x => typeof x !== 'string' || x.length > 300)) throw Error('选择器无效或过长');
  return c;
}

export function parseCountdown(value) {
  if (typeof value !== 'string') return null;
  const s = value.trim();
  let m = /^(?:(\d{1,3}):)?([0-5]?\d):([0-5]\d)$/.exec(s);
  if (m) return ((Number(m[1] || 0) * 3600 + Number(m[2]) * 60 + Number(m[3])) * 1000);
  m = /^(?:(\d+)\s*天\s*)?(?:(\d+)\s*小时\s*)?(?:(\d+)\s*分(?:钟)?\s*)?(\d+)\s*秒$/.exec(s);
  return m ? ((Number(m[1] || 0)*86400 + Number(m[2] || 0)*3600 + Number(m[3] || 0)*60 + Number(m[4]))*1000) : null;
}

export function intentKey(c) {
  return createHash('sha256').update(JSON.stringify([c.mode,c.url,c.region,c.model,c.storage,c.color,c.quantity,c.currency,c.maxTotal,c.delivery,c.targetTime,c.scenario,c.intentId])).digest('hex');
}

export class Engine {
  constructor(config) { this.config = config; this.state = 'READY'; this.lastRemaining = null; this.claimed = false; this.reason = '准备就绪'; this.remainingMs = null; this.source = null; }
  pause(reason) { if (['STOPPED','DONE','UNKNOWN'].includes(this.state)) return { type:'none' }; this.state = 'PAUSED'; this.reason = reason; return { type: 'none', reason }; }
  stop() { this.state = 'STOPPED'; this.reason = '用户已停止；不会自动恢复'; }
  observe(s, now = Date.now()) {
    if (['PAUSED','STOPPED','DONE','UNKNOWN','SUBMITTING'].includes(this.state)) return { type:'none' };
    const c = this.config;
    if (now > Date.parse(c.expiresAt)) return this.pause('任务已过期');
    if (!s || !Number.isFinite(s.observedAt) || now - s.observedAt > 5000 || s.observedAt > now + 1000) return this.pause('页面证据过期或时间异常');
    if (s.blocker) return this.pause(s.blocker);
    if (s.soldOut) return this.pause('商品售罄；不刷新或重试');
    for (const key of ['region','model','storage','color','quantity','currency','delivery']) {
      if (String(s[key] ?? '') !== String(c[key])) return this.pause(`页面 ${key} 与配置不符或无法验证`);
    }
    if (!Number.isSafeInteger(s.totalMinor) || s.totalMinor < 0) return this.pause('无法验证含税费配送费的总价');
    const maxMinor = Math.round(Number(c.maxTotal)*100);
    if (s.totalMinor > maxMinor) return this.pause('总价超过最高总价');
    if (this.lastPrice !== undefined && s.totalMinor !== this.lastPrice) return this.pause('检测到总价变化，需人工复核');
    this.lastPrice = s.totalMinor;
    let remaining;
    if (s.countdownPresent) {
      remaining = parseCountdown(s.countdownText);
      this.source = '页面可见倒计时';
      if (remaining === null) return this.pause('页面倒计时格式未知或选择器不唯一');
      if (this.lastRemaining !== null && remaining > this.lastRemaining + 1500) return this.pause('页面倒计时重置或延长');
    } else { remaining = Math.max(0, Date.parse(c.targetTime) - now); this.source = '本地计算（依赖电脑时钟）'; }
    this.lastRemaining = remaining; this.remainingMs = remaining;
    if (remaining > 0) { this.state = 'WAITING'; this.reason = '等待倒计时结束'; return { type:'none' }; }
    if (!s.buttonUnique) return this.pause('购买按钮不存在或不唯一');
    if (!s.buttonEnabled) { this.state = 'WAITING'; this.reason = '到点，等待按钮可用'; return { type:'none' }; }
    if (c.mode !== 'simulate') { this.state = 'DONE'; this.reason = '预演：条件满足，已停在购买动作前；真实点击和提交锁定'; return { type:'preview' }; }
    if (this.claimed) return this.pause('重复提交已拦截');
    this.claimed = true; this.state = 'SUBMITTING'; this.reason = '仅本地模拟：提交一次';
    return { type:'mock-submit' };
  }
  result(value) {
    if (this.state !== 'SUBMITTING') return;
    this.state = value === 'confirmed' ? 'DONE' : 'UNKNOWN';
    this.reason = value === 'confirmed' ? '本地模拟订单已确认；没有真实订单' : '提交结果未知；已锁定，禁止自动重试';
  }
}
