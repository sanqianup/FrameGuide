import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {CALIBRATION_PHASES,newCalibrationStep,calibrationFields,applyCalibrationPick,mountPurchaseCalibration} from '../extension/purchase-calibration.js';
import {config as fixtureConfig,path} from './purchase-fixture.mjs';
import {validatePurchase,createDuoSteps} from '../extension/purchase-config.js';
import {PurchaseCalibrationController} from '../extension/purchase-calibration-background.js';

const source=fs.readFileSync(new URL('../extension/purchase-calibration.js',import.meta.url),'utf8');
const pick=(selector='#target',extra={})=>({origin:'https://www.apple.com.cn',path,locator:{selector,role:'button',name:'加入购物袋'},...extra});
class Element {
  constructor(tag,doc){this.tagName=tag;this.ownerDocument=doc;this.children=[];this.dataset={};this.events={};this.attributes={};this.type='';this.value='';this.checked=false;this.disabled=false;}
  append(...nodes){this.children.push(...nodes);}
  replaceChildren(...nodes){this.children=[...nodes];}
  addEventListener(name,callback){this.events[name]=callback;}
  setAttribute(name,value){this.attributes[name]=value;}
}
function view(){const document={createElement:tag=>new Element(tag,document)};const host=new Element('div',document);const walk=node=>[node,...node.children.flatMap(walk)];return{host,walk,action:id=>walk(host).find(node=>node.dataset.calibrationAction===id),field:id=>walk(host).find(node=>node.dataset.calibrationField===id),text:()=>walk(host).map(node=>node.textContent??'').join('\n')};}
const tick=()=>new Promise(resolve=>setImmediate(resolve));
async function settle(){await tick();await tick();}
function harness(options={}){
  const ui=view(),messages=[],timers=new Map(),changes=[];let config=options.config??fixtureConfig(),plan=options.plan??[];
  const send=async message=>{messages.push(structuredClone(message));if(options.send)return options.send(message);if(message.type==='PURCHASE_PICK_BEGIN')return{ok:true,requestId:'pick-1'};if(message.type==='PURCHASE_PICK_STATUS')return{ok:true,status:'pending'};return{ok:true};};
  const controller=mountPurchaseCalibration(ui.host,{getConfig:()=>config,getPlan:()=>plan,onPlanChange:value=>changes.push(value),getTargetTabId:options.getTargetTabId??(()=>7),send,setTimeout:callback=>{timers.set(1,callback);return 1;},clearTimeout:id=>timers.delete(id)});
  return{...ui,controller,messages,timers,changes,setConfig:value=>{config=value;},setPlan:value=>{plan=value;},async click(id){const node=ui.action(id);assert.ok(node,`Missing action ${id}`);await node.events.click();await settle();},async poll(){const callback=timers.get(1);assert.ok(callback);timers.delete(1);await callback();await settle();}};
}

test('module has no storage access, merchant click, address fill, network or run side effect',()=>{
  assert.doesNotMatch(source,/(?:localStorage|sessionStorage|\.storage\.|\.click\(|\.submit\(|fetch\(|XMLHttpRequest|innerHTML|type\s*:\s*['"]START['"])/);
  assert.deepEqual(CALIBRATION_PHASES.map(([key])=>key),['configure','add-to-bag','address','review','submit-unpaid']);
});
test('honest new skeletons carry no fabricated source path or website selectors',()=>{
  for(const[stage]of CALIBRATION_PHASES){const step=newCalibrationStep(stage,{addressMode:'new'});assert.equal(step.path,'');assert.deepEqual(step.evidence,{});assert.equal(step.confirm.selector,'');assert.equal(step.confirm.text,'');assert.ok(!JSON.stringify(step).includes('#'));}
  assert.throws(()=>newCalibrationStep('payment'),/请选择/);
});
test('new-address guide starts with minimum field mappings and no recipient values',()=>{
  const step=newCalibrationStep('address',{addressMode:'new'});
  assert.deepEqual(step.fields.map(field=>field.key),['fullName','phone','province','city','district','addressLine1']);
  assert.ok(step.fields.every(field=>Object.keys(field).sort().join(',')==='autocomplete,key'));
  assert.deepEqual(newCalibrationStep('address',{addressMode:'existing'}).addressConfirmation,{selector:''});
});
test('every nonconfiguration phase requests exact required independent evidence',()=>{
  const config=fixtureConfig();for(const[stage]of CALIBRATION_PHASES.slice(1)){const step=newCalibrationStep(stage,config),fields=calibrationFields(step,0,[step],config);for(const key of ['model','storage','color','quantity','currency','region','delivery','itemCount'])assert.ok(fields.some(field=>field.id===`evidence.${key}`));assert.ok(fields.at(-1).isResult);}
});
test('configuration guide also checks previously selected dimensions',()=>{
  const color=newCalibrationStep('configure'),capacity={...newCalibrationStep('configure'),group:'dimensionCapacity'};
  const fields=calibrationFields(capacity,1,[color,capacity],{});
  assert.ok(fields.some(field=>field.id==='evidence.color'));assert.ok(fields.some(field=>field.id==='evidence.storage'));
});
test('safe action marking records source and explicit role without unrelated locator data',()=>{
  const original=newCalibrationStep(),result=pick('#add',{sessionQuery:'PRIVATE-SESSION',locator:{selector:'#add',role:'button',name:'加入购物袋',value:'PRIVATE-VALUE'}});
  const step=applyCalibrationPick(original,{id:'target',kind:'action'},result);
  assert.equal(original.path,'');assert.equal(step.path,path);assert.equal(step.origin,'https://www.apple.com.cn');assert.deepEqual(step.target,{selector:'#add',role:'button',name:'加入购物袋'});assert.ok(!JSON.stringify(step).includes('PRIVATE'));
});
test('public evidence ignores locator name and every private-looking extra value',()=>{
  const step=applyCalibrationPick(newCalibrationStep(),{id:'evidence.model',kind:'public-evidence'},pick('#model',{locator:{selector:'#model',role:'evidence',name:'PRIVATE-NAME',value:'PRIVATE-VALUE'}}));
  assert.equal(step.evidence.model,'#model');assert.ok(!JSON.stringify(step).includes('PRIVATE'));
});
test('address field marking records only key, selector and matching autocomplete',()=>{
  const original=newCalibrationStep('address',{addressMode:'new'}),field={id:'field.phone',fieldKey:'phone',kind:'address-field'};
  const step=applyCalibrationPick(original,field,pick('#phone',{locator:{selector:'#phone',autocomplete:'tel',name:'PRIVATE-NAME',value:'13800000000'}}));
  assert.deepEqual(step.fields.find(item=>item.key==='phone'),{key:'phone',selector:'#phone',autocomplete:'tel'});
  assert.throws(()=>applyCalibrationPick(original,field,pick('#phone',{locator:{selector:'#phone',autocomplete:'email'}})),/类型/);
});
test('payment or login targets and wrong roles cannot become action mappings',()=>{
  for(const name of ['立即付款','登录','同意条款'])assert.throws(()=>applyCalibrationPick(newCalibrationStep(),{id:'target'},pick('#unsafe',{locator:{selector:'#unsafe',role:'button',name}})),/安全/);
  assert.throws(()=>applyCalibrationPick(newCalibrationStep(),{id:'target'},pick('#radio',{locator:{selector:'#radio',role:'radio',name:'夜空色'}})),/安全/);
});
test('result from different page needs an explicit navigation confirmation',()=>{
  const original=applyCalibrationPick(newCalibrationStep(),{id:'target'},pick()),field={id:'confirm',isResult:true};
  const result=pick('#ready',{origin:'https://secure6.www.apple.com.cn',path:'/shop/checkout'});
  assert.throws(()=>applyCalibrationPick(original,field,result),/明确确认/);
  const step=applyCalibrationPick(original,field,result,{confirmNavigation:true});
  assert.equal(step.confirm.nextOrigin,result.origin);assert.equal(step.confirm.nextPath,'/shop/checkout');assert.equal(step.path,path);assert.equal(step.confirm.nextQuery,undefined);
});
test('a new-page result cannot silently move source evidence to another page',()=>{
  const original=applyCalibrationPick(newCalibrationStep(),{id:'target'},pick());
  assert.throws(()=>applyCalibrationPick(original,{id:'evidence.model'},pick('#model',{path:'/shop/bag'})),/不是本步骤/);
  assert.throws(()=>applyCalibrationPick(newCalibrationStep(),{id:'confirm'},pick('#ready')),/请先标记/);
});
test('exact same-page result removes obsolete transition and authentication metadata',()=>{
  const original={...fixtureConfig().steps[0],confirm:{selector:'#old',text:'原文',nextOrigin:'https://secure6.www.apple.com.cn',nextPath:'/shop/old',nextQuery:{product:'private'},allowAuthHandoff:true}};
  const step=applyCalibrationPick(original,{id:'confirm'},pick('#ready'));
  assert.deepEqual(step.confirm,{selector:'#ready',text:'原文'});
});
test('noncanonical destinations and unsafe selectors cannot enter guided mapping',()=>{
  for(const result of [pick('body'),pick('[value="private"]'),pick('#x',{origin:'https://evil.example'}),pick('#x',{path:'/shop/result?session=PRIVATE'}),pick('#x',{path:'/account'}),pick('#x',{path:'/shop/result#private'})])assert.throws(()=>applyCalibrationPick(newCalibrationStep(),{id:'evidence.model'},result));
});
test('mount is inert, displays one current marking card and hides map details',()=>{
  const ui=harness();assert.equal(ui.messages.length,0);assert.equal(ui.changes.length,0);assert.equal(ui.walk(ui.host).filter(node=>node.tagName==='h3').length,1);
  const details=ui.walk(ui.host).find(node=>node.tagName==='details');assert.ok(details);assert.equal(details.open,undefined);
  assert.ok(!ui.walk(ui.host).some(node=>node.tagName==='input'&&/selector|json|path/i.test(node.dataset.calibrationField??'')));
  assert.match(ui.text(),/待校准/);
});
test('incomplete full-plan save fails before backend save and never enables execution',async()=>{
  const ui=harness();await ui.click('save-plan');assert.equal(ui.messages.length,0);assert.equal(ui.changes.length,0);assert.ok(ui.walk(ui.host).some(node=>node.dataset.calibrationError));
});
test('complete save uses validator, removes private config extras, and only publishes after success',async()=>{
  const config={...fixtureConfig(),address:{fullName:'PRIVATE'},address_fullName:'PRIVATE',confirmedPurchase:false};
  const ui=harness({config,plan:config.steps});await ui.click('save-plan');
  assert.equal(ui.messages.length,1);assert.equal(ui.messages[0].type,'PURCHASE_SAVE_PLAN');assert.equal(ui.messages[0].confirmedCalibration,true);assert.equal(ui.changes.length,1);
  assert.ok(!JSON.stringify(ui.messages).includes('PRIVATE'));assert.equal(ui.messages[0].config.confirmedPurchase,true);assert.match(ui.text(),/仍须重新确认/);validatePurchase(ui.messages[0].config);
  ui.changes[0][0].target.name='mutated';assert.notEqual(ui.controller.getPlan()[0].target.name,'mutated');
});
test('backend save error leaves external plan unpublished',async()=>{
  const config=fixtureConfig(),ui=harness({config,plan:config.steps,send:()=>({ok:false,error:'保存失败'})});await ui.click('save-plan');assert.equal(ui.changes.length,0);assert.match(ui.text(),/保存失败/);
});
test('draft save keeps partial mappings local, strips unknown fields and does not publish executable plan',async()=>{
  const config={...fixtureConfig(),address:{phone:'PRIVATE'}},step={...newCalibrationStep(),address:{phone:'PRIVATE'},evidence:{model:'#model'},fields:[{key:'phone',selector:'#phone',autocomplete:'tel',value:'PRIVATE'}]};
  const ui=harness({config,plan:[step]});await ui.click('save-draft');const message=ui.messages[0];assert.equal(message.type,'PURCHASE_SAVE_DRAFT');assert.equal(message.steps[0].evidence.model,'#model');assert.ok(!JSON.stringify(message).includes('PRIVATE'));assert.equal(ui.changes.length,0);assert.match(ui.text(),/不能用于开始购买/);
});
test('guided picker handles pending and selected responses without merchant activation commands',async()=>{
  let status='pending',context;
  const ui=harness({getTargetTabId:value=>{context=value;return 9;},send:message=>message.type==='PURCHASE_PICK_BEGIN'?{ok:true,requestId:'pick-1'}:message.type==='PURCHASE_PICK_STATUS'?{ok:true,status,result:pick('#add')}:{ok:true}});
  await ui.click('pick');assert.equal(ui.messages[0].type,'PURCHASE_PICK_BEGIN');assert.equal(ui.messages[0].tabId,9);assert.equal(context.stage,'add-to-bag');assert.equal(context.isResult,false);assert.equal(ui.timers.size,1);assert.equal(ui.action('pick').disabled,true);
  status='selected';await ui.poll();assert.equal(ui.controller.getPlan()[0].target.selector,'#add');assert.equal(ui.action('pick').disabled,false);assert.match(ui.text(),/已标记/);
});
test('double pick clicks while begin is outstanding send one request',async()=>{
  let release;const gate=new Promise(resolve=>{release=resolve;});const ui=harness({getTargetTabId:()=>gate});
  ui.action('pick').events.click();ui.action('pick').events.click();await settle();assert.equal(ui.messages.length,0);release(7);await settle();assert.equal(ui.messages.filter(message=>message.type==='PURCHASE_PICK_BEGIN').length,1);await ui.controller.destroy();
});
test('cancel aborts the current picker and later stale result cannot overwrite mappings',async()=>{
  let releaseStatus;const deferred=new Promise(resolve=>{releaseStatus=resolve;});const ui=harness({send:message=>message.type==='PURCHASE_PICK_BEGIN'?{ok:true,requestId:'pending-1'}:message.type==='PURCHASE_PICK_STATUS'?deferred:{ok:true}});
  ui.action('pick').events.click();await settle();await ui.click('cancel-pick');assert.ok(ui.messages.some(message=>message.type==='PURCHASE_PICK_ABORT'));releaseStatus({ok:true,status:'selected',result:pick('#stale')});await settle();assert.equal(ui.controller.getPlan()[0].target.selector,undefined);
});
test('destroy aborts picker that finishes starting after closure',async()=>{
  let release;const gate=new Promise(resolve=>{release=resolve;});const ui=harness({send:message=>message.type==='PURCHASE_PICK_BEGIN'?gate:{ok:true}});ui.action('pick').events.click();await settle();await ui.controller.destroy();release({ok:true,requestId:'late-1'});await settle();assert.ok(ui.messages.some(message=>message.type==='PURCHASE_PICK_ABORT'&&message.requestId==='late-1'));assert.equal(ui.host.children.length,0);
});
test('route confirmation controls defer all mapping until explicit confirmation',async()=>{
  const config=fixtureConfig(),result=pick('#ready',{origin:'https://secure6.www.apple.com.cn',path:'/shop/checkout'});
  const ui=harness({config,plan:config.steps,send:message=>message.type==='PURCHASE_PICK_BEGIN'?{ok:true,requestId:'route-1'}:message.type==='PURCHASE_PICK_STATUS'?{ok:true,status:'selected',result}:{ok:true}});
  const count=calibrationFields(config.steps[0],0,config.steps,config).length;for(let index=1;index<count;index++)await ui.click('next');await ui.click('pick');assert.ok(ui.action('confirm-route'));assert.equal(ui.controller.getPlan()[0].confirm.nextPath,undefined);
  await ui.click('confirm-route');assert.equal(ui.controller.getPlan()[0].confirm.nextPath,'/shop/checkout');
});
test('address layout and optional controls synchronize summary keys across later stages',async()=>{
  const ui=harness({config:fixtureConfig({addressMode:'new'})});await ui.click('phase-address');const input=ui.field('address-layout');input.value='split';input.events.change();const optional=ui.field('optional-postalCode');optional.checked=true;optional.events.change();
  const plan=ui.controller.getPlan(),keys=plan.find(step=>step.kind==='address').fields.map(field=>field.key);assert.ok(!keys.includes('fullName'));assert.ok(keys.includes('familyName')&&keys.includes('givenName')&&keys.includes('postalCode'));
  for(const step of plan.filter(step=>step.addressConfirmation))assert.deepEqual(step.addressConfirmation.keys,keys);
});
test('refresh adopts changed advanced plan but does not discard unsaved guide progress',async()=>{
  const ui=harness();await ui.click('next');ui.controller.refresh();assert.match(ui.text(),/标记商品型号/);
  const config=fixtureConfig();ui.setPlan(config.steps);ui.controller.refresh();assert.equal(ui.controller.getPlan()[0].target.selector,'#add');
});
test('address-mode changes invalidate summaries and establish fresh mapping placeholders',async()=>{
  const config=fixtureConfig(),ui=harness({config,plan:config.steps});ui.setConfig({...config,addressMode:'new'});ui.controller.refresh();const plan=ui.controller.getPlan();assert.equal(plan[1].fields.length,6);assert.ok(plan.filter(step=>step.addressConfirmation).every(step=>step.addressConfirmation.selector===''));
});
test('draft loading is explicit and refuses different product targets',async()=>{
  const config=fixtureConfig(),ui=harness({config,send:()=>({ok:true,draft:{config:{...config,model:'Other Phone'},steps:config.steps}})});assert.equal(ui.messages.length,0);await ui.click('load-draft');assert.match(ui.text(),/不同商品/);assert.equal(ui.changes.length,0);
});
test('Duo helper is limited to known configuration steps and leaves checkout placeholders empty',async()=>{
  const config=fixtureConfig({model:'iPhone Duo',url:'https://www.apple.com.cn/shop/buy-iphone/iphone-duo',color:'夜空色',storage:'1TB'}),ui=harness({config});await ui.click('phase-configure');await ui.click('duo');const plan=ui.controller.getPlan();assert.deepEqual(plan.slice(0,2),createDuoSteps(config));assert.ok(plan.slice(2).every(step=>step.path===''));assert.equal(calibrationFields(plan[0],0,plan,config).length,0);
});


test('only approved static attachment query is kept in source and explicitly confirmed result locations',()=>{
  const query={product:'mjt74ch/a',step:'attach'},result=pick('#attach',{path:'/shop/buy-iphone/iphone-18-pro',query});
  const step=applyCalibrationPick(newCalibrationStep(),{id:'target'},result);assert.deepEqual(step.query,query);
  const plain={...step};delete plain.query;
  assert.throws(()=>applyCalibrationPick(plain,{id:'confirm'},result),/明确确认/);
  const next=applyCalibrationPick(plain,{id:'confirm'},result,{confirmNavigation:true});assert.deepEqual(next.confirm.nextQuery,query);assert.equal(next.confirm.nextPath,result.path);
  const same=applyCalibrationPick(step,{id:'confirm'},result);assert.equal(same.confirm.nextQuery,undefined);assert.deepEqual(same.query,query);
});
test('session and arbitrary query data are rejected even if supplied by a picker result',()=>{
  for(const query of ['session=PRIVATE',{product:'mjt74ch/a',step:'attach',session:'PRIVATE'},{product:'mjt74ch/a',step:'checkout'},{product:'PRIVATE-SESSION',step:'attach'}])assert.throws(()=>applyCalibrationPick(newCalibrationStep(),{id:'target'},pick('#attach',{path:'/shop/buy-iphone/iphone-18-pro',query})),/参数/);
  assert.throws(()=>applyCalibrationPick(newCalibrationStep(),{id:'target'},pick('#attach',{origin:'https://secure6.www.apple.com.cn',path:'/shop/checkout',query:{product:'mjt74ch/a',step:'attach'}})),/参数/);
});

test('target changes clear old guide mappings rather than silently reusing them',async()=>{
  const config=fixtureConfig(),ui=harness({config,plan:config.steps});ui.setConfig({...config,storage:'1TB'});ui.controller.refresh();assert.ok(ui.controller.getPlan().every(step=>step.path===''));assert.match(ui.text(),/购买目标已改变/);assert.equal(ui.changes.length,0);
});
test('target changes abort pending picker and reject its late result',async()=>{
  let release;const pending=new Promise(resolve=>{release=resolve;}),config=fixtureConfig();const ui=harness({config,send:message=>message.type==='PURCHASE_PICK_BEGIN'?{ok:true,requestId:'old-target'}:message.type==='PURCHASE_PICK_STATUS'?pending:{ok:true}});
  ui.action('pick').events.click();await settle();ui.setConfig({...config,color:'另一颜色'});ui.controller.refresh();await settle();assert.ok(ui.messages.some(message=>message.type==='PURCHASE_PICK_ABORT'&&message.requestId==='old-target'));
  release({ok:true,status:'selected',result:pick('#old-target')});await settle();assert.equal(ui.controller.getPlan()[0].target.selector,undefined);
});

test('normal guided marking produces a validator-ready plan for either address mode',()=>{
  for(const addressMode of ['existing','new']){
    const config=fixtureConfig({addressMode}),plan=CALIBRATION_PHASES.slice(1).map(([stage])=>newCalibrationStep(stage,config));
    for(let index=0;index<plan.length;index++){
      const reference=config.steps[index],fields=calibrationFields(plan[index],index,plan,config);
      for(const field of fields){
        if(field.type==='address-layout')continue;
        let selector;
        if(field.id==='target')selector=reference.target.selector;
        else if(field.id.startsWith('field.'))selector=`#shipping-${field.fieldKey}`;
        else if(field.id.startsWith('evidence.'))selector=reference.evidence[field.id.split('.')[1]];
        else selector=reference[field.id].selector;
        const locator={selector,role:field.kind==='action'?'button':field.kind==='address-field'?'textbox':'evidence',name:field.kind==='action'?reference.target.name:'',...(field.fieldKey?{autocomplete:plan[index].fields.find(item=>item.key===field.fieldKey).autocomplete}:{})};
        plan[index]=applyCalibrationPick(plan[index],field,pick(selector,{locator}));
        if(field.textPath==='confirm.text')plan[index].confirm.text=reference.confirm.text;
        if(field.textPath==='totalIncludesTaxShipping.text')plan[index].totalIncludesTaxShipping.text=reference.totalIncludesTaxShipping.text;
        if(field.textPath==='noChargeText')plan[index].noChargeText=reference.noChargeText;
      }
    }
    const validated=validatePurchase({...config,steps:plan});assert.equal(validated.steps.length,4);assert.equal(validated.addressMode,addressMode);assert.ok(!JSON.stringify(validated.steps).includes('value'));
  }
});
test('guide draft and full save round-trip through real background schema and storage',async()=>{
  const local={},session={};const store=data=>({get:async key=>({[key]:data[key]}),set:async update=>Object.assign(data,structuredClone(update))});
  const chrome={runtime:{id:'fixture',getURL:file=>`chrome-extension://fixture/${file}`},storage:{local:store(local),session:store(session)}};
  const backend=new PurchaseCalibrationController({chrome,read:async()=>null}),sender={id:'fixture',url:chrome.runtime.getURL('purchase.html')};
  const send=async message=>({ok:true,...await backend.handle(message,sender)});
  const draft=harness({config:fixtureConfig({addressMode:'new'}),send});await draft.click('save-draft');assert.equal(local.purchaseCalibrationDraft.steps.length,4);assert.equal(local.settings,undefined);assert.match(draft.text(),/已保存在本机/);
  await draft.click('load-draft');assert.deepEqual(draft.controller.getPlan(),local.purchaseCalibrationDraft.steps);
  const config=fixtureConfig(),ready=harness({config,plan:config.steps,send});await ready.click('save-plan');assert.equal(local.settings.confirmedPurchase,false);assert.equal(ready.changes.length,1);assert.equal(session.currentTask,undefined);
});
test('next after the final field advances to the next phase rather than silently looping',async()=>{
  const config=fixtureConfig(),ui=harness({config,plan:config.steps});const count=calibrationFields(config.steps[0],0,config.steps,config).length;for(let index=0;index<count;index++)await ui.click('next');assert.equal(ui.action('phase-address').dataset.selected,'true');assert.match(ui.text(),/本步骤第 1 /);
});
