import {ADDRESS_AUTOCOMPLETE, PURCHASE_ORIGIN, PURCHASE_ORIGINS, PURCHASE_STAGES, createDuoSteps, normalizePurchaseText, purchasePath, validatePurchase} from './purchase-config.js';

// This module only edits local mappings and asks the isolated picker for them.
// It never dispatches merchant clicks, fills addresses, starts a run, or stores consent.
export const CALIBRATION_PHASES = Object.freeze([
  ['configure','选择规格'], ['add-to-bag','加入购物袋'], ['address','收货地址'], ['review','复核订单'], ['submit-unpaid','未付款提交'],
]);
const EVIDENCE = Object.freeze({model:'商品型号',storage:'容量',color:'颜色',quantity:'购买数量',currency:'人民币货币标记',region:'中国大陆地区标记',delivery:'配送方式',itemCount:'购物袋商品项目数',itemPrice:'商品单价',total:'最终总价',noCharge:'提交不扣款声明'});
const ADDRESS_LABELS = Object.freeze({fullName:'收货人姓名',givenName:'名',familyName:'姓',phone:'手机号码',province:'省／直辖市',city:'城市',district:'区／县',addressLine1:'街道地址',addressLine2:'地址第二行',postalCode:'邮编',email:'邮箱'});
const MIN_ADDRESS = ['fullName','phone','province','city','district','addressLine1'];
const PUBLIC_CONFIG = ['mode','url','model','storage','color','quantity','maxTotal','currency','region','regionConfirmed','delivery','pollMs','targetTime','expiresAt','addressMode'];
const clone = value => JSON.parse(JSON.stringify(value));
const project = (value, keys) => Object.fromEntries(keys.filter(key => value?.[key] !== undefined).map(key => [key,clone(value[key])]));
const get = (object, path) => path.split('.').reduce((value,key) => value?.[key],object);
function put(object, path, value) { const keys=path.split('.'); let cursor=object; for(const key of keys.slice(0,-1)) cursor=cursor[key]??={}; if(value===undefined) delete cursor[keys.at(-1)]; else cursor[keys.at(-1)]=value; }
const publicConfig = config => project(config, PUBLIC_CONFIG);
const targetSignature = config => JSON.stringify(project(config,['url','model','storage','color']));
function boundedPlan(value) {
  if (!Array.isArray(value) || value.length>16 || value.some(step=>!step || typeof step!=='object' || Array.isArray(step))) throw Error('校准进度须为最多 16 个步骤。');
  return value.map(raw=>{
    const step=project(raw,['stage','kind','group','adapter','origin','path','timeoutMs','noChargeText']);
    if(raw.query) step.query=project(raw.query,['product','step']);
    if(raw.target) step.target=project(raw.target,['role','name','selector']);
    if(raw.evidence) step.evidence=project(raw.evidence,Object.keys(EVIDENCE));
    if(raw.confirm) { step.confirm=project(raw.confirm,['kind','selector','text','nextPath','nextOrigin','allowAuthHandoff']); if(raw.confirm.nextQuery) step.confirm.nextQuery=project(raw.confirm.nextQuery,['product','step']); }
    if(Array.isArray(raw.fields)) step.fields=raw.fields.map(field=>project(field,['key','selector','name','autocomplete']));
    if(raw.addressConfirmation) step.addressConfirmation=project(raw.addressConfirmation,['selector','keys']);
    if(raw.totalIncludesTaxShipping) step.totalIncludesTaxShipping=project(raw.totalIncludesTaxShipping,['selector','text']);
    return step;
  });
}
export function newCalibrationStep(stage='add-to-bag',config={}) {
  if(!PURCHASE_STAGES.includes(stage)) throw Error('请选择可校准的购买阶段。');
  const step={stage,kind:stage==='configure'?'radio':stage==='address'?'address':'button',origin:PURCHASE_ORIGIN,path:'',timeoutMs:15000,evidence:{},confirm:{selector:'',text:''}};
  if(stage==='configure') step.group='dimensionColor';
  if(step.kind!=='address') step.target={role:step.kind,name:''};
  if(['address','review','submit-unpaid'].includes(stage)) step.addressConfirmation={selector:'',...(config.addressMode==='new'?{keys:[...MIN_ADDRESS]}:{})};
  if(stage==='address'&&config.addressMode==='new') step.fields=MIN_ADDRESS.map(key=>({key,autocomplete:ADDRESS_AUTOCOMPLETE[key]}));
  if(['review','submit-unpaid'].includes(stage)) step.totalIncludesTaxShipping={selector:'',text:''};
  if(stage==='submit-unpaid') step.noChargeText='';
  return step;
}
export function calibrationFields(step,index,plan,config={}) {
  if(step.adapter==='apple-duo') return [];
  const fields=[];
  if(step.kind==='address'&&config.addressMode==='new') {
    fields.push({id:'address-layout',label:'选择网页的姓名栏格式',type:'address-layout'});
    for(const field of step.fields??[]) fields.push({id:`field.${field.key}`,label:`标记“${ADDRESS_LABELS[field.key]??field.key}”输入栏`,kind:'address-field',fieldKey:field.key});
  } else if(step.kind!=='address') fields.push({id:'target',label:step.stage==='configure'?`标记要选择的${step.group==='dimensionCapacity'?'容量':'颜色'}`:'标记本步骤的操作按钮',kind:'action'});
  const evidence=step.stage==='configure'?['model',step.group==='dimensionCapacity'?'storage':'color',...plan.slice(0,index).filter(item=>item.stage==='configure').map(item=>item.group==='dimensionCapacity'?'storage':'color')]:['model','storage','color','quantity','currency','region','delivery','itemCount',['review','submit-unpaid'].includes(step.stage)?'total':'itemPrice'];
  for(const key of new Set(evidence)) fields.push({id:`evidence.${key}`,label:`标记${EVIDENCE[key]}`,kind:'public-evidence'});
  if(['address','review','submit-unpaid'].includes(step.stage)) fields.push({id:'addressConfirmation',label:'标记网页中的完整配送地址摘要',kind:'public-evidence',help:'只记住摘要的位置；不会读取或保存这里的姓名、电话和地址原文。'});
  if(['review','submit-unpaid'].includes(step.stage)) fields.push({id:'totalIncludesTaxShipping',label:'标记总价包含税费和配送费的声明',kind:'public-evidence',textPath:'totalIncludesTaxShipping.text',help:'逐字填写网页上公开的含费声明。不要自行推断或改写。'});
  if(step.stage==='submit-unpaid') fields.push({id:'evidence.noCharge',label:'标记提交不会扣款的声明',kind:'public-evidence',textPath:'noChargeText',help:'只填写网页明确写出的不扣款声明。没有这项声明时，请保留未完成并手动处理。'});
  fields.push({id:'confirm',label:step.stage==='submit-unpaid'?'标记已创建未付款订单的公开结果':'标记本步骤完成后的独立结果',kind:'public-evidence',textPath:'confirm.text',isResult:true,help:'请自己查看已发生动作后的页面，仅标记公开状态文字。不要为了校准而创建订单；没有真实结果可核验时，保留未完成。不要输入订单号、姓名或地址。'});
  return fields;
}
function selectorOf(result) {
  if(!result||!PURCHASE_ORIGINS.includes(result.origin)) throw Error('只能标记已核验的 Apple 中国大陆页面。');
  purchasePath(result.path);
  if(result.query!==undefined&&(result.origin!==PURCHASE_ORIGIN||!/^\/shop\/buy-iphone\/[a-z0-9-]+$/u.test(result.path)||!result.query||typeof result.query!=='object'||Array.isArray(result.query)||Object.keys(result.query).length!==2||Object.keys(result.query).some(key=>!['product','step'].includes(key))||typeof result.query.product!=='string'||!/^[a-z0-9]{5,16}\/a$/iu.test(result.query.product)||result.query.step!=='attach')) throw Error('页面参数不是已核验的静态商品附件参数。');
  const selector=result.locator?.selector;
  if(typeof selector!=='string'||!selector.trim()||selector.length>300||/^(?:\*|html|body|:root)$/iu.test(selector)||selector.includes('\\')||/\[\s*value\b|[\u0000-\u001f\u007f]/iu.test(selector)) throw Error('网页没有提供安全、唯一的标记，请重新选择。');
  return selector;
}
export function applyCalibrationPick(original,field,result,{confirmNavigation=false}={}) {
  const selector=selectorOf(result),step=clone(original),isResult=field.id==='confirm';
  if(!step.path&&isResult) throw Error('请先标记本步骤的按钮、输入栏或商品信息，再标记结果。');
  const query=result.query?{product:result.query.product,step:'attach'}:undefined;
  const changed=!!step.path&&(result.origin!==(step.origin??PURCHASE_ORIGIN)||result.path!==step.path||JSON.stringify(query??{})!==JSON.stringify(step.query?{product:step.query.product,step:step.query.step}:{}));
  if(changed&&!isResult) throw Error('这不是本步骤已标记的页面。请返回原页面，或清除此步骤后重新标记。');
  if(changed&&isResult&&!confirmNavigation) throw Error('请明确确认这是本步骤动作后的实际结果页面。');
  if(!isResult&&!step.path) {step.origin=result.origin;step.path=result.path;if(query)step.query=query;else delete step.query;}
  if(field.id==='target') {
    const name=normalizePurchaseText(result.locator.name),role=step.kind;
    if(result.locator.role!==role||!name||name.length>160||globalThis.PurchasePolicy.unsafeAction(name)) throw Error('此目标不是安全、明确的本步骤按钮或规格选项。');
    step.target={role,name,selector};
  } else if(field.id.startsWith('field.')) {
    const key=field.fieldKey;
    if(!Object.hasOwn(ADDRESS_AUTOCOMPLETE,key)||result.locator.autocomplete!==ADDRESS_AUTOCOMPLETE[key]) throw Error('此输入栏的类型与所选地址字段不符。');
    const mapped={key,selector,autocomplete:ADDRESS_AUTOCOMPLETE[key]};
    const index=step.fields?.findIndex(item=>item.key===key)??-1;
    if(index<0) throw Error('请先选择需要标记的地址栏。');
    step.fields[index]=mapped;
  } else if(field.id.startsWith('evidence.')) put(step,field.id,selector);
  else if(['confirm','addressConfirmation','totalIncludesTaxShipping'].includes(field.id)) put(step,`${field.id}.selector`,selector);
  else throw Error('请选择本步骤需要标记的项目。');
  if(isResult) {
    delete step.confirm.nextQuery;delete step.confirm.allowAuthHandoff;
    if(changed) {step.confirm.nextOrigin=result.origin;step.confirm.nextPath=result.path;if(query)step.confirm.nextQuery=query;}
    else {delete step.confirm.nextOrigin;delete step.confirm.nextPath;}
  }
  return step;
}
function mapped(step,field) {
  if(field.type==='address-layout') return true;
  if(field.id==='target') return !!(step.target?.selector&&step.target?.name);
  if(field.id.startsWith('field.')) return !!step.fields?.find(item=>item.key===field.fieldKey)?.selector;
  return !!get(step,field.id.startsWith('evidence.')?field.id:`${field.id}.selector`);
}
function syncAddressKeys(plan,config) {
  const keys=(plan.find(step=>step.kind==='address')?.fields??[]).map(field=>field.key);
  for(const step of plan) if(step.addressConfirmation) {
    if(config.addressMode==='new') step.addressConfirmation.keys=[...keys];
    else delete step.addressConfirmation.keys;
  }
}

export function mountPurchaseCalibration(host,{getConfig=()=>({}),getPlan=()=>[],onPlanChange=()=>{},send=message=>globalThis.chrome.runtime.sendMessage(message),getTargetTabId=()=>{throw Error('请先选择要校准的 Apple 标签页。');},setTimeout=globalThis.setTimeout,clearTimeout=globalThis.clearTimeout}={}) {
  const doc=host.ownerDocument??globalThis.document;
  let plan=boundedPlan(getPlan()),phase=plan[0]?.stage??'add-to-bag',stepIndex=0,fieldIndex=0,status='',failure='',active=null,timer=null,pendingResult=null,disposed=false,busy=false,generation=0;
  let observedPlan=JSON.stringify(plan),addressMode=getConfig().addressMode,observedTarget=targetSignature(getConfig());
  if(!plan.length) plan=PURCHASE_STAGES.slice(1).map(stage=>newCalibrationStep(stage,getConfig()));
  const el=(tag,text)=>{const node=doc.createElement(tag);if(text!==undefined)node.textContent=text;return node;};
  const button=(text,action,id)=>{const node=el('button',text);node.type='button';node.className='secondary';if(id)node.dataset.calibrationAction=id;node.disabled=busy;node.addEventListener('click',action);return node;};
  const safeError=error=>typeof error?.message==='string'?error.message:'页面标记暂时不可用，请稍后重试。';
  async function request(message) { const response=await send(message);if(!response?.ok)throw Error(response?.error||'扩展后台未响应，请保留当前校准进度。');return response; }
  function stopTimer() { if(timer!==null){clearTimeout(timer);timer=null;} }
  async function cancelPick() {
    ++generation;stopTimer();const requestId=active?.requestId;active=null;pendingResult=null;busy=false;
    if(requestId) {try{await request({type:'PURCHASE_PICK_ABORT',requestId});}catch{failure='未能确认网页标记已取消。请返回网页按 Esc，再重新开始。';}}
  }
  function changed() { status='校准进度尚未保存；未完成的步骤不能开始购买。';failure=''; }
  function selectedIndex() {const candidates=plan.map((step,index)=>step.stage===phase?index:-1).filter(index=>index>=0);if(!candidates.includes(stepIndex))stepIndex=candidates[0]??-1;return candidates;}
  function currentFields() {return stepIndex<0?[]:calibrationFields(plan[stepIndex],stepIndex,plan,getConfig());}
  function acceptResult(field,result,allowNavigation=false) {plan[stepIndex]=applyCalibrationPick(plan[stepIndex],field,result,{confirmNavigation:allowNavigation});pendingResult=null;changed();status='已标记。请核对本项，再继续下一项。';render();}
  async function pollPick(expectedGeneration) {
    if(disposed||!active||generation!==expectedGeneration)return;
    try {
      const response=await request({type:'PURCHASE_PICK_STATUS',requestId:active.requestId});
      if(disposed||!active||generation!==expectedGeneration)return;
      if(response.status==='pending'){timer=setTimeout(()=>{void pollPick(expectedGeneration);},500);return;}
      const field=active.field;active=null;busy=false;
      if(response.status==='selected') {
        const result=response.result;selectorOf(result);
        if(field.isResult&&plan[stepIndex].path&&(result.origin!==(plan[stepIndex].origin??PURCHASE_ORIGIN)||result.path!==plan[stepIndex].path||JSON.stringify(result.query?{product:result.query.product,step:result.query.step}:{})!==JSON.stringify(plan[stepIndex].query?{product:plan[stepIndex].query.product,step:plan[stepIndex].query.step}:{}))) {pendingResult={field,result};status='结果位于另一个页面。请先明确确认页面关系。';render();}
        else acceptResult(field,result);
      } else if(response.status==='cancelled'){status='已取消本次网页标记。';render();}
      else throw Error(response.error||'网页标记已结束，请重新选择。');
    } catch(error) { if(generation!==expectedGeneration||disposed)return;active=null;busy=false;failure=safeError(error);render(); }
  }
  async function beginPick(field) {
    if(busy||disposed)return;busy=true;failure='';pendingResult=null;const attempt=++generation;
    // Keep the tab/permission callback in the original user-gesture turn.
    let target;
    try {target=getTargetTabId({kind:field.kind,fieldKey:field.fieldKey,stage:phase,stepIndex,expectedLocation:{origin:plan[stepIndex].origin??PURCHASE_ORIGIN,path:plan[stepIndex].path,...(plan[stepIndex].query?{query:clone(plan[stepIndex].query)}:{})},isResult:field.isResult===true});}
    catch(error){busy=false;failure=safeError(error);render();return;}
    render();
    try {
      const tabId=await target;
      if(disposed||attempt!==generation)return;
      if(!Number.isInteger(tabId)||tabId<0)throw Error('请明确选择一个 Apple 标签页。');
      const response=await request({type:'PURCHASE_PICK_BEGIN',tabId,kind:field.kind,...(field.fieldKey?{fieldKey:field.fieldKey}:{})});
      if(disposed||attempt!==generation){if(response.requestId)await request({type:'PURCHASE_PICK_ABORT',requestId:response.requestId});return;}
      if(typeof response.requestId!=='string'||!response.requestId)throw Error('网页标记没有启动，请重试。');
      active={requestId:response.requestId,field};status='请在 Apple 网页移动鼠标选择目标，并在标记浮层中确认。不会点击商家按钮。完成后回到这个设置页；按 Esc 可取消。';render();
      await pollPick(attempt);
    } catch(error){if(disposed||attempt!==generation)return;busy=false;failure=safeError(error);render();}
  }
  async function persist(complete) {
    if(busy||disposed)return;failure='';busy=true;const attempt=++generation;
    try {
      const config=publicConfig(getConfig());syncAddressKeys(plan,config);
      if(complete) {
        const validated=validatePurchase({...config,confirmedPurchase:true,steps:plan});
        render();await request({type:'PURCHASE_SAVE_PLAN',config:validated,confirmedCalibration:true});
        if(disposed||attempt!==generation)return;
        plan=clone(validated.steps);observedPlan=JSON.stringify(plan);onPlanChange(clone(plan));
        status='完整校准已保存。保存不会操作网页；开始购买时仍须重新确认本次授权。';
      } else {
        render();await request({type:'PURCHASE_SAVE_DRAFT',config,steps:boundedPlan(plan),confirmedCalibration:true});
        if(disposed||attempt!==generation)return;
        status='未完成的校准进度已保存在本机。它不能用于开始购买，也不包含个人地址。';
      }
    } catch(error){if(disposed||attempt!==generation)return;failure=safeError(error);}
    finally{if(!disposed&&attempt===generation){busy=false;render();}}
  }
  async function loadDraft() {
    if(busy||disposed)return;busy=true;failure='';const attempt=++generation;render();
    try {
      const response=await request({type:'PURCHASE_LOAD_DRAFT'});if(disposed||attempt!==generation)return;
      const draft=response.draft;if(!draft?.steps)throw Error('此浏览器没有未完成的校准进度。');
      const config=publicConfig(getConfig());
      for(const key of ['url','model','storage','color','addressMode'])if(draft.config?.[key]!==undefined&&draft.config[key]!==config[key])throw Error('保存的进度属于不同商品或地址模式。请先恢复相同购买目标，再载入。');
      plan=boundedPlan(draft.steps);phase=plan[0]?.stage??'add-to-bag';stepIndex=0;fieldIndex=0;status='已载入未完成进度。请继续逐项校准，完整检查后再保存可用流程。';
    }catch(error){if(!disposed&&attempt===generation)failure=safeError(error);}
    finally{if(!disposed&&attempt===generation){busy=false;render();}}
  }
  function render() {
    if(disposed)return;host.replaceChildren();
    host.append(el('p','一次只标记一项。标记只记录网页位置，不点击商家按钮、不输入地址，也不会创建订单。未知的后续页面请保留“待校准”。'));
    const phases=el('div');phases.className='row';
    for(const [key,label]of CALIBRATION_PHASES){const node=button(label,()=>{phase=key;fieldIndex=0;pendingResult=null;failure='';render();},`phase-${key}`);node.dataset.selected=String(key===phase);node.setAttribute?.('aria-pressed',String(key===phase));phases.append(node);}host.append(phases);
    const indices=selectedIndex();
    if(indices.length>1) {const steps=el('div');steps.className='row';indices.forEach((index,number)=>steps.append(button(`本阶段第 ${number+1} 步`,()=>{stepIndex=index;fieldIndex=0;pendingResult=null;render();},`step-${index}`)));host.append(steps);}
    if(phase==='configure')host.append(button('载入已观察的 Duo 颜色和容量',()=>{try{plan=[...createDuoSteps(getConfig()),...plan.filter(step=>step.stage!=='configure')];stepIndex=0;fieldIndex=0;changed();status='仅载入 Duo 规格选择。购物袋、地址、复核和订单结果仍须实际校准。';}catch(error){failure=safeError(error);}render();},'duo'));
    if(stepIndex<0) host.append(el('p','本阶段尚未添加步骤。已经手动选好规格时，可以从加入购物袋开始。'));
    else {
      const step=plan[stepIndex],card=el('section');card.className='calibration-card';
      if(step.adapter==='apple-duo') card.append(el('p',`已载入已观察的 Duo ${step.group==='dimensionColor'?'颜色':'容量'}选项。运行时仍会核对真实页面状态。`));
      else {
        if(phase==='configure') {const label=el('label','这一步选择什么？'),select=el('select');select.dataset.calibrationField='group';select.disabled=busy;for(const[key,title]of [['dimensionColor','颜色'],['dimensionCapacity','容量']]){const option=el('option',title);option.value=key;select.append(option);}select.value=step.group;select.addEventListener('change',()=>{plan[stepIndex]={...newCalibrationStep('configure',getConfig()),group:select.value};fieldIndex=0;changed();render();});label.append(select);card.append(label);}
        const fields=currentFields();fieldIndex=Math.max(0,Math.min(fieldIndex,fields.length-1));const field=fields[fieldIndex];
        if(field) {
          card.append(el('p',`本步骤第 ${fieldIndex+1} / ${fields.length} 项`),el('h3',field.label));
          if(field.help)card.append(el('p',field.help));
          if(field.type==='address-layout') {
            const label=el('label','网页上的姓名输入栏'),select=el('select');select.dataset.calibrationField='address-layout';select.disabled=busy;for(const[value,title]of [['full','姓名一个栏'],['split','姓和名分开']]){const option=el('option',title);option.value=value;select.append(option);}select.value=step.fields?.some(item=>item.key==='givenName')?'split':'full';
            const updateKeys=keys=>{step.fields=keys.map(key=>step.fields?.find(item=>item.key===key)??{key,autocomplete:ADDRESS_AUTOCOMPLETE[key]});syncAddressKeys(plan,getConfig());changed();render();};
            select.addEventListener('change',()=>updateKeys([...(select.value==='split'?['familyName','givenName']:['fullName']),...(step.fields??[]).map(item=>item.key).filter(key=>!['fullName','givenName','familyName'].includes(key))]));label.append(select);card.append(label);
            for(const key of ['postalCode','addressLine2','email']){const label=el('label',`网页还需要${ADDRESS_LABELS[key]}`),input=el('input');input.type='checkbox';input.checked=step.fields?.some(item=>item.key===key);input.disabled=busy;input.dataset.calibrationField=`optional-${key}`;input.addEventListener('change',()=>updateKeys(input.checked?[...step.fields.map(item=>item.key),key]:step.fields.map(item=>item.key).filter(item=>item!==key)));label.append(input);card.append(label);}
          } else {
            const marked=mapped(step,field);card.append(el('p',marked?'已标记':'待校准'));if(marked&&field.textPath&&!normalizePurchaseText(get(step,field.textPath)))card.append(el('p','位置已标记，还需填写网页上的公开原文。'));
            card.append(button(marked?'重新在网页上选取':'在网页上选取',()=>{void beginPick(field);},'pick'));
            if(field.textPath){const label=el('label','网页上的公开原文'),input=el('input');input.type='text';input.autocomplete='off';input.maxLength=500;input.value=get(step,field.textPath)??'';input.disabled=busy;input.dataset.calibrationField=field.textPath;input.placeholder='请按网页公开状态原文填写，不含个人信息';input.addEventListener('input',()=>{put(step,field.textPath,input.value);changed();});label.append(input);card.append(label);}
            if(pendingResult){card.append(el('p','你标记的结果来自不同页面。请确认它确实是本步骤动作后的结果，不是无关页面。'),button('确认这是本步骤的结果页面',()=>{try{acceptResult(pendingResult.field,pendingResult.result,true);}catch(error){failure=safeError(error);render();}},'confirm-route'),button('取消这个结果标记',()=>{pendingResult=null;status='未更改结果页面。';render();},'cancel-route'));}
            card.append(button('清除此项',()=>{if(field.id.startsWith('field.')){const item=step.fields.find(item=>item.key===field.fieldKey);delete item.selector;delete item.name;}else if(field.id==='target')step.target={role:step.kind,name:''};else{put(step,field.id.startsWith('evidence.')?field.id:`${field.id}.selector`,undefined);if(field.textPath)put(step,field.textPath,'');if(field.isResult){delete step.confirm.nextPath;delete step.confirm.nextOrigin;delete step.confirm.nextQuery;delete step.confirm.allowAuthHandoff;}}pendingResult=null;changed();render();},'clear-field'));
          }
          const navigation=el('div');navigation.className='row';const prev=button('上一项',()=>{fieldIndex--;pendingResult=null;render();},'previous');prev.disabled=busy||fieldIndex===0;
          const finalField=fieldIndex===fields.length-1;const next=button(finalField?(stepIndex<plan.length-1?'下一步骤':'检查并保存完整流程'):'下一项',()=>{pendingResult=null;if(!finalField){fieldIndex++;render();}else if(stepIndex<plan.length-1){stepIndex++;phase=plan[stepIndex].stage;fieldIndex=0;render();}else void persist(true);},'next');navigation.append(prev,next);card.append(navigation);
          const details=el('details');details.append(el('summary','高级：查看本步骤映射'));const raw=el('pre',JSON.stringify(step,null,2));details.append(raw);card.append(details);
        }
      }
      const actions=el('div');actions.className='row';actions.append(button('清除此步骤重新校准',()=>{plan[stepIndex]=newCalibrationStep(phase,getConfig());fieldIndex=0;pendingResult=null;changed();render();},'reset-step'),button('移除此步骤',()=>{plan.splice(stepIndex,1);stepIndex=-1;fieldIndex=0;changed();render();},'remove-step'));card.append(actions);host.append(card);
    }
    const additions=el('div');additions.className='row';
    const addStep=kind=>{if(plan.length>=16){failure='最多可校准 16 个步骤。';render();return;}const newStep=newCalibrationStep(phase,getConfig());if(kind==='button'){newStep.kind='button';newStep.target={role:'button',name:''};delete newStep.fields;}const order=PURCHASE_STAGES.indexOf(phase),position=plan.findIndex(step=>PURCHASE_STAGES.indexOf(step.stage)>order);stepIndex=position<0?plan.length:position;plan.splice(stepIndex,0,newStep);fieldIndex=0;changed();render();};
    additions.append(button('添加本阶段步骤',()=>addStep(), 'add-step'));if(phase==='address')additions.append(button('添加地址页继续按钮',()=>addStep('button'),'add-address-button'));host.append(additions);
    if(busy) {const cancel=button('取消网页标记',()=>{void cancelPick().then(()=>{status='已取消当前网页标记。';render();});},'cancel-pick');cancel.disabled=!active;host.append(cancel);}
    const save=el('div');save.className='row';save.append(button('保存未完成进度',()=>{void persist(false);},'save-draft'),button('载入未完成进度',()=>{void loadDraft();},'load-draft'),button('检查并保存完整流程',()=>{void persist(true);},'save-plan'));host.append(save);
    const summary=el('p',status||'所有后续阶段都需按实际网页逐项核验。完整流程通过检查后才能保存为可用配置。');summary.setAttribute?.('role','status');summary.dataset.calibrationStatus='true';host.append(summary);
    if(failure){const alert=el('p',failure);alert.setAttribute?.('role','alert');alert.dataset.calibrationError='true';host.append(alert);}
  }
  render();
  return {
    getPlan(){return clone(plan);},
    refresh(){
      if(disposed)return;
      const config=getConfig(),target=targetSignature(config),mode=config.addressMode;
      const targetChanged=target!==observedTarget,modeChanged=mode!==addressMode;
      if(busy&&!targetChanged&&!modeChanged)return;
      if(targetChanged||modeChanged)void cancelPick().then(()=>{if(!disposed)render();});
      const incoming=boundedPlan(getPlan()),signature=JSON.stringify(incoming);
      if(targetChanged){plan=PURCHASE_STAGES.slice(1).map(stage=>newCalibrationStep(stage,config));phase='add-to-bag';stepIndex=0;fieldIndex=0;observedTarget=target;observedPlan=signature;changed();status='购买目标已改变，旧的网页标记已清除。请为新目标重新校准。';}
      else if(signature!==observedPlan){plan=incoming.length?incoming:PURCHASE_STAGES.slice(1).map(stage=>newCalibrationStep(stage,config));observedPlan=signature;fieldIndex=0;pendingResult=null;}
      if(modeChanged){addressMode=mode;for(const step of plan){if(step.kind==='address'){if(mode==='new')step.fields=MIN_ADDRESS.map(key=>({key,autocomplete:ADDRESS_AUTOCOMPLETE[key]}));else delete step.fields;}if(step.addressConfirmation)step.addressConfirmation={selector:''};}syncAddressKeys(plan,config);if(!targetChanged)changed();}
      render();
    },
    async destroy(){if(disposed)return;disposed=true;await cancelPick();host.replaceChildren();},
  };
}
