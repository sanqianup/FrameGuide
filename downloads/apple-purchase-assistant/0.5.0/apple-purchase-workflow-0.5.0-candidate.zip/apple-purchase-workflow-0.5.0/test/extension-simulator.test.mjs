import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {setImmediate as nextTurn} from 'node:timers/promises';
import {DEFAULTS, Engine, TERMINAL} from '../extension/core.js';

// Node-only integration: the real simulator, DOM driver, and Engine run against a
// small deterministic DOM/Chrome model. This does not claim browser validation.
const simulatorSource = fs.readFileSync(new URL('../extension/simulator.js', import.meta.url), 'utf8');
const driverSource = fs.readFileSync(new URL('../extension/dom-driver.js', import.meta.url), 'utf8');
const fixtureHTML = fs.readFileSync(new URL('../extension/simulator.html', import.meta.url), 'utf8');

function makeDOM(location) {
  const observers = new Set();
  const listeners = new Map();
  const clicks = [];
  let document;

  function mutation(target, type, attributeName) {
    for (const observer of observers) {
      if (!observer.root || !(observer.root === target || observer.options.subtree && observer.root.contains(target))) continue;
      if (!observer.options[type]) continue;
      if (type === 'attributes' && observer.options.attributeFilter && !observer.options.attributeFilter.includes(attributeName)) continue;
      observer.records.push({target, type, attributeName});
      if (observer.queued) continue;
      observer.queued = true;
      queueMicrotask(() => {
        observer.queued = false;
        if (!observer.root || !observer.records.length) return;
        const records = observer.records.splice(0);
        observer.callback(records, observer);
      });
    }
  }

  class Element {
    constructor(tagName) {
      this.tagName = tagName.toUpperCase();
      this.nodeType = 1;
      this.ownerDocument = document;
      this.parentNode = null;
      this.children = [];
      this.attributes = new Map();
      this.listeners = new Map();
      this._text = '';
    }
    get parentElement() { return this.parentNode?.nodeType === 1 ? this.parentNode : null; }
    get id() { return this.getAttribute('id') || ''; }
    get isConnected() { return document.contains(this); }
    get textContent() { return this._text + this.children.map(child => child.textContent).join(''); }
    set textContent(value) {
      this._text = String(value);
      for (const child of this.children) child.parentNode = null;
      this.children = [];
      mutation(this, 'childList');
    }
    get innerText() { return this.textContent; }
    get disabled() { return this.hasAttribute('disabled'); }
    set disabled(value) { value ? this.setAttribute('disabled', '') : this.removeAttribute('disabled'); }
    get hidden() { return this.hasAttribute('hidden'); }
    get inert() { return this.hasAttribute('inert'); }
    getAttribute(name) { return this.attributes.has(name) ? this.attributes.get(name) : null; }
    hasAttribute(name) { return this.attributes.has(name); }
    setAttribute(name, value) { this.attributes.set(name, String(value)); mutation(this, 'attributes', name); }
    removeAttribute(name) {
      if (this.attributes.delete(name)) mutation(this, 'attributes', name);
    }
    append(...nodes) {
      for (const child of nodes) {
        child.parentNode = this;
        this.children.push(child);
      }
      mutation(this, 'childList');
    }
    contains(node) {
      for (let current = node; current; current = current.parentNode) if (current === this) return true;
      return false;
    }
    matches(selector) {
      return selector.split(',').some(part => {
        const value = part.trim();
        if (value === ':disabled') return this.disabled;
        if (value.startsWith('#')) return this.id === value.slice(1);
        const match = /^([\w-]+)?(?:\[([\w-]+)(?:=["']?([^\]"']+)["']?)?\])?$/.exec(value);
        if (!match) throw Error(`Unsupported mock selector: ${value}`);
        return (!match[1] || this.tagName.toLowerCase() === match[1].toLowerCase()) &&
          (!match[2] || (this.hasAttribute(match[2]) && (match[3] === undefined || this.getAttribute(match[2]) === match[3])));
      });
    }
    querySelectorAll(selector) {
      const results = [];
      const walk = node => {
        for (const child of node.children) {
          if (child.matches(selector)) results.push(child);
          walk(child);
        }
      };
      walk(this);
      return results;
    }
    querySelector(selector) { return this.querySelectorAll(selector)[0] || null; }
    getClientRects() { return this.isConnected ? [{}] : []; }
    addEventListener(type, callback) {
      if (!this.listeners.has(type)) this.listeners.set(type, []);
      this.listeners.get(type).push(callback);
    }
    click() {
      if (this.disabled || !this.isConnected) return;
      clicks.push(this);
      const event = {type: 'click', target: this};
      for (let current = this; current?.nodeType === 1; current = current.parentNode) {
        current.onclick?.(event);
        for (const callback of current.listeners.get('click') || []) callback(event);
      }
    }
  }

  class MockMutationObserver {
    constructor(callback) { this.callback = callback; this.root = null; this.records = []; this.queued = false; }
    observe(root, options) { this.root = root; this.options = options; observers.add(this); }
    disconnect() { this.root = null; this.records = []; observers.delete(this); }
  }

  document = {
    nodeType: 9, children: [], visibilityState: 'visible', location,
    contains: Element.prototype.contains,
    querySelectorAll: Element.prototype.querySelectorAll,
    querySelector: Element.prototype.querySelector,
    createElement: tagName => new Element(tagName),
    getElementById(id) { return this.querySelector(`#${id}`); },
    addEventListener(type, callback) { listeners.set(type, callback); },
    defaultView: {location, MutationObserver: MockMutationObserver, getComputedStyle: () => ({display: 'block', visibility: 'visible', opacity: '1'})},
  };

  // Preserve the shipped fixture's actual text, IDs and initial disabled state.
  // This deliberately small parser covers its current main element, not HTML generally.
  const main = document.createElement('main');
  main.parentNode = document;
  document.children.push(main);
  const stack = [main];
  const body = /<main(?:\s[^>]*)?>([\s\S]*?)<\/main>/.exec(fixtureHTML)?.[1];
  assert.ok(body, 'shipped simulator fixture has a main element');
  for (const token of body.matchAll(/<\/?([\w-]+)([^>]*)>|([^<]+)/g)) {
    if (token[3] !== undefined) {
      stack.at(-1)._text += token[3];
    } else if (token[0].startsWith('</')) {
      assert.equal(stack.at(-1).tagName.toLowerCase(), token[1]);
      stack.pop();
    } else {
      const element = document.createElement(token[1]);
      for (const attribute of token[2].matchAll(/([^\s=]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s]+)))?/g)) {
        element.setAttribute(attribute[1], attribute[2] ?? attribute[3] ?? attribute[4] ?? '');
      }
      stack.at(-1).append(element);
      stack.push(element);
    }
  }
  assert.equal(stack.length, 1);
  return {document, main, clicks, observers, MutationObserver: MockMutationObserver};
}

async function harness({scenario = 'normal', countdownMs = 3000, deferStatus = false} = {}) {
  const id = 'a'.repeat(32);
  const taskId = 'local-simulator-task';
  const location = {href: `chrome-extension://${id}/simulator.html?task=${taskId}`, origin: `chrome-extension://${id}`, pathname: '/simulator.html'};
  const dom = makeDOM(location);
  let now = Date.parse('2026-10-16T01:00:00Z');
  const config = {...DEFAULTS, mode: 'simulate', scenario, storage: 'TEST-256', color: 'TEST-WHITE',
    maxTotal: '200.00', targetTime: new Date(now + countdownMs).toISOString(), expiresAt: new Date(now + 180000).toISOString()};
  const engine = new Engine(config);
  const messages = [];
  const timers = new Map();
  let timerId = 0;
  let messageListener;
  let statusResolve;
  const task = () => ({id: taskId, state: engine.state, reason: engine.reason});
  const runtime = {
    id,
    getURL: path => `chrome-extension://${id}/${path}`,
    onMessage: {addListener: callback => { messageListener = callback; }},
    async sendMessage(message) {
      messages.push(structuredClone(message));
      assert.equal(message.taskId, taskId);
      assert.equal(message.tabId, 42);
      assert.equal(message.documentNonce, 'fixture-document-nonce');
      if (message.type === 'SIM_CONFIG') return {ok: true, config};
      if (message.type === 'STATUS') {
        const response = {ok: true, task: task()};
        if (deferStatus) return new Promise(resolve => { statusResolve = () => resolve(response); });
        return response;
      }
      if (message.type === 'STOP') {
        if (engine.state === 'SUBMITTING') engine.result('unknown');
        else engine.stop();
        return {ok: true, task: task()};
      }
      if (TERMINAL.has(engine.state)) return {ok: false, error: '任务已结束或不匹配'};
      if (message.type === 'OBSERVE') {
        const action = engine.observe(message.snapshot, now);
        return {ok: true, state: engine.state, reason: engine.reason, action: action.type};
      }
      if (message.type === 'MOCK_RESULT') {
        engine.result(message.outcome);
        return {ok: true, state: engine.state, reason: engine.reason};
      }
      if (message.type === 'DISCONNECT') {
        if (engine.state === 'SUBMITTING') engine.result('unknown');
        else engine.pause('页面离开、隐藏或运行中断，需要重新预检');
        return {ok: true, task: task()};
      }
      throw Error(`Unexpected mocked Chrome message: ${message.type}`);
    },
  };
  const context = vm.createContext({
    URL, document: dom.document, location, TERMINAL,
    Date: class extends Date { static now() { return now; } },
    crypto: {randomUUID: () => 'fixture-document-nonce'},
    chrome: {runtime, tabs: {getCurrent: async () => ({id: 42})}},
    MutationObserver: dom.MutationObserver, queueMicrotask,
    setTimeout(callback, delay) { const key = ++timerId; timers.set(key, {at: now + delay, callback}); return key; },
    clearTimeout: key => timers.delete(key),
    addEventListener() {},
    fetch() { throw Error('Network access is forbidden in simulator integration tests'); },
    XMLHttpRequest: class { constructor() { throw Error('Network access is forbidden in simulator integration tests'); } },
  });
  vm.runInContext(driverSource, context, {filename: 'extension/dom-driver.js'});
  assert.equal(typeof context.AppleDOMDriver?.clickLocalFixture, 'function');
  const ready = vm.runInContext(`(async () => {\n${simulatorSource.replace(/^import[^\n]*\n/gm, '')}\n})()`, context, {filename: 'extension/simulator.js'});
  await ready;
  const settle = () => nextTurn();
  await settle();

  async function advance(ms) {
    const end = now + ms;
    for (let count = 0; ; count += 1) {
      assert.ok(count < 1000, 'fake timer loop must make progress');
      const due = [...timers].filter(([, timer]) => timer.at <= end).sort((a, b) => a[1].at - b[1].at)[0];
      if (!due) break;
      now = due[1].at;
      timers.delete(due[0]);
      due[1].callback();
      await settle();
    }
    now = end;
    await settle();
  }

  return {
    ...dom, engine, messages, timers, advance, settle,
    button: dom.document.querySelector('#mock'),
    state: dom.document.querySelector('#state'),
    result: dom.document.querySelector('#result'),
    clock: dom.document.querySelector('#clock'),
    statusPending: () => !!statusResolve,
    resolveStatus() { assert.ok(statusResolve, 'STATUS response is pending'); statusResolve(); },
    async stop() { await dom.document.querySelector('#stop').onclick(); await settle(); },
    halt(reason = '任务已停止') { messageListener({type: 'HALT', taskId, reason}, {id}, () => {}); },
    mutate(count = 30) { for (let i = 0; i < count; i += 1) dom.main.setAttribute('class', `mutation-${i}`); },
  };
}

test('simulator counts down from shipped disabled fixture to exactly one confirmed local click', async () => {
  const h = await harness();
  assert.equal(h.engine.state, 'WAITING');
  assert.equal(h.button.disabled, true);
  assert.equal(h.clock.textContent, '00:03');
  assert.equal(h.clicks.length, 0);
  await h.advance(2000);
  assert.equal(h.engine.state, 'WAITING');
  assert.equal(h.clock.textContent, '00:01');
  assert.equal(h.clicks.length, 0);
  await h.advance(1000);
  assert.equal(h.engine.state, 'DONE');
  assert.deepEqual(h.clicks, [h.button]);
  assert.match(h.result.textContent, /模拟订单已确认/);
  assert.equal(h.messages.filter(message => message.type === 'MOCK_RESULT').length, 1);
  assert.equal(h.messages.find(message => message.type === 'MOCK_RESULT').outcome, 'confirmed');
  assert.equal(h.button.disabled, true);
  assert.equal(h.timers.size, 0);
  assert.equal(h.observers.size, 0);
});

test('simulator coalesces repeated mutations and cannot double-click after completion', async () => {
  const h = await harness({countdownMs: 1000});
  const before = h.messages.filter(message => message.type === 'OBSERVE').length;
  h.mutate(100);
  await h.settle();
  assert.equal(h.messages.filter(message => message.type === 'OBSERVE').length, before);
  await h.advance(1000);
  assert.equal(h.engine.state, 'DONE');
  const completedCount = h.messages.length;
  h.mutate(100);
  await h.advance(10000);
  assert.equal(h.clicks.length, 1);
  assert.equal(h.messages.length, completedCount);
  assert.equal(h.timers.size, 0);
});

test('unknown local response locks the attempt without retrying on mutations or elapsed time', async () => {
  const h = await harness({scenario: 'unknown', countdownMs: 1000});
  await h.advance(1000);
  assert.equal(h.engine.state, 'UNKNOWN');
  assert.equal(h.clicks.length, 1);
  assert.match(h.result.textContent, /模拟响应未知/);
  assert.equal(h.messages.find(message => message.type === 'MOCK_RESULT').outcome, 'unknown');
  const completedCount = h.messages.length;
  h.mutate(100);
  await h.advance(60000);
  assert.equal(h.clicks.length, 1);
  assert.equal(h.messages.length, completedCount);
  assert.equal(h.timers.size, 0);
});

test('stopping before asynchronous STATUS resolves prevents the already-claimed local click', async () => {
  const h = await harness({countdownMs: 1000, deferStatus: true});
  await h.advance(1000);
  assert.equal(h.engine.state, 'SUBMITTING');
  assert.equal(h.statusPending(), true);
  assert.equal(h.clicks.length, 0);
  await h.stop();
  assert.equal(h.engine.state, 'UNKNOWN');
  h.resolveStatus();
  await h.settle();
  h.mutate(100);
  await h.advance(10000);
  assert.equal(h.clicks.length, 0);
  assert.equal(h.messages.filter(message => message.type === 'MOCK_RESULT').length, 0);
  assert.equal(h.button.disabled, true);
  assert.equal(h.timers.size, 0);
  assert.equal(h.observers.size, 0);
});

test('payment and specification mismatch scenarios pause before any local click', async t => {
  for (const [scenario, reason] of [['payment', /付款方式/], ['mismatch', /color/]]) {
    await t.test(scenario, async () => {
      const h = await harness({scenario, countdownMs: 1000});
      assert.equal(h.engine.state, 'PAUSED');
      assert.match(h.state.textContent, reason);
      h.mutate(100);
      await h.advance(10000);
      assert.equal(h.clicks.length, 0);
      assert.equal(h.messages.filter(message => message.type === 'STATUS' || message.type === 'MOCK_RESULT').length, 0);
      assert.equal(h.button.disabled, true);
      assert.equal(h.timers.size, 0);
      assert.equal(h.observers.size, 0);
    });
  }
});
