import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {DEFAULTS, validate, TERMINAL} from '../extension/core.js';
import {validateAssist} from '../extension/assist-config.js';

// Node-only controller integration, using the shipped popup script and form
// names. These deterministic DOM/Chrome mocks are not browser acceptance tests.
const source = fs.readFileSync(new URL('../extension/popup.js', import.meta.url), 'utf8');
const html = fs.readFileSync(new URL('../extension/popup.html', import.meta.url), 'utf8');

function element(tagName) {
  return {
    tagName: tagName.toUpperCase(), name: '', value: '', textContent: '', disabled: false,
    children: [], listeners: new Map(),
    append(...children) { this.children.push(...children); },
    replaceChildren(...children) { this.children = children; },
    addEventListener(type, callback) { this.listeners.set(type, callback); },
  };
}

function makeDOM() {
  const form = element('form');
  form.elements = [];
  const addControl = control => {
    form.elements.push(control);
    form.elements[control.name] = control;
  };
  const nodes = new Map([['form', form], ['fieldset', element('fieldset')]]);
  for (const match of html.matchAll(/<([\w-]+)\b([^>]*\bid="([^"]+)"[^>]*)>/g)) {
    const node = match[1] === 'form' ? form : match[1] === 'fieldset' ? nodes.get('fieldset') : element(match[1]);
    node.disabled = /\bdisabled\b/.test(match[2]);
    nodes.set(`#${match[3]}`, node);
  }
  for (const match of html.matchAll(/<(input|select)\b[^>]*\bname="([^"]+)"[^>]*>/g)) {
    const control = element(match[1]);
    control.name = match[2];
    addControl(control);
  }
  assert.ok(form.elements.mode, 'the shipped form contains its mode control');
  const selectors = nodes.get('#selectors');
  assert.ok(selectors, 'the shipped form has the selector container');
  selectors.append = function (...labels) {
    this.children.push(...labels);
    for (const label of labels) for (const child of label.children) if (child.name) addControl(child);
  };
  const documentListeners = new Map();
  const document = {
    querySelector: selector => nodes.get(selector) || null,
    createElement: element,
    addEventListener: (type, callback) => documentListeners.set(type, callback),
  };
  return {document, form, nodes, documentListeners};
}

const settings = (overrides = {}) => ({...DEFAULTS, storage: 'TEST-256', color: 'TEST-WHITE', maxTotal: 200, ...overrides});
const task = (overrides = {}) => ({id: 'background-owned-task', state: 'WAITING', reason: '等待倒计时结束', remainingMs: 3100,
  source: '页面可见倒计时', events: [{time: 0, message: '仅本地模拟任务，无真实交易'}], ...overrides});

function background({config = settings(), currentTask = task()} = {}) {
  return {
    settings: structuredClone(config), task: structuredClone(currentTask), statusFailure: null,
    async send(message) {
      if (message.type === 'STATUS') {
        if (this.statusFailure instanceof Error) throw this.statusFailure;
        if (this.statusFailure) return this.statusFailure;
        return {ok: true, settings: this.settings, task: this.task};
      }
      if (message.type === 'STOP') {
        if (this.task && !TERMINAL.has(this.task.state)) this.task = {...this.task,
          state: this.task.state === 'SUBMITTING' ? 'UNKNOWN' : 'STOPPED', reason: '用户已停止，不会自动恢复'};
        return {ok: true, task: this.task};
      }
      if (message.type === 'START') {
        this.settings = structuredClone(message.config);
        this.task = task({state: 'READY', remainingMs: null});
        return {ok: true, task: this.task};
      }
      throw Error(`Unexpected popup message: ${message.type}`);
    },
  };
}

async function harness(backend = background(), {grantPermission = true, launcherTabs = [], openWait = null, openFailure = false} = {}) {
  const dom = makeDOM();
  const messages = [], permissionRequests = [], tabQueries = [], tabActions = [], timers = new Map(), listeners = new Map();
  let nextTimer = 0, closed = false;
  const chrome = {
    runtime: {getURL:path => `chrome-extension://test/${path}`,async sendMessage(message) {
      assert.equal(closed, false, 'a closed popup must not send messages');
      messages.push(structuredClone(message));
      return structuredClone(await backend.send(message));
    }},
    permissions: {async request(value) { permissionRequests.push(structuredClone(value)); return grantPermission; }},
    tabs: {async query(value) { tabQueries.push(structuredClone(value)); return value.url?.startsWith('chrome-extension:') ? launcherTabs : [{id: 42}]; }, async create(value) { tabActions.push(['create',structuredClone(value)]); if (openWait) await openWait; if (openFailure) throw Error('failed'); return {id:9,...value}; },async update(id,value) { tabActions.push(['update',id,structuredClone(value)]); return {id,...value}; }},
  };
  const context = vm.createContext({
    ...dom, chrome, DEFAULTS, validate, validateAssist, TERMINAL, URL,
    setInterval(callback, delay) { const id = ++nextTimer; timers.set(id, {callback, delay}); return id; },
    clearInterval: id => timers.delete(id),
    setTimeout() { throw Error('The popup must not own the task execution timer'); },
    addEventListener: (type, callback) => listeners.set(type, callback),
    fetch() { throw Error('Network access is forbidden in popup integration tests'); },
    XMLHttpRequest: class { constructor() { throw Error('Network access is forbidden in popup integration tests'); } },
  });
  context.window = context;
  await vm.runInContext(`(async () => {\n${source.replace(/^import[^\n]*\n/gm, '')}\n})()`, context,
    {filename: 'extension/popup.js'});
  const node = selector => {
    const result = dom.nodes.get(selector);
    assert.ok(result, `shipped popup contains ${selector}`);
    return result;
  };
  return {
    ...dom, backend, messages, timers, permissionRequests, tabQueries, tabActions, node,
    async poll() { for (const {callback} of [...timers.values()]) await callback(); },
    async submit() {
      let prevented = false;
      await dom.form.onsubmit({preventDefault() { prevented = true; }});
      assert.equal(prevented, true);
    },
    stop: () => node('#stop').onclick(),
    close() {
      for (const type of ['pagehide', 'beforeunload', 'unload']) {
        listeners.get(type)?.({type});
        dom.documentListeners.get(type)?.({type});
      }
      closed = true;
      timers.clear(); // Browser destruction removes only this popup's refresh timer.
    },
  };
}

function assertLocked(h, {stopEnabled = false} = {}) {
  for (const selector of ['fieldset', '#start', '#demo']) assert.equal(h.node(selector).disabled, true, selector);
  assert.equal(h.node('#stop').disabled, !stopEnabled);
}

test('popup restores persisted settings, selectors, active status and logs without starting work', async () => {
  const config = settings({mode: 'official-readonly', quantity: 2, maxTotal: 345.67,
    selectors: {...DEFAULTS.selectors, countdown: '#sale-clock', button: '[data-buy]'}});
  const h = await harness(background({config, currentTask: task({remainingMs: 3661001})}));
  for (const key of ['mode', 'model', 'storage', 'color', 'quantity', 'maxTotal', 'targetTime', 'expiresAt', 'timeZone']) {
    assert.equal(h.form.elements[key].value, String(config[key]), key);
  }
  assert.equal(h.form.elements.selector_countdown.value, '#sale-clock');
  assert.equal(h.form.elements.selector_button.value, '[data-buy]');
  assert.equal(h.node('#start').textContent, '开始只读预演');
  assert.equal(h.node('#state').textContent, '等待开售');
  assert.equal(h.node('#clock').textContent, '01:01:02');
  assert.equal(h.node('#reason').textContent, '等待倒计时结束');
  assert.equal(h.node('#source').textContent, '页面可见倒计时');
  assert.equal(h.node('#events').children.length, 1);
  assert.match(h.node('#events').children[0].textContent, /仅本地模拟任务，无真实交易/);
  assertLocked(h, {stopEnabled: true});
  assert.deepEqual(h.messages, [{type: 'STATUS'}]);
  assert.equal(h.permissionRequests.length, 0);
  assert.equal(h.tabQueries.length, 0);
});

test('popup refresh only reads background status and does not infer countdown progress', async () => {
  const h = await harness();
  assert.equal(h.timers.size, 1);
  assert.equal([...h.timers.values()][0].delay, 1000);
  assert.equal(h.node('#clock').textContent, '00:00:04');
  await h.poll();
  assert.equal(h.node('#clock').textContent, '00:00:04', 'background remains the source of countdown truth');
  h.backend.task.remainingMs = 900;
  await h.poll();
  assert.equal(h.node('#clock').textContent, '00:00:01');
  assert.ok(h.messages.every(message => message.type === 'STATUS'));
});

test('closing popup never stops a task; reopening reflects independently progressed task and settings', async () => {
  const backend = background();
  const first = await harness(backend);
  const beforeClose = structuredClone(backend.task);
  first.close();
  assert.deepEqual(backend.task, beforeClose);
  assert.deepEqual(first.messages, [{type: 'STATUS'}]);
  assert.equal(first.timers.size, 0);
  backend.task = task({state: 'DONE', reason: '模拟成功，没有真实订单', remainingMs: 0});
  const reopened = await harness(backend);
  assert.equal(reopened.node('#state').textContent, '已完成');
  assert.equal(reopened.node('#clock').textContent, '00:00:00');
  assert.equal(reopened.form.elements.storage.value, backend.settings.storage);
  assert.equal(reopened.node('#start').disabled, false);
  assert.equal(reopened.node('#stop').disabled, true);
  assert.deepEqual(reopened.messages, [{type: 'STATUS'}]);
});

test('STOP is explicitly sent to background and terminal state survives reopening', async () => {
  const h = await harness();
  assert.equal(h.node('#stop').disabled, false);
  await h.stop();
  assert.deepEqual(h.messages, [{type: 'STATUS'}, {type: 'STOP'}]);
  assert.equal(h.backend.task.state, 'STOPPED');
  assert.equal(h.node('#state').textContent, '已停止');
  assert.equal(h.node('#start').disabled, false);
  assert.equal(h.node('#stop').disabled, true);
  h.close();
  const reopened = await harness(h.backend);
  assert.equal(reopened.node('#state').textContent, '已停止');
  assert.deepEqual(reopened.messages, [{type: 'STATUS'}]);
});

test('STOP during submitting renders the background UNKNOWN result without retry', async () => {
  const h = await harness(background({currentTask: task({state: 'SUBMITTING'})}));
  await h.stop();
  assert.equal(h.node('#state').textContent, '结果未知 · 已锁定');
  assert.equal(h.node('#stop').disabled, true);
  await h.poll();
  assert.deepEqual(h.messages.map(message => message.type), ['STATUS', 'STOP', 'STATUS']);
});

test('initial missing, rejected and failed STATUS responses lock all task controls', async () => {
  for (const response of [undefined, {ok: false, error: 'offline'}, new Error('disconnected')]) {
    const backend = {async send() { if (response instanceof Error) throw response; return response; }};
    const h = await harness(backend);
    assertLocked(h);
    assert.match(h.node('#error').textContent, /无法连接扩展后台/);
    assert.equal(h.timers.size, 0);
    assert.deepEqual(h.messages, [{type: 'STATUS'}]);
  }
});

test('polling STATUS failure disables controls without sending STOP, START or assuming completion', async () => {
  for (const failure of [new Error('connection lost'), {ok: false, error: 'worker unavailable'}]) {
    const h = await harness();
    h.backend.statusFailure = failure;
    await h.poll();
    assertLocked(h);
    assert.match(h.node('#error').textContent, /后台不可用.*不会自动恢复/);
    assert.equal(h.backend.task.state, 'WAITING');
    assert.equal(h.node('#state').textContent, '等待开售');
    assert.deepEqual(h.messages.map(message => message.type), ['STATUS', 'STATUS']);
  }
});

test('successful polling recovery clears its stale connection error and renders current task', async () => {
  const h = await harness();
  h.backend.statusFailure = new Error('temporary disconnect');
  await h.poll();
  assert.match(h.node('#error').textContent, /后台不可用/);
  assertLocked(h);
  h.backend.statusFailure = null;
  h.backend.task = task({state: 'DONE', reason: '模拟成功，没有真实订单', remainingMs: 0});
  await h.poll();
  assert.equal(h.node('#error').textContent, '');
  assert.equal(h.node('#state').textContent, '已完成');
  assert.equal(h.node('#start').disabled, false);
  assert.equal(h.node('#stop').disabled, true);
  assert.deepEqual(h.messages.map(message => message.type), ['STATUS', 'STATUS', 'STATUS']);
});

test('successful STATUS refresh preserves unrelated form validation and START errors', async () => {
  const h = await harness(background({config: null, currentTask: null}));
  await h.submit();
  const validationError = h.node('#error').textContent;
  assert.match(validationError, /请填写/);
  await h.poll();
  assert.equal(h.node('#error').textContent, validationError);
  h.node('#demo').onclick();
  const original = h.backend.send;
  h.backend.send = function (message) {
    return message.type === 'START' ? {ok: false, error: '无法启动任务页面，任务已暂停'} : original.call(this, message);
  };
  await h.submit();
  assert.equal(h.node('#error').textContent, '无法启动任务页面，任务已暂停');
  await h.poll();
  assert.equal(h.node('#error').textContent, '无法启动任务页面，任务已暂停');
});

test('a failed STOP displays its error and never pretends the active task has stopped', async () => {
  const backend = background();
  const original = backend.send;
  backend.send = function (message) {
    return message.type === 'STOP' ? {ok: false, error: '停止请求未确认'} : original.call(this, message);
  };
  const h = await harness(backend);
  await h.stop();
  assert.equal(h.node('#state').textContent, '等待开售');
  assert.equal(backend.task.state, 'WAITING');
  assert.equal(h.node('#error').textContent, '停止请求未确认');
  assertLocked(h, {stopEnabled: true});
});

test('idle popup loads defaults and simulation START uses validated numeric form settings', async () => {
  const h = await harness(background({config: null, currentTask: null}));
  assert.equal(h.form.elements.mode.value, 'simulate');
  assert.equal(h.node('#state').textContent, '尚未启动');
  assert.equal(h.node('#start').disabled, false);
  assert.equal(h.node('#stop').disabled, true);
  h.node('#demo').onclick();
  await h.submit();
  const start = h.messages.find(message => message.type === 'START');
  assert.ok(start);
  assert.equal(start.config.mode, 'simulate');
  for (const key of ['quantity', 'maxTotal', 'pollMs', 'countdownSeconds']) assert.equal(typeof start.config[key], 'number');
  assert.equal(start.config.maxTotal, 200);
  assert.equal(start.config.storage, '模拟容量（虚构）');
  assert.equal(start.tabId, undefined);
  assert.deepEqual(h.messages.map(message => message.type), ['STATUS', 'START', 'STATUS']);
  assert.equal(h.permissionRequests.length, 0);
  assert.equal(h.tabQueries.length, 0);
  assertLocked(h, {stopEnabled: true});
});

test('invalid popup configuration fails before START or site permission request', async () => {
  const h = await harness(background({config: null, currentTask: null}));
  await h.submit();
  assert.match(h.node('#error').textContent, /请填写/);
  assert.deepEqual(h.messages, [{type: 'STATUS'}]);
  assert.equal(h.permissionRequests.length, 0);
});

test('readonly START requests only the configured origin and wires the active tab', async () => {
  const config = settings({mode: 'official-readonly', targetTime: new Date(Date.now() + 60000).toISOString(),
    expiresAt: new Date(Date.now() + 120000).toISOString()});
  const h = await harness(background({config, currentTask: null}));
  assert.equal(h.permissionRequests.length, 0, 'opening the popup must not request site permission');
  await h.submit();
  assert.deepEqual(h.permissionRequests, [{origins: ['https://www.apple.com.cn/*']}]);
  assert.deepEqual(h.tabQueries, [{active: true, currentWindow: true}]);
  assert.equal(h.messages.find(message => message.type === 'START').tabId, 42);
});

test('denied readonly permission never sends START or queries tabs', async () => {
  const config = settings({mode: 'official-readonly', targetTime: new Date(Date.now() + 60000).toISOString(),
    expiresAt: new Date(Date.now() + 120000).toISOString()});
  const h = await harness(background({config, currentTask: null}), {grantPermission: false});
  await h.submit();
  assert.match(h.node('#error').textContent, /站点权限未授权，任务未启动/);
  assert.deepEqual(h.messages.map(message => message.type), ['STATUS', 'STATUS']);
  assert.equal(h.tabQueries.length, 0);
  assert.equal(h.node('#start').disabled, false);
  assert.equal(h.node('#stop').disabled, true);
});


test('default popup has one main entry and keeps every expert control inside closed advanced tools', () => {
  const advanced = html.indexOf('<details id="legacy-tools">');
  assert.ok(advanced > 0);
  const normal = html.slice(0,advanced);
  assert.equal([...normal.matchAll(/<button\b/g)].length,1);
  assert.match(normal,/id="open-purchase"/);
  assert.doesNotMatch(normal,/<(?:form|input|textarea|select)\b/);
  assert.ok(html.indexOf('<form') > advanced);
  assert.doesNotMatch(html,/<details id="legacy-tools"[^>]*\bopen\b/);
});

test('main popup entry opens only the extension purchase UI without starting or requesting site access', async () => {
  const h = await harness(background({config:null,currentTask:null}));
  await h.node('#open-purchase').onclick();
  assert.deepEqual(h.tabActions,[['create',{url:'chrome-extension://test/purchase.html',active:true}]]);
  assert.deepEqual(h.messages,[{type:'STATUS'}]);
  assert.equal(h.permissionRequests.length,0);
});

test('main entry reuses its existing settings tab and blocks double clicks during opening', async () => {
  const h = await harness(background({config:null,currentTask:null}),{launcherTabs:[{id:12,url:'chrome-extension://test/purchase.html'}]});
  await h.node('#open-purchase').onclick();
  assert.deepEqual(h.tabActions,[['update',12,{active:true}]]);
  let release; const openWait = new Promise(resolve => {release=resolve;});
  const pending = await harness(background({config:null,currentTask:null}),{openWait});
  const first = pending.node('#open-purchase').onclick();
  await Promise.resolve(); await pending.node('#open-purchase').onclick();
  release(); await first;
  assert.equal(pending.tabActions.length,1);
  assert.equal(pending.node('#open-purchase').disabled,false);
});

test('launcher error is visible outside advanced tools and does not start any task', async () => {
  const h = await harness(background({config:null,currentTask:null}),{openFailure:true});
  await h.node('#open-purchase').onclick();
  assert.match(h.node('#launcher-status').textContent,/无法打开/);
  assert.deepEqual(h.messages,[{type:'STATUS'}]);
  assert.equal(h.node('#open-purchase').disabled,false);
});
