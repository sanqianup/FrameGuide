import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

const source = fs.readFileSync(new URL('../extension/purchase-picker.js', import.meta.url), 'utf8');
class Events {
  constructor() { this.events = new Map(); }
  addEventListener(type, fn) { if (!this.events.has(type)) this.events.set(type, new Set()); this.events.get(type).add(fn); }
  removeEventListener(type, fn) { this.events.get(type)?.delete(fn); }
  emit(type, details = {}) {
    const event = { type, isTrusted: true, key: '', target: null, defaultPrevented: false, stopped: false,
      preventDefault() { this.defaultPrevented = true; }, stopImmediatePropagation() { this.stopped = true; }, ...details };
    for (const fn of [...(this.events.get(type) ?? [])]) { fn(event); if (event.stopped) break; }
    return event;
  }
  count() { return [...this.events.values()].reduce((sum, set) => sum + set.size, 0); }
}
class Element extends Events {
  constructor(doc, tag, attrs = {}, text = '') {
    super(); this.ownerDocument = doc; this.tagName = tag.toUpperCase(); this.nodeType = 1; this.attributes = new Map(Object.entries(attrs)); this.ownText = text; this.children = []; this.parentElement = null;
    this.style = { setProperty(key, value, priority) { assert.equal(priority, 'important'); this[key.replace(/-([a-z])/gu, (_, letter) => letter.toUpperCase())] = value; } }; this.hidden = false; this.disabled = false; this.clicks = 0; this.readText = 0;
    Object.defineProperty(this, 'value', { get() { assert.fail('Picker must never read values'); }, set() { assert.fail('Picker must never write values'); } });
  }
  get isConnected() { return this.ownerDocument.documentElement?.contains(this) ?? false; }
  get textContent() { this.readText++; if (this.forbidText || /^(?:INPUT|TEXTAREA|SELECT|OPTION)$/u.test(this.tagName)) assert.fail('Private/control text must not be read'); return this.ownText + this.children.map(child => child.textContent).join(''); }
  set textContent(text) { this.ownText = String(text); this.children = []; }
  getAttribute(key) { assert.notEqual(key, 'value', 'Value attributes must never be read'); return this.attributes.get(key) ?? null; }
  hasAttribute(key) { return this.attributes.has(key); }
  setAttribute(key, value) { assert.notEqual(key, 'value'); this.attributes.set(key, String(value)); }
  append(...nodes) { for (const node of nodes) { node.remove(); node.parentElement = this; this.children.push(node); } }
  remove() { if (this.parentElement) this.parentElement.children = this.parentElement.children.filter(node => node !== this); this.parentElement = null; }
  contains(node) { return node === this || this.children.some(child => child.contains(node)); }
  attachShadow(options) { assert.equal(options.mode, 'closed'); this.testShadow = new Element(this.ownerDocument, 'shadow-root'); return this.testShadow; }
  matches(selector) {
    if (selector.includes(',')) return selector.split(',').some(part => this.matches(part.trim()));
    const chain = selector.split(/\s*>\s*/u);
    if (chain.length > 1) return this.matches(chain.at(-1)) && !!this.parentElement?.matches(chain.slice(0, -1).join(' > '));
    if (selector === '*') return true;
    if (/^#[\w-]+$/u.test(selector)) return this.getAttribute('id') === selector.slice(1);
    const match = /^(\w+)?(?:\[([\w-]+)(?:="([^"]*)")?\])?$/u.exec(selector);
    if (!match) throw Error('Unsupported fake selector: ' + selector);
    return (!match[1] || this.tagName.toLowerCase() === match[1]) && (!match[2] || this.hasAttribute(match[2]) && (match[3] === undefined || this.getAttribute(match[2]) === match[3]));
  }
  querySelectorAll(selector) { return this.children.flatMap(child => [...(child.matches(selector) ? [child] : []), ...child.querySelectorAll(selector)]); }
  getClientRects() { return this.isConnected && !this.hidden && this.style.display !== 'none' ? [this.getBoundingClientRect()] : []; }
  getBoundingClientRect() { return { left: 100, top: 100, width: 200, height: 40 }; }
  click() { this.clicks++; assert.fail('Picker must never click merchant controls'); }
  focus() { assert.fail('Picker must never focus merchant controls'); }
}
function harness({ href = 'https://www.apple.com.cn/shop/bag', iframe = false, sender = { id: 'extension-id' } } = {}) {
  const events = new Events(), document = new Events(), sent = [], timers = new Map(); let listener, timer = 0, pointed;
  document.visibilityState = 'visible';
  document.createElement = tag => new Element(document, tag);
  document.documentElement = document.createElement('html'); document.body = document.createElement('body'); document.documentElement.append(document.body);
  document.querySelectorAll = selector => [...(document.documentElement.matches(selector) ? [document.documentElement] : []), ...document.documentElement.querySelectorAll(selector)];
  document.elementFromPoint = () => { assert.equal(host()?.style.pointerEvents, 'none', 'Hit-test must go through the full-screen shield'); return pointed; };
  for (const key of ['cookie']) Object.defineProperty(document, key, { get() { assert.fail('No cookies'); } });
  const context = { URL, document, location: { href }, getComputedStyle: node => ({ display: 'block', visibility: 'visible', opacity: '1', ...node.style }),
    addEventListener: events.addEventListener.bind(events), removeEventListener: events.removeEventListener.bind(events),
    setTimeout(fn, ms) { timers.set(++timer, { fn, ms }); return timer; }, clearTimeout(id) { timers.delete(id); },
    MutationObserver: class { constructor() { assert.fail('No mutation-observer loops'); } }, fetch() { assert.fail('No network'); },
    localStorage: new Proxy({}, { get() { assert.fail('No persistence'); } }),
    chrome: { runtime: { id: 'extension-id', onMessage: { addListener(fn) { assert.equal(listener, undefined); listener = fn; } }, sendMessage(message) { sent.push(JSON.parse(JSON.stringify(message))); return Promise.resolve({ ok: true }); } } }
  };
  context.self = context; context.top = iframe ? {} : context;
  vm.createContext(context); vm.runInContext(source, context);
  function host() { return document.documentElement.children.find(node => node.hasAttribute('data-apple-purchase-picker')); }
  const ui = text => host()?.testShadow.querySelectorAll('*').find(node => node.ownText === text);
  const start = (kind = 'action', fieldKey, requestId = 'request-one') => deliver({ type: 'START_PICKER', requestId, kind, ...(fieldKey ? { fieldKey } : {}) });
  function deliver(message, from = sender) { let result; const async = listener(message, from, value => { result = value; }); assert.equal(async, false); return result && JSON.parse(JSON.stringify(result)); }
  function dispatch(type, extra = {}) { return events.emit(type, { target: host(), composedPath: () => [host()], clientX: 150, clientY: 120, ...extra }); }
  function pressKey(key, extra = {}) { dispatch('keydown', { key, ...extra }); return dispatch('keyup', { key, ...extra }); }
  function hover(node, extra = {}) { pointed = node; return dispatch('pointermove', extra); }
  function clickUI(text = '确认选择', extra = {}) { const button = ui(text), panel = button?.parentElement; return dispatch('click', { target: host(), composedPath: () => [button, panel, host()], ...extra }); }
  function add(tag, attrs = {}, text = '', parent = document.body) { const node = new Element(document, tag, attrs, text); parent.append(node); return node; }
  return { context, document, events, sent, timers, start, deliver, dispatch, pressKey, hover, clickUI, host, ui, add,
    selected: () => !ui('确认选择')?.disabled, reload: () => vm.runInContext(source, context), expire: () => [...timers.values()][0]?.fn() };
}
const result = h => h.sent.find(message => message.type === 'PURCHASE_PICK_RESULT');

test('trusted hover and overlay confirmation return a unique action locator without clicking merchant', () => {
  const h = harness(), button = h.add('button', { id: 'add-to-bag' }, '添加到购物袋');
  assert.deepEqual(h.start(), { ok: true, requestId: 'request-one' });
  assert.equal(h.hover(button).defaultPrevented, true); assert.equal(h.selected(), true);
  h.clickUI();
  assert.deepEqual(result(h), { type: 'PURCHASE_PICK_RESULT', requestId: 'request-one', kind: 'action', locator: { selector: '#add-to-bag', role: 'button', name: '添加到购物袋' }, origin: 'https://www.apple.com.cn', path: '/shop/bag' });
  assert.equal(button.clicks, 0); assert.equal(h.host(), undefined); assert.equal(h.events.count(), 0); assert.equal(h.document.count(), 0); assert.equal(h.timers.size, 0);
});

test('pointer hover promotes action child to button but merchant pointer/click activation is swallowed', () => {
  const h = harness(), button = h.add('button', { 'data-autom': 'add-to-cart' }, ''), child = h.add('span', {}, 'Add to bag', button);
  h.start(); h.hover(child); assert.equal(h.selected(), true);
  for (const type of ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click', 'auxclick', 'dblclick', 'contextmenu', 'touchstart', 'touchend']) assert.equal(h.dispatch(type).defaultPrevented, true);
  assert.equal(result(h), undefined); assert.equal(button.clicks, 0);
  h.pressKey('Enter'); assert.equal(result(h).locator.selector, 'button[data-autom="add-to-cart"]');
});

test('untrusted synthetic pointer/click/keys cannot select or confirm', () => {
  const h = harness(), node = h.add('button', { id: 'continue' }, 'Continue'); h.start();
  h.hover(node, { isTrusted: false }); assert.equal(h.selected(), false);
  h.hover(node); h.clickUI('确认选择', { isTrusted: false }); h.dispatch('keydown', { key: 'Enter', isTrusted: false });
  assert.equal(result(h), undefined); h.clickUI(); assert.ok(result(h));
});

test('public evidence and private address summary return metadata only and never read their text', () => {
  for (const [tag, id] of [['span', 'item-total'], ['address', 'selected-address']]) {
    const h = harness(), node = h.add(tag, { id, 'aria-label': 'Private customer and contact text' }, 'Private Address 13812345678'); node.forbidText = true;
    h.start('public-evidence'); h.hover(node); assert.equal(h.selected(), true); h.clickUI();
    assert.deepEqual(result(h).locator, { selector: '#' + id, role: 'evidence', name: '' });
    assert.equal(node.readText, 0); assert.equal(JSON.stringify(h.sent).includes('Private'), false);
  }
});

test('public evidence excludes controls and control ancestors without reading values or text', () => {
  for (const tag of ['input', 'textarea', 'select', 'option', 'iframe']) {
    const h = harness(), container = h.add('div', { id: 'summary' }), node = h.add(tag, { id: 'field' }, 'PRIVATE', container); container.forbidText = true;
    h.start('public-evidence'); h.hover(node); assert.equal(h.selected(), false, tag); h.hover(container); assert.equal(h.selected(), false, tag); h.clickUI(); assert.equal(result(h), undefined);
  }
});

test('address fields match explicit field semantics and never read populated input values', () => {
  const h = harness(), node = h.add('input', { id: 'shipping-phone', type: 'tel', autocomplete: 'shipping tel', 'aria-label': '手机号码' });
  h.start('address-field', 'phone'); h.hover(node); assert.equal(h.selected(), true); h.clickUI();
  assert.deepEqual(result(h).locator, { selector: '#shipping-phone', role: 'textbox', name: '手机号码', autocomplete: 'tel' });
  assert.equal(result(h).fieldKey, 'phone');
});

test('address mappings use empty name instead of private labels and reject conflicting autocomplete', () => {
  const h = harness(), node = h.add('input', { id: 'shipping-name', autocomplete: 'name', 'aria-label': 'Jane User private address' });
  h.start('address-field', 'fullName'); h.hover(node); assert.equal(h.selected(), true); h.clickUI(); assert.equal(result(h).locator.name, '');
  assert.equal(JSON.stringify(h.sent).includes('Jane'), false);
  const x = harness(), wrong = x.add('input', { id: 'phone', autocomplete: 'email', 'aria-label': '手机号' });
  x.start('address-field', 'phone'); x.hover(wrong); assert.equal(x.selected(), false);
});

test('field label wrapping a textarea never reads its default text or other control text', () => {
  const h = harness(), label = h.add('label', {}, '详细地址'), node = h.add('textarea', { id: 'address-line', autocomplete: 'address-line1' }, 'PRIVATE DEFAULT', label);
  label.forbidText = true; h.start('address-field', 'addressLine1'); h.hover(node); assert.equal(h.selected(), true); h.clickUI();
  assert.equal(result(h).locator.name, ''); assert.equal(label.readText, 0); assert.equal(node.readText, 0);
});

test('credential, OTP, payment card, ID, session and contenteditable targets are rejected', () => {
  for (const attrs of [{ type: 'password' }, { autocomplete: 'one-time-code' }, { name: 'cvv' }, { id: 'OTPCode' }, { name: 'cvvInput' }, { id: 'PINCode' }, { id: 'credit-card-number' }, { autocomplete: 'cc-exp' }, { name: 'national-id' }, { 'data-autom': 'session-secret' }, { id: 'identity-number' }, { contenteditable: 'true' }]) {
    const h = harness(), node = h.add('input', { id: 'field', autocomplete: 'name', ...attrs }); h.start('address-field', 'fullName'); h.hover(node); assert.equal(h.selected(), false, JSON.stringify(attrs));
    const x = harness(), outer = x.add('div', { id: 'evidence', ...attrs }, 'PRIVATE'); outer.forbidText = true; x.start('public-evidence'); x.hover(outer); assert.equal(x.selected(), false, JSON.stringify(attrs));
  }
});

test('dangerous or private action labels cannot become mapping metadata', () => {
  for (const label of ['Pay now', '登录', '同意服务条款', '王先生 上海市静安区某路100号', 'Contact 13812345678', 'user@example.com']) {
    const h = harness(), node = h.add('button', { id: 'action' }, label); h.start(); h.hover(node); assert.equal(h.selected(), false, label); h.clickUI(); assert.equal(result(h), undefined);
  }
});

test('ambiguous duplicate identifiers never fall back to nth-child or hidden-node filtering', () => {
  const h = harness(), first = h.add('button', { id: 'continue' }, 'Continue'), second = h.add('button', { id: 'continue' }, 'Continue'); second.hidden = true;
  h.start(); h.hover(first); assert.equal(h.selected(), false); h.clickUI(); assert.equal(result(h), undefined);
});

test('unstable UUID and timestamp IDs are skipped in favor of stable semantic attributes', () => {
  for (const id of ['id-123e4567-e89b-12d3-a456-426614174000', 'element-1730000000000', 'x-abcdef0123456789']) {
    const h = harness(), node = h.add('button', { id, 'data-autom': 'add-to-cart' }, 'Add to bag'); h.start(); h.hover(node); assert.equal(h.selected(), true); h.clickUI();
    assert.equal(result(h).locator.selector, 'button[data-autom="add-to-cart"]'); assert.equal(JSON.stringify(result(h)).includes(id), false);
  }
});

test('unique stable ancestor plus unindexed structural chain handles repeated controls', () => {
  const h = harness(), panel = h.add('section', { id: 'bag-actions' }), wrapper = h.add('div', {}, '', panel), node = h.add('button', {}, 'Continue', wrapper);
  h.add('button', {}, 'Continue'); h.start(); h.hover(node); assert.equal(h.selected(), true); h.clickUI();
  assert.equal(result(h).locator.selector, '#bag-actions > div > button'); assert.equal(result(h).locator.selector.includes('nth'), false);
});

test('aria selector names and metadata are sanitized, and source never uses value selectors', () => {
  const h = harness(), node = h.add('button', { 'aria-label': 'Add to bag' }); h.add('button', {}, 'Continue'); h.start(); h.hover(node); h.clickUI();
  assert.equal(result(h).locator.selector, 'button[aria-label="Add to bag"]');
  assert.doesNotMatch(source, /\.click\s*\(|\b(?:node|element|input|control)\.value\b|\[value=/u);
});

test('confirmation re-resolves selector and rejects element replacements and new duplicates', () => {
  for (const change of ['replace', 'duplicate', 'name']) {
    const h = harness(), node = h.add('button', { id: 'continue' }, 'Continue'); h.start(); h.hover(node);
    if (change === 'replace') { node.remove(); h.add('button', { id: 'continue' }, 'Continue'); }
    if (change === 'duplicate') h.add('button', { id: 'continue' }, 'Continue');
    if (change === 'name') node.ownText = 'Save';
    h.clickUI(); assert.equal(result(h), undefined, change); assert.equal(h.selected(), false);
  }
});

test('only exact supported HTTPS hosts, shop paths and main frame can start', () => {
  for (const href of ['https://www.apple.com/shop/bag', 'https://www.apple.com.cn.evil.test/shop/bag', 'http://www.apple.com.cn/shop/bag', 'https://www.apple.com.cn:8443/shop/bag', 'https://user@www.apple.com.cn/shop/bag', 'https://www.apple.com.cn/account', 'https://www.apple.com.cn/shop/sign-in', 'https://www.apple.com.cn/shop/bag#address', 'https://www.apple.com.cn/shop/a%20b', 'https://secure6.www.apple.com.cn/shop/session-token']) {
    const h = harness({ href }); assert.equal(h.start().ok, false, href); assert.equal(h.host(), undefined);
  }
  assert.equal(harness({ iframe: true }).start().ok, false);
});

test('secure6 query tokens are never included in results', () => {
  const h = harness({ href: 'https://secure6.www.apple.com.cn/shop/checkout?_a=private-token&_s=another-secret' }), node = h.add('div', { id: 'selected-address' }); node.forbidText = true;
  assert.equal(h.start('public-evidence').ok, true); h.hover(node); h.clickUI();
  assert.equal(result(h).origin, 'https://secure6.www.apple.com.cn'); assert.equal(result(h).path, '/shop/checkout'); assert.equal(JSON.stringify(h.sent).includes('token'), false); assert.equal(JSON.stringify(h.sent).includes('_s'), false);
});

test('navigation, query change, hidden page, resize and scroll invalidate current selection', () => {
  for (const change of ['navigation', 'query', 'hidden', 'resize', 'scroll']) {
    const h = harness(), node = h.add('button', { id: 'continue' }, 'Continue'); h.start(); h.hover(node);
    if (change === 'navigation') h.context.location.href = 'https://www.apple.com.cn/shop/review';
    if (change === 'query') h.context.location.href += '?private=changed';
    if (change === 'hidden') { h.document.visibilityState = 'hidden'; h.document.emit('visibilitychange'); }
    if (change === 'resize') h.dispatch('resize');
    if (change === 'scroll') h.document.emit('scroll');
    h.clickUI(); assert.equal(result(h), undefined, change);
  }
});

test('start authenticates extension sender, rejects malformed payloads and cannot be initiated by page messages', () => {
  for (const sender of [{ id: 'other-extension' }, { id: 'extension-id', tab: { id: 1 } }, { id: 'extension-id', url: 'https://www.apple.com.cn/shop/bag' }, {}]) assert.equal(harness({ sender }).start().ok, false);
  for (const message of [{ type: 'START_PICKER', requestId: 'short', kind: 'action' }, { type: 'START_PICKER', requestId: 12345678, kind: 'action' }, { type: 'START_PICKER', requestId: 'request-one', kind: 'address-field', fieldKey: 'password' }, { type: 'START_PICKER', requestId: 'request-one', kind: 'action', script: 'run' }]) assert.equal(harness().deliver(message).ok, false);
  const h = harness(); assert.equal(h.events.events.has('message'), false); assert.equal(h.deliver({ type: 'arbitrary' }), undefined);
});

test('duplicate injection and same active request are idempotent; replacement cancels precisely once', () => {
  const h = harness(); h.reload(); h.start(); const count = h.events.count(), host = h.host(); h.start();
  assert.equal(h.events.count(), count); assert.equal(h.host(), host); assert.equal(h.timers.size, 1);
  h.start('public-evidence', undefined, 'request-two'); assert.equal(h.sent.length, 1); assert.deepEqual(h.sent[0], { type: 'PURCHASE_PICK_CANCELLED', requestId: 'request-one', reason: 'replaced-by-new-request' });
  assert.equal(h.events.count(), count); assert.equal(h.timers.size, 1); assert.equal(h.start().ok, false);
});

test('Escape, cancel button, exact background cancel, expiry and unload clean all resources', () => {
  for (const cancel of [h => h.pressKey('Escape'), h => h.clickUI('取消'), h => h.deliver({ type: 'CANCEL_PICKER', requestId: 'request-one' }), h => h.expire(), h => h.dispatch('pagehide')]) {
    const h = harness(); h.start(); cancel(h); assert.equal(h.host(), undefined); assert.equal(h.events.count(), 0); assert.equal(h.document.count(), 0); assert.equal(h.timers.size, 0); assert.equal(h.sent.length, 1); assert.equal(h.sent[0].type, 'PURCHASE_PICK_CANCELLED');
    assert.equal(h.start().ok, false);
  }
  const h = harness(); h.start(); assert.equal(h.deliver({ type: 'CANCEL_PICKER', requestId: 'stale-request' }).ok, false); assert.ok(h.host());
});

test('overlay warns about earlier page handlers and never treats blocked page clicks as confirmation', () => {
  const h = harness(), node = h.add('button', { id: 'continue' }, 'Continue'); h.start();
  assert.ok(h.host().testShadow.querySelectorAll('p').some(item => /先注册的事件处理器/u.test(item.ownText)));
  h.hover(node); h.dispatch('click', { target: node, composedPath: () => [node, h.document.body] }); assert.equal(result(h), undefined);
  h.dispatch('keydown', { key: 'Enter', ctrlKey: true }); assert.equal(result(h), undefined);
});


test('closed-shadow retargeting resolves overlay buttons internally and does not change hover on the panel', () => {
  const h = harness(), node = h.add('button', { id: 'continue' }, 'Continue'); h.start(); h.hover(node);
  const confirm = h.ui('确认选择');
  h.host().testShadow.elementFromPoint = () => confirm;
  const before = confirm.disabled;
  h.dispatch('pointermove'); assert.equal(confirm.disabled, before);
  h.dispatch('click'); assert.ok(result(h)); assert.equal(result(h).locator.selector, '#continue');
});


test('keyboard confirmation waits for swallowed keyup and cannot leak a release to merchant focus', () => {
  const h = harness(), node = h.add('button', { id: 'continue' }, 'Continue'); h.start(); h.hover(node);
  let merchantKeys = 0; h.events.addEventListener('keyup', () => merchantKeys++);
  h.dispatch('keydown', { key: 'Enter' }); assert.equal(result(h), undefined); assert.ok(h.host());
  const release = h.dispatch('keyup', { key: 'Enter' }); assert.equal(release.defaultPrevented, true);
  assert.ok(result(h)); assert.equal(merchantKeys, 0); assert.equal(h.host(), undefined);
  const x = harness(), other = x.add('button', { id: 'continue' }, 'Continue'); x.start(); x.hover(other);
  x.dispatch('keyup', { key: 'Enter' }); assert.equal(result(x), undefined);
  x.dispatch('keydown', { key: 'Enter', ctrlKey: true }); x.dispatch('keyup', { key: 'Enter' }); assert.equal(result(x), undefined);
});
