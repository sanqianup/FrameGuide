// Read-only evidence for the observed Apple China pre-login flow. This is not a
// purchase preset: it has no click, navigation, authentication, or storage code.
(() => {
  'use strict';
  if (globalThis.AppleStoreObserved) return;
  const norm = value => String(value ?? '').normalize('NFKC').replace(/\s+/gu, ' ').trim();
  const BASE = '/shop/buy-iphone/iphone-18-pro';
  const SKU = 'mjt74ch/a';
  const OBSERVED = Object.freeze({ model: 'iPhone 18 Pro', storage: '256GB', color: '黑色' });
  const SUMMARY = 'iPhone 18 Pro 256GB 黑色';
  const CHECKOUT_IDS = ['shoppingCart.actions.navCheckout', 'shoppingCart.actions.checkout'];
  const unsafeTextTags = /^(?:INPUT|TEXTAREA|SELECT|OPTION|SCRIPT|STYLE|NOSCRIPT|IFRAME)$/u;
  const sensitiveControl = /password|passcode|cc-|card|payment|credential|one.?time|captcha|verification|验证码|密码|银行卡|支付/iu;
  const all = (root, selector) => [...root.querySelectorAll(selector)];

  function classifyURL(raw) {
    try {
      const url = new URL(raw);
      if (url.protocol !== 'https:' || url.username || url.password || url.port || url.hash) return null;
      if (url.hostname === 'secure6.www.apple.com.cn' && url.pathname === '/shop/signIn') return 'sign-in';
      if (url.hostname === 'secure6.www.apple.com.cn' && url.pathname === '/shop/checkout') return 'checkout-observation';
      if (url.hostname !== 'www.apple.com.cn') return null;
      if (url.pathname === '/shop/bag' && !url.search) return 'bag';
      if (url.pathname === `${BASE}/${SKU}` && !url.search) return 'configuration';
      if (url.pathname !== BASE) return null;
      if (!url.search) return 'configuration';
      const entries = [...url.searchParams];
      return entries.length === 2 && url.searchParams.getAll('product').length === 1 &&
        url.searchParams.getAll('step').length === 1 && url.searchParams.get('product') === SKU &&
        url.searchParams.get('step') === 'attach' ? 'attach' : null;
    } catch { return null; }
  }

  function empty(kind) {
    return {
      supported: kind !== null, pageKind: kind,
      product: { summary: null, model: null, storage: null, color: null, matchesExpected: null },
      selections: {},
      cart: { quantity: null, quantityMatchesExpected: null, quantityControlCount: null,
        itemCount: null, noExtraItems: null, subtotalMinor: null, shippingMinor: null,
        totalMinor: null, currency: null, totalIncludesTaxShipping: null },
      actions: {}, blocker: null, preorderNoticeObserved: false,
      authenticationRequired: kind === 'sign-in', loginWidgetObserved: false,
      ambiguity: [], evidenceMissing: kind ? ['complete-cart-inventory', 'tax-inclusion',
        'address', 'payment', 'final-submission'] : []
    };
  }

  function visible(element, labelAlternative = false) {
    if (!element || element.isConnected === false) return false;
    const view = element.ownerDocument?.defaultView;
    for (let current = element; current; current = current.parentElement) {
      if (current.hidden || current.hasAttribute?.('hidden') || current.getAttribute?.('aria-hidden') === 'true') return false;
      const style = view?.getComputedStyle?.(current);
      if (style && (style.display === 'none' || style.visibility === 'hidden' ||
        style.visibility === 'collapse' || style.contentVisibility === 'hidden' ||
        (style.opacity === '0' && (current !== element || !labelAlternative)))) return false;
    }
    return labelAlternative || !!element.getClientRects?.().length;
  }

  function enabled(element) {
    if (element.disabled || element.matches?.(':disabled')) return false;
    for (let current = element; current; current = current.parentElement) {
      if (current.inert || current.hasAttribute?.('inert') || current.getAttribute?.('aria-disabled') === 'true' ||
        current.getAttribute?.('aria-busy') === 'true') return false;
    }
    return true;
  }

  function unsafeText(element) {
    return unsafeTextTags.test(element.tagName ?? '') || element.hasAttribute?.('contenteditable') ||
      element.getAttribute?.('role') === 'textbox';
  }

  // Avoid aggregate reads of inputs, payment fields, credentials, or editable
  // content. The sole form value reader below is an already uniquely named select.
  function publicText(element, except = null) {
    for (let current = element; current; current = current.parentElement) if (unsafeText(current)) return null;
    if (all(element, '*').some(child => child !== except && unsafeText(child))) return null;
    return norm(element.textContent);
  }

  function labelOf(element, doc) {
    const labels = all(doc, 'label').filter(label => {
      const id = element.getAttribute('id');
      return (id && label.getAttribute('for') === id) || label.contains?.(element);
    });
    const by = norm(element.getAttribute('aria-labelledby'));
    let references = [];
    if (by) {
      const ids = by.split(' '), identified = all(doc, '[id]');
      if (new Set(ids).size !== ids.length) throw Error('duplicate-label-reference');
      references = ids.map(id => {
        const matches = identified.filter(node => node.getAttribute('id') === id);
        if (matches.length !== 1) throw Error('nonunique-label-reference');
        return matches[0];
      });
      const texts = references.map(node => publicText(node, element));
      if (texts.some(text => !text)) throw Error('unsafe-label');
      return { name: norm(texts.join(' ')), labels: [...labels, ...references] };
    }
    const aria = element.getAttribute('aria-label');
    if (aria !== null) return { name: norm(aria), labels };
    if (labels.length > 1) throw Error('multiple-labels');
    if (labels.length === 1) {
      const name = publicText(labels[0], element);
      if (name === null) throw Error('unsafe-label');
      return { name, labels };
    }
    if (/^(?:INPUT|SELECT|TEXTAREA)$/u.test(element.tagName)) return { name: '', labels: [] };
    return { name: publicText(element) ?? '', labels: [] };
  }

  function addFault(result, key) {
    if (!result.ambiguity.includes(key)) result.ambiguity.push(key);
  }

  function action(result, key, candidates) {
    const status = candidates.length > 1 ? 'ambiguous' : !candidates.length ? 'missing' : candidates[0].enabled ? 'ready' : 'disabled';
    result.actions[key] = { status, candidates };
    if (status === 'ambiguous') addFault(result, `${key}:multiple-controls`);
    if (status === 'missing') result.evidenceMissing.push(`${key}-control`);
  }

  function readProduct(doc, result, expected) {
    // Configuration has no established summary selector. Match complete public
    // text only, never assemble independent model/storage/color fragments.
    const headings = all(doc, 'h1,h2,h3,h4,h5,h6,[role="heading"]').filter(node => visible(node));
    const headingMatches = headings.filter(node => publicText(node) === SUMMARY);
    let matches = headingMatches;
    if (result.pageKind !== 'bag' && !matches.length) {
      matches = all(doc, '*').filter(node => visible(node) && !node.children?.length && publicText(node) === SUMMARY);
    }
    if (matches.length > 1) addFault(result, 'product:multiple-summaries');
    if (matches.length !== 1) { result.evidenceMissing.push('exact-product-summary'); return; }
    result.product = { summary: SUMMARY, ...OBSERVED, matchesExpected: null };
    if (expected && ['model', 'storage', 'color'].every(key => typeof expected[key] === 'string' && norm(expected[key]))) {
      result.product.matchesExpected = ['model', 'storage', 'color'].every(key => norm(expected[key]) === OBSERVED[key]);
    } else result.evidenceMissing.push('expected-product');
  }

  function readSelections(doc, result) {
    const definitions = [
      ['model', 'iPhone 18 Pro 6.3 英寸显示屏', name => name === 'iPhone 18 Pro 6.3 英寸显示屏'],
      ['color', '黑色', name => name === '黑色'],
      ['storage', '256GB', name => /(?:^|[^0-9])256GB(?![A-Za-z0-9])/u.test(name)],
      ['tradeIn', '不折抵换购', name => name === '不折抵换购'],
      ['appleCare', '不加 AppleCare+ 服务计划', name => name === '不加 AppleCare+ 服务计划']
    ];
    const radios = [];
    for (const node of all(doc, 'input[type="radio"]')) {
      if (!visible(node, true)) continue;
      try {
        const label = labelOf(node, doc);
        if (visible(node) || label.labels.some(item => visible(item))) radios.push({ node, name: label.name });
      } catch { addFault(result, 'radio:uncertain-label'); }
    }
    for (const [key, name, match] of definitions) {
      const matches = radios.filter(radio => match(radio.name));
      const unique = matches.length === 1;
      result.selections[key] = { status: matches.length > 1 ? 'ambiguous' : unique ? 'observed' : 'missing',
        name, selected: unique ? matches[0].node.checked === true : null,
        enabled: unique ? enabled(matches[0].node) : null };
      if (matches.length > 1) addFault(result, `${key}:multiple-options`);
      if (!matches.length) result.evidenceMissing.push(`${key}-option`);
    }
  }

  function money(text) {
    const match = /^(?:(?:RMB|CNY|¥|￥)\s*)?((?:0|[1-9]\d*|[1-9]\d{0,2}(?:,\d{3})+))(?:\.(\d{1,2}))?(?:\s*元)?$/u.exec(norm(text));
    if (!match) return null;
    const amount = Number(match[1].replace(/,/gu, '')) * 100 + Number((match[2] ?? '').padEnd(2, '0'));
    return Number.isSafeInteger(amount) && amount >= 0 ? amount : null;
  }

  function readTotal(doc, result, label, field) {
    // A unique visible label with an immediate two-child row is evidence. No
    // document-wide price regex, guessed data-autom attribute, or nearest amount.
    const labels = all(doc, '*').filter(node => visible(node) && !node.children?.length && publicText(node) === label);
    if (labels.length !== 1) {
      if (labels.length > 1) addFault(result, `${field}:multiple-labels`);
      result.evidenceMissing.push(field);
      return;
    }
    const node = labels[0], siblings = [...(node.parentElement?.children ?? [])].filter(item => visible(item));
    if (siblings.length !== 2 || siblings[0] !== node) { result.evidenceMissing.push(`${field}-paired-amount`); return; }
    const text = publicText(siblings[1]);
    const amount = field === 'shippingMinor' && text === '免费' ? 0 : text === null ? null : money(text);
    if (amount === null) result.evidenceMissing.push(`${field}-paired-amount`);
    else result.cart[field] = amount;
  }

  function readCart(doc, result, expected) {
    const named = [];
    let uncertain = false;
    for (const select of all(doc, 'select').filter(node => visible(node))) {
      try { if (labelOf(select, doc).name === '数量') named.push(select); }
      catch { uncertain = true; addFault(result, 'quantity:uncertain-label'); }
    }
    result.cart.quantityControlCount = named.length;
    if (named.length > 1) addFault(result, 'quantity:multiple-controls');
    if (named.length === 1 && !uncertain) {
      // Never read any other select, or any input/textarea value or value attribute.
      const metadata = ['autocomplete', 'id', 'name', 'type'].map(key => named[0].getAttribute(key) ?? '').join(' ');
      const value = sensitiveControl.test(metadata) ? null : named[0].value;
      if (sensitiveControl.test(metadata)) addFault(result, 'quantity:sensitive-control');
      if (typeof value === 'string' && /^[1-9]\d*$/u.test(value) && Number.isSafeInteger(Number(value))) {
        result.cart.quantity = Number(value);
        if (Number.isSafeInteger(expected?.quantity) && expected.quantity > 0) {
          result.cart.quantityMatchesExpected = result.cart.quantity === expected.quantity;
        }
      }
    }
    if (result.cart.quantity === null) result.evidenceMissing.push('quantity');
    // One heading/select cannot prove the complete cart inventory. These stay
    // null even for the observed bag until separately mapped inventory exists.
    readTotal(doc, result, '小计', 'subtotalMinor');
    readTotal(doc, result, '运费', 'shippingMinor');
    readTotal(doc, result, '总计', 'totalMinor');
    if (['subtotalMinor', 'shippingMinor', 'totalMinor'].every(key => result.cart[key] !== null)) {
      // CNY is scoped to this exact mainland storefront, not inferred tax coverage.
      result.cart.currency = 'CNY';
    }
    const candidates = all(doc, 'button').filter(node => visible(node) && CHECKOUT_IDS.includes(node.getAttribute('id')))
      .map(node => ({ role: 'button', selector: `button[id="${node.getAttribute('id')}"]`, enabled: enabled(node) }));
    action(result, 'checkout', candidates);
  }

  function maintenanceObserved(doc) {
    const notice = norm('来得早，来得好。即将与你见面。北京时间晚8点接受预购。一会儿见。').replace(/\s/gu, '');
    // Match the observed complete notice, including a split-leaf rendering. Its
    // prose is not a machine-readable countdown or an authorized action time.
    const leaves = all(doc, '*').filter(node => visible(node) && !node.children?.length);
    const text = leaves.map(node => publicText(node) ?? '').join('').replace(/\s/gu, '');
    return text.includes(notice);
  }

  function inspect(doc, url, expected = null) {
    const kind = classifyURL(url), result = empty(kind);
    // Do not touch a document outside the exact observed merchant endpoints.
    if (!kind) return result;
    if (!doc?.querySelectorAll || doc.nodeType !== 9) { result.evidenceMissing.push('document'); return result; }
    try {
      if (maintenanceObserved(doc)) {
        result.blocker = 'maintenance-preorder-paused';
        result.preorderNoticeObserved = true;
        result.evidenceMissing.push('maintenance-page-interrupted-observation');
        return result;
      }
      if (kind === 'checkout-observation') {
        // The exact route was observed, but its address/payment/review stages
        // have no complete evidence contract. Only maintenance is inspected.
        result.evidenceMissing.push('checkout-stage-not-mapped');
        return result;
      }
      if (kind === 'sign-in') {
        // No input reads, iframe src, frame contents, or session query emission.
        const frames = all(doc, 'iframe').filter(node => visible(node) &&
          node.getAttribute('id') === 'aid-auth-widget-iFrame' && node.getAttribute('name') === 'aid-auth-widget');
        result.loginWidgetObserved = frames.length === 1;
        if (frames.length > 1) addFault(result, 'login-widget:multiple-frames');
        if (!frames.length) result.evidenceMissing.push('login-widget');
        return result;
      }
      readProduct(doc, result, expected);
      if (kind === 'configuration') readSelections(doc, result);
      if (kind === 'bag') readCart(doc, result, expected);
      if (kind === 'configuration' || kind === 'attach') {
        const key = kind === 'configuration' ? 'addToBag' : 'viewBag';
        const name = kind === 'configuration' ? '添加到购物袋' : '查看购物袋';
        const candidates = [];
        for (const node of all(doc, 'button').filter(item => visible(item))) {
          try {
            if (labelOf(node, doc).name === name) candidates.push({ role: 'button', name, enabled: enabled(node) });
          } catch { addFault(result, `${key}:uncertain-label`); }
        }
        action(result, key, candidates);
      }
      return result;
    } catch {
      const failed = empty(kind);
      failed.evidenceMissing.push('dom-inspection');
      return failed;
    }
  }

  globalThis.AppleStoreObserved = Object.freeze({ inspect, supportsURL: url => classifyURL(url) !== null });
})();
