import './purchase-policy.js';
import './apple-duo-readonly.js';
// Explicit, site-calibrated purchase plans. No address values belong in a plan.
export const PURCHASE_ORIGIN = 'https://www.apple.com.cn';
export const PURCHASE_ORIGINS = Object.freeze([PURCHASE_ORIGIN,'https://secure6.www.apple.com.cn']);
const origin=x=>{if(!PURCHASE_ORIGINS.includes(x))throw Error('购买来源仅允许明确核验的 Apple 中国大陆主站或 secure6');return x;};
export const ADDRESS_AUTOCOMPLETE = Object.freeze({fullName:'name',givenName:'given-name',familyName:'family-name',phone:'tel',email:'email',addressLine1:'address-line1',addressLine2:'address-line2',city:'address-level2',district:'address-level3',province:'address-level1',postalCode:'postal-code'});
export const PURCHASE_STAGES = Object.freeze(['configure','add-to-bag','address','review','submit-unpaid']);
const plain = x => !!x && typeof x === 'object' && !Array.isArray(x);
export const normalizePurchaseText = x => String(x ?? '').normalize('NFKC').replace(/\s+/gu,' ').trim();
const controls = /[\u0000-\u001f\u007f\u200b-\u200f\u202a-\u202e\u2060-\u206f]/u;
function text(x,label,max=300){if(typeof x!=='string'||!normalizePurchaseText(x)||x.length>max||controls.test(x))throw Error(`${label}须为明确有效的文字`);return normalizePurchaseText(x);}
function keys(x,allowed,label){if(!plain(x)||Object.keys(x).some(k=>!allowed.includes(k)))throw Error(`${label}格式无效或含不支持的字段`);}
function selector(x,label){const s=text(x,label,300);if(/^(?:\*|html|body|:root)$/iu.test(s)||s.includes('\\')||/\[\s*value\b/iu.test(s))throw Error(`${label}不允许宽泛或转义选择器`);return s;}
export function purchasePath(x){if(typeof x!=='string'||!/^\/shop(?:\/|$)/u.test(x)||/[?#\\%\s]/u.test(x)||x.includes('//'))throw Error('购买路径须为精确的 Apple 中国大陆 /shop 路径，不含查询或片段');const u=new URL(x,PURCHASE_ORIGIN);if(u.origin!==PURCHASE_ORIGIN||u.pathname!==x)throw Error('购买路径无效');return x;}
function queryValue(raw,host,path){
 if(raw===undefined)return undefined;
 keys(raw,['product','step'],'静态附件页面参数');
 if(host!==PURCHASE_ORIGIN||!/^\/shop\/buy-iphone\/[a-z0-9-]+$/u.test(path)||typeof raw.product!=='string'||!/^[a-z0-9]{5,16}\/a$/iu.test(raw.product)||raw.step!=='attach'||Object.keys(raw).length!==2)throw Error('仅允许已配置的商品 product 与 attach 静态参数');
 return {product:raw.product,step:'attach'};
}
export function purchaseURL(x){try{const u=new URL(x);if(!PURCHASE_ORIGINS.includes(u.origin)||u.username||u.password||u.hash||purchasePath(u.pathname)!==u.pathname)return false;if(u.origin===PURCHASE_ORIGIN&&u.search){const q=Object.fromEntries(u.searchParams);if([...u.searchParams].length!==2)return false;queryValue(q,u.origin,u.pathname);}return true;}catch{return false;}}
export function purchaseLocationMatches(value,location){try{if(!purchaseURL(value))return false;const u=new URL(value),host=location.origin??PURCHASE_ORIGIN;if(u.origin!==host||u.pathname!==location.path)return false;if(host!==PURCHASE_ORIGIN)return true;const expected=location.query??{};return [...u.searchParams].length===Object.keys(expected).length&&Object.entries(expected).every(([k,v])=>u.searchParams.get(k)===v);}catch{return false;}}
export function safePurchaseURL(value){const u=new URL(value);return u.origin===PURCHASE_ORIGIN?u.href:`${u.origin}${u.pathname}`;}
export const nextPurchaseLocation=step=>({origin:step.confirm.nextOrigin??step.origin,path:step.confirm.nextPath??step.path,...(step.confirm.nextQuery?{query:step.confirm.nextQuery}:step.confirm.nextPath?{}:step.query?{query:step.query}:{})});
export const purchaseLoginPath=path=>/\/(?:sign[-_]?in|log[-_]?in|auth|account)(?:\/|$)/iu.test(path);
const paymentNow={test:globalThis.PurchasePolicy.unsafeAction};
export const positiveNoCharge=globalThis.PurchasePolicy.positiveNoCharge;
function positiveComplete(x){const s=normalizePurchaseText(x);return /(?:包含|包括|含|includes?|inclusive)/iu.test(s)&&/(?:税|tax)/iu.test(s)&&/(?:运费|配送费|shipping|delivery fee)/iu.test(s)&&!/(?:不|未|尚未|没有|尚无).{0,8}(?:含|包括|计入)|(?:税|运费|配送费|shipping|tax).{0,30}(?:另计|额外|未计|excluded)|(?:可能|预计|将会|将|稍后|随后|另计|额外)|\b(?:not|never|without|excluding|excludes?|excluded|may|might|will|would|later|additional|extra)\b|\b(?:no|not yet|not currently)\b.{0,30}\binclud/iu.test(s);}
function confirmation(raw,label,host){keys(raw,['selector','text','nextPath','nextOrigin','nextQuery','allowAuthHandoff'],label);const r={selector:selector(raw.selector,label),text:text(raw.text,`${label}文字`,500)};if(raw.nextPath!==undefined)r.nextPath=purchasePath(raw.nextPath);if(raw.nextOrigin!==undefined){if(!r.nextPath)throw Error('nextOrigin 须同时指定 nextPath');r.nextOrigin=origin(raw.nextOrigin);}if(raw.allowAuthHandoff!==undefined){if(raw.allowAuthHandoff!==true||!r.nextPath||(r.nextOrigin??host)!=='https://secure6.www.apple.com.cn')throw Error('登录交接仅支持配置好的 secure6 后续路径');r.allowAuthHandoff=true;}if(raw.nextQuery!==undefined){if(!r.nextPath)throw Error('nextQuery 须同时指定 nextPath');r.nextQuery=queryValue(raw.nextQuery,r.nextOrigin??host,r.nextPath);}return r;}
const evidenceKeys=['model','storage','color','quantity','currency','region','delivery','itemCount','itemPrice','total','noCharge'];
function validateStep(raw,config,index){
 const label=`购买第 ${index+1} 步`;keys(raw,['stage','kind','group','adapter','origin','path','query','target','fields','evidence','confirm','timeoutMs','noChargeText','totalIncludesTaxShipping','addressConfirmation'],label);
 if(!PURCHASE_STAGES.includes(raw.stage))throw Error(`${label}阶段无效`);
 if(!['button','address','radio'].includes(raw.kind)||raw.kind==='address'&&raw.stage!=='address'||(raw.kind==='radio')!==(raw.stage==='configure'))throw Error(`${label}动作无效`);
 const s={stage:raw.stage,kind:raw.kind,origin:origin(raw.origin??PURCHASE_ORIGIN),path:purchasePath(raw.path),timeoutMs:raw.timeoutMs??15000};
 if(!Number.isInteger(s.timeoutMs)||s.timeoutMs<1000||s.timeoutMs>30000)throw Error('步骤超时须为 1000 至 30000 毫秒');
 if(raw.query!==undefined)s.query=queryValue(raw.query,s.origin,s.path);
 if(raw.adapter!==undefined){if(raw.adapter!=='apple-duo'||s.stage!=='configure'||s.kind!=='radio'||s.origin!==PURCHASE_ORIGIN||s.query||!globalThis.AppleDuoReadonly.supportsURL(`${s.origin}${s.path}`)||config.model!=='iPhone Duo')throw Error('内置规格适配只用于已记录的 iPhone Duo 商品路径');s.adapter='apple-duo';keys(raw.confirm,['kind'],'Duo 规格后置条件');if(raw.confirm.kind!=='apple-selection')throw Error('Duo 规格必须通过独立应用状态确认');s.confirm={kind:'apple-selection'};}else s.confirm=confirmation(raw.confirm,`${label}后置条件`,s.origin);
 const maps=raw.evidence??{};keys(maps,evidenceKeys,`${label}证据`);s.evidence={};for(const k of Object.keys(maps))s.evidence[k]=selector(maps[k],`${label} ${k} 证据`);
 for(const k of (s.adapter==='apple-duo'?[]:s.stage==='configure'?['model',raw.group==='dimensionColor'?'color':'storage']:['model','storage','color','quantity','currency','region','delivery','itemCount',(['review','submit-unpaid'].includes(s.stage)?'total':'itemPrice')]))if(!s.evidence[k])throw Error(`${label}缺少 ${k} 独立证据映射`);
 if(['button','radio'].includes(s.kind)){
  keys(raw.target,['role','name','selector'],`${label}动作`);if(raw.target.role!==s.kind)throw Error('购买动作须使用明确匹配的语义角色');
  s.target={role:s.kind,name:text(raw.target.name,`${label}目标名称`,160)};
  if(s.kind==='radio'){if(!['dimensionColor','dimensionCapacity'].includes(raw.group))throw Error('规格配置只支持明确的颜色或容量单选组');s.group=raw.group;const dimension=raw.group==='dimensionColor'?'color':'storage';if(s.target.name!==config[dimension])throw Error('单选规格必须与本次目标完全相同');}else if(raw.group!==undefined)throw Error('按钮不得配置单选组');if(paymentNow.test(s.target.name))throw Error('付款或立即扣款按钮必须交给用户');
  if(raw.target.selector!==undefined)s.target.selector=selector(raw.target.selector,`${label}按钮`);
  if(s.target.selector&&s.target.selector===s.confirm.selector||s.target.name===s.confirm.text)throw Error('后置条件必须独立于动作按钮');
  if(raw.fields!==undefined)throw Error('按钮步骤不接受地址字段');
 }else{
  if(raw.target!==undefined)throw Error('地址步骤不接受点击目标');
  if(config.addressMode==='new'){
   if(!Array.isArray(raw.fields)||raw.fields.length<1||raw.fields.length>11)throw Error('地址步骤须映射 1 至 11 个字段');
   const used=new Set(),selectors=new Set();s.fields=raw.fields.map(f=>{keys(f,['key','selector','name','autocomplete'],'地址字段');if(!Object.hasOwn(ADDRESS_AUTOCOMPLETE,f.key)||used.has(f.key))throw Error('地址字段键无效或重复');used.add(f.key);if(f.autocomplete!==ADDRESS_AUTOCOMPLETE[f.key])throw Error('地址字段 autocomplete 与字段键不符');const field={key:f.key,autocomplete:f.autocomplete};if(f.name!==undefined&&f.name!=='')field.name=text(f.name,'地址字段可访问名称',160);if(f.selector!==undefined&&f.selector!==''){field.selector=selector(f.selector,'地址字段');if(selectors.has(field.selector)||field.selector===s.confirm.selector)throw Error('地址字段必须使用独立映射');selectors.add(field.selector);}return field;});
  }else if(raw.fields!==undefined&&raw.fields.length)throw Error('已选地址模式不得配置字段填充');
 }
 if(['review','submit-unpaid'].includes(s.stage)){
  keys(raw.totalIncludesTaxShipping,['selector','text'],'完整总价声明');s.totalIncludesTaxShipping={selector:selector(raw.totalIncludesTaxShipping.selector,'完整总价声明'),text:text(raw.totalIncludesTaxShipping.text,'完整总价声明',500)};
  if(!positiveComplete(s.totalIncludesTaxShipping.text))throw Error('总价声明须明确包含税费和配送费');
 }
 if(['address','review','submit-unpaid'].includes(s.stage)){
  keys(raw.addressConfirmation,['selector','keys'],'配送地址核对');s.addressConfirmation={selector:selector(raw.addressConfirmation.selector,'配送地址核对')};
  if(config.addressMode==='new'){
   if(!Array.isArray(raw.addressConfirmation.keys)||!raw.addressConfirmation.keys.length||new Set(raw.addressConfirmation.keys).size!==raw.addressConfirmation.keys.length||raw.addressConfirmation.keys.some(k=>!Object.hasOwn(ADDRESS_AUTOCOMPLETE,k)))throw Error('地址核对须列出准确字段键');
   s.addressConfirmation.keys=[...raw.addressConfirmation.keys];
  }else if(raw.addressConfirmation.keys!==undefined)throw Error('已选地址使用本地确认摘要，不接受地址字段键');
 }
 if(s.stage==='submit-unpaid'){
  if(s.confirm.allowAuthHandoff)throw Error('最终订单提交不允许登录交接或恢复');
  if(s.kind!=='button'||!s.evidence.noCharge)throw Error('未付款订单提交须有独立按钮和未扣款证据');s.noChargeText=text(raw.noChargeText,'未扣款声明',500);
  if(!positiveNoCharge(s.noChargeText)||!globalThis.PurchasePolicy.unpaidOrderResult(s.confirm.text))throw Error('必须明确观察无即时扣款声明，并以已创建的未付款订单确认');
 }else if(raw.noChargeText!==undefined)throw Error('仅最终未付款订单步骤可声明提交授权');
 return s;
}
export function validatePurchase(raw,now=Date.now()){
 if(!plain(raw)||raw.mode!=='purchase'||raw.confirmedPurchase!==true)throw Error('请明确授权本次加入购物袋、地址及未付款订单创建');
 if(!purchaseURL(raw.url))throw Error('仅支持精确的 Apple 中国大陆 HTTPS 商店链接');
 if(raw.testMode!==undefined||raw.fixtureURL!==undefined||raw.fixtureOrigin!==undefined||raw.fixturePath!==undefined)throw Error('测试模式只能由固定扩展测试页面启动');
 if(raw.address!==undefined)throw Error('地址不得写入配置，请仅使用本次会话地址');
 const initial=new URL(raw.url);if(initial.origin!==PURCHASE_ORIGIN)throw Error('购买任务须从 Apple 中国大陆主站商品页开始');
 const c={mode:'purchase',confirmedPurchase:true,addressMode:raw.addressMode??'new',url:initial.href};
 if(!['new','existing'].includes(c.addressMode))throw Error('地址模式无效');
 for(const key of ['model','storage','color','region','currency','delivery'])c[key]=text(raw[key],key,160);
 if(c.region!=='CN'||c.currency!=='CNY'||raw.regionConfirmed!==true)throw Error('必须确认中国大陆站及人民币 CNY');c.regionConfirmed=true;
 c.quantity=raw.quantity;if(!Number.isInteger(c.quantity)||c.quantity<1||c.quantity>10)throw Error('购买数量须为 1 至 10 的整数');
 c.maxTotal=Number(raw.maxTotal);if(!Number.isFinite(c.maxTotal)||c.maxTotal<=0||c.maxTotal>100000000||Math.abs(c.maxTotal*100-Math.round(c.maxTotal*100))>0.00001)throw Error('请填写最多两位小数的完整总价上限');
 c.pollMs=raw.pollMs??1000;if(!Number.isInteger(c.pollMs)||c.pollMs<1000||c.pollMs>60000)throw Error('检测间隔须为 1000 至 60000 毫秒');
 c.targetTime=raw.targetTime||new Date(now).toISOString();if(typeof c.targetTime!=='string'||!/(Z|[+-]\d{2}:\d{2})$/.test(c.targetTime)||!Number.isFinite(Date.parse(c.targetTime))||Date.parse(c.targetTime)>now+24*3600000)throw Error('开始时间须包含时区，且在未来 24 小时内');
 c.expiresAt=raw.expiresAt||new Date(Math.max(now,Date.parse(c.targetTime))+30*60000).toISOString();if(typeof c.expiresAt!=='string'||!/(Z|[+-]\d{2}:\d{2})$/.test(c.expiresAt)||!Number.isFinite(Date.parse(c.expiresAt))||Date.parse(c.expiresAt)<=Math.max(now,Date.parse(c.targetTime))||Date.parse(c.expiresAt)>now+24*3600000)throw Error('购买会话须在未来 24 小时内过期');
 let plan=raw.steps;if(raw.purchasePlan!==undefined){if(typeof raw.purchasePlan!=='string'||raw.purchasePlan.length>60000)throw Error('购买步骤须为 JSON 文字');try{plan=JSON.parse(raw.purchasePlan);}catch{throw Error('购买步骤须为有效 JSON 数组');}}
 if(!Array.isArray(plan)||plan.length<4||plan.length>16)throw Error('购买计划须包含 4 至 16 个明确步骤');
 c.steps=plan.map((s,i)=>validateStep(s,c,i));
 let previous=c.steps[0].stage==='configure'?-1:0;const configured=new Set();for(const s of c.steps){if(s.stage==='configure'){for(const prior of configured)if(s.adapter!=='apple-duo'&&!s.evidence[prior])throw Error('后续规格步骤须核对已选规格');configured.add(s.group==='dimensionColor'?'color':'storage');if(s.evidence.itemPrice&&!s.evidence.currency)throw Error('规格标价须有独立货币证据');}const stage=PURCHASE_STAGES.indexOf(s.stage);if(stage<previous||stage>previous+1)throw Error('购买阶段须依次为加入购物袋、地址、复核和未付款提交');previous=stage;}
 if(previous!==4||c.steps.filter(s=>s.stage==='submit-unpaid').length!==1||c.steps.at(-1).stage!=='submit-unpaid'||c.steps.filter(s=>s.kind==='address').length!==1)throw Error('须含一次地址核对和唯一最终未付款提交');
 if(!purchaseLocationMatches(c.url,c.steps[0]))throw Error('首步路径必须与起始商品链接完全相同');
 for(let i=0;i<c.steps.length-1;i++){const next=nextPurchaseLocation(c.steps[i]),actual=c.steps[i+1];if(next.path!==actual.path||next.origin!==actual.origin||JSON.stringify(next.query??{})!==JSON.stringify(actual.query??{}))throw Error('相邻步骤须以明确的 nextPath、来源和静态参数连接，不能任意跳转');}
 if(c.addressMode==='new'){const minimum=['phone','province','city','district','addressLine1'];const complete=ks=>minimum.every(k=>ks.includes(k))&&(ks.includes('fullName')||ks.includes('givenName')&&ks.includes('familyName'));for(const step of c.steps){if(step.kind==='address'&&!complete(step.fields.map(f=>f.key)))throw Error('新地址须完整映射姓名、手机、省、市、区和街道');if(step.addressConfirmation&&!complete(step.addressConfirmation.keys))throw Error('配送地址核对须覆盖姓名、手机、省、市、区和街道');}const mapped=c.steps.find(step=>step.kind==='address').fields.map(f=>f.key).sort();for(const step of c.steps)if(step.addressConfirmation&&(step.addressConfirmation.keys.length!==mapped.length||!mapped.every(k=>step.addressConfirmation.keys.includes(k))))throw Error('各阶段配送地址核对必须覆盖全部已填字段');}
 return c;
}
export function validatePurchaseAddress(raw,config){
 if(config.addressMode==='existing'){if(raw!==undefined&&raw!==null&&Object.keys(raw).length)throw Error('已选地址模式无需传入地址');return null;}
 keys(raw,Object.keys(ADDRESS_AUTOCOMPLETE),'会话地址');const address={};for(const [k,v]of Object.entries(raw))address[k]=text(v,'地址字段',300);
 const needed=new Set(config.steps.flatMap(s=>[...(s.fields??[]).map(f=>f.key),...(s.addressConfirmation?.keys??[])]));for(const k of needed)if(!address[k])throw Error('本次会话地址缺少已配置字段');if(!/^(?:\+?86[- ]?)?1[3-9]\d{9}$/u.test(address.phone??''))throw Error('请填写有效的中国大陆手机号码');if(address.postalCode&&!/^\d{6}$/u.test(address.postalCode))throw Error('邮政编码须为六位数字');return address;
}
export function purchaseEvidenceFault(c,index,e,now=Date.now()){
 const s=c?.steps?.[index];if(!s||c.mode!=='purchase'||!c.confirmedPurchase)return '购买计划或授权无效';
 if(!Number.isFinite(now)||now>=Date.parse(c.expiresAt))return '购买任务已过期';
 if(!e||!Number.isFinite(e.observedAt)||now-e.observedAt>5000||e.observedAt>now+1000)return '页面证据或电脑时钟异常';
 if(!purchaseLocationMatches(e.url,s))return '页面不在本步骤的精确授权路径';
 if(e.blocker||e.paymentCommit===true)return '页面存在登录、验证或支付承诺，请用户接手';
 if(!Array.isArray(e.ambiguity)||e.ambiguity.length)return '页面证据不唯一，请人工检查';
 if(s.stage==='configure'){
  if(normalizePurchaseText(e.model)!==c.model)return '规格配置页面型号缺失或不符';
  if(e.quantity!==undefined&&e.quantity!==null&&e.quantity!==c.quantity)return '规格配置数量与目标不符';
  if(e.itemPriceMinor!==undefined&&e.itemPriceMinor!==null&&(!Number.isSafeInteger(e.itemPriceMinor)||e.itemPriceMinor<=0||e.currency!==c.currency||e.itemPriceMinor*c.quantity>Math.round(c.maxTotal*100)))return '已知规格标价或货币异常，或超过上限';
  for(const prior of c.steps.slice(0,index).filter(x=>x.stage==='configure')){const field=prior.group==='dimensionColor'?'color':'storage';if(normalizePurchaseText(e[field])!==c[field])return '此前已选规格发生变化';}return null;
 }
 for(const k of ['model','storage','color','currency','region','delivery'])if(normalizePurchaseText(e[k])!==c[k])return `页面 ${k} 缺失或与配置不符`;
 if(e.quantity!==c.quantity||!Number.isInteger(e.quantity)||e.itemCount!==1)return '商品数量或购物袋项目不匹配，请人工核对';
 const final=['review','submit-unpaid'].includes(s.stage),price=final?e.totalMinor:e.itemPriceMinor;
 if(!Number.isSafeInteger(price)||price<=0||(final?price:price*c.quantity)>Math.round(c.maxTotal*100))return final?'完整订单总价缺失或超过上限':'商品标价缺失或乘数量超过上限';
 if(final&&(e.totalIncludesTaxShipping!==true||e.addressMatches!==true&&c.addressMode==='new'))return '完整含费总价或配送地址未核验';
 if(s.stage==='address'&&s.kind==='button'&&c.addressMode==='new'&&e.addressMatches!==true)return '继续前须核对完整配送地址';
 if(s.stage==='submit-unpaid'&&(e.noChargeText!==s.noChargeText||!positiveNoCharge(e.noChargeText)||e.paymentCommit!==false))return '没有明确无即时扣款证据，最终动作须由用户完成';
 return null;
}

export function validateAddressProfile(raw){
 keys(raw,Object.keys(ADDRESS_AUTOCOMPLETE),'本地地址预设');
 const keysList=Object.keys(raw),required=['phone','province','city','district','addressLine1'];
 if(!required.every(k=>keysList.includes(k))||!(keysList.includes('fullName')||keysList.includes('givenName')&&keysList.includes('familyName')))throw Error('本地地址预设须包含完整姓名、手机、省、市、区及街道');
 return validatePurchaseAddress(raw,{addressMode:'new',steps:[{fields:keysList.map(key=>({key})),addressConfirmation:{keys:keysList}}]});
}

export function createDuoSteps(config){
 if(!config||!purchaseURL(config.url)||!globalThis.AppleDuoReadonly.supportsURL(config.url)||new URL(config.url).search||config.model!=='iPhone Duo')throw Error('请先选择已记录的 iPhone Duo 商品链接与型号');
 const path=new URL(config.url).pathname;
 return [['dimensionColor','color'],['dimensionCapacity','storage']].map(([group,field])=>({stage:'configure',kind:'radio',adapter:'apple-duo',group,origin:PURCHASE_ORIGIN,path,target:{role:'radio',name:text(config[field],field,160)},evidence:{},confirm:{kind:'apple-selection'},timeoutMs:15000}));
}
