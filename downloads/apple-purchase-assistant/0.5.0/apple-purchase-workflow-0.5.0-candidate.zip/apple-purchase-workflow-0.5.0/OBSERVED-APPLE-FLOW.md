# Observed Apple China flow: bounded read-only adapter

## Scope and provenance

The parent task supplied live cloud-browser observations on 2026-10-16. This adapter implements a conservative reader for those observations; this implementation worker did not browse Apple, sign in, or submit an order. The tests reconstruct the reported semantic facts. They are not a copied production DOM or proof that every production container layout matches the test scaffolding.

Files owned by this change:

- `extension/apple-store-observed.js`: classic-script global `AppleStoreObserved`
- `test/apple-store-observed.test.mjs`: dependency-free semantic fixtures and regression tests
- This document

This module has no network calls, browser automation, timers, authentication, storage, address filling, payment behavior, or full checkout preset. Action descriptors are observations, not permission to use them. No existing runner/configuration/manifest files are changed by this worker.

## Verified pre-login observations

### Configuration

Exact mainland storefront base path:

`https://www.apple.com.cn/shop/buy-iphone/iphone-18-pro`

Observed selected SKU path:

`https://www.apple.com.cn/shop/buy-iphone/iphone-18-pro/mjt74ch/a`

Reported controls:

- Native radio accessible name `iPhone 18 Pro 6.3 英寸显示屏`
- Native radio accessible name `黑色`
- Native radio accessible name containing `256GB`
- Native radio accessible name `不折抵换购`, with observed ID `noTradeIn`
- Native radio accessible name `不加 AppleCare+ 服务计划`
- Button accessible name `添加到购物袋`

The reader uses live checked state for radios and semantic names. It does not infer checked state from attributes, select choices, or issue clicks. Separate radio labels are never combined into a supposedly observed product summary.

### Attach stage

Observed path and non-sensitive query contract:

`/shop/buy-iphone/iphone-18-pro?product=mjt74ch/a&step=attach`

Reported combined product text: `iPhone 18 Pro 256GB 黑色`.

Reported button: `查看购物袋`.

The request did not want accessories. This adapter does not choose or enumerate accessories and makes no claim that the bag contains none.

### Bag

Exact path: `https://www.apple.com.cn/shop/bag`.

Reported product heading: `iPhone 18 Pro 256GB 黑色`.

Reported native select accessible name: `数量`, current value `1`. Its ID was a runtime UUID. The reader resolves its current associated label or accessible name, never uses a hardcoded quantity ID, and never returns its runtime ID.

Reported totals:

- `小计`: RMB 9,999
- `运费`: 免费
- `总计`: RMB 9,999

The reader accepts each amount only beside one unique visible exact label in a conservative two-child semantic row. This row shape is a reader contract and test scaffolding, not an observed production selector. If the real DOM has different nesting, the corresponding amount remains missing. No `data-autom` selector was observed or assumed. Currency is scoped to this exact mainland storefront; the observed amount is not a claim that all taxes or all checkout fees are included.

Two checkout button IDs were observed:

- `shoppingCart.actions.navCheckout`
- `shoppingCart.actions.checkout`

The full accessible button names were not supplied, so descriptors use only these exact known IDs. The observed two-button bag yields `actions.checkout.status: "ambiguous"`, including when one button is disabled. It never selects whichever appears first. A unique visible matching control can be reported as ready or disabled, but this still supplies no authorization to click it.

One product heading and one quantity select do not prove that all cart line items are enumerated. Consequently `cart.itemCount` and `cart.noExtraItems` always remain `null`; `complete-cart-inventory` stays missing. Extra quantity controls block quantity reads. Complete independently verified inventory must be mapped before any purchasing workflow could rely on a clean-bag claim.

### Sign-in boundary

A reported manual/test click on the observed navigation checkout control reached the exact endpoint:

`https://secure6.www.apple.com.cn/shop/signIn`

The real redirect included session query parameters. They must not be copied into reports, config, logs, URLs returned by this module, or test fixtures. The tests use a synthetic sentinel to verify non-emission.

Observed login iframe metadata:

- ID `aid-auth-widget-iFrame`
- Name `aid-auth-widget`

The adapter reports the authentication boundary and the presence of this exact iframe metadata. It does not read iframe `src`, frame contents, passwords, OTPs, or any credential values. It does not sign in. Other numbered secure hosts and all unknown secure paths remain unsupported. The later verified `/shop/checkout` route is allowed for maintenance-only observation as described below.

## API and integration contract

Load `apple-store-observed.js` as a classic script. It defines:

```js
const facts = AppleStoreObserved.inspect(document, location.href, {
  model: 'iPhone 18 Pro',
  storage: '256GB',
  color: '黑色',
  quantity: 1
});
const supported = AppleStoreObserved.supportsURL(location.href);
```

Returned serializable keys:

- `supported`, `pageKind`: `configuration`, `attach`, `bag`, `sign-in`, `checkout-observation`, or `null`
- `product`: `summary`, `model`, `storage`, `color`, `matchesExpected`
- `selections`: on configuration only, five target options with `status`, fixed semantic `name`, live `selected`, and `enabled`
- `cart`: `quantity`, `quantityMatchesExpected`, `quantityControlCount`, `itemCount`, `noExtraItems`, `subtotalMinor`, `shippingMinor`, `totalMinor`, `currency`, `totalIncludesTaxShipping`
- `actions`: `addToBag`, `viewBag`, or `checkout`, with `status` and serializable `candidates`
- `blocker`, `preorderNoticeObserved`, `authenticationRequired`, `loginWidgetObserved`
- `ambiguity`, `evidenceMissing`

Unknown facts are `null`; missing option/action status is explicit. Native select value access occurs only after resolving exactly one visible `数量` select without ambiguous label references or sensitive-control metadata. No other select or any input/textarea value is read.

Product matching requires one complete exact normalized `iPhone 18 Pro 256GB 黑色` summary. The bag specifically requires a heading; configuration/attach may use an exact public leaf when no matching heading exists. Partial matches, Pro Max, different storage/color, duplicate summaries, and concatenated independent option labels do not establish the product.

No output contains elements, callbacks, full URLs, query strings, credentials, a final-submit target, or inferred checkout completion. Callers must not convert these facts into a purchase preset or populate missing complete-inventory, tax, delivery, address, no-charge, or final-submit evidence. The module may be displayed as optional observation metadata. It cannot by itself satisfy a purchase runner's authorization/evidence requirements.

## Observed maintenance interruption

The parent subsequently reported this exact visible notice:

`来得早，来得好。即将与你见面。北京时间晚8点接受预购。一会儿见。`

The actual refresh was a single manual browser refresh, not an extension refresh. This does not establish extension retry behavior or a successful order flow.

When the complete notice is found on a supported endpoint, including split visible text leaves, the adapter returns `blocker: "maintenance-preorder-paused"`, `preorderNoticeObserved: true`, no action candidates, and no partial product/cart facts. It does not infer a countdown, release date, deadline, timezone conversion, or scheduled action from the 8pm phrase. An isolated time phrase does not trigger a countdown or satisfy the complete notice match.

## Additional shipping observations: documentation only

The parent supplied subsequent live observations after sign-in and subsequently verified the exact route `https://secure6.www.apple.com.cn/shop/checkout` for both shipping and the maintenance notice. The adapter accepts this exact origin/path only for maintenance observation. It returns `checkout-stage-not-mapped` otherwise. None of the following facts are executable mappings:

- Fulfillment initially showed pickup. The browser worker chose radio `为我送货`; the alternative was `我要取货`.
- A region control was reported as `选择地区 编辑邮政编码`.
- Region tab IDs were reported as:
  - `checkout.fulfillment.deliveryTab.delivery.deliveryLocation.address.provinceCityDistrictTabsForCheckout.state`
  - `checkout.fulfillment.deliveryTab.delivery.deliveryLocation.address.provinceCityDistrictTabsForCheckout.city`
  - `checkout.fulfillment.deliveryTab.delivery.deliveryLocation.address.provinceCityDistrictTabsForCheckout.district`
- Region choices are user-specific and must not be hardcoded.
- Missing district selection prevented advancing.
- A button `继续填写送货地址` had ID `rs-checkout-continue-button-bottom`.
- Summary button ID `companionbar-button` had an accessible name containing `显示订单摘要： RMB 9,999`.
- Free standard shipping was described as 3–5 business days, weekday delivery 08:00–18:00, with a signature required.

The summary was not expanded. Its amount is not independently verified final-total evidence. No complete address-entry, payment, final-review, final-submit, order-confirmation, or no-charge DOM was observed. Nothing here proves that an unpaid order can be created, that the observed shipping promise applies to the final address, or that an end-to-end extension purchase succeeded.

## Validation

Run:

```sh
node --check extension/apple-store-observed.js
node --test test/apple-store-observed.test.mjs
```

The focused suite currently has 28 passing tests, covering the supplied observations and strict domain/path scope, dynamic quantity IDs, exact combined product matching, duplicate/ambiguous checkout controls, unique labelled amount pairing, duplicate quantity/labels/totals, invalid numbers, credentials and payment-value avoidance, hidden evidence, session-query non-emission, maintenance interruption, and plain serializable output. These are offline fixture tests, not a live production-browser compatibility claim or an end-to-end purchase test.
