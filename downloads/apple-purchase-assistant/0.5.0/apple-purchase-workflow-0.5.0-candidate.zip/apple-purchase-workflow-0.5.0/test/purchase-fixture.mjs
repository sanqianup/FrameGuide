export const path='/shop/buy-iphone/test-phone',url=`https://www.apple.com.cn${path}`;
export const selectedFingerprint='a'.repeat(64);
export const address={fullName:'Fixture Recipient',phone:'13800000000',province:'测试省',city:'测试市',district:'测试区',addressLine1:'测试街 1 号'};
export function config(extra={}){
 const evidence=Object.fromEntries(['model','storage','color','quantity','currency','region','delivery','itemCount','itemPrice','total','noCharge'].map(k=>[k,`#e-${k}`]));
 const common={path,evidence,timeoutMs:15000};
 return {mode:'purchase',confirmedPurchase:true,addressMode:'existing',url,region:'CN',regionConfirmed:true,model:'Fixture Phone',storage:'256GB',color:'测试白色',quantity:1,currency:'CNY',delivery:'国内配送',maxTotal:200,pollMs:1000,expiresAt:new Date(Date.now()+300000).toISOString(),steps:[
  {...common,stage:'add-to-bag',kind:'button',target:{role:'button',name:'加入购物袋',selector:'#add'},confirm:{selector:'#added',text:'已加入指定商品'}},
  {...common,stage:'address',kind:'address',addressConfirmation:{selector:'#destination'},confirm:{selector:'#address-done',text:'配送地址已核对'}},
  {...common,stage:'review',kind:'button',target:{role:'button',name:'核对信息',selector:'#review'},addressConfirmation:{selector:'#destination'},totalIncludesTaxShipping:{selector:'#complete-total',text:'总价包含税费和配送费'},confirm:{selector:'#review-done',text:'信息核对完成'}},
  {...common,stage:'submit-unpaid',kind:'button',target:{role:'button',name:'创建未付款订单',selector:'#submit'},addressConfirmation:{selector:'#destination'},totalIncludesTaxShipping:{selector:'#complete-total',text:'总价包含税费和配送费'},noChargeText:'创建未付款订单，不扣款',confirm:{selector:'#order-created',text:'订单已创建，待付款'}}
 ],...extra};
}
export function evidence(c,extra={}){return {observedAt:Date.now(),url:c.url,model:c.model,storage:c.storage,color:c.color,quantity:c.quantity,currency:c.currency,region:c.region,delivery:c.delivery,itemCount:1,itemPriceMinor:10000,totalMinor:10000,totalIncludesTaxShipping:true,addressMatches:true,addressComplete:true,addressFingerprint:selectedFingerprint,noChargeText:c.steps.at(-1).noChargeText.normalize('NFKC'),paymentCommit:false,ambiguity:[],...extra};}
