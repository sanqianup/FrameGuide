// Pure validation for explicitly authorized, non-transactional configuration clicks.
// An item-price ceiling is not an order-total verification or payment authorization.
import {DEFAULTS, validate} from './core.js';
import './apple-duo-readonly.js';

const normalize = value => String(value ?? '').normalize('NFKC').replace(/\s+/gu, ' ').trim();
const groups = Object.freeze({dimensionColor: 'color', dimensionCapacity: 'storage'});
const forbidden = /(?:check[\s_-]*out|add[\s_-]*(?:to[\s_-]*)?(?:bag|cart)|shopping|purchase|payment|place[\s_-]*order|submit|buy|order|cart|bag|pay|reserve|下单|订单|提交|付款|支付|结账|结算|购买|购物|加入|预订)/iu;
const plain = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const own = (value, key) => Object.prototype.hasOwnProperty.call(value, key);

function text(value, label, max = 160) {
  if (typeof value !== 'string' || !normalize(value) || value.length > max || /[\u0000-\u001f\u007f]/u.test(value)) {
    throw Error(`${label}须为明确且有效的文字`);
  }
  return normalize(value);
}

function selector(value, label, required = false) {
  if (value === undefined || value === '') {
    if (required) throw Error(`${label}必须填写独立的具体选择器`);
    return '';
  }
  const result = text(value, label, 300);
  if (/^(?:\*|html|body|:root)$/iu.test(result) || /[\\\u200b-\u200f\u202a-\u202e\u2060-\u206f]/u.test(result)) {
    throw Error(`${label}不允许宽泛或转义选择器`);
  }
  if (forbidden.test(result)) throw Error('禁止配置订单、付款、购物袋或结账相关选择器');
  return result;
}

function keysOnly(value, allowed, label) {
  if (!plain(value) || Object.keys(value).some(key => !allowed.includes(key))) throw Error(`${label}格式无效或含不支持的字段`);
}

function validateStep(raw, config, index) {
  const label = `第 ${index + 1} 步`;
  keysOnly(raw, ['kind', 'name', 'selector', 'group', 'confirm', 'timeoutMs'], label);
  if (!['radio', 'button'].includes(raw.kind)) throw Error(`${label}仅支持 radio 或 button`);
  const name = text(raw.name, `${label}目标名称`);
  if (forbidden.test(name)) throw Error('订单提交、付款、加入购物袋和结账动作尚未实现，不允许配置');
  const actionSelector = selector(raw.selector, `${label}目标选择器`);
  const timeoutMs = raw.timeoutMs === undefined ? 10000 : raw.timeoutMs;
  if (!Number.isInteger(timeoutMs) || timeoutMs < 1000 || timeoutMs > 30000) throw Error('每步超时须为 1000 至 30000 毫秒');
  const result = {kind: raw.kind, name, timeoutMs};
  if (actionSelector) result.selector = actionSelector;
  if (raw.kind === 'radio') {
    if (!own(groups, raw.group)) throw Error('仅支持已观察的 dimensionColor 和 dimensionCapacity 单选组');
    if (name !== config[groups[raw.group]]) throw Error('单选目标必须与用户填写的精确颜色或容量相同');
    const confirmation = raw.confirm === undefined ? {kind: 'checked'} : raw.confirm;
    keysOnly(confirmation, ['kind'], `${label}确认条件`);
    if (confirmation.kind !== 'checked') throw Error('规格单选必须以目标 checked 状态确认');
    result.group = raw.group;
    result.confirm = {kind: 'checked'};
  } else {
    if (raw.group !== undefined) throw Error('按钮步骤不得设置单选组');
    keysOnly(raw.confirm, ['kind', 'selector', 'text'], `${label}确认条件`);
    if (!['visible', 'text'].includes(raw.confirm.kind)) throw Error('按钮必须有独立的可见或文字后置条件');
    const confirmationSelector = selector(raw.confirm.selector, `${label}确认条件`, true);
    if (confirmationSelector === actionSelector) throw Error('按钮后置条件必须独立于按钮本身');
    result.confirm = {kind: raw.confirm.kind, selector: confirmationSelector};
    if (raw.confirm.kind === 'text') {
      result.confirm.text = text(raw.confirm.text, `${label}确认文字`, 300);
      if (result.confirm.text === name || forbidden.test(result.confirm.text)) throw Error('按钮确认文字须为独立的非交易状态');
    } else if (raw.confirm.text !== undefined) throw Error('visible 确认条件不支持 text 字段');
  }
  return result;
}

export function validateAssist(raw, now = Date.now()) {
  if (!plain(raw) || raw.mode !== 'assist') throw Error('请明确选择官网配置自动点击模式');
  if (raw.confirmedAssist !== true) throw Error('请勾选授权本次非交易配置点击；订单和付款仍须手动完成');
  if (!Number.isFinite(now)) throw Error('电脑时间无效');
  // URL and exact desired specification must be supplied, never invented from a SKU.
  if (typeof raw.url !== 'string' || !globalThis.AppleDuoReadonly.supportsURL(raw.url)) throw Error('仅支持已核验的 www.apple.com.cn iPhone Duo 商品配置链接');
  const url = new URL(raw.url);
  if (url.hash) throw Error('商品链接不得包含片段');
  for (const key of ['model', 'storage', 'color']) text(raw[key], `请填写 ${key}`);
  // Retain a well-formed sale-time reference for the other modes, but this
  // mode starts on the user's click. Its expiry is measured from now, never
  // from an inherited future sale time that is not used for scheduling.
  const referenceTarget = raw.targetTime ?? '';
  if (typeof referenceTarget !== 'string' || (referenceTarget &&
      (!/(Z|[+-]\d{2}:\d{2})$/.test(referenceTarget) || !Number.isFinite(Date.parse(referenceTarget))))) {
    throw Error('时间须包含 UTC 偏移量，例如 +08:00');
  }
  const effective = {...DEFAULTS, ...raw,
    targetTime: new Date(now).toISOString(),
    expiresAt: raw.expiresAt || new Date(now + 30 * 60 * 1000).toISOString(),
    mode: 'simulate'};
  const config = validate(effective, now);
  config.targetTime = referenceTarget || effective.targetTime;
  if (Date.parse(config.expiresAt) <= now) throw Error('自动点击过期时间已到，请重新设置');
  if (!config.regionConfirmed || config.region !== 'CN' || config.currency !== 'CNY') throw Error('当前自动点击仅支持已确认的中国大陆站及 CNY 商品标价');
  for (const key of ['model', 'storage', 'color']) config[key] = normalize(config[key]);
  config.mode = 'assist';
  config.confirmedAssist = true;
  config.quantitySelector = selector(raw.quantitySelector, '页面数量选择器');

  let steps;
  if (typeof raw.assistSteps === 'string' && raw.assistSteps.trim()) {
    if (raw.assistSteps.length > 16000) throw Error('自定义步骤过长');
    try { steps = JSON.parse(raw.assistSteps); } catch { throw Error('自定义步骤必须是有效 JSON 数组'); }
  } else if (raw.assistSteps !== undefined && typeof raw.assistSteps !== 'string') {
    throw Error('自定义步骤须为 JSON 文字');
  } else if (raw.steps !== undefined && !(typeof raw.assistSteps === 'string' && !raw.assistSteps.trim())) {
    steps = raw.steps;
  } else {
    steps = [
      {kind: 'radio', group: 'dimensionColor', name: config.color},
      {kind: 'radio', group: 'dimensionCapacity', name: config.storage},
    ];
  }
  if (!Array.isArray(steps) || steps.length < 1 || steps.length > 8) throw Error('步骤须为包含 1 至 8 项的数组');
  config.steps = Array.from(steps, (step, index) => validateStep(step, config, index));
  // The serialized canonical plan is the sole execution source after validation.
  delete config.assistSteps;
  return config;
}

function sameProduct(left, right) {
  try {
    const a = new URL(left), b = new URL(right);
    return a.origin === b.origin && a.pathname.split('/').slice(0, 4).join('/') === b.pathname.split('/').slice(0, 4).join('/');
  } catch { return false; }
}

export function assistStepEvidenceFault(config, stepIndex, evidence, now = Date.now()) {
  const step = config?.steps?.[stepIndex];
  if (config?.mode !== 'assist' || config?.confirmedAssist !== true || !Number.isInteger(stepIndex) || !step) return '自动点击计划或授权无效';
  if (!Number.isFinite(now) || !Number.isFinite(Date.parse(config.expiresAt)) || now >= Date.parse(config.expiresAt)) return '自动点击任务已过期';
  if (!evidence || !Number.isFinite(evidence.observedAt) || now - evidence.observedAt > 5000 || evidence.observedAt > now + 1000) return '页面证据或电脑时钟异常';
  if (!globalThis.AppleDuoReadonly.supportsURL(evidence.url) || !sameProduct(config.url, evidence.url)) return '页面离开已授权的商品配置范围';
  if (evidence.blocker) return String(evidence.blocker);
  if (Array.isArray(evidence.ambiguity) && evidence.ambiguity.length) return '商品页面证据不唯一，请人工检查';
  if (normalize(evidence.model) !== config.model) return '页面型号缺失或与配置不符';
  for (let prior = 0; prior < stepIndex; prior++) {
    const completed = config.steps[prior];
    if (completed.kind === 'radio') {
      const field = groups[completed.group];
      if (normalize(evidence[field]) !== config[field]) return `此前已选 ${field} 发生变化，后续点击已暂停`;
    }
  }
  if (evidence.quantity !== undefined && evidence.quantity !== null && (!Number.isInteger(evidence.quantity) || evidence.quantity !== config.quantity)) return '页面实际数量与配置不符';
  const priceKnown = evidence.itemPriceMinor !== null && evidence.itemPriceMinor !== undefined;
  if (priceKnown && (!Number.isSafeInteger(evidence.itemPriceMinor) || evidence.itemPriceMinor <= 0)) return '商品标价无效';
  if (priceKnown && evidence.itemCurrency !== config.currency) return '商品标价货币缺失或与配置不符';
  if (priceKnown && evidence.itemPriceMinor * config.quantity > Math.round(Number(config.maxTotal) * 100)) return '商品标价乘数量超过上限；最终含费总价仍未核验';
  if (step.kind === 'button') {
    if (!Number.isInteger(evidence.quantity) || evidence.quantity !== config.quantity) return '无法验证页面实际数量，按钮点击已暂停';
    if (!priceKnown) return '无法验证商品标价，按钮点击已暂停';
    for (const key of ['color', 'storage']) if (normalize(evidence[key]) !== config[key]) return `页面 ${key} 未选择目标规格，按钮点击已暂停`;
  }
  return null;
}
