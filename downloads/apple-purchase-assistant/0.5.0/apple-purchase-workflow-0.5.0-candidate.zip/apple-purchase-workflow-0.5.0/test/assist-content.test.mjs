import { test } from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import fs from 'node:fs';

const sources = ['dom-driver.js', 'apple-duo-readonly.js', 'assist-content.js'].map(file =>
  fs.readFileSync(new URL(`../extension/${file}`, import.meta.url), 'utf8'));
const PRODUCT = 'https://www.apple.com.cn/shop/buy-iphone/iphone-duo';

class Element {
  constructor(doc, tag, text = '', attrs = {}) {
    this.ownerDocument = doc; this.tagName = tag.toUpperCase(); this.nodeType = 1;
    this.ownText = text; this.attributes = new Map(Object.entries(attrs));
    this.children = []; this.parentElement = null; this.checked = false; this.disabled = false; this.hidden = false;
    this.style = { display: 'block', visibility: 'visible', opacity: '1', contentVisibility: 'visible' };
    this.clicks = 0; this.onClick = null;
    Object.defineProperty(this, 'value', { get() { assert.fail('Input value must never be read'); } });
  }
  get textContent() { return this.ownText + this.children.map(child => child.textContent).join(''); }
  set textContent(value) { this.ownText = String(value); this.children = []; }
  get innerText() { return this.textContent; }
  get isConnected() { return this.ownerDocument.contains(this); }
  getAttribute(name) { assert.notEqual(name, 'value'); return this.attributes.get(name) ?? null; }
  getAttributeNames() { return [...this.attributes.keys()]; }
  hasAttribute(name) { return this.attributes.has(name); }
  setAttribute(name, value) { this.attributes.set(name, String(value)); }
  removeAttribute(name) { this.attributes.delete(name); }
  addEventListener(name, handler) { if (name === 'click') this.onClick = handler; }
  append(...nodes) { for (const node of nodes) { node.remove(); node.parentElement = this; this.children.push(node); } }
  remove() { if (this.parentElement) this.parentElement.children = this.parentElement.children.filter(node => node !== this); this.parentElement = null; }
  contains(node) { return node === this || this.children.some(child => child.contains(node)); }
  matches(selector) {
    if (selector.includes(',')) return selector.split(',').some(part => this.matches(part.trim()));
    if (selector === '*') return true;
    if (selector === ':disabled') return this.disabled || !!this.closest('fieldset')?.disabled;
    if (/^#[\w-]+$/u.test(selector)) return this.getAttribute('id') === selector.slice(1);
    const match = /^(\w+)?(?:\[([\w-]+)(?:="([^"]*)")?\])?$/u.exec(selector);
    if (!match) throw Error(`Unsupported mock selector: ${selector}`);
    return (!match[1] || this.tagName.toLowerCase() === match[1]) &&
      (!match[2] || (this.hasAttribute(match[2]) && (match[3] === undefined || this.getAttribute(match[2]) === match[3])));
  }
  closest(selector) { for (let node = this; node; node = node.parentElement) if (node.matches(selector)) return node; return null; }
  querySelectorAll(selector) { return this.children.flatMap(child => [...(child.matches(selector) ? [child] : []), ...child.querySelectorAll(selector)]); }
  getClientRects() { return this.isConnected && !this.hidden && this.style.display !== 'none' ? [{}] : []; }
  click() {
    this.clicks++;
    if (this.tagName === 'INPUT' && this.getAttribute('type') === 'radio') {
      if (!this.preventDefaultSelection) {
        for (const node of this.ownerDocument.querySelectorAll('input[type="radio"]')) if (node.getAttribute('name') === this.getAttribute('name')) node.checked = node === this;
      }
    }
    this.onClick?.();
    this.ownerDocument.events.change?.();
  }
}

function harness() {
  let now = 1000, listener, observer, response, timerId = 0;
  const sent = [], timers = new Map(), events = {};
  const document = {
    nodeType: 9, visibilityState: 'visible', events: {},
    defaultView: { getComputedStyle: node => node.style },
    create(tag, text = '', attrs = {}) { return new Element(this, tag, text, attrs); },
    createElement(tag) { return new Element(this, tag); },
    contains(node) { return node === this || this.body.contains(node); },
    querySelectorAll(selector) { return [...(this.body.matches(selector) ? [this.body] : []), ...this.body.querySelectorAll(selector)]; },
    getElementById(id) { return this.querySelectorAll('[id]').find(node => node.getAttribute('id') === id) ?? null; },
    addEventListener(name, handler) { this.events[name] = handler; }
  };
  Object.defineProperty(document, 'cookie', { get() { assert.fail('Cookies must never be read'); } });
  document.body = document.create('body');
  const main = document.create('main'), heading = document.create('h1', 'iPhone Duo');
  const price = document.create('span', 'RMB 100.00', { 'data-autom': 'full-price' });
  const quantity = document.create('span', '1', { id: 'quantity-summary' });
  const button = document.create('button', '继续', { type: 'button', id: 'continue-button' });
  const next = document.create('section', '下一步已显示', { id: 'next-panel' }); next.hidden = true;
  const summary = document.create('span', 'iPhone Duo', { 'data-autom': 'summary-productName' });
  document.body.append(main); main.append(heading, price, quantity, button, next, summary);
  const reflectApp = () => {
    const selected = group => document.querySelectorAll('input[type="radio"]').find(node => node.getAttribute('name') === group && node.checked);
    const label = node => node ? document.querySelectorAll('label').find(item => item.getAttribute('for') === node.getAttribute('id') || item.contains(node))?.textContent ?? '' : '';
    summary.ownText = `iPhone Duo ${label(selected('dimensionCapacity'))} ${label(selected('dimensionColor'))}`.replace(/\s+/gu, ' ').trim();
  };
  function option(group, name, id) {
    const input = document.create('input', '', { type: 'radio', name: group, id });
    const label = document.create('label', name, { for: id });
    input.onClick = reflectApp;
    main.append(input, label); return { input, label };
  }
  const colors = [option('dimensionColor', '星光白色', 'color-white'), option('dimensionColor', '夜空色', 'color-dark')];
  const capacities = [option('dimensionCapacity', '256GB', 'capacity-256'), option('dimensionCapacity', '512GB', 'capacity-512')];
  const config = {
    mode: 'assist', confirmedAssist: true, url: PRODUCT, model: 'iPhone Duo', color: '星光白色', storage: '256GB',
    quantity: 1, maxTotal: '1000', expiresAt: new Date(100000).toISOString(), pollMs: 1000,
    steps: [
      { kind: 'radio', group: 'dimensionColor', name: '星光白色', confirm: { kind: 'checked' }, timeoutMs: 10000 },
      { kind: 'radio', group: 'dimensionCapacity', name: '256GB', confirm: { kind: 'checked' }, timeoutMs: 10000 }
    ]
  };
  const context = {
    URL, document, location: { href: PRODUCT }, Date: class extends Date { static now() { return now; } },
    queueMicrotask, setTimeout: (fn, ms) => { timers.set(++timerId, { fn, ms }); return timerId; }, clearTimeout: id => timers.delete(id),
    MutationObserver: class { constructor(fn) { this.fn = fn; } observe() { observer = this; } disconnect() { if (observer === this) observer = null; } },
    addEventListener: (name, fn) => { events[name] = fn; },
    fetch: () => { assert.fail('No network requests are allowed'); },
    chrome: { runtime: { id: 'extension-id', onMessage: { addListener: fn => { listener = fn; } }, sendMessage: async message => {
      sent.push(message);
      const custom = response?.(message);
      if (custom !== undefined) return custom;
      if (message.type === 'ASSIST_CLAIM') return { ok: true, action: 'assist-click', state: 'SUBMITTING', claimToken: `claim-${message.stepIndex}`, deadline: now + 10000 };
      if (message.type === 'ASSIST_CHECK') return { ok: true, allowed: true, state: 'SUBMITTING', deadline: now + 10000 };
      if (['ASSIST_RESULT', 'ASSIST_SKIP'].includes(message.type)) return { ok: true, state: message.outcome === 'unknown' ? 'UNKNOWN' : message.stepIndex === config.steps.length - 1 ? 'DONE' : 'WAITING', stepIndex: message.stepIndex + 1 };
      return { ok: true, state: 'PAUSED' };
    } } }
  };
  vm.createContext(context); sources.forEach(source => vm.runInContext(source, context));
  const settle = async () => { for (let i = 0; i < 100; i++) await Promise.resolve(); };
  const start = (id = 'task', sender = 'extension-id') => { let result; listener({ type: 'START_ASSISTING', taskId: id, config }, { id: sender }, reply => { result = reply; }); return result; };
  const buttonStep = () => {
    colors[0].input.checked = capacities[0].input.checked = true;
    reflectApp();
    config.quantitySelector = '#quantity-summary';
    config.steps = [{ kind: 'button', name: '继续', selector: '#continue-button', confirm: { kind: 'visible', selector: '#next-panel' }, timeoutMs: 10000 }];
  };
  return { context, document, main, heading, price, quantity, button, next, summary, reflectApp, colors, capacities, config, sent, timers, events, start, settle, buttonStep,
    mutate: () => observer?.fn([]), setResponse: fn => { response = fn; }, setNow: value => { now = value; },
    fireTimer: async () => { const first = timers.entries().next().value; if (first) { timers.delete(first[0]); now += first[1].ms; first[1].fn(); await settle(); } },
    halt: () => listener({ type: 'HALT', taskId: 'task' }, { id: 'extension-id' }, () => {}) };
}

test('user-started default radios claim, check, click once and confirm without treating price as order total', async () => {
  const h = harness(); assert.equal(h.start().ok, true); await h.settle();
  assert.equal(h.colors[0].input.clicks, 1); assert.equal(h.capacities[0].input.clicks, 1); assert.equal(h.button.clicks, 0);
  assert.deepEqual(h.sent.map(message => message.type), ['ASSIST_CLAIM', 'ASSIST_CHECK', 'ASSIST_RESULT', 'ASSIST_CLAIM', 'ASSIST_CHECK', 'ASSIST_RESULT']);
  const evidence = h.sent[0].evidence;
  assert.equal(evidence.itemPriceMinor, 10000); assert.equal(evidence.itemCurrency, 'CNY'); assert.equal(evidence.quantity, null);
  assert.equal('totalMinor' in evidence, false); assert.equal(h.timers.size, 0);
  for (let i = 0; i < 20; i++) h.mutate(); await h.settle(); assert.equal(h.sent.length, 6);
});

test('already checked native radios advance via skip, including a disabled checked radio', async () => {
  const h = harness(); h.colors[0].input.checked = h.capacities[0].input.checked = true; h.colors[0].input.disabled = true;
  h.reflectApp();
  h.start(); await h.settle(); assert.deepEqual(h.sent.map(message => message.type), ['ASSIST_SKIP', 'ASSIST_SKIP']);
  assert.equal(h.colors[0].input.clicks + h.capacities[0].input.clicks, 0);
});

test('never starts by injection, from another sender, without consent, or in another mode', async () => {
  const h = harness(); await h.settle(); assert.equal(h.sent.length, 0);
  assert.equal(h.start('untrusted', 'other-extension'), undefined); h.config.confirmedAssist = false; assert.equal(h.start().ok, false);
  h.config.confirmedAssist = true; h.config.mode = 'official-readonly'; assert.equal(h.start().ok, false); await h.settle(); assert.equal(h.sent.length, 0);
});

test('known SKU paths and product queries are accepted; unobserved SKU/hash paths are rejected', async () => {
  const h = harness(); h.context.location.href = `${PRODUCT}/mk2n4ch/a`; h.start(); await h.settle(); assert.equal(h.colors[0].input.clicks, 1);
  const q = harness(); q.context.location.href = PRODUCT + '?fnode=product'; assert.equal(q.start().ok, true); await q.settle(); assert.equal(q.colors[0].input.clicks, 1);
  for (const suffix of ['/unobserved/a', '#payment']) {
    const x = harness(); x.context.location.href = PRODUCT + suffix; assert.equal(x.start().ok, false); assert.equal(x.sent.length, 0);
  }
});

test('disabled radios wake immediately on input/change without subsecond polling or mutation floods', async () => {
  const h = harness(); h.colors[0].input.disabled = true; h.start(); await h.settle(); assert.equal(h.sent.length, 0);
  assert.deepEqual([...h.timers.values()].map(timer => timer.ms), [1000]);
  for (let i = 0; i < 50; i++) h.mutate(); await h.settle(); assert.equal(h.sent.length, 0);
  h.colors[0].input.disabled = false; h.document.events.input(); await h.settle(); assert.equal(h.colors[0].input.clicks, 1);
});

test('missing readiness times out without a click or continuing request loop', async () => {
  const h = harness(); h.colors[0].input.disabled = true; h.start(); await h.settle(); h.setNow(11000); h.mutate(); await h.settle();
  assert.equal(h.sent.at(-1).type, 'ASSIST_STOP'); assert.match(h.sent.at(-1).reason, /not-ready/u); assert.equal(h.timers.size, 0);
});

test('ambiguous visible radio duplicates, including disabled duplicates, fail closed', async () => {
  const h = harness(); h.colors[1].label.ownText = '星光白色'; h.colors[1].input.disabled = true; h.start(); await h.settle();
  assert.equal(h.sent[0].type, 'ASSIST_STOP'); assert.equal(h.colors[0].input.clicks, 0);
});

test('visually hidden native radio uses its visible label but hidden ancestors remain rejected', async () => {
  const h = harness(); h.colors[0].input.style.opacity = '0'; h.start(); await h.settle(); assert.equal(h.colors[0].input.clicks, 1);
  const x = harness(); const hidden = x.document.create('section'); hidden.hidden = true; x.main.append(hidden); hidden.append(x.colors[0].input);
  x.start(); await x.settle(); assert.equal(x.colors[0].input.clicks, 0); assert.equal(x.sent.length, 0);
});

test('safe accessible names support aria-label, labelledby and direct wrapping labels without input values', async () => {
  const h = harness(); h.colors[0].input.setAttribute('aria-label', '星光白色');
  h.capacities[0].label.setAttribute('id', 'storage-label'); h.capacities[0].input.setAttribute('aria-labelledby', 'storage-label');
  h.start(); await h.settle(); assert.equal(h.capacities[0].input.clicks, 1);
  const x = harness(); x.colors[0].label.removeAttribute('for'); x.colors[0].label.append(x.colors[0].input);
  x.start(); await x.settle(); assert.equal(x.colors[0].input.clicks, 1);
});

test('exact name remains mandatory even with an explicit selector', async () => {
  const h = harness(); h.config.steps[0].selector = '#color-dark'; h.start(); await h.settle();
  assert.equal(h.colors[0].input.clicks + h.colors[1].input.clicks, 0); h.setNow(11000); h.mutate(); await h.settle(); assert.equal(h.sent.at(-1).type, 'ASSIST_STOP');
});

test('fresh target is resolved after both asynchronous authorization boundaries', async () => {
  const h = harness(); const old = h.colors[0].input; let intermediate, newest;
  const replace = () => { const previous = h.document.getElementById('color-white'); const node = h.document.create('input', '', Object.fromEntries(previous.attributes)); node.onClick = h.reflectApp; previous.remove(); h.main.append(node); return node; };
  h.setResponse(message => { if (message.stepIndex !== 0) return; if (message.type === 'ASSIST_CLAIM') intermediate = replace(); if (message.type === 'ASSIST_CHECK') newest = replace(); });
  h.start(); await h.settle(); assert.equal(old.clicks, 0); assert.equal(intermediate.clicks, 0); assert.equal(newest.clicks, 1);
});

test('halt during a delayed claim or check cannot click or revive a timer', async () => {
  for (const type of ['ASSIST_CLAIM', 'ASSIST_CHECK']) {
    const h = harness(); let release;
    h.setResponse(message => message.type === type ? new Promise(resolve => { release = resolve; }) : undefined);
    h.start(); await h.settle(); h.halt(); release({ ok: true, action: 'assist-click', claimToken: 'late', state: 'SUBMITTING', allowed: true }); await h.settle();
    assert.equal(h.colors[0].input.clicks, 0); assert.equal(h.timers.size, 0);
  }
});

test('late claim from old task never affects a separately user-started new task', async () => {
  const h = harness(); let release;
  h.setResponse(message => message.type === 'ASSIST_CLAIM' && message.taskId === 'task' ? new Promise(resolve => { release = resolve; }) : undefined);
  h.start(); await h.settle(); h.halt(); assert.equal(h.start('new-task').ok, true); await h.settle();
  release({ ok: true, action: 'assist-click', claimToken: 'old', state: 'SUBMITTING' }); await h.settle();
  assert.equal(h.colors[0].input.clicks, 1); assert.equal(h.capacities[0].input.clicks, 1);
});

test('an unconfirmed click times out as unknown and cannot retry by mutation or restarting the same task', async () => {
  const h = harness(); h.colors[0].input.preventDefaultSelection = true; h.start(); await h.settle(); assert.equal(h.colors[0].input.clicks, 1);
  for (let i = 0; i < 20; i++) h.mutate(); await h.settle(); assert.equal(h.colors[0].input.clicks, 1);
  h.setNow(11000); h.mutate(); await h.settle(); assert.equal(h.sent.at(-1).outcome, 'unknown'); assert.match(h.sent.at(-1).reason, /timeout/u);
  assert.equal(h.start().ok, false); assert.equal(h.timers.size, 0);
});

test('a throwing click is unknown, and pagehide/hidden stop immediately', async () => {
  const h = harness(); h.colors[0].input.onClick = () => { throw Error('handler failure'); }; h.start(); await h.settle();
  assert.equal(h.colors[0].input.clicks, 1); assert.equal(h.sent.at(-1).outcome, 'unknown');
  for (const event of ['pagehide', 'hidden']) {
    const x = harness(); x.colors[0].input.preventDefaultSelection = true; x.start(); await x.settle();
    if (event === 'pagehide') x.events.pagehide(); else { x.document.visibilityState = 'hidden'; x.document.events.visibilitychange(); }
    await x.settle(); assert.equal(x.sent.at(-1).outcome, 'unknown'); assert.equal(x.timers.size, 0);
  }
});

test('a denied second-stage authorization and price/spec changes prevent click after claim', async () => {
  for (const mutation of ['denied', 'price', 'model', 'url']) {
    const h = harness(); h.setResponse(message => {
      if (message.type !== 'ASSIST_CHECK') return;
      if (mutation === 'denied') return { ok: true, allowed: false };
      if (mutation === 'price') h.price.ownText = 'RMB 99999';
      if (mutation === 'model') h.heading.ownText = 'Other phone';
      if (mutation === 'url') h.context.location.href = 'https://www.apple.com.cn/shop/bag';
    });
    h.start(); await h.settle(); assert.equal(h.colors[0].input.clicks, 0, mutation); assert.equal(h.sent.at(-1).outcome, 'unknown', mutation);
  }
});

test('known excessive product price blocks radios; missing price does not invent order total', async () => {
  const h = harness(); h.price.ownText = 'RMB 1,001'; h.start(); await h.settle(); assert.equal(h.sent[0].type, 'ASSIST_STOP'); assert.equal(h.colors[0].input.clicks, 0);
  const x = harness(); x.price.remove(); x.start(); await x.settle(); assert.equal(x.colors[0].input.clicks, 1); assert.equal(x.sent[0].evidence.itemPriceMinor, null);
});

test('explicit Continue button requires visible quantity and item price, then confirms an independent transition', async () => {
  const h = harness(); h.buttonStep(); h.button.onClick = () => { h.next.hidden = false; h.button.remove(); }; h.start(); await h.settle();
  assert.equal(h.button.clicks, 1); assert.equal(h.sent.at(-1).outcome, 'confirmed'); assert.equal(h.sent[0].evidence.quantity, 1);
  for (const field of ['quantity', 'price']) {
    const x = harness(); x.buttonStep(); x[field].remove(); x.start(); await x.settle(); assert.equal(x.button.clicks, 0); assert.equal(x.sent[0].type, 'ASSIST_STOP');
  }
});

test('button postcondition must start unfulfilled and cannot be target, ancestor, or descendant', async () => {
  for (const variant of ['already', 'target', 'ancestor', 'descendant']) {
    const h = harness(); h.buttonStep();
    if (variant === 'already') h.next.hidden = false;
    if (variant === 'target') h.config.steps[0].confirm.selector = 'button';
    if (variant === 'ancestor') { h.main.setAttribute('id', 'main'); h.config.steps[0].confirm.selector = '#main'; }
    if (variant === 'descendant') { const span = h.document.create('span', '', { id: 'button-child' }); h.button.append(span); h.config.steps[0].confirm.selector = '#button-child'; }
    h.start(); await h.settle(); assert.equal(h.button.clicks, 0, variant); assert.equal(h.sent[0].type, 'ASSIST_STOP', variant);
  }
});

test('text postcondition needs exact before/after text and never reads editable or sensitive controls', async () => {
  const h = harness(); h.buttonStep(); h.next.hidden = false; h.next.ownText = '等待'; h.config.steps[0].confirm = { kind: 'text', selector: '#next-panel', text: '准备好' };
  h.button.onClick = () => { h.next.ownText = '准备好'; }; h.start(); await h.settle(); assert.equal(h.button.clicks, 1); assert.equal(h.sent.at(-1).outcome, 'confirmed');
  const x = harness(); x.buttonStep(); x.quantity.remove(); x.main.append(x.document.create('input', '', { id: 'quantity-summary', type: 'text' }));
  x.start(); await x.settle(); assert.equal(x.button.clicks, 0); assert.match(x.sent[0].reason, /unsafe-quantity/u);
});

test('transaction, authentication and legal step names/selectors and submit form targets are prohibited', async () => {
  for (const name of ['Add to Bag', 'Buy now', 'Pay', 'Place Order', '立即购买', '加入购物袋', '提交订单', '同意条款', '登录']) {
    const h = harness(); h.buttonStep(); h.config.steps[0].name = name; assert.equal(h.start().ok, false, name);
  }
  for (const variant of ['submit', 'form', 'metadata']) {
    const h = harness(); h.buttonStep();
    if (variant === 'submit') h.button.setAttribute('type', 'submit');
    if (variant === 'form') { const form = h.document.create('form'); h.main.append(form); form.append(h.button); }
    if (variant === 'metadata') h.button.setAttribute('data-action', 'checkout');
    h.start(); await h.settle(); assert.equal(h.button.clicks, 0, variant); assert.match(h.sent[0].reason, /unsafe/u);
  }
});

test('visible CAPTCHA, login, terms and payment fields halt without reading their values', async () => {
  for (const variant of ['password', 'cc-number', 'captcha', 'terms', 'login']) {
    const h = harness(); let node;
    if (variant === 'password') node = h.document.create('input', '', { type: 'password' });
    if (variant === 'cc-number') node = h.document.create('input', '', { autocomplete: 'cc-number' });
    if (variant === 'captcha') node = h.document.create('iframe', '', { title: 'captcha' });
    if (variant === 'terms') node = h.document.create('p', '同意服务条款');
    if (variant === 'login') node = h.document.create('h2', '登录');
    h.main.append(node); h.start(); await h.settle(); assert.equal(h.colors[0].input.clicks, 0, variant); assert.equal(h.sent[0].type, 'ASSIST_STOP', variant);
  }
});

test('native checked toggle without a hydrated application handler never confirms or retries', async () => {
  const h = harness(); h.colors[0].input.onClick = null; h.start(); await h.settle();
  assert.equal(h.colors[0].input.checked, true); assert.equal(h.colors[0].input.clicks, 1);
  assert.equal(h.sent.some(message => message.type === 'ASSIST_RESULT'), false);
  assert.equal(h.capacities[0].input.clicks, 0);
  h.setNow(11000); h.mutate(); await h.settle();
  assert.equal(h.sent.at(-1).outcome, 'unknown'); assert.equal(h.colors[0].input.clicks, 1);
});

test('capacity checked requires a newly matching full model/storage/color application summary', async () => {
  const h = harness(); h.capacities[0].input.onClick = null; h.start(); await h.settle();
  assert.equal(h.colors[0].input.clicks, 1); assert.equal(h.capacities[0].input.checked, true);
  assert.equal(h.sent.filter(message => message.type === 'ASSIST_RESULT').length, 1);
  h.summary.ownText = 'iPhone Duo 1256GB 星光白色'; h.mutate(); await h.settle();
  assert.equal(h.sent.filter(message => message.type === 'ASSIST_RESULT').length, 1, 'substring capacity is not a match');
  h.setNow(11000); h.mutate(); await h.settle(); assert.equal(h.sent.at(-1).outcome, 'unknown');
});

test('color can confirm from newly enabled desired capacity, without inventing a summary', async () => {
  const h = harness(); h.config.steps = [h.config.steps[0]]; h.capacities.forEach(option => { option.input.disabled = true; });
  h.colors[0].input.onClick = () => { h.capacities[0].input.disabled = false; };
  h.start(); await h.settle(); assert.equal(h.sent.at(-1).outcome, 'confirmed'); assert.equal(h.summary.ownText, 'iPhone Duo');
});

test('already checked selections without corresponding application state are never skipped', async () => {
  const h = harness(); h.colors[0].input.checked = true; h.capacities.forEach(option => { option.input.disabled = true; });
  h.start(); await h.settle(); assert.equal(h.sent.length, 0); h.setNow(11000); h.mutate(); await h.settle();
  assert.equal(h.sent[0].type, 'ASSIST_STOP'); assert.match(h.sent[0].reason, /application-confirmation/u);
});

test('page-level stop removes itself and immediately cancels a delayed claim', async () => {
  const h = harness(); let release;
  h.setResponse(message => message.type === 'ASSIST_CLAIM' ? new Promise(resolve => { release = resolve; }) : undefined);
  h.start(); await h.settle(); const stop = h.document.getElementById('apple-configuration-assist-stop-extension-id');
  assert.ok(stop); assert.equal(stop.textContent, '停止配置辅助'); stop.click();
  assert.equal(stop.isConnected, false); release({ ok: true, action: 'assist-click', claimToken: 'late', deadline: 11000, state: 'SUBMITTING' }); await h.settle();
  assert.equal(h.colors[0].input.clicks, 0); assert.equal(h.sent.at(-1).type, 'ASSIST_STOP'); assert.equal(h.timers.size, 0);
});

test('page-level stop immediately locks an already clicked uncertain step and disappears on success', async () => {
  const h = harness(); h.colors[0].input.onClick = null; h.start(); await h.settle();
  h.document.getElementById('apple-configuration-assist-stop-extension-id').click(); await h.settle();
  assert.equal(h.sent.at(-1).type, 'ASSIST_STOP'); assert.equal(h.colors[0].input.clicks, 1); assert.equal(h.timers.size, 0);
  const x = harness(); x.start(); await x.settle(); assert.equal(x.document.getElementById('apple-configuration-assist-stop-extension-id'), null);
});

test('missing or expired authoritative claim/check deadline prevents any click', async () => {
  for (const phase of ['ASSIST_CLAIM', 'ASSIST_CHECK']) for (const deadline of [undefined, 1000]) {
    const h = harness(); h.setResponse(message => message.type === phase ? { ok: true, action: 'assist-click', allowed: true, claimToken: 'expired', deadline, state: 'SUBMITTING' } : undefined);
    h.start(); await h.settle(); assert.equal(h.colors[0].input.clicks, 0); assert.equal(h.sent.at(-1).outcome, 'unknown');
  }
});

test('a delayed CHECK reply cannot extend the original durable claim deadline', async () => {
  const h = harness(); let release;
  h.setResponse(message => message.type === 'ASSIST_CHECK' ? new Promise(resolve => { release = resolve; }) : undefined);
  h.start(); await h.settle(); h.setNow(12000); release({ ok: true, allowed: true, state: 'SUBMITTING', deadline: 50000 }); await h.settle();
  assert.equal(h.colors[0].input.clicks, 0); assert.equal(h.sent.at(-1).outcome, 'unknown');
});

test('a button checks exact current specs after CHECK even with later corrective radio steps', async () => {
  const h = harness(); const later = h.config.steps[0]; h.buttonStep(); h.config.steps.push(later);
  h.setResponse(message => { if (message.type === 'ASSIST_CHECK') { h.colors[0].input.checked = false; h.colors[1].input.checked = true; h.reflectApp(); } });
  h.start(); await h.settle(); assert.equal(h.button.clicks, 0); assert.equal(h.sent.at(-1).outcome, 'unknown'); assert.match(h.sent.at(-1).reason, /color/u);
});

test('aria-label cannot mask transaction text, and separator variants in metadata are rejected', async () => {
  for (const variant of ['visible', 'cart', 'add_to_bag', 'check-out', 'reserve']) {
    const h = harness(); h.buttonStep();
    if (variant === 'visible') { h.button.setAttribute('aria-label', '继续'); h.button.ownText = '加入购物袋'; }
    else h.button.setAttribute('data-action', variant);
    h.start(); await h.settle(); assert.equal(h.button.clicks, 0); assert.equal(h.sent.at(-1).type, 'ASSIST_STOP');
  }
});

test('step limits match canonical validator and a late transition cannot turn timeout into success', async () => {
  for (const timeout of [999, 30001]) { const h = harness(); h.config.steps[0].timeoutMs = timeout; assert.equal(h.start().ok, false); }
  const h = harness(); h.colors[0].input.onClick = null; h.start(); await h.settle(); h.setNow(11000); h.reflectApp(); h.mutate(); await h.settle();
  assert.equal(h.sent.at(-1).outcome, 'unknown');
  const x = harness(); x.config.steps = Array(9).fill(x.config.steps[0]); assert.equal(x.start().ok, false);
});

test('duplicate START is rejected without silently abandoning an existing active task', async () => {
  const h = harness(); h.colors[0].input.disabled = true; h.start(); await h.settle(); assert.equal(h.start().ok, false);
  assert.ok(h.document.getElementById('apple-configuration-assist-stop-extension-id'));
  h.colors[0].input.disabled = false; h.document.events.change(); await h.settle(); assert.equal(h.colors[0].input.clicks, 1);
});

test('buttons with arbitrary navigation data, inline handlers or nonbutton roles stop safely', async () => {
  for (const [attribute, value] of [['data-destination', '/shop/bag'], ['onclick', 'advance()'], ['href', '/next'], ['role', 'link']]) {
    const h = harness(); h.buttonStep(); h.button.setAttribute(attribute, value); h.start(); await h.settle();
    assert.equal(h.button.clicks, 0); assert.equal(h.sent[0].type, 'ASSIST_STOP');
  }
});

test('application summary alone cannot confirm a step after the actual model heading disappears', async () => {
  const h = harness(); h.colors[0].input.onClick = () => { h.reflectApp(); h.heading.remove(); }; h.start(); await h.settle();
  assert.equal(h.colors[0].input.clicks, 1); assert.equal(h.sent.at(-1).outcome, 'unknown'); assert.equal(h.capacities[0].input.clicks, 0);
});
