// User-mapped purchase workflow. No merchant selectors, network calls, credential
// readers, payment actions, or guessed page transitions are built into this runner.
(() => {
  'use strict';
  if (globalThis.__applePurchaseController) return;
  const D = globalThis.AppleDOMDriver;
  const norm = value => String(value ?? '').normalize('NFKC').replace(/\s+/gu, ' ').trim();
  const terminal = new Set(['PAUSED', 'STOPPED', 'DONE', 'UNKNOWN']);
  const radioFields = Object.freeze({ dimensionColor: 'color', dimensionCapacity: 'storage' });
  const fieldTypes = Object.freeze({ fullName: 'name', givenName: 'given-name', familyName: 'family-name', phone: 'tel', email: 'email',
    addressLine1: 'address-line1', addressLine2: 'address-line2', city: 'address-level2', district: 'address-level3', province: 'address-level1', postalCode: 'postal-code' });
  const controls = /^(?:INPUT|TEXTAREA|SELECT|OPTION|SCRIPT|STYLE|NOSCRIPT)$/u;
  const secrets = /password|\b(?:passwd|pwd|otp|pin|cvv|cvc|ssn|pan)\b|social.?security|national.?id|identity.?number|id.?number|passport|tax.?id|护照|cc-number|cc-csc|cc-exp|credit.?card|card.?number|one-time-code|captcha|verification|身份证|银行卡|信用卡/iu;
  const policy = globalThis.PurchasePolicy;
  const positiveUnpaid = value => policy?.positiveNoCharge(value) === true;
  const paymentContradiction = value => policy?.paymentCommitment(value) !== false;
  const dangerousAction = value => policy?.unsafeAction(value) !== false;
  const seen = new Set(), attempts = new Set();
  let task = null, generation = 0, observer = null, timer = null, overlay = null, busy = false, queued = false, dirty = false;
  const visible = element => !!D?.isVisible(element);
  const ownUI = element => !!overlay?.contains?.(element);

  function selectorOK(value) {
    return typeof value === 'string' && value.length > 0 && value.length <= 300 &&
      !/^(?:\*|html|body|:root)$/iu.test(norm(value)) && !/[\\\u0000-\u001f\u200b-\u200f\u202a-\u202e\u2060-\u206f]/u.test(value) &&
      !/\[\s*value\b/iu.test(value);
  }
  function publicText(element, except = null) {
    if (!element || ownUI(element)) return null;
    for (let node = element; node; node = node.parentElement) {
      if (controls.test(node.tagName ?? '') || node.hasAttribute?.('contenteditable') || node.getAttribute?.('role') === 'textbox') return null;
    }
    if ([...element.querySelectorAll('*')].some(node => node !== except &&
      (controls.test(node.tagName ?? '') || node.hasAttribute?.('contenteditable') || node.getAttribute?.('role') === 'textbox'))) return null;
    // Reading textContent of an input's ancestor can never expose .value; still
    // reject all controls except the one explicitly associated with a label.
    return norm(element.textContent);
  }
  function nameOf(element) {
    const by = norm(element.getAttribute('aria-labelledby'));
    if (by) {
      const ids = by.split(' '), all = [...document.querySelectorAll('[id]')];
      if (new Set(ids).size !== ids.length) throw Error('ambiguous-label');
      const values = ids.map(id => {
        const nodes = all.filter(node => node.getAttribute('id') === id);
        if (nodes.length !== 1) throw Error('ambiguous-label');
        return publicText(nodes[0], element);
      });
      if (values.some(value => !value)) throw Error('unsafe-label');
      return norm(values.join(' '));
    }
    const aria = element.getAttribute('aria-label');
    if (aria !== null) return norm(aria);
    if (/^(?:INPUT|TEXTAREA|SELECT)$/u.test(element.tagName)) {
      const id = element.getAttribute('id');
      const labels = [...document.querySelectorAll('label')].filter(label => (id && label.getAttribute('for') === id) || label.contains(element));
      if (labels.length !== 1) throw Error('ambiguous-label');
      const text = publicText(labels[0], element);
      if (!text) throw Error('unsafe-label');
      return text;
    }
    return publicText(element) ?? '';
  }
  function readMapped(selector, label = 'evidence', required = true) {
    if (!selectorOK(selector)) throw Error(`invalid-${label}-selector`);
    const nodes = [...document.querySelectorAll(selector)].filter(node => visible(node) && !ownUI(node));
    if (nodes.length > 1) throw Error(`ambiguous-${label}`);
    if (!nodes.length) { if (required) throw Error(`missing-${label}`); return null; }
    const text = publicText(nodes[0]);
    if (text === null || text.length > 4000) throw Error(`unsafe-${label}-reader`);
    return { node: nodes[0], text };
  }
  function stageLocation(current, next = false) {
    const step = current.config.steps[current.index];
    if (next && step.confirm.nextPath) return { origin: step.confirm.nextOrigin ?? step.origin ?? 'https://www.apple.com.cn', path: step.confirm.nextPath, query: step.confirm.nextQuery };
    return { origin: step.origin ?? 'https://www.apple.com.cn', path: step.path, query: step.query };
  }
  function locationMatches(value, mapped) {
    try {
      const url = new URL(value);
      if (!['https://www.apple.com.cn', 'https://secure6.www.apple.com.cn'].includes(mapped.origin) ||
        url.origin !== mapped.origin || url.username || url.password || url.port || url.hash || url.pathname !== mapped.path || !/^\/shop(?:\/|$)/u.test(url.pathname)) return false;
      if (mapped.origin === 'https://secure6.www.apple.com.cn') return !mapped.query;
      const pairs = [...url.searchParams], expected = mapped.query ?? {};
      if (mapped.query && (!/^\/shop\/buy-iphone\/[a-z0-9-]+$/u.test(mapped.path) || Object.keys(expected).length !== 2 ||
        !/^[a-z0-9]{5,16}\/a$/iu.test(expected.product ?? '') || expected.step !== 'attach')) return false;
      return pairs.length === Object.keys(expected).length && Object.entries(expected).every(([key, value]) => url.searchParams.get(key) === value);
    } catch { return false; }
  }
  function fixtureActive(config) {
    if (config?.testMode !== true || typeof chrome.runtime.getURL !== 'function') return false;
    const exact = chrome.runtime.getURL('workflow-fixture.html');
    return /^chrome-extension:\/\/[a-p]{32}\/workflow-fixture\.html$/u.test(exact) && config.fixtureURL === exact && location.href === exact;
  }
  function stageMatches(current, next = false) {
    if (current.config.testMode === true) return fixtureActive(current.config) && !next && stageLocation(current).origin === 'https://www.apple.com.cn' && stageLocation(current).path === '/shop/fixture' && !stageLocation(current).query;
    return locationMatches(location.href, stageLocation(current, next));
  }
  function safeLocation() { if (task?.config.testMode === true) { if (!fixtureActive(task.config)) throw Error('invalid-local-fixture'); return 'https://www.apple.com.cn/shop/fixture'; } const url = new URL(location.href); return url.origin === 'https://secure6.www.apple.com.cn' ? url.origin + url.pathname : url.href; }
  function checkContext(current, next = false) {
    if (!stageMatches(current, next)) throw Error('url-outside-exact-stage');
    if (/\/(?:sign[-_]?in|log[-_]?in|auth|account)(?:\/|$)/iu.test(new URL(location.href).pathname)) throw Error('login-required');
    if (document.visibilityState !== 'visible') throw Error('page-hidden');
    if (Date.now() >= Date.parse(current.config.expiresAt)) throw Error('purchase-expired');
  }
  function metadata(element) {
    return ['type', 'name', 'autocomplete', 'id', 'title', 'aria-label', 'data-action', 'data-autom', 'href', 'formaction'].map(key => element.getAttribute(key) ?? '').join(' ');
  }
  function blocker() {
    for (const element of document.querySelectorAll('input,textarea,select,iframe,[role="checkbox"]')) {
      if (!visible(element) || ownUI(element)) continue;
      if (secrets.test(metadata(element))) return 'authentication-challenge-or-payment';
      if (element.tagName === 'INPUT' && element.getAttribute('type') === 'checkbox' && element.checked !== true || element.getAttribute('role') === 'checkbox' && element.getAttribute('aria-checked') !== 'true') {
        let name = ''; try { name = nameOf(element); } catch { /* an unnamed checkbox does not authorize anything */ }
        if (/terms|conditions|agreement|条款|协议/iu.test(name)) return 'new-terms-acceptance';
      }
    }
    for (const element of document.querySelectorAll('*')) {
      if (!visible(element) || ownUI(element)) continue;
      if (element.children?.length && !/^(?:P|DIV|SPAN|SECTION|LABEL|LI|H[1-6])$/u.test(element.tagName)) continue;
      const text = publicText(element);
      if (!text || text.length > 4000) continue;
      if (/来得早[，,]\s*来得好|即将与你见面|北京时间晚\s*8\s*点接受预购|一会儿见|we[’']?ll be right back|store is (?:currently )?(?:unavailable|being updated)|under maintenance|商店暂时关闭/iu.test(text)) return 'store-maintenance-or-prerelease-pause';
      if (/captcha|access denied|waiting room|unusual activity|人机验证|验证码|排队中|访问被拒绝|请求过于频繁/iu.test(text)) return 'challenge-or-access-restriction';
      if (/^(?:sign\s*in|log\s*in|登录|登陆)$|sign\s*in\s*to\s*continue|登录以继续/iu.test(text)) return 'login-required';
      if (/^(?:payment method|card number|Apple Pay|Face ID|Touch ID|付款方式|支付方式)$/iu.test(text)) return 'payment-requires-manual-action';
      if (paymentContradiction(text)) return 'payment-commitment-statement';
      if (element.matches('button,[role="button"],a[href]') && dangerousAction(text)) return 'payment-login-or-terms-action';
    }
    return null;
  }
  function checkDestination(element, current) {
    const step = current.config.steps[current.index];
    const allowed = [stageLocation(current), ...(step.confirm.nextPath ? [stageLocation(current, true)] : [])];
    const form = element.form || element.closest?.('form');
    for (const [node, key] of [[element, 'href'], [element, 'formaction'], [form, 'action']]) {
      if (!node) continue;
      const value = node.getAttribute(key);
      if (value === null || value === '') continue;
      let destination; try { destination = new URL(value, location.href).href; } catch { throw Error('unsafe-form-destination'); }
      if (current.config.testMode === true) {
        if (!fixtureActive(current.config) || destination !== current.config.fixtureURL) throw Error('fixture-navigation-forbidden');
        destination = 'https://www.apple.com.cn/shop/fixture';
      }
      if (!allowed.some(mapped => locationMatches(destination, mapped))) throw Error('unsafe-form-destination');
    }
    if (element.getAttribute('target') && element.getAttribute('target') !== '_self' || form?.getAttribute('target') && form.getAttribute('target') !== '_self') throw Error('new-context-destination');
    if (form) for (const control of form.querySelectorAll('input,textarea,select')) if (secrets.test(metadata(control))) throw Error('sensitive-form-control');
  }
  function resolveButton(current) {
    const step = current.config.steps[current.index], mapping = step.target;
    const nodes = [...document.querySelectorAll('button,input[type="button"],input[type="submit"],a[href],[role="button"]')];
    const matches = [];
    for (const node of nodes) {
      if (ownUI(node) || !visible(node) || mapping.selector && !node.matches(mapping.selector)) continue;
      if (nameOf(node) === norm(mapping.name)) matches.push(node);
    }
    if (matches.length > 1) throw Error('ambiguous-target');
    if (!matches.length) return { status: 'missing', element: null };
    const node = matches[0];
    if (dangerousAction(nameOf(node)) || dangerousAction(metadata(node)) || secrets.test(metadata(node))) throw Error('unsafe-target-action');
    const type = norm(node.getAttribute('type')).toLowerCase();
    if (node.tagName === 'INPUT' && !['button', 'submit'].includes(type) || node.tagName === 'BUTTON' && type === 'reset') throw Error('unsafe-target-kind');
    if (node.getAttribute('role') && node.getAttribute('role') !== 'button') throw Error('unsafe-target-role');
    checkDestination(node, current);
    return { status: D.isEnabled(node) ? 'ready' : 'disabled', element: node };
  }
  function resolveRadio(current) {
    const step = current.config.steps[current.index], matches = [];
    for (const node of document.querySelectorAll('input[type="radio"]')) {
      if (node.getAttribute('name') !== step.group || step.target.selector && !node.matches(step.target.selector)) continue;
      let hidden = false;
      for (let ancestor = node.parentElement; ancestor; ancestor = ancestor.parentElement) {
        const style = document.defaultView?.getComputedStyle?.(ancestor);
        if (ancestor.hidden || ancestor.getAttribute('aria-hidden') === 'true' || style && (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0')) hidden = true;
      }
      if (node.hidden || node.getAttribute('aria-hidden') === 'true' || hidden) continue;
      const id = node.getAttribute('id'), labels = [...document.querySelectorAll('label')].filter(label => id && label.getAttribute('for') === id || label.contains(node));
      if (!visible(node) && !labels.some(visible)) continue;
      if (nameOf(node) === norm(step.target.name)) matches.push(node);
    }
    if (matches.length > 1) throw Error('ambiguous-radio-target');
    if (!matches.length) return { status: 'missing', element: null };
    const node = matches[0]; if (secrets.test(metadata(node))) throw Error('unsafe-radio-target');
    return { status: D.isEnabled(node) ? 'ready' : 'disabled', element: node };
  }
  function resolveAction(current) {
    const kind = current.config.steps[current.index].kind;
    return kind === 'button' ? resolveButton(current) : kind === 'radio' ? resolveRadio(current) : { status: 'ready', element: null };
  }
  const fieldAliases = Object.freeze({
    fullName: ['姓名', '收货人', '收件人', 'Full name', 'Name'], givenName: ['名', '名字', 'Given name', 'First name'], familyName: ['姓', '姓氏', 'Family name', 'Last name'],
    phone: ['手机', '手机号', '手机号码', '联系电话', 'Phone', 'Phone number', 'Mobile'], email: ['电子邮件', '电子邮箱', 'Email', 'Email address'],
    addressLine1: ['街道地址', '详细地址', '地址', 'Address line 1', 'Street address'], addressLine2: ['地址第二行', '地址补充', 'Address line 2'],
    province: ['省', '省份', 'Province', 'State'], city: ['市', '城市', 'City'], district: ['区', '区县', 'District'], postalCode: ['邮政编码', '邮编', 'Postal code', 'ZIP code']
  });
  const addressOrder = ['fullName', 'givenName', 'familyName', 'phone', 'email', 'province', 'city', 'district', 'addressLine1', 'addressLine2', 'postalCode'];
  function fieldSemantics(node, field) {
    const autocomplete = norm(node.getAttribute('autocomplete')).toLowerCase(), tokens = autocomplete.split(' ').filter(Boolean);
    const standard = tokens.at(-1) === fieldTypes[field.key] && tokens.slice(0, -1).every(token => token === 'shipping' || /^section-[a-z0-9_-]+$/u.test(token));
    let name = ''; try { name = nameOf(node); } catch (error) { if (node.hasAttribute('aria-labelledby')) throw error; }
    const nativeName = norm(node.getAttribute('name'));
    if (field.name) return (name === norm(field.name) || !name && nativeName === norm(field.name)) && (standard || !autocomplete || ['off', 'on'].includes(autocomplete));
    if (standard) return true;
    if (autocomplete && !['off', 'on'].includes(autocomplete)) return false;
    const aliases = [...(fieldAliases[field.key] || []), field.key, fieldTypes[field.key]].map(value => norm(value).toLowerCase());
    return aliases.includes((name || nativeName).toLowerCase());
  }
  function resolveFields(current) {
    const step = current.config.steps[current.index], seenNodes = new Set();
    const fields = [...(step.fields || [])].sort((a, b) => addressOrder.indexOf(a.key) - addressOrder.indexOf(b.key));
    const result = fields.map(field => {
      if (!Object.hasOwn(fieldTypes, field.key) || field.autocomplete !== fieldTypes[field.key] || field.selector && !selectorOK(field.selector)) throw Error('unsafe-address-field-mapping');
      const candidates = [...document.querySelectorAll(field.selector || 'input,textarea,select')].filter(node => visible(node) && !ownUI(node));
      const nodes = candidates.filter(node => fieldSemantics(node, field));
      if (nodes.length > 1) throw Error('ambiguous-address-field');
      if (!nodes.length) {
        if (field.selector && candidates.length) throw Error('unsafe-address-field');
        return { field, node: null, writable: false };
      }
      const node = nodes[0], type = norm(node.getAttribute('type')).toLowerCase();
      if (seenNodes.has(node) || !['INPUT', 'TEXTAREA', 'SELECT'].includes(node.tagName) || node.tagName === 'INPUT' && !(['', 'text'].includes(type) || type === 'tel' && field.key === 'phone' || type === 'email' && field.key === 'email' || type === 'number' && ['phone', 'postalCode'].includes(field.key)) ||
        secrets.test(metadata(node)) || node.hasAttribute('contenteditable') || node.tagName === 'SELECT' && (node.multiple || node.hasAttribute('multiple'))) throw Error('unsafe-address-field');
      checkDestination(node, current); seenNodes.add(node);
      const constructor = node.tagName === 'INPUT' ? globalThis.HTMLInputElement : node.tagName === 'TEXTAREA' ? globalThis.HTMLTextAreaElement : globalThis.HTMLSelectElement;
      const descriptor = constructor && Object.getOwnPropertyDescriptor(constructor.prototype, 'value');
      if (typeof descriptor?.set !== 'function' || typeof descriptor?.get !== 'function') throw Error('native-address-setter-unavailable');
      return { field, node, descriptor, writable: !node.readOnly && !node.hasAttribute('readonly') && D.isEnabled(node) };
    });
    const forms = new Set(result.filter(item => item.node).map(item => item.node.form || item.node.closest?.('form')).filter(Boolean));
    for (const node of document.querySelectorAll('input,textarea,select,[aria-required="true"]')) {
      if (!visible(node) || ownUI(node) || !(node.required || node.hasAttribute('required') || node.getAttribute('aria-required') === 'true')) continue;
      if (forms.size && ![...forms].some(form => form.contains(node))) continue;
      if (!seenNodes.has(node)) throw Error('unknown-required-address-field');
    }
    return result;
  }
  function selectedAddressValue(entry, expected) {
    if (!entry.node) return null;
    if (entry.node.tagName !== 'SELECT') return expected;
    const prototype = globalThis.HTMLOptionElement?.prototype;
    const valueGetter = prototype && Object.getOwnPropertyDescriptor(prototype, 'value')?.get;
    const textGetter = prototype && Object.getOwnPropertyDescriptor(prototype, 'text')?.get;
    if (!valueGetter || !textGetter) throw Error('native-address-option-reader-unavailable');
    const matches = [];
    for (const option of entry.node.querySelectorAll('option')) {
      if (option.disabled || option.closest?.('optgroup')?.disabled) continue;
      const value = valueGetter.call(option), text = norm(textGetter.call(option));
      if (value && (value === expected || text === norm(expected))) matches.push(value);
    }
    if (matches.length > 1) throw Error('ambiguous-address-option');
    return matches[0] ?? null;
  }
  function amount(text) {
    const match = /^(?:(?:CNY|RMB|¥|￥)\s*)?((?:0|[1-9]\d*|[1-9]\d{0,2}(?:,\d{3})+)(?:\.\d{1,2})?)(?:\s*(?:CNY|RMB|元))?$/iu.exec(text);
    if (!match) throw Error('invalid-price-evidence');
    const [integer, fraction = ''] = match[1].replace(/,/gu, '').split('.');
    const minor = Number(integer) * 100 + Number(fraction.padEnd(2, '0'));
    if (!Number.isSafeInteger(minor) || minor < 0) throw Error('invalid-price-evidence');
    return minor;
  }
  function count(text) { if (!/^(?:0|[1-9]\d*)$/u.test(text)) throw Error('invalid-count-evidence'); return Number(text); }
  function addressMatches(current) {
    const mapping = current.config.steps[current.index].addressConfirmation;
    if (!mapping) return false;
    const read = readMapped(mapping.selector, 'address-confirmation');
    if (current.config.addressMode === 'existing') return !!current.addressProof && read.text === current.addressProof.text;
    if (!current.address || !Array.isArray(mapping.keys) || !mapping.keys.length) return false;
    const parts = mapping.keys.map(key => Object.hasOwn(fieldTypes, key) && typeof current.address[key] === 'string' ? norm(current.address[key]) : '');
    return parts.every(Boolean) && read.text === norm(parts.join(' '));
  }
  async function prepareAddressProof(current) {
    if (current.config.addressMode !== 'existing') return;
    const mapping = current.config.steps[current.index].addressConfirmation;
    if (!mapping) return;
    const before = readMapped(mapping.selector, 'address-confirmation').text;
    if (!before || before.length > 2000) throw Error('invalid-selected-address');
    if (current.addressProof?.text === before) return;
    const bytes = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(before));
    if (task !== current) return;
    if (readMapped(mapping.selector, 'address-confirmation').text !== before) throw Error('selected-address-changed-during-check');
    current.addressProof = { text: before, fingerprint: [...new Uint8Array(bytes)].map(byte => byte.toString(16).padStart(2, '0')).join('') };
  }
  function snapshot(current) {
    checkContext(current);
    const step = current.config.steps[current.index], mapping = step.evidence;
    const evidence = { observedAt: Date.now(), url: safeLocation(), blocker: blocker(), ambiguity: [], paymentCommit: false };
    if (step.stage === 'configure' && step.adapter === 'apple-duo') {
      const adapter = globalThis.AppleDuoReadonly;
      if (!adapter?.supportsURL(location.href)) throw Error('unsupported-duo-adapter-page');
      const observed = adapter.inspect(document, { url: location.href, driver: D });
      if (!observed.supported || !observed.model) throw Error('missing-model');
      return { ...evidence, model: observed.model, color: observed.color, storage: observed.storage, itemPriceMinor: observed.itemPriceMinor, currency: observed.itemCurrency,
        summary: observed.summary, capacityOptions: (observed.options?.storage || []).map(option => ({ name: option.name, enabled: option.enabled === true })), ambiguity: observed.ambiguity || [] };
    }
    if (step.stage === 'configure') {
      evidence.model = readMapped(mapping.model, 'model').text;
      for (const key of ['color', 'storage', 'currency']) if (mapping[key]) evidence[key] = readMapped(mapping[key], key, false)?.text ?? null;
      if (mapping.itemPrice) { const value = readMapped(mapping.itemPrice, 'item-price', false); evidence.itemPriceMinor = value?.text ? amount(value.text) : null; }
      if (mapping.quantity) { const value = readMapped(mapping.quantity, 'quantity', false); evidence.quantity = value?.text ? count(value.text) : null; }
      return evidence;
    }
    for (const key of ['model', 'storage', 'color', 'currency', 'region', 'delivery']) evidence[key] = readMapped(mapping[key], key).text;
    evidence.quantity = count(readMapped(mapping.quantity, 'quantity').text);
    evidence.itemCount = count(readMapped(mapping.itemCount, 'item-count').text);
    if (['review', 'submit-unpaid'].includes(step.stage)) {
      evidence.totalMinor = amount(readMapped(mapping.total, 'total').text);
      evidence.totalIncludesTaxShipping = readMapped(step.totalIncludesTaxShipping.selector, 'total-completeness').text === norm(step.totalIncludesTaxShipping.text);
      evidence.addressMatches = addressMatches(current);
    } else evidence.itemPriceMinor = amount(readMapped(mapping.itemPrice, 'item-price').text);
    if (step.stage === 'address' && step.kind === 'button' && step.addressConfirmation) evidence.addressMatches = addressMatches(current);
    if (current.config.addressMode === 'existing' && step.addressConfirmation) {
      evidence.addressMatches = addressMatches(current);
      if (evidence.addressMatches) evidence.addressFingerprint = current.addressProof.fingerprint;
    }
    if (step.stage === 'submit-unpaid') {
      evidence.noChargeText = readMapped(mapping.noCharge, 'no-charge').text;
      evidence.paymentCommit = !positiveUnpaid(evidence.noChargeText);
    }
    return evidence;
  }
  function evidenceFault(current, evidence) {
    const c = current.config, step = c.steps[current.index];
    if (evidence.blocker) return evidence.blocker;
    if (evidence.ambiguity?.length) return 'ambiguous-page-evidence';
    if (step.stage === 'configure') {
      if (norm(evidence.model) !== norm(c.model)) return 'model-mismatch';
      for (const prior of c.steps.slice(0, current.index).filter(item => item.kind === 'radio')) if (norm(evidence[radioFields[prior.group]]) !== norm(c[radioFields[prior.group]])) return 'previous-selection-changed';
      if (evidence.quantity !== undefined && evidence.quantity !== null && evidence.quantity !== c.quantity) return 'quantity-mismatch';
      if (evidence.itemPriceMinor !== undefined && evidence.itemPriceMinor !== null && (!Number.isSafeInteger(evidence.itemPriceMinor) || evidence.itemPriceMinor <= 0 || evidence.itemPriceMinor * c.quantity > Math.round(Number(c.maxTotal) * 100) || evidence.currency !== c.currency)) return 'price-over-limit-or-unverified';
      return null;
    }
    for (const key of ['model', 'storage', 'color', 'currency', 'region', 'delivery']) if (norm(evidence[key]) !== norm(c[key])) return `${key}-mismatch`;
    if (evidence.quantity !== c.quantity || evidence.itemCount !== 1) return 'unapproved-cart-contents';
    const total = ['review', 'submit-unpaid'].includes(step.stage) ? evidence.totalMinor : evidence.itemPriceMinor * c.quantity;
    if (!Number.isSafeInteger(total) || total <= 0 || total > Math.round(Number(c.maxTotal) * 100)) return 'price-over-limit-or-unverified';
    if (['review', 'submit-unpaid'].includes(step.stage) && (!evidence.totalIncludesTaxShipping || !evidence.addressMatches)) return 'total-or-address-unverified';
    if (step.stage === 'address' && step.kind === 'button' && !evidence.addressMatches) return 'address-unverified-before-continuation';
    if (step.stage === 'submit-unpaid' && (evidence.paymentCommit || evidence.noChargeText !== norm(step.noChargeText) || !positiveUnpaid(evidence.noChargeText))) return 'unpaid-submit-not-verified';
    return null;
  }
  function duoApplicationConfirmed(current, evidence, before = null) {
    const step = current.config.steps[current.index], config = current.config;
    if (norm(evidence[radioFields[step.group]]) !== norm(step.target.name)) return false;
    const summaryMatches = keys => {
      const summary = norm(evidence.summary);
      return !!summary && keys.every(key => {
        const wanted = norm(config[key]).replace(/[.*+?^${}()|[\]\\]/gu, '\\$&');
        return new RegExp(`(?:^|\\s)${wanted}(?:\\s|$)`, 'u').test(summary);
      });
    };
    if (step.group === 'dimensionCapacity') return summaryMatches(['model', 'storage', 'color']) && (!before || norm(before.summary) !== norm(evidence.summary));
    const summaryReady = summaryMatches(['model', 'color']) && (!before || norm(before.summary) !== norm(evidence.summary));
    const enabled = evidence.capacityOptions.some(option => option.enabled && norm(option.name) === norm(config.storage));
    const wasEnabled = before?.capacityOptions.some(option => option.enabled && norm(option.name) === norm(config.storage));
    return summaryReady || enabled && (!before || !wasEnabled);
  }
  function confirmation(current, target = null, navigation = false) {
    const step = current.config.steps[current.index];
    checkContext(current, navigation);
    if (step.adapter === 'apple-duo') {
      const evidence = snapshot(current);
      const radio = target || resolveRadio(current).element;
      return { kind: 'apple-selection', matched: radio?.checked === true && duoApplicationConfirmed(current, evidence, current.claim?.before ?? null) };
    }
    const entry = readMapped(step.confirm.selector, 'postcondition', false);
    if (!entry) return { matched: false, selector: step.confirm.selector, text: step.confirm.text };
    if (target && (entry.node === target || entry.node.contains(target) || target.contains(entry.node))) throw Error('postcondition-not-independent');
    if (step.kind === 'address') for (const field of step.fields || []) {
      const controls = field.selector ? [...document.querySelectorAll(field.selector)] : resolveFields(current).filter(item => item.field.key === field.key && item.node).map(item => item.node);
      if (controls.some(node => entry.node === node || entry.node.contains(node) || node.contains(entry.node))) throw Error('postcondition-not-independent');
    }
    return { matched: entry.text === norm(step.confirm.text), selector: step.confirm.selector, text: step.confirm.text };
  }
  function validate(config) {
    if (config?.testMode === true && (!fixtureActive(config) || config.url !== 'https://www.apple.com.cn/shop/fixture' || !Array.isArray(config.steps) || config.steps.some(step => (step.origin ?? 'https://www.apple.com.cn') !== 'https://www.apple.com.cn' || step.path !== '/shop/fixture' || step.query || step.confirm?.nextPath || step.adapter))) throw Error('invalid-local-fixture');
    if (!policy || !D || !['isVisible', 'isEnabled'].every(key => typeof D[key] === 'function') || config?.mode !== 'purchase' || config.confirmedPurchase !== true ||
      !['new', 'existing'].includes(config.addressMode) || !Array.isArray(config.steps) || config.steps.length < 1 || config.steps.length > 16 ||
      !Number.isFinite(Date.parse(config.expiresAt)) || Date.parse(config.expiresAt) <= Date.now()) throw Error('invalid-purchase-authorization');
    for (const step of config.steps) {
      const adapted = step.adapter === 'apple-duo';
      if (adapted && (step.stage !== 'configure' || step.kind !== 'radio' || config.model !== 'iPhone Duo' || step.confirm?.kind !== 'apple-selection' || !globalThis.AppleDuoReadonly?.supportsURL((step.origin ?? 'https://www.apple.com.cn') + step.path))) throw Error('invalid-duo-adapter');
      if (!['configure', 'add-to-bag', 'address', 'review', 'submit-unpaid'].includes(step.stage) || !['radio', 'button', 'address'].includes(step.kind) ||
        !adapted && (!selectorOK(step.confirm?.selector) || !norm(step.confirm.text)) || !Number.isInteger(step.timeoutMs) || step.timeoutMs < 1000 || step.timeoutMs > 30000) throw Error('invalid-purchase-step');
      if (step.kind === 'radio' && (step.stage !== 'configure' || !radioFields[step.group] || step.target?.role !== 'radio' || norm(step.target.name) !== norm(config[radioFields[step.group]]) || !adapted && !selectorOK(step.evidence?.[radioFields[step.group]]))) throw Error('invalid-radio-mapping');
      if (step.kind === 'button' && (step.target?.role !== 'button' || !norm(step.target.name) || step.target.selector && !selectorOK(step.target.selector))) throw Error('invalid-button-mapping');
      if (step.kind === 'address' && config.addressMode === 'new' && (!Array.isArray(step.fields) || !step.fields.length || step.fields.some(field =>
        !Object.hasOwn(fieldTypes, field.key) || field.autocomplete !== fieldTypes[field.key] || field.name !== undefined && !norm(field.name) || field.selector !== undefined && !selectorOK(field.selector)))) throw Error('invalid-address-mapping');
    }
    return JSON.parse(JSON.stringify(config));
  }
  async function send(current, type, extra = {}) {
    const reply = await chrome.runtime.sendMessage({ type, taskId: current.id, documentNonce: current.nonce, stepIndex: current.index, ...extra });
    if (!reply?.ok) throw Error('background-authorization-unavailable');
    return reply;
  }
  function stop() {
    generation++; task = null; clearTimeout(timer); timer = null; observer?.disconnect(); observer = null; overlay?.remove(); overlay = null; dirty = false;
  }
  async function fail(reason, current = task) {
    if (!current || task !== current) return;
    const claim = current.claim;
    stop();
    const safeReason = /^[a-z0-9:-]{1,100}$/u.test(reason) ? reason : 'purchase-workflow-error';
    await send(current, claim ? 'PURCHASE_RESULT' : 'PURCHASE_STOP', claim ?
      { claimToken: claim.token, outcome: 'unknown', reason: safeReason } : { reason: safeReason }).catch(() => {});
  }
  function wake() {
    if (!task) return; dirty = true;
    if (busy || queued) return; queued = true;
    queueMicrotask(() => { queued = false; void tick(); });
  }
  function schedule(current) {
    if (task !== current) return; clearTimeout(timer);
    const deadline = current.claim?.deadline ?? current.deadline;
    timer = setTimeout(wake, Math.max(1, Math.min(1000, deadline - Date.now())));
  }
  async function bind(current) {
    const response = await send(current, 'PURCHASE_BIND', { url: safeLocation() });
    if (task !== current) return;
    if (terminal.has(response.state) || response.state === 'AWAITING_USER') { stop(); return; }
    current.config = validate(response.config || current.config);
    if (!Number.isInteger(response.stepIndex) || !current.config.steps[response.stepIndex]) throw Error('invalid-bound-stage');
    current.index = response.stepIndex;
    if (response.address && typeof response.address === 'object') current.address = response.address;
    if (response.pendingClaim) {
      const claim = response.pendingClaim;
      if (typeof claim.token !== 'string' || claim.checked !== true || !Number.isFinite(claim.deadline) || !current.config.steps[current.index].confirm.nextPath) throw Error('invalid-navigation-claim');
      current.claim = { token: claim.token, deadline: claim.deadline, acted: true, navigation: true };
    }
    current.deadline = Math.max(Date.now(), Date.parse(current.config.targetTime || '') || 0) + current.config.steps[current.index].timeoutMs;
    checkContext(current, !!current.claim?.navigation);
  }
  function createOverlay(current) {
    overlay = document.createElement('section');
    overlay.setAttribute('id', `purchase-assistant-stop-${chrome.runtime.id}`);
    overlay.setAttribute('aria-label', '购买辅助控制');
    Object.assign(overlay.style, { position: 'fixed', top: '12px', right: '12px', zIndex: '2147483647', background: '#fff', color: '#111', border: '2px solid #b42318', borderRadius: '8px', padding: '12px', maxWidth: '380px', font: '16px system-ui, sans-serif', boxShadow: '0 2px 12px #0005' });
    const button = document.createElement('button'); button.setAttribute('type', 'button'); button.textContent = '停止购买辅助';
    Object.assign(button.style, { background: '#b42318', color: '#fff', padding: '10px 16px', cursor: 'pointer' });
    button.addEventListener('click', () => { const active = task; stop(); if (active) void send(active, 'PURCHASE_STOP', { reason: 'user-stopped-on-page' }).catch(() => {}); });
    overlay.append(button); (document.documentElement ?? document.body).append(overlay);
  }
  function showAddressAcknowledgment(current) {
    if (current.addressConfirmed || current.addressPrompt) return;
    const panel = document.createElement('section'), description = document.createElement('p'), button = document.createElement('button');
    description.textContent = `请确认本次订单使用页面当前选中的地址：${current.addressProof.text}`;
    button.setAttribute('type', 'button'); button.textContent = '确认使用此已选地址';
    panel.append(description, button); overlay.append(panel); current.addressPrompt = panel;
    const expected = current.addressProof.fingerprint;
    button.addEventListener('click', event => {
      if (event.isTrusted !== true) return;
      void (async () => {
        if (task !== current || current.addressConfirmBusy) return;
        current.addressConfirmBusy = true;
        try {
          checkContext(current); await prepareAddressProof(current);
          if (task !== current) return;
          if (current.addressProof.fingerprint !== expected || !addressMatches(current)) throw Error('selected-address-changed-before-confirmation');
          const result = await send(current, 'PURCHASE_CONFIRM_ADDRESS', { addressFingerprint: expected, addressConfirmed: true });
          if (task !== current) return;
          if (result.addressConfirmed !== true && result.confirmed !== true) throw Error('address-confirmation-denied');
          current.addressConfirmed = true; panel.remove(); current.addressPrompt = null; wake();
        } catch (error) { await fail(error.message, current); }
      })();
    });
  }
  function addressComplete(current) {
    const fields = resolveFields(current);
    return fields.length > 0 && fields.every(entry => {
      const expected = current.address?.[entry.field.key];
      const selected = typeof expected === 'string' && norm(expected) ? selectedAddressValue(entry, expected) : null;
      return entry.node && selected !== null && entry.descriptor.get.call(entry.node) === selected && entry.node.validity?.valid !== false;
    });
  }
  function fillAddress(current) {
    // One checked claim covers the whole native address step. Each field is
    // written at most once. Dependent options may arrive on a later observer
    // wake; completed fields are re-resolved and verified rather than replayed.
    current.addressWrites ??= new Set();
    let fields = resolveFields(current);
    if (!fields.length || fields.some(({ field }) => typeof current.address?.[field.key] !== 'string' || !norm(current.address[field.key]))) throw Error('incomplete-session-address');
    for (const { field } of fields) {
      if (task !== current) throw Error('task-stopped-during-address-fill');
      checkContext(current); const fault = blocker(); if (fault) throw Error(fault);
      fields = resolveFields(current);
      const fresh = fields.find(item => item.field.key === field.key), expected = current.address[field.key];
      if (!fresh?.node) return false;
      const selected = selectedAddressValue(fresh, expected);
      if (current.addressWrites.has(field.key)) {
        if (selected === null || fresh.descriptor.get.call(fresh.node) !== selected) throw Error('completed-address-field-changed');
        continue;
      }
      if (!fresh.writable || selected === null) return false;
      // Refuse to repeat even if an event handler throws or replaces a control.
      current.addressWrites.add(field.key);
      fresh.descriptor.set.call(fresh.node, selected);
      if (task !== current) throw Error('task-stopped-during-address-fill');
      fresh.node.dispatchEvent(new Event('input', { bubbles: true }));
      if (task !== current) throw Error('task-stopped-during-address-fill');
      const afterInput = resolveFields(current).find(item => item.field.key === field.key);
      if (!afterInput?.node || selectedAddressValue(afterInput, expected) !== afterInput.descriptor.get.call(afterInput.node)) throw Error('address-field-changed-during-input');
      afterInput.node.dispatchEvent(new Event('change', { bubbles: true }));
      if (task !== current) throw Error('task-stopped-during-address-fill');
      const afterChange = resolveFields(current).find(item => item.field.key === field.key);
      if (!afterChange?.node || selectedAddressValue(afterChange, expected) !== afterChange.descriptor.get.call(afterChange.node)) throw Error('address-field-changed-during-change');
    }
    return addressComplete(current);
  }
  async function result(current, evidence) {
    const version = generation, response = await send(current, 'PURCHASE_RESULT', { claimToken: current.claim.token, outcome: 'confirmed', evidence });
    if (task !== current || generation !== version) return;
    current.claim = null; current.addressWrites = null;
    if (terminal.has(response.state) || response.state === 'AWAITING_USER') { stop(); return; }
    if (response.stepIndex !== current.index + 1) throw Error('invalid-next-step');
    current.index = response.stepIndex; current.addressProof = null; current.addressConfirmed = false; current.addressPrompt?.remove(); current.addressPrompt = null;
    await bind(current);
    if (task === current) dirty = true;
  }
  async function tick() {
    if (!task || busy) return;
    busy = true; dirty = false; clearTimeout(timer);
    const current = task, version = generation;
    try {
      const step = current.config.steps[current.index];
      if (!current.claim && Date.now() < (Date.parse(current.config.targetTime || '') || 0)) {
        checkContext(current);
        if (!current.lastHeartbeat || Date.now() - current.lastHeartbeat >= 30000) { current.lastHeartbeat = Date.now(); await send(current, 'PURCHASE_HEARTBEAT'); }
        schedule(current); return;
      }
      if (current.claim?.navigation || current.claim?.acted && step.confirm.nextPath && stageMatches(current, true)) {
        checkContext(current, true);
        const blocked = blocker(); if (blocked) throw Error(blocked);
        if (Date.now() >= current.claim.deadline) throw Error('navigation-postcondition-timeout-no-retry');
        const confirmed = confirmation(current, null, true);
        if (confirmed.matched) await result(current, { observedAt: Date.now(), url: safeLocation(), blocker: null, ambiguity: [], paymentCommit: false,
          confirmation: confirmed, ...(step.stage === 'submit-unpaid' ? { unpaidOrder: policy.unpaidOrderResult(confirmed.text) } : {}) });
        schedule(current); return;
      }
      checkContext(current);
      if (current.claim?.acted && step.kind === 'button' && !step.confirm.nextPath) {
        const blocked = blocker(); if (blocked) throw Error(blocked);
        if (Date.now() >= current.claim.deadline) throw Error('postcondition-timeout-no-retry');
        const confirmed = confirmation(current);
        // A successful same-route transition may replace the old cart/review
        // DOM entirely. Verify its exact independent result, rather than
        // re-reading stale pre-action selectors or replaying the action.
        if (confirmed.matched) await result(current, { observedAt: Date.now(), url: safeLocation(), blocker: null, ambiguity: [], paymentCommit: false,
          confirmation: confirmed, ...(step.stage === 'submit-unpaid' ? { unpaidOrder: policy.unpaidOrderResult(confirmed.text) } : {}) });
        schedule(current); return;
      }
      await prepareAddressProof(current);
      if (task !== current || version !== generation) return;
      if (step.kind === 'address' && current.config.addressMode === 'existing' && !current.addressConfirmed) {
        const blocked = blocker(); if (blocked) throw Error(blocked);
        showAddressAcknowledgment(current);
        if (Date.now() >= current.deadline) throw Error('address-confirmation-timeout');
        schedule(current); return;
      }
      const evidence = snapshot(current), fault = evidenceFault(current, evidence);
      if (fault) throw Error(fault);
      if (current.claim) {
        if (!current.claim.acted) throw Error('unresolved-claim');
        if (Date.now() >= current.claim.deadline) throw Error('postcondition-timeout-no-retry');
        if (step.kind === 'address' && current.config.addressMode === 'new' && !fillAddress(current)) { schedule(current); return; }
        // Navigation claims can only be completed on the explicitly mapped next page.
        if (step.confirm.nextPath) { schedule(current); return; }
        const resolved = step.kind === 'radio' ? resolveRadio(current) : null;
        const confirmed = confirmation(current, resolved?.element);
        if (confirmed.matched && (step.kind !== 'radio' || resolved.element?.checked === true && norm(evidence[radioFields[step.group]]) === norm(current.config[radioFields[step.group]]))) {
          if (step.kind === 'radio') { evidence.radioChecked = true; evidence.selectionApplied = true; }
          if (step.kind === 'address') {
            evidence.addressComplete = current.config.addressMode === 'existing' ? addressMatches(current) : addressComplete(current);
            evidence.addressMatches = addressMatches(current);
            if (!evidence.addressComplete || !evidence.addressMatches) throw Error('address-not-applied');
          }
          if (step.stage === 'submit-unpaid') evidence.unpaidOrder = policy.unpaidOrderResult(confirmed.text);
          await result(current, { ...evidence, confirmation: confirmed });
        }
        schedule(current); return;
      }
      let target = resolveAction(current);
      if (step.kind === 'address' && current.config.addressMode === 'new') resolveFields(current);
      if (target.status !== 'ready' && !(step.kind === 'radio' && target.element?.checked === true)) {
        if (Date.now() >= current.deadline) throw Error('target-readiness-timeout');
        schedule(current); return;
      }
      const alreadySelected = step.kind === 'radio' && target.element?.checked === true;
      if (alreadySelected && (!confirmation(current, target.element).matched || norm(evidence[radioFields[step.group]]) !== norm(current.config[radioFields[step.group]]))) {
        if (Date.now() >= current.deadline) throw Error('radio-application-state-unconfirmed');
        schedule(current); return;
      }
      // Existing-address acknowledgment is an explicit no-write step. Other
      // actions require an observable transition from a previously false state.
      if (!step.confirm.nextPath && confirmation(current, target.element).matched && !(step.kind === 'address' && current.config.addressMode === 'existing') && !alreadySelected) throw Error('preexisting-postcondition');
      if (Date.now() >= current.deadline) throw Error('step-readiness-timeout');
      const grant = await send(current, 'PURCHASE_CLAIM', { evidence });
      if (task !== current || version !== generation) return;
      if (terminal.has(grant.state)) { stop(); return; }
      if (grant.action === 'none') { schedule(current); return; }
      if (grant.action !== 'purchase-act' || typeof grant.claimToken !== 'string' || !grant.claimToken || !Number.isFinite(grant.deadline)) throw Error('invalid-action-grant');
      current.claim = { token: grant.claimToken, deadline: Math.min(grant.deadline, Date.now() + step.timeoutMs), acted: false, navigation: false };
      await prepareAddressProof(current);
      if (task !== current || version !== generation) return;
      const checkEvidence = snapshot(current), checkFault = evidenceFault(current, checkEvidence); if (checkFault) throw Error(checkFault);
      const check = await send(current, 'PURCHASE_CHECK', { claimToken: current.claim.token, evidence: checkEvidence });
      if (task !== current || version !== generation) return;
      if (check.allowed !== true || terminal.has(check.state) || !Number.isFinite(check.deadline)) throw Error('claim-check-denied');
      current.claim.deadline = Math.min(current.claim.deadline, check.deadline);
      if (check.address) current.address = check.address;
      // No asynchronous boundary occurs between this fresh snapshot/relocation
      // and the native action. Never click the object resolved before a grant.
      const fresh = snapshot(current), freshFault = evidenceFault(current, fresh); if (freshFault) throw Error(freshFault);
      const invariant = value => JSON.stringify(Object.fromEntries(Object.entries(value).filter(([key]) => key !== 'observedAt')));
      if (invariant(fresh) !== invariant(checkEvidence)) throw Error('evidence-changed-after-check');
      target = resolveAction(current);
      if (target.status !== 'ready' && !(step.kind === 'radio' && target.element?.checked === true && alreadySelected)) throw Error('target-changed-after-check');
      if (step.kind === 'radio' && (target.element.checked === true) !== alreadySelected) throw Error('radio-selection-changed-after-check');
      if (!step.confirm.nextPath && confirmation(current, target.element).matched && !(step.kind === 'address' && current.config.addressMode === 'existing') && !alreadySelected) throw Error('postcondition-changed-after-check');
      if (Date.now() >= current.claim.deadline) throw Error('claim-expired-before-action');
      const key = `${current.id}:${current.index}`; if (attempts.has(key)) throw Error('step-already-attempted'); attempts.add(key);
      current.claim.before = alreadySelected ? null : fresh;
      current.claim.acted = true;
      if (step.kind === 'address') { if (current.config.addressMode === 'new') fillAddress(current); }
      else if (!alreadySelected) target.element.click();
      dirty = true; schedule(current);
    } catch (error) {
      if (task === current && version === generation) {
        if (!current.claim && /^missing-/u.test(error.message) && Date.now() < current.deadline) schedule(current);
        else await fail(error.message, current);
      }
    }
    finally { busy = false; if (dirty && task) wake(); }
  }

  function receive(message, sender, reply) {
    if (sender.id !== chrome.runtime.id) return;
    if (message.type === 'START_PURCHASE_FIXTURE' || message.type === 'HALT_PURCHASE_FIXTURE') {
      const config = message.type === 'START_PURCHASE_FIXTURE' ? message.config : task?.config;
      if (!fixtureActive(config) || !Number.isInteger(message.targetTabId) || typeof chrome.tabs?.getCurrent !== 'function') return;
      void chrome.tabs.getCurrent().then(tab => {
        if (tab?.id !== message.targetTabId || !fixtureActive(config)) return;
        receive({ ...message, type: message.type === 'START_PURCHASE_FIXTURE' ? 'START_PURCHASE' : 'HALT' }, sender, reply);
      }).catch(() => {});
      return true;
    }
    if (message.type === 'HALT' && task?.id === message.taskId) { stop(); reply({ ok: true }); return; }
    if (message.type !== 'START_PURCHASE') return;
    void (async () => {
      let current = null;
      try {
        if (task || typeof message.taskId !== 'string' || !message.taskId || message.taskId.length > 100 || seen.has(message.taskId)) throw Error('task-already-started-or-invalid');
        const config = validate(message.config); seen.add(message.taskId);
        current = task = { id: message.taskId, nonce: crypto.randomUUID(), config, index: 0, claim: null, address: null, addressProof: null, addressConfirmed: false };
        // Acknowledge receipt before BIND: the service worker serializes START
        // and cannot process BIND while waiting for this response.
        reply({ ok: true });
        await bind(current); if (task !== current) return;
        createOverlay(current);
        observer = new MutationObserver(wake); observer.observe(document, { subtree: true, childList: true, characterData: true, attributes: true });
        wake();
      } catch {
        if (current) await fail('purchase-start-failed', current);
        else reply({ ok: false, error: 'purchase-start-failed' });
      }
    })();
    return true;
  }
  chrome.runtime.onMessage.addListener(receive);
  function leaveDocument(reason) {
    const current = task;
    if (!current) return;
    // pagehide and visibilitychange ordering differs between browsers. Once a
    // checked, one-shot navigation action was dispatched, retire this document
    // and let the backend verify the exact destination or expire UNKNOWN.
    if (current.claim?.acted && current.config.steps[current.index].confirm.nextPath) {
      const token = current.claim.token; stop();
      void send(current, 'PURCHASE_DISCONNECT', { claimToken: token, expectedNavigation: true, reason }).catch(() => {});
    } else void fail(reason, current);
  }
  addEventListener('pagehide', () => leaveDocument('unexpected-pagehide'));
  document.addEventListener('visibilitychange', () => { if (document.visibilityState !== 'visible') leaveDocument('page-hidden'); });
  document.addEventListener('input', wake, true); document.addEventListener('change', wake, true);
  globalThis.__applePurchaseController = Object.freeze({ stop });
})();
