// Explicitly started, bounded configuration assistance in Chrome's isolated world.
// No checkout/order/payment action, fetch, request replay, or form-value reader.
(() => {
  'use strict';
  if (globalThis.__appleAssistController) return;
  const D = globalThis.AppleDOMDriver;
  const adapter = globalThis.AppleDuoReadonly;
  const normalize = value => String(value ?? '').normalize('NFKC').replace(/\s+/gu, ' ').trim();
  const terminal = new Set(['PAUSED', 'STOPPED', 'DONE', 'UNKNOWN']);
  const groups = { dimensionColor: 'color', dimensionCapacity: 'storage' };
  const prohibited = /(?:check[\s_-]*out|add[\s_-]*(?:to[\s_-]*)?(?:bag|cart)|shopping|purchase|payment|place[\s_-]*order|submit|buy|order|cart|bag|pay|reserve|sign[\s_-]*in|log[\s_-]*in|captcha|accept|agree|terms|conditions|购买|立即买|下单|订单|订购|提交|付款|支付|结账|结算|购物|加入|预订|登录|登陆|验证码|人机验证|同意|接受|条款|协议)/iu;
  const unsafeSelector = /(?:password|credit.?card|cc-number|cc-csc|[\\\u200b-\u200f\u202a-\u202e\u2060-\u206f])/iu;
  const safeSelector = value => typeof value === 'string' && value.length > 0 && value.length <= 300 &&
    !/^(?:\*|html|body|:root)$/iu.test(normalize(value)) && !unsafeSelector.test(value) && !prohibited.test(value);
  const sensitiveTags = /^(?:INPUT|TEXTAREA|SELECT|OPTION|SCRIPT|STYLE|NOSCRIPT)$/u;
  const seenTasks = new Set();
  const attempts = new Set();
  let task = null, generation = 0, observer = null, timer = null, stopButton = null;
  let busy = false, queued = false, dirty = false;

  function hiddenTree(element) {
    if (!element || element.isConnected === false) return true;
    const view = element.ownerDocument?.defaultView;
    for (let node = element; node; node = node.parentElement) {
      if (node.hidden || node.hasAttribute?.('hidden') || node.getAttribute?.('aria-hidden') === 'true') return true;
      const style = view?.getComputedStyle?.(node);
      if (style && (style.display === 'none' || style.visibility === 'hidden' || style.visibility === 'collapse' ||
        style.contentVisibility === 'hidden' || (node !== element && style.opacity === '0'))) return true;
    }
    return false;
  }

  function safeText(element, allowedRadio = null) {
    // Never read text from controls, editable trees, or a container containing a
    // control. Even a malicious accessible-name/quantity selector cannot read it.
    for (let node = element; node; node = node.parentElement) {
      if (sensitiveTags.test(node.tagName ?? '') || node.hasAttribute?.('contenteditable') || node.getAttribute?.('role') === 'textbox') return null;
    }
    if ([...element.querySelectorAll('*')].some(node => node !== allowedRadio && (sensitiveTags.test(node.tagName ?? '') ||
      node.hasAttribute?.('contenteditable') || node.getAttribute?.('role') === 'textbox'))) return null;
    return normalize(element.textContent);
  }

  function nameOf(element) {
    const associated = [...document.querySelectorAll('label')].filter(label => {
      const id = element.getAttribute('id');
      return (id && label.getAttribute('for') === id) || label.contains?.(element);
    });
    const by = normalize(element.getAttribute('aria-labelledby'));
    if (by) {
      const ids = by.split(' '), identified = [...document.querySelectorAll('[id]')];
      const matches = ids.map(id => identified.filter(node => node.getAttribute('id') === id));
      if (new Set(ids).size !== ids.length || matches.some(nodes => nodes.length !== 1)) return { name: '', labels: associated, fault: 'ambiguous-or-missing-label' };
      const labels = matches.map(nodes => nodes[0]), texts = labels.map(node => safeText(node, element.tagName === 'INPUT' ? element : null));
      if (texts.some(text => !text)) return { name: '', labels: associated, fault: 'unsafe-or-empty-label' };
      return { name: normalize(texts.join(' ')), labels: [...associated, ...labels] };
    }
    const aria = element.getAttribute('aria-label');
    if (aria !== null) return { name: normalize(aria), labels: associated };
    if (element.tagName === 'INPUT') {
      if (associated.length !== 1) return { name: '', labels: associated, fault: 'ambiguous-or-missing-label' };
      // Wrapping labels legitimately contain the radio itself. Read only safe
      // non-control leaf text, and never the radio's value or value attribute.
      const label = associated[0];
      let text = safeText(label, element);
      if (text === null && label.contains?.(element)) {
        text = normalize([...label.querySelectorAll('*')].filter(node => !node.children?.length && node !== element)
          .map(node => safeText(node)).filter(value => value !== null).join(' '));
      }
      return { name: text ?? '', labels: associated };
    }
    return { name: safeText(element) ?? '', labels: associated };
  }

  function safeURL(value) {
    try {
      const url = new URL(value);
      return url.protocol === 'https:' && url.hostname === 'www.apple.com.cn' && !url.username && !url.password &&
        !url.port && !url.hash && adapter.supportsURL(url.href);
    } catch { return false; }
  }

  function validate(config) {
    if (!D || !adapter || !['isVisible', 'isEnabled'].every(key => typeof D[key] === 'function')) throw Error('assist-readers-unavailable');
    if (config?.mode !== 'assist' || config.confirmedAssist !== true || !safeURL(config.url)) throw Error('assist-not-authorized');
    for (const key of ['model', 'color', 'storage']) {
      if (typeof config[key] !== 'string' || !normalize(config[key]) || config[key].length > 160) throw Error(`invalid-${key}`);
    }
    const cap = Number(config.maxTotal);
    if (!Number.isInteger(config.quantity) || config.quantity < 1 || config.quantity > 10 || !Number.isFinite(cap) || cap <= 0 ||
      !Number.isSafeInteger(Math.round(cap * 100)) || Math.abs(cap * 100 - Math.round(cap * 100)) > 0.00001) throw Error('invalid-quantity-or-price-cap');
    if (!Number.isFinite(Date.parse(config.expiresAt)) || Date.parse(config.expiresAt) <= Date.now()) throw Error('assist-expired');
    if (!Array.isArray(config.steps) || config.steps.length < 1 || config.steps.length > 8) throw Error('invalid-assist-steps');
    if (config.quantitySelector && !safeSelector(config.quantitySelector)) throw Error('unsafe-quantity-selector');
    for (const step of config.steps) {
      if (!['radio', 'button'].includes(step?.kind) || typeof step.name !== 'string' || !normalize(step.name) || step.name.length > 160 ||
        prohibited.test(step.name) || (step.purpose && prohibited.test(step.purpose)) || (step.type && prohibited.test(step.type))) throw Error('unsafe-step');
      if (step.selector && !safeSelector(step.selector)) throw Error('unsafe-step-selector');
      if (!Number.isInteger(step.timeoutMs ?? 10000) || (step.timeoutMs ?? 10000) < 1000 || (step.timeoutMs ?? 10000) > 30000) throw Error('invalid-step-timeout');
      if (step.kind === 'radio') {
        if (!groups[step.group] || normalize(step.name) !== normalize(config[groups[step.group]]) || step.confirm?.kind !== 'checked' || step.confirm.selector) throw Error('unsafe-radio-step');
      } else if (!['visible', 'text'].includes(step.confirm?.kind) || typeof step.confirm.selector !== 'string' || !step.confirm.selector ||
        !safeSelector(step.confirm.selector) || step.confirm.selector === step.selector ||
        (step.confirm.kind === 'text' && (typeof step.confirm.text !== 'string' || !normalize(step.confirm.text) || step.confirm.text.length > 300 ||
          normalize(step.confirm.text) === normalize(step.name) || prohibited.test(step.confirm.text)))) throw Error('independent-postcondition-required');
    }
    return JSON.parse(JSON.stringify(config));
  }

  function resolve(step) {
    const candidates = [...document.querySelectorAll(step.kind === 'radio' ? 'input[type="radio"]' : 'button')];
    const matches = [];
    for (const element of candidates) {
      if (step.kind === 'radio' && element.getAttribute('name') !== step.group) continue;
      if (step.selector && !element.matches(step.selector)) continue;
      if (hiddenTree(element)) continue;
      const label = nameOf(element);
      if (!D.isVisible(element) && !(step.kind === 'radio' && label.labels.some(node => D.isVisible(node)))) continue;
      if (label.fault) return { status: 'ambiguous', element: null };
      if (label.name !== normalize(step.name)) continue;
      matches.push(element);
    }
    if (matches.length > 1) return { status: 'ambiguous', element: null };
    if (!matches.length) return { status: 'missing', element: null };
    const element = matches[0];
    if (step.kind === 'button') {
      const type = normalize(element.getAttribute('type')).toLowerCase();
      const attributeNames = typeof element.getAttributeNames === 'function' ? element.getAttributeNames() : [];
      const metadataNames = new Set(['id', 'name', 'data-autom', 'data-action', 'title', 'aria-label', 'formaction', 'href',
        ...attributeNames.filter(name => name.startsWith('data-'))]);
      const metadata = [...metadataNames].map(key => element.getAttribute(key) ?? '').join(' ');
      if (element.form || element.closest?.('form') || (type && type !== 'button') ||
        element.hasAttribute('formaction') || element.hasAttribute('form') || element.hasAttribute('onclick') || element.hasAttribute('href') ||
        (element.getAttribute('role') && element.getAttribute('role') !== 'button') || prohibited.test(metadata) ||
        safeText(element) === null || prohibited.test(safeText(element))) return { status: 'unsafe', element: null };
    }
    return { status: D.isEnabled(element) ? 'ready' : 'disabled', element };
  }

  function blocker() {
    for (const element of document.querySelectorAll('input,iframe')) {
      if (!D.isVisible(element)) continue;
      const attributes = ['type', 'name', 'autocomplete', 'id', 'title'].map(key => element.getAttribute(key) ?? '').join(' ');
      if (/password|cc-number|cc-csc|cc-exp|credit.?card|card.?number|one-time-code|captcha|verification|银行卡|信用卡/iu.test(attributes)) return 'authentication-challenge-or-payment';
    }
    for (const element of document.querySelectorAll('*')) {
      if (element.children?.length || !D.isVisible(element)) continue;
      const text = safeText(element);
      if (!text) continue;
      if (/验证码|人机验证|排队中|等候室|请求过于频繁|access denied|captcha|waiting room|unusual activity/iu.test(text)) return 'challenge-or-access-restriction';
      if (/^(?:登录|登陆|sign\s*in|log\s*in)$|登录以继续|sign\s*in\s*to\s*continue/iu.test(text)) return 'login-required';
      if (/同意.{0,12}(?:条款|协议)|accept.{0,20}(?:terms|conditions)|agree.{0,20}(?:terms|conditions)/iu.test(text)) return 'terms-require-manual-action';
      if (/^(?:付款方式|支付方式|payment method|card number|Apple Pay|Face ID|Touch ID)$/iu.test(text)) return 'payment-requires-manual-action';
    }
    return null;
  }

  function snapshot(current) {
    if (!safeURL(location.href) || !safeURL(current.config.url)) throw Error('url-outside-authorized-product');
    if (document.visibilityState !== 'visible') throw Error('page-hidden');
    if (Date.now() > Date.parse(current.config.expiresAt)) throw Error('assist-expired');
    const e = adapter.inspect(document, { url: location.href, driver: D });
    if (!e.supported) throw Error('unknown-product-page');
    let quantity = null;
    if (current.config.quantitySelector) {
      const matches = [...document.querySelectorAll(current.config.quantitySelector)].filter(node => D.isVisible(node));
      if (matches.length > 1) throw Error('ambiguous-quantity');
      if (matches.length === 1) {
        const text = safeText(matches[0]);
        if (text === null) throw Error('unsafe-quantity-reader');
        if (/^(?:[1-9]|10)$/u.test(text)) quantity = Number(text);
      }
    }
    return { observedAt: Date.now(), url: location.href, model: e.model ?? null, color: e.color ?? null, storage: e.storage ?? null,
      itemPriceMinor: e.itemPriceMinor ?? null, itemCurrency: e.itemCurrency ?? null, quantity,
      summary: e.summary ?? null, capacityOptions: (e.options?.storage ?? []).map(option => ({ name: option.name, enabled: option.enabled === true })),
      ambiguity: e.ambiguity ?? [], blocker: blocker() };
  }

  function evidenceFault(current, evidence) {
    if (evidence.blocker) return evidence.blocker;
    if (evidence.ambiguity.length) return 'ambiguous-product-evidence';
    if (evidence.model && normalize(evidence.model) !== normalize(current.config.model)) return 'model-mismatch';
    for (const key of ['color', 'storage']) {
      const earlierSelection = current.config.steps.slice(0, current.index).some(step => step.kind === 'radio' && groups[step.group] === key);
      if ((earlierSelection || current.config.steps[current.index]?.kind === 'button') &&
        normalize(evidence[key]) !== normalize(current.config[key])) return `${key}-mismatch-or-unobserved`;
    }
    if (evidence.quantity !== null && evidence.quantity !== current.config.quantity) return 'quantity-mismatch';
    if (evidence.itemPriceMinor !== null && (!Number.isSafeInteger(evidence.itemPriceMinor) || evidence.itemPriceMinor <= 0 ||
      evidence.itemCurrency !== 'CNY' || evidence.itemPriceMinor * current.config.quantity > Math.round(Number(current.config.maxTotal) * 100))) return 'product-price-exceeds-cap-or-unverified';
    if (current.config.steps[current.index]?.kind === 'button' && (!evidence.model || evidence.quantity === null || evidence.itemPriceMinor === null)) return 'button-requires-observed-specs-quantity-and-product-price';
    return null;
  }

  function postcondition(step, target) {
    if (step.kind === 'radio') return { satisfied: target?.checked === true };
    const nodes = [...document.querySelectorAll(step.confirm.selector)].filter(node => D.isVisible(node));
    if (nodes.length > 1) throw Error('ambiguous-postcondition');
    if (!nodes.length) return { satisfied: false };
    const node = nodes[0];
    if (node === target || node.contains?.(target) || target?.contains?.(node)) throw Error('postcondition-not-independent');
    const text = safeText(node);
    if (text === null) throw Error('unsafe-postcondition-reader');
    return { satisfied: step.confirm.kind === 'visible' || text === normalize(step.confirm.text) };
  }

  function summaryMatches(evidence, config, keys) {
    const summary = normalize(evidence.summary);
    return !!summary && keys.every(key => {
      const wanted = normalize(config[key]).replace(/[.*+?^${}()|[\]\\]/gu, '\\$&');
      return new RegExp(`(?:^|\\s)${wanted}(?:\\s|$)`, 'u').test(summary);
    });
  }

  function applicationConfirmed(current, evidence, before = null) {
    const step = current.config.steps[current.index];
    if (step.kind !== 'radio') return true;
    if (normalize(evidence[groups[step.group]]) !== normalize(step.name)) return false;
    if (step.group === 'dimensionCapacity') {
      return summaryMatches(evidence, current.config, ['model', 'storage', 'color']) &&
        (!before || normalize(before.summary) !== normalize(evidence.summary));
    }
    const summaryReady = summaryMatches(evidence, current.config, ['model', 'color']) &&
      (!before || normalize(before.summary) !== normalize(evidence.summary));
    const enabled = evidence.capacityOptions.some(option => option.enabled && normalize(option.name) === normalize(current.config.storage));
    const previouslyEnabled = before?.capacityOptions.some(option => option.enabled && normalize(option.name) === normalize(current.config.storage));
    return summaryReady || (enabled && (!before || !previouslyEnabled));
  }

  async function send(message) {
    const reply = await chrome.runtime.sendMessage(message);
    if (!reply?.ok) throw Error(reply?.error || 'background-unavailable');
    return reply;
  }

  function stop() {
    generation++;
    task = null;
    clearTimeout(timer);
    timer = null;
    observer?.disconnect();
    observer = null;
    stopButton?.remove();
    stopButton = null;
    dirty = false;
  }

  async function fail(reason, current = task) {
    if (!current || task !== current) return;
    const claim = current.claim;
    stop();
    const message = claim ? { type: 'ASSIST_RESULT', taskId: current.id, stepIndex: current.index, claimToken: claim.token, outcome: 'unknown', reason } :
      { type: 'ASSIST_STOP', taskId: current.id, reason };
    await send(message).catch(() => {});
  }

  function wake() {
    if (!task) return;
    dirty = true;
    if (busy || queued) return;
    queued = true;
    queueMicrotask(() => { queued = false; void tick(); });
  }

  function schedule(current) {
    if (task !== current) return;
    clearTimeout(timer);
    const deadline = current.claim?.deadline ?? current.deadline;
    // There is no fast polling/request loop. Mutations and input/change wake
    // immediately; the sole fallback is at most once per second.
    timer = setTimeout(wake, Math.max(1, Math.min(1000, deadline - Date.now())));
  }

  async function advance(current, type, evidence, reason) {
    const version = generation;
    const reply = await send({ type, taskId: current.id, stepIndex: current.index, evidence,
      ...(current.claim ? { claimToken: current.claim.token, outcome: 'confirmed', reason } : {}) });
    if (task !== current || version !== generation) return;
    current.claim = null;
    if (terminal.has(reply.state)) { stop(); return; }
    current.index++;
    current.lastRequest = null;
    if (current.index >= current.config.steps.length) { await fail('background-did-not-finish-last-step', current); return; }
    current.deadline = Date.now() + (current.config.steps[current.index].timeoutMs ?? 10000);
    dirty = true;
  }

  async function tick() {
    if (!task || busy) return;
    busy = true;
    dirty = false;
    const current = task, version = generation;
    clearTimeout(timer);
    try {
      const step = current.config.steps[current.index];
      const evidence = snapshot(current), fault = evidenceFault(current, evidence);
      if (fault) throw Error(fault);
      let target = resolve(step);
      if (['ambiguous', 'unsafe'].includes(target.status)) throw Error(`target-${target.status}`);
      if (current.claim) {
        if (!current.claim.clicked) throw Error('unresolved-claim');
        if (!evidence.model) throw Error('model-no-longer-observable');
        if (Date.now() >= current.claim.deadline) throw Error('postcondition-timeout-no-retry');
        if ((target.element || step.kind === 'button') && postcondition(step, target.element).satisfied &&
          applicationConfirmed(current, evidence, current.claim.before)) {
          await advance(current, 'ASSIST_RESULT', evidence, 'observable-transition-confirmed');
        }
        schedule(current);
        return;
      }
      if (!evidence.model || !target.element || target.status === 'disabled' && target.element.checked !== true) {
        if (Date.now() >= current.deadline) throw Error('target-or-model-not-ready');
        schedule(current);
        return;
      }
      const before = postcondition(step, target.element);
      if (before.satisfied) {
        if (step.kind !== 'radio') throw Error('button-postcondition-already-satisfied');
        if (applicationConfirmed(current, evidence)) await advance(current, 'ASSIST_SKIP', evidence, 'already-checked-with-application-state');
        else if (Date.now() >= current.deadline) throw Error('checked-without-application-confirmation');
        schedule(current);
        return;
      }
      if (Date.now() >= current.deadline) throw Error('target-readiness-timeout');
      const fingerprint = JSON.stringify({ ...evidence, observedAt: 0 });
      if (current.lastRequest?.fingerprint === fingerprint && Date.now() - current.lastRequest.time < 1000) { schedule(current); return; }
      current.lastRequest = { fingerprint, time: Date.now() };
      const grant = await send({ type: 'ASSIST_CLAIM', taskId: current.id, stepIndex: current.index, evidence });
      if (task !== current || version !== generation) return;
      if (terminal.has(grant.state)) { stop(); return; }
      if (grant.action === 'none') { schedule(current); return; }
      if (grant.action !== 'assist-click' || typeof grant.claimToken !== 'string' || !grant.claimToken) throw Error('invalid-click-grant');
      current.claim = { token: grant.claimToken, clicked: false, before: evidence,
        deadline: Math.min(grant.deadline, Date.now() + (step.timeoutMs ?? 10000)) };
      if (!Number.isFinite(current.claim.deadline) || Date.now() >= current.claim.deadline) throw Error('claim-deadline-expired');
      const checkEvidence = snapshot(current), checkFault = evidenceFault(current, checkEvidence);
      if (checkFault) throw Error(checkFault);
      const check = await send({ type: 'ASSIST_CHECK', taskId: current.id, stepIndex: current.index, claimToken: current.claim.token, evidence: checkEvidence });
      if (task !== current || version !== generation) return;
      if (check.allowed !== true || terminal.has(check.state)) throw Error('claim-check-denied');
      current.claim.deadline = Math.min(current.claim.deadline, check.deadline);
      if (!Number.isFinite(current.claim.deadline) || Date.now() >= current.claim.deadline) throw Error('claim-deadline-expired-after-check');
      // Re-read both evidence and target after the final async boundary. No
      // element from before CLAIM or CHECK is ever clicked.
      const freshEvidence = snapshot(current), freshFault = evidenceFault(current, freshEvidence);
      if (freshFault || !freshEvidence.model) throw Error(freshFault || 'model-no-longer-observable');
      target = resolve(step);
      if (target.status !== 'ready') throw Error(`target-${target.status}-after-claim`);
      if (postcondition(step, target.element).satisfied) throw Error('postcondition-changed-after-claim');
      current.claim.before = freshEvidence;
      if (Date.now() >= current.claim.deadline) throw Error('claim-deadline-expired-before-click');
      const key = `${current.id}:${current.index}`;
      if (attempts.has(key)) throw Error('step-already-attempted');
      attempts.add(key);
      current.claim.clicked = true;
      target.element.click();
      dirty = true;
      schedule(current);
    } catch (error) {
      if (task === current && version === generation) await fail(error?.message || 'assist-error', current);
    } finally {
      busy = false;
      if (dirty && task) wake();
    }
  }

  chrome.runtime.onMessage.addListener((message, sender, reply) => {
    if (sender.id !== chrome.runtime.id) return;
    if (message.type === 'HALT' && task?.id === message.taskId) { stop(); reply({ ok: true }); return; }
    if (message.type !== 'START_ASSISTING') return;
    let starting = false;
    try {
      if (typeof message.taskId !== 'string' || !message.taskId || message.taskId.length > 100 || seenTasks.has(message.taskId)) throw Error('task-already-started-or-invalid');
      const config = validate(message.config);
      if (!safeURL(location.href) || document.visibilityState !== 'visible') throw Error('page-not-available');
      if (task) throw Error('another-assist-task-is-active');
      seenTasks.add(message.taskId);
      task = { id: message.taskId, config, index: 0, claim: null, deadline: Date.now() + (config.steps[0].timeoutMs ?? 10000), lastRequest: null };
      starting = true;
      stopButton = document.createElement('button');
      stopButton.setAttribute('type', 'button');
      stopButton.setAttribute('id', `apple-configuration-assist-stop-${chrome.runtime.id}`);
      stopButton.textContent = '停止配置辅助';
      Object.assign(stopButton.style, { position: 'fixed', top: '12px', right: '12px', zIndex: '2147483647',
        background: '#b42318', color: '#fff', border: '2px solid #fff', borderRadius: '8px', padding: '12px 18px',
        font: '600 16px system-ui, sans-serif', cursor: 'pointer', boxShadow: '0 2px 12px #0005' });
      stopButton.addEventListener('click', () => {
        const current = task;
        stop();
        if (current) void send({ type: 'ASSIST_STOP', taskId: current.id, reason: 'user-stopped-on-page' }).catch(() => {});
      });
      (document.documentElement ?? document.body).append(stopButton);
      observer = new MutationObserver(wake);
      observer.observe(document, { subtree: true, childList: true, characterData: true, attributes: true });
      wake();
      reply({ ok: true });
    } catch (error) { if (starting) stop(); reply({ ok: false, error: error.message }); }
  });
  addEventListener('pagehide', () => { void fail('pagehide'); });
  document.addEventListener('visibilitychange', () => { if (document.visibilityState !== 'visible') void fail('page-hidden'); });
  document.addEventListener('input', wake, true);
  document.addEventListener('change', wake, true);
  globalThis.__appleAssistController = Object.freeze({ stop });
})();
