import './apple-duo-readonly.js';
import {validateAssist,assistStepEvidenceFault} from './assist-config.js';
import {PurchaseController,sendFixtureControl} from './purchase-background.js';
import {DEFAULTS,validate,appleUrl,TERMINAL,continuationFault,Engine} from './core.js';
const SLOT='currentTask',CONFIG='settings';
let serial=Promise.resolve();
const queue=job=>{const result=serial.then(job,job);serial=result.catch(()=>{});return result;};
const read=async()=> (await chrome.storage.local.get(SLOT))[SLOT]||null;
const save=async record=>chrome.storage.local.set({[SLOT]:record});
const event=(record,message)=>{record.events=[...(record.events||[]),{time:Date.now(),message}].slice(-80);};
async function paint(record){await chrome.action.setBadgeText({text:record&&!TERMINAL.has(record.state)?'ON':record?.state==='PAUSED'?'!':''});await chrome.action.setBadgeBackgroundColor({color:'#0071e3'});}
async function halt(reason,state='PAUSED'){
  const r=await read();if(!r)return r;
  const unresolved=r.state==='SUBMITTING'||r.claim?.status==='pending';
  if(TERMINAL.has(r.state)&&!(unresolved&&['PAUSED','STOPPED'].includes(r.state)))return r;
  // Every interrupted durable claim is unknown, regardless of which lifecycle path halted it.
  if(unresolved){state='UNKNOWN';if(!reason.includes('结果未知'))reason+=(r.mode==='purchase'?'；先前购买动作结果未知，不重试':r.mode==='assist'?'；先前点击结果未知，不重试':'；先前模拟提交结果未知，不重试');}
  r.state=state;r.reason=reason;if(r.engine){r.engine.state=state;r.engine.reason=reason;}if(r.claim&&state==='UNKNOWN')r.claim.status='unknown';event(r,reason);await save(r);await chrome.alarms.clear('watchdog');await paint(r);
  if(Number.isInteger(r.tabId)){if(r.mode==='purchase'&&r.testMode)await sendFixtureControl(chrome,{type:'HALT_PURCHASE_FIXTURE',targetTabId:r.tabId,taskId:r.id,reason},1000).catch(()=>{});else await chrome.tabs.sendMessage(r.tabId,{type:'HALT',taskId:r.id,reason}).catch(()=>{});}
  return r;
}
const purchase=new PurchaseController({chrome,read,save,halt,paint,event});
async function recover(){
  const r=await read();
  if(r?.mode==='purchase'){await purchase.recover();return;}
  if(r?.claim?.status==='pending'&&['PAUSED','STOPPED'].includes(r.state)){await halt('恢复先前未确认的动作状态','UNKNOWN');return;}
  const fault=continuationFault(r);if(fault)await halt(fault,r?.state==='SUBMITTING'?'UNKNOWN':'PAUSED');
  else if(r&&!TERMINAL.has(r.state))await chrome.alarms.create('watchdog',{periodInMinutes:1});
}
chrome.runtime.onStartup.addListener(()=>{void queue(async()=>{const r=await read();if(r&&!TERMINAL.has(r.state))await (r.mode==='purchase'?purchase.stop('浏览器重启，购买任务未自动恢复',r.state==='SUBMITTING'?'UNKNOWN':'PAUSED'):halt('浏览器重启，任务未自动恢复',r.state==='SUBMITTING'?'UNKNOWN':'PAUSED'));});});
chrome.runtime.onInstalled.addListener(()=>{void queue(async()=>{await chrome.storage.local.setAccessLevel({accessLevel:'TRUSTED_CONTEXTS'});const r=await read();if(r&&!TERMINAL.has(r.state))await (r.mode==='purchase'?purchase.stop('扩展安装或更新，需重新核对'):halt('扩展安装或更新，需重新预检'));});});
chrome.alarms.onAlarm.addListener(alarm=>{if(alarm.name==='watchdog')void queue(recover);});
chrome.tabs.onRemoved.addListener(tabId=>{void queue(async()=>{const r=await read();if(r?.tabId===tabId)await (r.mode==='purchase'?purchase.stop('任务标签页已关闭',r.state==='SUBMITTING'?'UNKNOWN':'PAUSED'):halt('任务标签页已关闭',r.state==='SUBMITTING'?'UNKNOWN':'PAUSED'));});});
chrome.tabs.onUpdated.addListener((tabId,change)=>{void queue(async()=>{const r=await read();if(r?.mode==='purchase'){await purchase.navigation(tabId,change);return;}if(change.status==='loading'&&r?.tabId===tabId&&(r.mode!=='simulate'||r.simDocument))await halt('页面重载或导航，需重新预检',r.state==='SUBMITTING'?'UNKNOWN':'PAUSED');});});

// Durable authorization is issued one step at a time; a checked claim cannot be replayed.
async function assistMessage(message,r){
  if(message.type==='DISCONNECT'||message.type==='ASSIST_STOP')return {task:await halt(String(message.reason||'页面中断，需要重新检查').slice(0,240))};
  if(!['ASSIST_CLAIM','ASSIST_CHECK','ASSIST_RESULT','ASSIST_SKIP','ASSIST_HEARTBEAT'].includes(message.type))throw Error('未知自动点击消息');
  const fault=continuationFault(r);if(fault){await halt(fault);throw Error(fault);}
  const c=(await chrome.storage.session.get(`config:${r.id}`))[`config:${r.id}`];
  if(!c){await halt('会话配置丢失，需要重新检查');throw Error('会话配置丢失');}
  if(message.type==='ASSIST_HEARTBEAT'){r.lastSeen=Date.now();await save(r);return{state:r.state,stepIndex:r.stepIndex};}
  if(!Number.isInteger(message.stepIndex)||message.stepIndex!==r.stepIndex||!c.steps[r.stepIndex])throw Error('步骤不匹配');
  const step=c.steps[r.stepIndex];
  if(message.type==='ASSIST_RESULT'){
    if(r.state!=='SUBMITTING'||r.claim?.status!=='pending'||message.claimToken!==r.claim.token)throw Error('没有匹配的待确认点击');
    if(message.outcome!=='confirmed'||r.claim.checked!==true){await halt(String(message.reason||'点击结果未知，不自动重试').slice(0,240),'UNKNOWN');return{state:'UNKNOWN',stepIndex:r.stepIndex};}
    r.claim.status='confirmed';r.claim.confirmedAt=Date.now();r.claims.push({...r.claim});r.claim=null;r.stepIndex++;
  }else{
    const evidenceFault=assistStepEvidenceFault(c,r.stepIndex,message.evidence);
    if(evidenceFault){await halt(evidenceFault);throw Error(evidenceFault);}
    if(message.type==='ASSIST_SKIP'){
      if(r.claim?.status==='pending')throw Error('待确认点击不能跳过');
      const key=step.group==='dimensionColor'?'color':'storage';
      if(step.kind!=='radio'||message.evidence[key]!==step.name)throw Error('仅已选中的规格可跳过');
      r.claims.push({stepIndex:r.stepIndex,status:'skipped',time:Date.now()});r.stepIndex++;
    }else if(message.type==='ASSIST_CLAIM'){
      if(r.claim||r.state==='SUBMITTING')return{action:'none',state:r.state,stepIndex:r.stepIndex};
      r.claim={stepIndex:r.stepIndex,token:crypto.randomUUID(),time:Date.now(),deadline:Date.now()+step.timeoutMs+5000,status:'pending',checked:false};
      r.state='SUBMITTING';r.reason=`正在执行第 ${r.stepIndex+1} 步：${step.name}`;r.lastSeen=Date.now();
      event(r,r.reason);await save(r);await paint(r);
      return{action:'assist-click',claimToken:r.claim.token,deadline:r.claim.deadline,state:r.state,stepIndex:r.stepIndex};
    }else if(message.type==='ASSIST_CHECK'){
      if(r.state!=='SUBMITTING'||r.claim?.status!=='pending'||r.claim.token!==message.claimToken||r.claim.checked)return{allowed:false,state:r.state,stepIndex:r.stepIndex};
      r.claim.checked=true;r.lastSeen=Date.now();await save(r);
      return{allowed:true,deadline:r.claim.deadline,state:r.state,stepIndex:r.stepIndex};
    }
  }
  r.lastSeen=Date.now();r.state=r.stepIndex>=c.steps.length?'DONE':'WAITING';
  r.reason=r.state==='DONE'?'配置步骤完成；最终订单提交尚未实现，请自行核对后手动完成':`第 ${r.stepIndex} 步已确认，等待下一步`;
  event(r,r.reason);await save(r);await paint(r);if(r.state==='DONE')await chrome.alarms.clear('watchdog');
  return{state:r.state,stepIndex:r.stepIndex,reason:r.reason};
}

chrome.runtime.onMessage.addListener((message,sender,reply)=>{
  if(['START_PURCHASE_FIXTURE','HALT_PURCHASE_FIXTURE'].includes(message.type))return false;
  queue(async()=>{
    if(sender.id!==chrome.runtime.id)throw Error('消息来源无效');
    const fromExtension=typeof sender.url==='string'&&sender.url.startsWith(chrome.runtime.getURL(''));
    if(['STATUS','START','STOP','PURCHASE_CLEAR_ADDRESS','PURCHASE_RESUME','PURCHASE_SAVE_ADDRESS_PROFILE','PURCHASE_LOAD_ADDRESS_PROFILE','PURCHASE_CLEAR_ADDRESS_PROFILE','PURCHASE_FIXTURE_START','PURCHASE_FIXTURE_RESET'].includes(message.type)&&!fromExtension)throw Error('仅扩展界面可控制任务');
    if(message.type==='STATUS'){await recover();return {defaults:DEFAULTS,settings:(await chrome.storage.local.get(CONFIG))[CONFIG]||null,task:await read(),liveEnabled:false,assistedEnabled:true,purchaseEnabled:true,unpaidOrdersEnabled:true,finalOrdersEnabled:false};}
    if(['PURCHASE_SAVE_ADDRESS_PROFILE','PURCHASE_LOAD_ADDRESS_PROFILE','PURCHASE_CLEAR_ADDRESS_PROFILE'].includes(message.type))return purchase.profile(message);
    if(message.type==='PURCHASE_FIXTURE_START')return purchase.start(message,sender,true);
    if(message.type==='PURCHASE_FIXTURE_RESET')return purchase.resetFixture(message,sender);
    if(message.type==='PURCHASE_RESUME')return purchase.resume(message);
    if(message.type==='PURCHASE_CLEAR_ADDRESS'){const r=await read();if(r?.mode==='purchase'){if(!TERMINAL.has(r.state))await purchase.stop('用户已清除会话地址，购买任务已停止','STOPPED');else await purchase.clearPrivate(r.id);}return{cleared:true,task:await read()};}
    if(message.type==='STOP'){const r=await read();return {task:r?.mode==='purchase'?await purchase.stop('用户已停止购买任务，不会自动恢复','STOPPED'):await halt(r?.state==='SUBMITTING'?'已停止，先前动作结果未知，不重试':'用户已停止，不会自动恢复',r?.state==='SUBMITTING'?'UNKNOWN':'STOPPED')};}
    if(message.type==='START'){
      if(message.config?.mode==='purchase')return purchase.start(message,sender);
      const existing=await read();if(existing&&!TERMINAL.has(existing.state))throw Error('已有任务，请先停止');
      const c=message.config?.mode==='assist'?validateAssist(message.config):validate(message.config);
      await chrome.storage.local.set({[CONFIG]:c});
      const id=crypto.randomUUID();let tabId=null;
      if(c.mode!=='simulate'){
        const tab=await chrome.tabs.get(message.tabId);
        if(!tab.active||!appleUrl(tab.url)||(new URL(tab.url).href!==new URL(c.url).href&&!(globalThis.AppleDuoReadonly.supportsURL(tab.url)&&globalThis.AppleDuoReadonly.supportsURL(c.url))))throw Error('请先在当前标签页打开配置中的 Apple 购买链接');
        const permission={origins:[`${new URL(c.url).origin}/*`]};
        if(!await chrome.permissions.contains(permission))throw Error('未获得该 Apple 站点权限');
        tabId=tab.id;
      }
      const now=Date.now();const effective=c.mode==='simulate'?{...c,targetTime:new Date(now+c.countdownSeconds*1000).toISOString(),expiresAt:new Date(now+180000).toISOString()}:c;
      const r={id,mode:c.mode,tabId,state:'READY',reason:'准备就绪',lastSeen:now,expiresAt:Date.parse(effective.expiresAt),claim:null,...(c.mode==='assist'?{stepIndex:0,claims:[]}:{}),remainingMs:null,source:null,events:[]};
      await chrome.storage.session.set({[`config:${id}`]:effective});
      event(r,c.mode==='simulate'?'仅本地模拟任务，无真实交易':c.mode==='assist'?'用户启动官网配置步骤自动点击；最终订单与支付未实现':'当前 Apple 标签页只读预演，真实点击和提交锁定');await save(r);await paint(r);await chrome.alarms.create('watchdog',{periodInMinutes:1});
      try{
        if(c.mode==='simulate'){
          const tab=await chrome.tabs.create({url:'about:blank',active:true});r.tabId=tab.id;await save(r);
          await chrome.tabs.update(tab.id,{url:chrome.runtime.getURL(`simulator.html?task=${id}`)});
        }else{
          await chrome.scripting.executeScript({target:{tabId},files:c.mode==='assist'?['dom-driver.js','apple-duo-readonly.js','assist-content.js']:['dom-driver.js','apple-duo-readonly.js','content.js'],injectImmediately:true});
          const response=await chrome.tabs.sendMessage(tabId,{type:c.mode==='assist'?'START_ASSISTING':'START_OBSERVING',taskId:id,config:effective});
          if(!response?.ok)throw Error('内容脚本未就绪');
        }
      }catch{await halt('无法启动任务页面，请人工检查');throw Error('无法启动任务页面，任务已暂停');}
      return {task:await read()};
    }
    const r=await read();
    if(!r||r.id!==message.taskId||TERMINAL.has(r.state))throw Error('任务已结束或不匹配');
    if(r.mode==='purchase')return purchase.handle(message,sender,r);
    const simulator=fromExtension&&sender.url.startsWith(chrome.runtime.getURL('simulator.html'))&&r.mode==='simulate';
    const senderTabId=sender.tab?.id??(simulator?message.tabId:null);
    if(senderTabId!==r.tabId)throw Error('标签页与任务不匹配');
    if(!simulator&&!(['official-readonly','assist'].includes(r.mode)&&appleUrl(sender.url)))throw Error('页面不在允许范围');
    if(r.mode==='assist')return assistMessage(message,r);
    if(message.type==='SIM_CONFIG'){
      if(!simulator)throw Error('非模拟页面');
      if(typeof message.documentNonce!=='string'||message.documentNonce.length>80)throw Error('模拟文档标识无效');
      if(r.simDocument&&r.simDocument!==message.documentNonce){await halt('模拟页面重载，任务不会自动恢复',r.state==='SUBMITTING'?'UNKNOWN':'PAUSED');throw Error('模拟页面重载，请重新预检');}
      r.simDocument=message.documentNonce;await save(r);
      return {config:(await chrome.storage.session.get(`config:${r.id}`))[`config:${r.id}`]};
    }
    if(simulator&&message.documentNonce!==r.simDocument)throw Error('模拟文档与任务不匹配');
    if(message.type==='DISCONNECT')return {task:await halt('页面离开、隐藏或运行中断，需要重新预检',r.state==='SUBMITTING'?'UNKNOWN':'PAUSED')};
    if(message.type==='OBSERVE'||message.type==='MOCK_RESULT'){
      const fault=continuationFault(r);if(fault){await halt(fault,r.state==='SUBMITTING'?'UNKNOWN':'PAUSED');throw Error(fault);}
      const c=(await chrome.storage.session.get(`config:${r.id}`))[`config:${r.id}`];
      if(!c){await halt('会话配置丢失，需要重新预检');throw Error('会话配置丢失');}
      if(r.mode==='official-readonly'&&message.type==='OBSERVE'&&message.snapshot?.pageEvidence?.supported){
        // Retain bounded read-only diagnostics, never use them to authorize an action.
        const e=message.snapshot.pageEvidence,short=x=>typeof x==='string'?x.slice(0,160):null;
        const options=key=>Array.isArray(e.options?.[key])?e.options[key].slice(0,12).map(x=>({name:short(x.name),selected:x.selected===true,enabled:x.enabled===true})):[];
        r.pageEvidence={summary:short(e.summary),itemPriceMinor:Number.isSafeInteger(e.itemPriceMinor)?e.itemPriceMinor:null,itemCurrency:short(e.itemCurrency),releaseNotice:short(e.releaseNotice),pageKind:short(e.pageKind),model:short(e.model),color:short(e.color),storage:short(e.storage),
          options:{color:options('color'),storage:options('storage')},continue:{status:short(e.continue?.status),name:short(e.continue?.name),enabled:e.continue?.enabled===true},
          evidenceMissing:Array.isArray(e.evidenceMissing)?e.evidenceMissing.slice(0,20).map(short):[],ambiguity:Array.isArray(e.ambiguity)?e.ambiguity.slice(0,20).map(short):[],observedAt:Date.now()};
      }
      const engine=new Engine(c);if(r.engine)Object.assign(engine,r.engine);
      let action={type:'none'};
      if(message.type==='MOCK_RESULT'){
        if(!simulator||!r.claim||r.state!=='SUBMITTING')throw Error('没有待确认的模拟提交');
        engine.result(message.outcome==='confirmed'?'confirmed':'unknown');
      }else{
        action=engine.observe(message.snapshot);
        if(action.type==='mock-submit'){
          if(!simulator||r.claim){await halt('重复模拟提交已阻止','UNKNOWN');throw Error('模拟提交已锁定');}
          r.claim={time:Date.now(),status:'pending'};
        }
      }
      const changed=r.state!==engine.state;
      r.engine=Object.fromEntries(['state','reason','remainingMs','source','lastRemaining','lastPrice','claimed'].filter(k=>engine[k]!==undefined).map(k=>[k,engine[k]]));
      r.state=engine.state;r.reason=engine.reason;r.remainingMs=engine.remainingMs;r.source=engine.source;r.lastSeen=Date.now();
      if(r.claim&&['DONE','UNKNOWN'].includes(r.state))r.claim.status=r.state==='DONE'?'confirmed':'unknown';
      if(changed)event(r,r.reason);
      // Claim and engine state are durable before a simulated action can be returned.
      await save(r);await paint(r);if(TERMINAL.has(r.state))await chrome.alarms.clear('watchdog');
      return {state:r.state,reason:r.reason,remainingMs:r.remainingMs,source:r.source,action:action.type};
    }
    throw Error('未知消息');
  }).then(value=>reply({ok:true,...value}),error=>reply({ok:false,error:error.message}));
  return true;
});
void queue(async()=>{await purchase.recover(true);await recover();});
