import {DEFAULTS,validate,TERMINAL} from './core.js';
import {validateAssist} from './assist-config.js';
const form=document.querySelector('form'),fieldset=document.querySelector('fieldset'),start=document.querySelector('#start'),stop=document.querySelector('#stop'),demo=document.querySelector('#demo'),error=document.querySelector('#error');
const labels={countdown:'倒计时',model:'型号',storage:'容量',color:'颜色',quantity:'数量',total:'含全部费用总价',currency:'货币',region:'地区',delivery:'送达方式',button:'购买按钮'};
let pending=false,lastLog='';
const connectionError='扩展后台不可用；不会自动恢复任务，请人工检查。';
for(const[key,labelText]of Object.entries(labels)){const label=document.createElement('label');label.textContent=labelText;const input=document.createElement('input');input.name=`selector_${key}`;input.autocomplete='off';label.append(input);document.querySelector('#selectors').append(label);}
async function send(message){const r=await chrome.runtime.sendMessage(message);if(!r?.ok)throw Error(r?.error||'扩展后台未响应');return r;}
function modeLabel(){const assist=form.elements.mode.value==='assist';start.textContent=assist?'开始配置点击':form.elements.mode.value==='simulate'?'开始模拟':'开始只读预演';document.querySelector('#assist-settings').hidden=!assist;document.querySelector('#budget-label').textContent=assist?'商品标价 × 数量上限（元）':'最高总价（元）';form.elements.maxTotal.placeholder=assist?'仅商品标价 × 数量':'含税费、配送费';document.querySelector('#time-label').textContent=assist?'开售时间（本模式不用，点击开始立即执行）':'开售时间（含时区偏移）';form.elements.targetTime.required=!assist;form.elements.expiresAt.required=!assist;}
function defaultPlan(c){return c.steps?.length===2&&c.steps.every((step,index)=>step.kind==='radio'&&step.group===['dimensionColor','dimensionCapacity'][index]&&step.name===c[['color','storage'][index]]&&!step.selector&&step.timeoutMs===10000&&step.confirm?.kind==='checked');}
function fill(c){for(const[key,value]of Object.entries(c))if(form.elements[key]&&!['confirmedAssist','assistSteps'].includes(key))form.elements[key].value=String(value);for(const[key,value]of Object.entries(c.selectors||{}))form.elements[`selector_${key}`].value=value;if(form.elements.assistSteps)form.elements.assistSteps.value=c.mode==='assist'&&c.steps&&!defaultPlan(c)?JSON.stringify(c.steps,null,2):'';form.elements.quantitySelector.value=c.quantitySelector||'';form.elements.confirmedAssist.checked=false;modeLabel();}
function config(){const c={...DEFAULTS,regionConfirmed:true,selectors:{}};for(const el of form.elements)if(el.name&&!el.name.startsWith('selector_')&&el.name!=='confirmedAssist')c[el.name]=el.value;c.confirmedAssist=form.elements.confirmedAssist.checked===true;for(const key of ['quantity','maxTotal','pollMs','countdownSeconds'])c[key]=Number(c[key]);for(const key of Object.keys(labels))c.selectors[key]=form.elements[`selector_${key}`].value.trim();return c.mode==='assist'?validateAssist(c):validate(c);}
function lock(value){fieldset.disabled=value;start.disabled=value;demo.disabled=value;stop.disabled=!value;}
const stateNames={READY:'准备就绪',WAITING:'等待开售',SUBMITTING:'仅模拟提交中',PAUSED:'已暂停',STOPPED:'已停止',DONE:'已完成',UNKNOWN:'结果未知 · 已锁定'};
function render(r){const t=r.task;const assist=t?.mode==='assist'||t?.config?.mode==='assist';document.querySelector('#state').textContent=t?(assist&&t.state==='SUBMITTING'?'步骤执行中':stateNames[t.state]||t.state):'尚未启动';document.querySelector('#reason').textContent=t?.reason||'中国大陆官网 · 国内配送';const s=t?.remainingMs==null?null:Math.ceil(Math.max(0,t.remainingMs)/1000);document.querySelector('#clock').textContent=s===null?'--:--':`${String(Math.floor(s/3600)).padStart(2,'0')}:${String(Math.floor(s%3600/60)).padStart(2,'0')}:${String(s%60).padStart(2,'0')}`;document.querySelector('#source').textContent=t?.source||'默认模拟，真实下单锁定';if(!pending)lock(!!t&&!TERMINAL.has(t.state));const log=JSON.stringify(t?.events||[]);if(log!==lastLog){lastLog=log;document.querySelector('#events').replaceChildren(...(t?.events||[]).map(item=>{const li=document.createElement('li');li.textContent=`${new Date(item.time).toLocaleTimeString('zh-CN')} ${item.message}`;return li;}));}}
form.elements.mode.addEventListener('change',()=>{form.elements.confirmedAssist.checked=false;modeLabel();});
form.onsubmit=async event=>{event.preventDefault();error.textContent='';let c;try{c=config();}catch(e){error.textContent=e.message;return;}
 form.elements.confirmedAssist.checked=false;pending=true;lock(true);
 try{
  let tabId;
  if(c.mode==='official-readonly'||c.mode==='assist'){
    // Optional permission is requested only from this explicit user gesture.
    const granted=await chrome.permissions.request({origins:[`${new URL(c.url).origin}/*`]});
    if(!granted)throw Error('站点权限未授权，任务未启动');
    const[tab]=await chrome.tabs.query({active:true,currentWindow:true});tabId=tab?.id;
  }
  render(await send({type:'START',config:c,tabId}));
 }catch(e){error.textContent=e.message;}finally{pending=false;await poll();}
};
stop.onclick=async()=>{error.textContent='';try{render(await send({type:'STOP'}));}catch(e){error.textContent=e.message;}};
demo.onclick=()=>{fill({...DEFAULTS,storage:'模拟容量（虚构）',color:'模拟颜色（虚构）',maxTotal:200});error.textContent='已载入虚构规格、100.00 测试总价和 200.00 测试预算，不代表 Apple 商品或报价。';};
async function poll(){try{render(await send({type:'STATUS'}));if(error.textContent===connectionError)error.textContent='';}catch{error.textContent=connectionError;lock(true);stop.disabled=true;}}
try{const r=await send({type:'STATUS'});fill(r.settings||DEFAULTS);render(r);setInterval(poll,1000);}catch{error.textContent='无法连接扩展后台，请检查扩展错误。';lock(true);stop.disabled=true;}
