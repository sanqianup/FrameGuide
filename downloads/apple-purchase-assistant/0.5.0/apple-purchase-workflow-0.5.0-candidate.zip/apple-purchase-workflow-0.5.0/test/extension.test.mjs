import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {DEFAULTS,validate,appleUrl,parseCountdown,Engine,continuationFault} from '../extension/core.js';
import {Engine as OriginalEngine,parseCountdown as originalParse} from '../core.mjs';

const now=Date.parse('2026-10-16T11:59:58Z');
const c=(overrides={})=>validate({...DEFAULTS,storage:'TEST-256',color:'TEST-WHITE',delivery:'国内配送',maxTotal:200,...overrides},now);
const s=(overrides={})=>({observedAt:now,region:'CN',model:'iPhone Duo',storage:'TEST-256',color:'TEST-WHITE',delivery:'国内配送',quantity:'1',currency:'CNY',totalMinor:10000,countdownPresent:true,countdownText:'00:00',buttonUnique:true,buttonEnabled:true,...overrides});

test('extension URL whitelist is restricted to two visible Apple store domains',()=>{
 for(const u of ['https://www.apple.com.cn/shop/buy-iphone/iphone-duo','https://www.apple.com/us/shop/buy-iphone/iphone-duo'])assert.equal(appleUrl(u),true);
 for(const u of ['https://evil.test/shop','https://www.apple.com.cn.evil.test/shop','https://secure.store.apple.com/shop','http://www.apple.com.cn/shop','https://www.apple.com.cn:444/shop'])assert.equal(appleUrl(u),false);
});
test('extension countdown parser preserves original pure logic',()=>{
 for(const value of ['00:00','00:03','01:02:03','1天2小时3分4秒','3秒','未知','00:99',null])assert.equal(parseCountdown(value),originalParse(value));
});
test('shared original and extension engines agree on fixture state/action transitions',()=>{
 const sequences=[[s()],[s({countdownText:'00:03'}),s({countdownText:'00:01'}),s()],[s({countdownText:'00:02'}),s({countdownText:'00:10'})],[s({soldOut:true})],[s({blocker:'付款方式'})],[s({countdownText:'00:03'}),s({totalMinor:11000})],[s({color:'WRONG'})],[s({buttonEnabled:false}),s()]];
 for(const sequence of sequences){const a=new OriginalEngine(c()),b=new Engine(c());for(const snapshot of sequence){assert.equal(a.observe(snapshot,now).type,b.observe(snapshot,now).type);assert.equal(a.state,b.state);assert.equal(a.remainingMs,b.remainingMs);}}
});
test('real execution cannot be selected, missing fields and stale official start fail',()=>{
 assert.equal(DEFAULTS.mode,'simulate');assert.throws(()=>validate(DEFAULTS,now));
 for(const extra of [{mode:'live'},{mode:'execute'},{mode:'official'},{maxTotal:0},{pollMs:10},{quantity:0},{timeZone:'INVALID'},{mode:'official-readonly',regionConfirmed:false}])assert.throws(()=>c(extra));
 assert.throws(()=>validate({...c(),mode:'official-readonly'},Date.parse(DEFAULTS.expiresAt)+1));
});
test('official readonly returns preview, never claim',()=>{const e=new Engine(c({mode:'official-readonly'}));assert.equal(e.observe(s(),now).type,'preview');assert.equal(e.state,'DONE');assert.equal(e.claimed,false);});
test('duplicate observation, unknown result, stop and late exceptions cannot restart',()=>{
 const e=new Engine(c());assert.equal(e.observe(s(),now).type,'mock-submit');for(let i=0;i<10;i++)assert.equal(e.observe(s(),now).type,'none');e.result('unknown');e.pause('late');assert.equal(e.state,'UNKNOWN');assert.equal(e.observe(s(),now).type,'none');
 const stopped=new Engine(c());stopped.stop();stopped.pause('late');assert.equal(stopped.state,'STOPPED');
});
test('engine can be restored across service worker sleeps without duplicate action',()=>{
 const e=new Engine(c());e.observe(s({countdownText:'00:02'}),now);
 const stored=JSON.parse(JSON.stringify(e));const restored=new Engine(c());Object.assign(restored,stored);assert.equal(restored.observe(s(),now).type,'mock-submit');
 const restarted=new Engine(c());Object.assign(restarted,JSON.parse(JSON.stringify(restored)));assert.equal(restarted.observe(s(),now).type,'none');
});
test('heartbeat interruption, expiry and stale pending claim fail closed',()=>{
 const fresh={state:'WAITING',lastSeen:now,expiresAt:now+120000};assert.equal(continuationFault(fresh,now+1000),null);
 assert.match(continuationFault(fresh,now+71000),/心跳/);assert.match(continuationFault({...fresh,expiresAt:now},now+1),/过期/);
 assert.equal(continuationFault({...fresh,state:'SUBMITTING',claim:{time:now}},now+1000),null);
 assert.match(continuationFault({...fresh,state:'SUBMITTING',claim:{time:now-11000}},now),/未知/);
 assert.equal(continuationFault({...fresh,state:'STOPPED'},now+999999),null);
});
test('manifest has no broad hosts, cookies, tabs listing or remote content scripts',async()=>{
 const manifest=JSON.parse(await readFile(new URL('../extension/manifest.json',import.meta.url),'utf8'));
 assert.equal(manifest.manifest_version,3);assert.deepEqual(manifest.permissions,['activeTab','scripting','storage','alarms']);
 assert.deepEqual(manifest.optional_host_permissions,['https://www.apple.com.cn/*','https://www.apple.com/*','https://secure6.www.apple.com.cn/*']);assert.equal(manifest.content_scripts,undefined);assert.equal(manifest.host_permissions,undefined);
 const content=await readFile(new URL('../extension/content.js',import.meta.url),'utf8');assert.doesNotMatch(content,/\.click\s*\(|fetch\s*\(|document\.cookie|localStorage|sessionStorage|\.value\b/);
});
