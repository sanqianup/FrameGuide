import { test } from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import fs from 'node:fs';
import { webcrypto, createHash } from 'node:crypto';
const sources = ['dom-driver.js', 'apple-duo-readonly.js', 'purchase-policy.js', 'purchase-content.js'].map(file => fs.readFileSync(new URL(`../extension/${file}`, import.meta.url), 'utf8'));
const ROOT = 'https://www.apple.com.cn';
const values = new WeakMap();
class Element {
  constructor(doc, tag, text = '', attrs = {}) {
    this.ownerDocument = doc; this.tagName = tag.toUpperCase(); this.nodeType = 1; this.ownText = text;
    this.attributes = new Map(Object.entries(attrs)); this.children = []; this.parentElement = null;
    this.disabled = false; this.hidden = false; this.readOnly = false; this.checked = false; this.clicks = 0; this.events = {};
    this.style = { display: 'block', visibility: 'visible', opacity: '1', contentVisibility: 'visible' };
  }
  get textContent() { if (/^(INPUT|TEXTAREA|SELECT)$/u.test(this.tagName)) assert.fail('Control text must not be read'); return this.ownText + this.children.filter(x => !/^(INPUT|TEXTAREA|SELECT)$/u.test(x.tagName)).map(x => x.textContent).join(''); }
  set textContent(value) { this.ownText = String(value); this.children = []; }
  get isConnected() { return this.ownerDocument.contains(this); }
  getAttribute(key) { if (key === 'value') assert.fail('Control value attributes must not be read'); return this.attributes.get(key) ?? null; }
  setAttribute(key, value) { this.attributes.set(key, String(value)); }
  hasAttribute(key) { return this.attributes.has(key); }
  removeAttribute(key) { this.attributes.delete(key); }
  append(...nodes) { for (const node of nodes) { node.remove(); node.parentElement = this; this.children.push(node); } }
  remove() { if (this.parentElement) this.parentElement.children = this.parentElement.children.filter(x => x !== this); this.parentElement = null; }
  contains(node) { return node === this || this.children.some(child => child.contains(node)); }
  matches(selector) {
    if (selector.includes(',')) return selector.split(',').some(s => this.matches(s.trim()));
    if (selector === '*') return true;
    if (selector === ':disabled') return this.disabled || !!this.closest('fieldset')?.disabled;
    if (/^#[\w-]+$/u.test(selector)) return this.getAttribute('id') === selector.slice(1);
    const m = /^(\w+)?(?:\[([\w-]+)(?:="([^"]*)")?\])?$/u.exec(selector);
    if (!m) throw Error('Unsupported test selector: ' + selector);
    return (!m[1] || this.tagName.toLowerCase() === m[1]) && (!m[2] || this.hasAttribute(m[2]) && (m[3] === undefined || this.getAttribute(m[2]) === m[3]));
  }
  closest(selector) { for (let node = this; node; node = node.parentElement) if (node.matches(selector)) return node; return null; }
  querySelectorAll(selector) { return this.children.flatMap(child => [...(child.matches(selector) ? [child] : []), ...child.querySelectorAll(selector)]); }
  getClientRects() { return this.isConnected && !this.hidden && this.style.display !== 'none' ? [{}] : []; }
  addEventListener(type, fn) { (this.events[type] ??= []).push(fn); }
  dispatchEvent(event) { for (const fn of this.events[event.type] ?? []) fn(event); for (const fn of this.ownerDocument.events[event.type] ?? []) fn(event); return true; }
  click() { this.clicks++; for (const fn of this.events.click ?? []) fn({ type: 'click', isTrusted: false }); this.onClick?.(); this.ownerDocument.mutate(); }
}
class Input extends Element {
  constructor(doc, tag, text, attrs) { super(doc, tag, text, attrs); values.set(this, ''); this.writes = 0; this.validity = { valid: true }; }
  get value() { if (/password|cc-number/iu.test([...this.attributes.values()].join(' '))) assert.fail('Sensitive value read'); return values.get(this); }
  set value(value) { if (/password|cc-number/iu.test([...this.attributes.values()].join(' '))) assert.fail('Sensitive value write'); values.set(this, String(value)); this.writes++; }
}
class Option extends Element {
  get value() { return this.attributes.get('value') ?? this.ownText; }
  get text() { return this.ownText; }
}
const address = { fullName: 'Fixture Person', addressLine1: '10 Test Street', city: 'Fixture City', province: 'Fixture Province', district: 'Fixture District', phone: '13800000000' };
const fieldMap = { fullName: 'name', addressLine1: 'address-line1', city: 'address-level2', province: 'address-level1', district: 'address-level3', phone: 'tel' };
const addressText = Object.values(address).join(' ');
function plan({ multipage = false, existing = false } = {}) {
  const evidence = { model: '#model', storage: '#storage', color: '#color', quantity: '#quantity', currency: '#currency', region: '#region', delivery: '#delivery', itemCount: '#item-count' };
  const paths = multipage ? ['/shop/product', '/shop/address', '/shop/review', '/shop/submit'] : Array(4).fill('/shop/product');
  const steps = [
    { stage: 'add-to-bag', kind: 'button', path: paths[0], target: { role: 'button', name: 'Add to bag', selector: '#add' }, evidence: { ...evidence, itemPrice: '#item-price' }, confirm: { selector: '#bag-done', text: 'Bag ready', ...(multipage ? { nextPath: paths[1] } : {}) } },
    { stage: 'address', kind: 'address', path: paths[1], ...(existing ? {} : { fields: Object.entries(fieldMap).map(([key, autocomplete]) => ({ key, autocomplete, name: key, selector: '#field-' + key })) }), evidence: { ...evidence, itemPrice: '#item-price' }, addressConfirmation: { selector: '#selected-address', ...(existing ? {} : { keys: Object.keys(address) }) }, confirm: { selector: '#address-done', text: 'Address ready' } },
    { stage: 'review', kind: 'button', path: paths[2], target: { role: 'button', name: 'Continue to order review', selector: '#review' }, evidence: { ...evidence, total: '#total' }, totalIncludesTaxShipping: { selector: '#total-completeness', text: 'Total includes tax and shipping' }, addressConfirmation: { selector: '#selected-address', ...(existing ? {} : { keys: Object.keys(address) }) }, confirm: { selector: '#review-done', text: 'Order review ready', ...(multipage ? { nextPath: paths[3] } : {}) } },
    { stage: 'submit-unpaid', kind: 'button', path: paths[3], target: { role: 'button', name: 'Create unpaid order', selector: '#submit' }, evidence: { ...evidence, total: '#total', noCharge: '#no-charge' }, totalIncludesTaxShipping: { selector: '#total-completeness', text: 'Total includes tax and shipping' }, addressConfirmation: { selector: '#selected-address', ...(existing ? {} : { keys: Object.keys(address) }) }, noChargeText: 'Creates an unpaid order with no charge.', confirm: { selector: '#order-done', text: 'Unpaid order created' } }
  ].map(step => ({ ...step, timeoutMs: 15000 }));
  // Address fill itself does not navigate. A separately mapped address-stage
  // continuation button is required when the address and review pages differ.
  if (multipage) {
    steps.splice(2, 0, { stage: 'address', kind: 'button', path: paths[1], target: { role: 'button', name: 'Continue from address', selector: '#continue-address' }, addressConfirmation: { selector: '#selected-address', ...(existing ? {} : { keys: Object.keys(address) }) }, evidence: { ...evidence, itemPrice: '#item-price' }, confirm: { selector: '#address-next', text: 'Delivery confirmed', nextPath: paths[2] }, timeoutMs: 15000 });
  }
  return { mode: 'purchase', confirmedPurchase: true, addressMode: existing ? 'existing' : 'new', url: ROOT + paths[0], model: 'Fixture Phone', storage: '256GB', color: 'White', quantity: 1, currency: 'CNY', region: 'CN', delivery: 'delivery', maxTotal: 110, expiresAt: new Date(200000).toISOString(), steps };
}
function backend(config = plan()) {
  return { config, index: 0, pending: null, state: 'WAITING', sent: [], fingerprint: null, custom: null,
    async send(message) {
      this.sent.push(message); const override = this.custom?.(message); if (override !== undefined) return override;
      const step = this.config.steps[this.index];
      if (message.type === 'PURCHASE_BIND') return { ok: true, config: this.config, stepIndex: this.index, state: this.state,
        ...(this.config.addressMode === 'new' && ['address', 'review', 'submit-unpaid'].includes(step.stage) ? { address } : {}), ...(this.pending?.checked && message.url === ROOT + step.confirm.nextPath ? { pendingClaim: this.pending } : {}) };
      if (message.type === 'PURCHASE_CONFIRM_ADDRESS') { assert.equal(message.addressConfirmed, true); assert.match(message.addressFingerprint, /^[\da-f]{64}$/u); this.fingerprint = message.addressFingerprint; return { ok: true, addressConfirmed: true }; }
      if (message.type === 'PURCHASE_CLAIM') {
        assert.equal(this.pending, null, 'No duplicate claim');
        if (this.config.addressMode === 'existing' && step.addressConfirmation) assert.equal(message.evidence.addressFingerprint, this.fingerprint);
        this.pending = { token: 'token-' + this.index, checked: false, deadline: (message.evidence?.observedAt ?? 1000) + 50000 }; this.state = 'SUBMITTING';
        return { ok: true, action: 'purchase-act', claimToken: this.pending.token, deadline: this.pending.deadline, state: this.state };
      }
      if (message.type === 'PURCHASE_CHECK') { assert.equal(message.claimToken, this.pending.token); assert.equal(this.pending.checked, false); this.pending.checked = true; return { ok: true, allowed: true, deadline: this.pending.deadline, address }; }
      if (message.type === 'PURCHASE_RESULT') {
        if (message.outcome !== 'confirmed') { this.state = 'UNKNOWN'; return { ok: true, state: this.state }; }
        assert.equal(message.evidence.confirmation.matched, true); this.index++; this.pending = null; this.state = this.index === this.config.steps.length ? 'DONE' : 'WAITING';
        return { ok: true, state: this.state, stepIndex: this.index };
      }
      if (message.type === 'PURCHASE_HEARTBEAT') return { ok: true, state: this.state, stepIndex: this.index };
      if (message.type === 'PURCHASE_DISCONNECT') return { ok: true, state: this.state };
      this.state = 'PAUSED'; return { ok: true, state: this.state };
    }
  };
}
function harness({ b = backend(), path = new URL(b.config.url).pathname, page = 0 } = {}) {
  let now = 1000, listener, observer, timerID = 0;
  const timers = new Map(), events = {};
  const document = { nodeType: 9, visibilityState: 'visible', events: {}, defaultView: { getComputedStyle: node => node.style },
    createElement(tag) { return new (tag.toLowerCase() === 'option' ? Option : /^(?:input|textarea|select)$/iu.test(tag) ? Input : Element)(this, tag); },
    create(tag, text = '', attrs = {}) { return new (tag.toLowerCase() === 'option' ? Option : /^(?:input|textarea|select)$/iu.test(tag) ? Input : Element)(this, tag, text, attrs); },
    contains(node) { return node === this || this.body.contains(node); },
    querySelectorAll(selector) { return [...(this.body.matches(selector) ? [this.body] : []), ...this.body.querySelectorAll(selector)]; },
    addEventListener(type, fn) { (this.events[type] ??= []).push(fn); }, mutate() { observer?.fn([]); }
  };
  Object.defineProperty(document, 'cookie', { get() { assert.fail('Cookies must never be read'); } });
  document.body = document.create('body'); const main = document.create('main'); document.body.append(main);
  const nodes = {};
  function add(id, text, tag = 'span', attrs = {}) { const node = document.create(tag, text, { id, ...attrs }); nodes[id] = node; main.append(node); return node; }
  for (const [key, text] of Object.entries({ model: 'Fixture Phone', storage: '256GB', color: 'White', quantity: '1', currency: 'CNY', region: 'CN', delivery: 'delivery', 'item-count': '1', 'item-price': '100.00', total: '105.00', 'total-completeness': 'Total includes tax and shipping', 'no-charge': 'Creates an unpaid order with no charge.' })) add(key, text);
  for (const [id, text] of Object.entries({ 'bag-done': 'Bag ready', 'address-done': 'Address ready', 'address-next': 'Delivery confirmed', 'review-done': 'Order review ready', 'order-done': 'Unpaid order created' })) add(id, text).hidden = true;
  const selected = add('selected-address', b.config.addressMode === 'existing' || page > 0 ? addressText : '');
  for (const [id, text, done] of [['add', 'Add to bag', 'bag-done'], ['review', 'Continue to order review', 'review-done'], ['submit', 'Create unpaid order', 'order-done'], ['continue-address', 'Continue from address', 'address-next']]) {
    const node = add(id, text, 'button', { type: 'button' }); node.onClick = () => { nodes[done].hidden = false; };
  }
  const fields = {};
  for (const [key, autocomplete] of Object.entries(fieldMap)) {
    const input = add('field-' + key, '', 'input', { type: key === 'phone' ? 'tel' : 'text', autocomplete, 'aria-label': key }); fields[key] = input;
    // An own page-defined value override must never be used for address filling.
    Object.defineProperty(input, 'value', { get() { assert.fail('Use native allowlisted getter'); }, set() { assert.fail('Use native allowlisted setter'); } });
    input.addEventListener('change', () => { if (Object.entries(address).every(([key, value]) => values.get(fields[key]) === value)) { selected.ownText = addressText; nodes['address-done'].hidden = false; } });
  }
  if (b.config.addressMode === 'existing') nodes['address-done'].hidden = false;
  const context = { URL, TextEncoder, Uint8Array, crypto: { randomUUID: () => webcrypto.randomUUID(), subtle: { async digest(algorithm, bytes) { assert.equal(algorithm, 'SHA-256'); const hash = createHash('sha256').update(bytes).digest(); return hash.buffer.slice(hash.byteOffset, hash.byteOffset + hash.byteLength); } } }, Event: class { constructor(type, options) { this.type = type; Object.assign(this, options); } }, HTMLInputElement: Input, HTMLTextAreaElement: Input, HTMLSelectElement: Input, HTMLOptionElement: Option,
    document, location: { href: ROOT + path }, Date: class extends Date { static now() { return now; } }, queueMicrotask,
    setTimeout: (fn, ms) => { timers.set(++timerID, { fn, ms }); return timerID; }, clearTimeout: id => timers.delete(id),
    MutationObserver: class { constructor(fn) { this.fn = fn; } observe() { observer = this; } disconnect() { if (observer === this) observer = null; } },
    addEventListener: (type, fn) => { events[type] = fn; }, fetch() { assert.fail('No network requests'); },
    chrome: { runtime: { id: 'extension-id', onMessage: { addListener(fn) { listener = fn; } }, sendMessage: message => b.send(message) } }
  };
  vm.createContext(context); sources.forEach(source => vm.runInContext(source, context));
  const settle = async () => { for (let round = 0; round < 4; round++) { for (let i = 0; i < 80; i++) await Promise.resolve(); await new Promise(resolve => setImmediate(resolve)); } };
  const start = async (taskId = 'task') => { let result; listener({ type: 'START_PURCHASE', taskId, config: b.config }, { id: 'extension-id' }, value => { result = value; }); await settle(); return result; };
  return { b, document, main, nodes, fields, context, events, timers, start, settle, deliver: async message => { let result; listener(message, { id: 'extension-id' }, value => { result = value; }); await settle(); return result; }, mutate: () => document.mutate(), setNow: value => { now = value; },
    halt: () => listener({ type: 'HALT', taskId: 'task' }, { id: 'extension-id' }, () => {}),
    confirmAddress: () => document.querySelectorAll('button').find(node => node.ownText === '确认使用此已选地址')?.dispatchEvent({ type: 'click', isTrusted: true }) };
}

test('generic user-mapped purchase runs add, native address, review and one unpaid submit without load or requests', async () => {
  const h = harness(); assert.equal((await h.start()).ok, true); assert.equal(h.b.state, 'DONE');
  for (const id of ['add', 'review', 'submit']) assert.equal(h.nodes[id].clicks, 1);
  for (const field of Object.values(h.fields)) assert.equal(field.writes, 1);
  assert.equal(h.b.sent.filter(m => m.type === 'PURCHASE_CLAIM').length, 4);
  assert.equal(h.b.sent.filter(m => m.type === 'PURCHASE_CHECK').length, 4);
  const results = h.b.sent.filter(m => m.type === 'PURCHASE_RESULT'); assert.equal(results[1].evidence.addressComplete, true); assert.equal(results[3].evidence.unpaidOrder, true);
  assert.equal(JSON.stringify(h.b.sent).includes(address.fullName), false); assert.equal(h.timers.size, 0);
  for (let i = 0; i < 50; i++) h.mutate(); await h.settle(); assert.equal(h.nodes.submit.clicks, 1);
});

test('semantic target must be unique visible and enabled; a disabled duplicate is ambiguous', async () => {
  const h = harness(); h.b.config.steps[0].target.selector = undefined;
  const duplicate = h.document.create('button', 'Add to bag', { type: 'button' }); duplicate.disabled = true; h.main.append(duplicate);
  await h.start(); assert.equal(h.nodes.add.clicks, 0); assert.match(h.b.sent.at(-1).reason, /ambiguous-target/u);
  const x = harness(); x.nodes.add.disabled = true; await x.start(); assert.equal(x.nodes.add.clicks, 0); x.nodes.add.disabled = false; x.mutate(); await x.settle(); assert.equal(x.b.state, 'DONE');
});

test('fresh semantic relocation after claim/check never clicks replaced nodes', async () => {
  const h = harness(); const original = h.nodes.add; let intermediate, newest;
  const replace = () => { const old = h.nodes.add, node = h.document.create('button', 'Add to bag', { type: 'button', id: 'add' }); node.onClick = old.onClick; old.remove(); h.main.append(node); h.nodes.add = node; return node; };
  h.b.custom = message => { if (message.stepIndex !== 0) return; if (message.type === 'PURCHASE_CLAIM') intermediate = replace(); if (message.type === 'PURCHASE_CHECK') newest = replace(); };
  await h.start(); assert.equal(original.clicks, 0); assert.equal(intermediate.clicks, 0); assert.equal(newest.clicks, 1); assert.equal(h.b.state, 'DONE');
});

test('changed final total, specs, cart lines, address or URL at check prevents final submission', async () => {
  for (const change of ['total', 'within-cap-total', 'model', 'item-count', 'selected-address', 'url', 'no-charge', 'total-completeness']) {
    const h = harness(); h.b.custom = message => { if (message.type === 'PURCHASE_CHECK' && message.stepIndex === 3) {
      if (change === 'url') h.context.location.href = ROOT + '/shop/unmapped';
      else if (change === 'within-cap-total') h.nodes.total.ownText = '106.00';
      else h.nodes[change].ownText = change === 'total' ? '111.00' : change === 'item-count' ? '2' : 'Changed';
    } };
    await h.start(); assert.equal(h.nodes.submit.clicks, 0, change); assert.equal(h.b.state, 'UNKNOWN', change);
  }
});

test('payment/login/CAPTCHA/new terms and sensitive fields halt without reading values', async () => {
  for (const [tag, text, attrs] of [['input', '', { type: 'password' }], ['input', '', { autocomplete: 'cc-number' }], ['iframe', '', { title: 'CAPTCHA' }], ['button', 'Pay now', {}], ['button', 'Accept terms', {}], ['span', 'Sign in to continue', {}], ['input', '', { type: 'checkbox', 'aria-label': 'Accept terms and conditions' }]]) {
    const h = harness(); h.main.append(h.document.create(tag, text, attrs)); await h.start(); assert.equal(h.nodes.add.clicks, 0); assert.equal(h.b.state, 'PAUSED');
  }
});

test('new address is never entered into remapped password, wrong autocomplete or unapproved form destination', async () => {
  for (const kind of ['password', 'autocomplete', 'destination']) {
    const h = harness();
    if (kind === 'password') h.fields.fullName.setAttribute('type', 'password');
    if (kind === 'autocomplete') h.fields.fullName.setAttribute('autocomplete', 'cc-number');
    if (kind === 'destination') { const form = h.document.create('form', '', { action: 'https://example.invalid/collect' }); h.main.append(form); form.append(...Object.values(h.fields)); }
    await h.start(); assert.equal(Object.values(h.fields).reduce((n, field) => n + field.writes, 0), 0); assert.equal(h.nodes.submit.clicks, 0);
  }
});

test('address events cannot reroute later writes to a changed destination or sensitive replacement', async () => {
  const h = harness(); h.fields.fullName.addEventListener('input', () => h.fields.addressLine1.setAttribute('autocomplete', 'cc-number'));
  await h.start(); assert.equal(h.fields.fullName.writes, 1); assert.equal(h.fields.addressLine1.writes, 0); assert.equal(h.nodes.submit.clicks, 0); assert.equal(h.b.state, 'UNKNOWN');
});

test('unconfirmed action times out unknown, never retries or restarts same task', async () => {
  const h = harness(); h.nodes.add.onClick = () => {}; await h.start(); assert.equal(h.nodes.add.clicks, 1);
  for (let i = 0; i < 20; i++) h.mutate(); await h.settle(); assert.equal(h.nodes.add.clicks, 1);
  h.setNow(17000); h.mutate(); await h.settle(); assert.equal(h.b.state, 'UNKNOWN'); assert.equal((await h.start()).ok, false); assert.equal(h.timers.size, 0);
});

test('halt during delayed authorization prevents action and visible stop remains actionable', async () => {
  for (const type of ['PURCHASE_CLAIM', 'PURCHASE_CHECK']) {
    const h = harness(); let release; h.b.custom = m => m.type === type ? new Promise(resolve => { release = resolve; }) : undefined;
    await h.start(); const stop = h.document.querySelectorAll('button').find(node => node.ownText === '停止购买辅助'); assert.ok(stop); stop.click();
    release({ ok: true, action: 'purchase-act', claimToken: 'late', deadline: 50000, allowed: true }); await h.settle(); assert.equal(h.nodes.add.clicks, 0); assert.equal(h.timers.size, 0);
  }
});

test('existing address requires explicit local acknowledgment and only hash/booleans leave page', async () => {
  const h = harness({ b: backend(plan({ existing: true })) }); await h.start(); assert.equal(h.nodes.add.clicks, 1); assert.equal(h.nodes.review.clicks, 0);
  assert.equal(h.b.sent.some(m => m.type === 'PURCHASE_CONFIRM_ADDRESS'), false); h.confirmAddress(); await h.settle(); assert.equal(h.b.state, 'DONE');
  assert.equal(Object.values(h.fields).reduce((n, field) => n + field.writes, 0), 0); assert.equal(JSON.stringify(h.b.sent).includes(address.fullName), false);
  assert.match(h.b.fingerprint, /^[\da-f]{64}$/u); assert.equal(h.nodes.submit.clicks, 1);
});

test('existing address replacement before acknowledgment or after final grant stops', async () => {
  const h = harness({ b: backend(plan({ existing: true })) }); await h.start(); h.nodes['selected-address'].ownText = 'Different destination'; h.confirmAddress(); await h.settle(); assert.equal(h.nodes.review.clicks, 0); assert.equal(h.b.state, 'PAUSED');
  const x = harness({ b: backend(plan({ existing: true })) }); x.b.custom = m => { if (m.type === 'PURCHASE_CHECK' && m.stepIndex === 3) x.nodes['selected-address'].ownText = 'Different destination'; };
  await x.start(); x.confirmAddress(); await x.settle(); assert.equal(x.nodes.submit.clicks, 0); assert.equal(x.b.state, 'UNKNOWN');
});

test('explicit multi-page continuation binds next document, confirms old claim, and never re-clicks', async () => {
  const b = backend(plan({ multipage: true }));
  const product = harness({ b }); product.nodes.add.onClick = () => { product.events.pagehide(); }; await product.start();
  assert.equal(product.nodes.add.clicks, 1); assert.equal(b.index, 0); assert.equal(b.pending.checked, true);
  const delivery = harness({ b, path: '/shop/address', page: 1 }); delivery.nodes['bag-done'].hidden = false;
  delivery.nodes['continue-address'].onClick = () => { delivery.events.pagehide(); }; await delivery.start(); assert.equal(b.index, 2); assert.equal(delivery.nodes.add.clicks, 0); assert.equal(delivery.nodes['continue-address'].clicks, 1);
  const review = harness({ b, path: '/shop/review', page: 2 }); review.nodes['address-next'].hidden = false; review.nodes.review.onClick = () => { review.events.pagehide(); };
  await review.start(); assert.equal(b.index, 3); assert.equal(review.nodes.review.clicks, 1);
  const submit = harness({ b, path: '/shop/submit', page: 3 }); submit.nodes['review-done'].hidden = false; await submit.start();
  assert.equal(b.state, 'DONE'); assert.equal(submit.nodes.submit.clicks, 1); assert.equal(b.sent.filter(m => m.type === 'PURCHASE_CLAIM').length, 5);
});

test('unexpected pagehide is unknown and wrong next page cannot bind or act', async () => {
  const h = harness(); h.nodes.add.onClick = () => h.events.pagehide(); await h.start(); assert.equal(h.b.state, 'UNKNOWN'); assert.equal(h.nodes.submit.clicks, 0);
  const b = backend(plan({ multipage: true })), first = harness({ b }); first.nodes.add.onClick = () => first.events.pagehide(); await first.start();
  const wrong = harness({ b, path: '/shop/other' }); assert.equal((await wrong.start()).ok, true); assert.equal(wrong.nodes.add.clicks, 0); assert.equal(b.state, 'PAUSED');
});

test('postcondition cannot read a credential-containing container or already-satisfied action result', async () => {
  const h = harness(); h.nodes['bag-done'].hidden = false; h.nodes['bag-done'].append(h.document.create('input', '', { type: 'password' })); await h.start(); assert.equal(h.nodes.add.clicks, 0);
  const x = harness(); x.nodes['bag-done'].hidden = false; await x.start(); assert.equal(x.nodes.add.clicks, 0); assert.match(x.b.sent.at(-1).reason, /preexisting/u);
});

test('stopping synchronously during address input prevents every remaining write', async () => {
  for (const event of ['input', 'change']) {
    const h = harness(); h.fields.fullName.addEventListener(event, () => h.halt());
    await h.start(); assert.equal(h.fields.fullName.writes, 1); assert.equal(h.fields.addressLine1.writes, 0); assert.equal(h.nodes.submit.clicks, 0); assert.equal(h.timers.size, 0);
  }
});

test('visible ordinary future charge promises block despite mapped no-charge declaration', async () => {
  for (const statement of ['Your card will be charged when you place this order', 'Your card will automatically be charged later', 'No charge now. Your card will be charged tomorrow', '订单创建后会自动扣款', 'No payment now. Payment will be collected later', 'Your card is charged when this order is submitted.', 'By placing your order, you agree to pay the total shown.', '提交订单即表示您同意支付全部金额。']) {
    const h = harness(); h.main.append(h.document.create('p', statement)); await h.start(); assert.equal(h.nodes.submit.clicks, 0, statement); assert.equal(h.nodes.add.clicks, 0, statement);
  }
});

test('Chinese unpaid action names and explicit negative charge statements remain usable', async () => {
  for (const declaration of ['提交订单不会扣款，创建后自行付款', 'Your card will not be charged. Creates an unpaid order.', 'No charge. This creates an unpaid order.']) {
    const h = harness(); h.b.config.steps[3].target.name = '创建未付款订单'; h.nodes.submit.ownText = '创建未付款订单';
    h.b.config.steps[3].noChargeText = declaration; h.nodes['no-charge'].ownText = declaration;
    h.b.config.steps[3].confirm.text = '未付款订单已创建'; h.nodes['order-done'].ownText = '未付款订单已创建';
    await h.start(); assert.equal(h.b.state, 'DONE', declaration); assert.equal(h.nodes.submit.clicks, 1);
  }
});

test('unpaid label alone or contradictory result wording cannot authorize final submit', async () => {
  const h = harness(); h.nodes['no-charge'].ownText = h.b.config.steps[3].noChargeText = 'Unpaid order'; await h.start(); assert.equal(h.nodes.submit.clicks, 0);
  const x = harness(); x.nodes['order-done'].ownText = x.b.config.steps[3].confirm.text = 'Order created, not an unpaid order'; await x.start(); assert.equal(x.b.state, 'UNKNOWN');
});

test('page-generated clicks cannot acknowledge an existing destination', async () => {
  const h = harness({ b: backend(plan({ existing: true })) }); await h.start();
  h.document.querySelectorAll('button').find(node => node.ownText === '确认使用此已选地址').click(); await h.settle();
  assert.equal(h.b.sent.some(m => m.type === 'PURCHASE_CONFIRM_ADDRESS'), false); assert.equal(h.nodes.review.clicks, 0);
  h.confirmAddress(); await h.settle(); assert.equal(h.b.state, 'DONE');
});

test('exact attachment query is supported while extra parameters or another product stop', async () => {
  for (const suffix of ['?product=mjt74ch/a&step=attach', '?step=attach&product=mjt74ch%2Fa', '?product=other11/a&step=attach', '?product=mjt74ch/a&step=attach&extra=1']) {
    const c = plan(); for (const step of c.steps) { step.path = '/shop/buy-iphone/iphone-18-pro'; step.query = { product: 'mjt74ch/a', step: 'attach' }; }
    c.url = ROOT + '/shop/buy-iphone/iphone-18-pro?product=mjt74ch/a&step=attach'; const h = harness({ b: backend(c), path: '/shop/buy-iphone/iphone-18-pro' + suffix });
    await h.start(); assert.equal(h.nodes.add.clicks, suffix.includes('other11') || suffix.includes('extra=') ? 0 : 1, suffix);
  }
});

test('secure6 exact routes redact dynamic tokens and login endpoints never act', async () => {
  const c = plan(); for (const step of c.steps) step.origin = 'https://secure6.www.apple.com.cn';
  const h = harness({ b: backend(c) }); h.context.location.href = 'https://secure6.www.apple.com.cn/shop/product?session=DO_NOT_REPORT'; await h.start();
  assert.equal(h.b.state, 'DONE'); assert.equal(JSON.stringify(h.b.sent).includes('DO_NOT_REPORT'), false);
  for (const origin of ['https://secure5.www.apple.com.cn', 'https://secure6.www.apple.com.cn.evil.invalid']) {
    const x = harness({ b: backend(c) }); x.context.location.href = origin + '/shop/product'; await x.start(); assert.equal(x.nodes.add.clicks, 0);
  }
  const x = harness({ b: backend(c) }); c.steps[0].path = '/shop/signIn'; x.context.location.href = 'https://secure6.www.apple.com.cn/shop/signIn?session=DO_NOT_REPORT'; await x.start(); assert.equal(x.nodes.add.clicks, 0); assert.equal(JSON.stringify(x.b.sent).includes('DO_NOT_REPORT'), false);
});

test('START acknowledges before pending BIND can complete, eliminating worker queue deadlock', async () => {
  const h = harness(); let release;
  h.b.custom = m => m.type === 'PURCHASE_BIND' ? new Promise(resolve => { release = resolve; }) : undefined;
  assert.equal((await h.start()).ok, true); assert.equal(h.nodes.add.clicks, 0);
  release({ ok: true, config: h.b.config, stepIndex: 0, state: 'WAITING' }); await h.settle();
  // Subsequent BIND deliberately remains pending, but first action completed.
  assert.equal(h.nodes.add.clicks, 1);
});

test('observed store maintenance text pauses immediately and makes checked actions unknown', async () => {
  const h = harness(); h.main.append(h.document.create('p', '来得早，来得好。即将与你见面。北京时间晚8点接受预购。一会儿见。'));
  await h.start(); assert.equal(h.nodes.add.clicks, 0); assert.equal(h.b.state, 'PAUSED');
  for (const stepIndex of [0, 3]) {
    const x = harness(); x.b.custom = m => { if (m.type === 'PURCHASE_CHECK' && m.stepIndex === stepIndex) x.main.append(x.document.create('p', '来得早，来得好。')); };
    await x.start(); assert.equal(x.b.state, 'UNKNOWN'); assert.equal(x.nodes.submit.clicks, 0); if (stepIndex === 0) assert.equal(x.nodes.add.clicks, 0);
  }
});

test('visibilitychange before pagehide retires a dispatched mapped navigation without replay', async () => {
  const b = backend(plan({ multipage: true })), first = harness({ b });
  first.nodes.add.onClick = () => { first.document.visibilityState = 'hidden'; for (const fn of first.document.events.visibilitychange) fn(); first.events.pagehide(); };
  await first.start(); assert.equal(first.nodes.add.clicks, 1); assert.equal(b.state, 'SUBMITTING'); assert.equal(b.sent.filter(m => m.type === 'PURCHASE_DISCONNECT').length, 1);
  assert.equal(first.timers.size, 0);
  const second = harness({ b, path: '/shop/address', page: 1 }); second.nodes['bag-done'].hidden = false; second.nodes['continue-address'].onClick = () => second.events.pagehide();
  await second.start(); assert.equal(b.index, 2); assert.equal(second.nodes.add.clicks, 0);
});

function addConfiguration(h, { selected = false, reflect = true } = {}) {
  const stages = [], radios = [], proofs = [];
  for (const [group, field] of [['dimensionColor', 'color'], ['dimensionCapacity', 'storage']]) {
    const target = h.document.create('input', '', { type: 'radio', name: group, id: 'configure-' + field, 'aria-label': h.b.config[field] });
    const proof = h.document.create('span', selected ? h.b.config[field] : '', { id: 'chosen-' + field });
    const confirmation = h.document.create('section', field + ' applied', { id: 'configured-' + field }); confirmation.hidden = !selected;
    target.checked = selected;
    target.onClick = () => { target.checked = true; if (reflect) { proof.ownText = h.b.config[field]; confirmation.hidden = false; } };
    h.main.append(target, proof, confirmation); radios.push(target); proofs.push(proof);
    stages.push({ stage: 'configure', kind: 'radio', group, path: '/shop/product', target: { role: 'radio', name: h.b.config[field], selector: '#configure-' + field },
      evidence: { model: '#model', [field]: '#chosen-' + field, ...(field === 'storage' ? { color: '#chosen-color' } : {}), itemPrice: '#item-price', currency: '#currency', quantity: '#quantity' },
      confirm: { selector: '#configured-' + field, text: field + ' applied' }, timeoutMs: 15000 });
  }
  h.b.config.steps.unshift(...stages); return { radios, proofs };
}

test('one start runs semantic specification selection through unpaid submit with application confirmation', async () => {
  const h = harness(), { radios } = addConfiguration(h); await h.start(); assert.equal(h.b.state, 'DONE');
  assert.deepEqual(radios.map(node => node.clicks), [1, 1]); assert.equal(h.nodes.add.clicks, 1); assert.equal(h.nodes.submit.clicks, 1);
  const results = h.b.sent.filter(m => m.type === 'PURCHASE_RESULT'); assert.equal(results.length, 6);
  for (const result of results.slice(0, 2)) { assert.equal(result.evidence.radioChecked, true); assert.equal(result.evidence.selectionApplied, true); }
});

test('already selected radios no-op only with independent exact application proof', async () => {
  const h = harness(), { radios } = addConfiguration(h, { selected: true }); radios[0].disabled = true;
  await h.start(); assert.equal(h.b.state, 'DONE'); assert.deepEqual(radios.map(node => node.clicks), [0, 0]); assert.equal(h.b.sent.filter(m => m.type === 'PURCHASE_CLAIM').length, 6);
  const x = harness(), setup = addConfiguration(x, { reflect: false }); await x.start();
  assert.equal(setup.radios[0].checked, true); assert.equal(x.nodes.add.clicks, 0); x.setNow(17000); x.mutate(); await x.settle(); assert.equal(x.b.state, 'UNKNOWN');
});

test('configuration regression during next grant blocks subsequent selection and purchase', async () => {
  const h = harness(), { radios, proofs } = addConfiguration(h);
  h.b.custom = m => { if (m.type === 'PURCHASE_CHECK' && m.stepIndex === 1) proofs[0].ownText = 'Wrong color'; };
  await h.start(); assert.equal(radios[0].clicks, 1); assert.equal(radios[1].clicks, 0); assert.equal(h.nodes.add.clicks, 0); assert.equal(h.b.state, 'UNKNOWN');
});

test('scheduled start waits with observer and heartbeat, then starts without load or refresh', async () => {
  const h = harness(), { radios } = addConfiguration(h); h.b.config.targetTime = new Date(60000).toISOString();
  await h.start(); assert.equal(radios[0].clicks, 0); assert.equal(h.nodes.add.clicks, 0); assert.equal(h.b.sent.filter(m => m.type === 'PURCHASE_HEARTBEAT').length, 1);
  h.setNow(31000); h.mutate(); await h.settle(); assert.equal(h.b.sent.filter(m => m.type === 'PURCHASE_HEARTBEAT').length, 2); assert.equal(h.nodes.add.clicks, 0);
  h.setNow(59999); h.mutate(); await h.settle(); assert.equal(radios[0].clicks, 0);
  h.setNow(60000); h.mutate(); await h.settle(); assert.equal(h.b.state, 'DONE'); assert.equal(radios[0].clicks, 1); assert.equal(h.nodes.submit.clicks, 1);
});

test('late hydrated evidence is observed immediately, missing proof does not trigger premature action', async () => {
  const h = harness(); h.nodes.model.hidden = true; await h.start(); assert.equal(h.nodes.add.clicks, 0); assert.equal(h.b.sent.at(-1).type, 'PURCHASE_BIND');
  h.nodes.model.hidden = false; h.mutate(); await h.settle(); assert.equal(h.b.state, 'DONE');
});

test('standard autocomplete needs no selectors; exact label/aria/name fallback remains semantic', async () => {
  for (const fallback of ['autocomplete', 'aria', 'label', 'name']) {
    const h = harness(); h.b.config.steps[1].fields = Object.entries(fieldMap).map(([key, autocomplete]) => ({ key, autocomplete }));
    for (const [key, node] of Object.entries(h.fields)) {
      if (fallback === 'autocomplete') { node.removeAttribute('aria-label'); node.setAttribute('autocomplete', 'section-delivery shipping ' + fieldMap[key]); }
      else { node.removeAttribute('autocomplete'); if (fallback !== 'aria') node.removeAttribute('aria-label'); }
      if (fallback === 'label') h.main.append(h.document.create('label', key, { for: 'field-' + key }));
      if (fallback === 'name') node.setAttribute('name', key);
    }
    await h.start(); assert.equal(h.b.state, 'DONE', fallback); assert.equal(h.nodes.submit.clicks, 1);
  }
});

function nativeCascade(h, { stopAtProvince = false, missingCity = false } = {}) {
  const writeRecords = [];
  const codes = { province: 'P1', city: 'C1', district: 'D1' };
  function select(key, ready = false) {
    const previous = h.fields[key], node = h.document.create('select', '', { id: 'field-' + key, autocomplete: fieldMap[key], 'aria-label': key });
    node.disabled = !ready;
    if (ready) node.append(h.document.create('option', address[key], { value: codes[key] }));
    previous.remove(); h.main.append(node); h.fields[key] = node; writeRecords.push(node); return node;
  }
  select('city'); select('district'); const province = select('province', true);
  const reflect = () => {
    if (Object.entries(address).every(([key, value]) => values.get(h.fields[key]) === (codes[key] ?? value))) { h.nodes['selected-address'].ownText = addressText; h.nodes['address-done'].hidden = false; }
  };
  province.addEventListener('change', () => {
    if (stopAtProvince) { h.halt(); return; }
    if (missingCity) return;
    queueMicrotask(() => {
      const city = select('city', true);
      city.addEventListener('change', () => queueMicrotask(() => { const district = select('district', true); district.addEventListener('change', reflect); h.mutate(); }));
      h.mutate();
    });
  });
  for (const node of Object.values(h.fields)) node.addEventListener('change', reflect);
  return { province, writeRecords };
}

test('native province/city/district waits for exact late options and fresh replacement controls', async () => {
  const h = harness(); h.b.config.steps[1].fields = Object.entries(fieldMap).map(([key, autocomplete]) => ({ key, autocomplete }));
  const cascade = nativeCascade(h); await h.start(); assert.equal(h.b.state, 'DONE');
  assert.equal(values.get(h.fields.province), 'P1'); assert.equal(values.get(h.fields.city), 'C1'); assert.equal(values.get(h.fields.district), 'D1');
  assert.equal(h.nodes.submit.clicks, 1); assert.equal(cascade.writeRecords.reduce((sum, node) => sum + node.writes, 0), 3);
  assert.equal(h.b.sent.filter(m => m.type === 'PURCHASE_CLAIM' && m.stepIndex === 1).length, 1);
});

test('stop while dependent native selects populate prevents all later address writes', async () => {
  const h = harness(); nativeCascade(h, { stopAtProvince: true }); await h.start();
  assert.equal(h.fields.province.writes, 1); assert.equal(h.fields.city.writes, 0); assert.equal(h.fields.district.writes, 0); assert.equal(h.fields.addressLine1.writes, 0); assert.equal(h.nodes.submit.clicks, 0);
});

test('unknown or ambiguous select options never guessed and pending field times out without reentry', async () => {
  const h = harness(); nativeCascade(h, { missingCity: true }); await h.start(); assert.equal(h.fields.province.writes, 1); assert.equal(h.fields.city.writes, 0);
  h.setNow(17000); h.mutate(); await h.settle(); assert.equal(h.b.state, 'UNKNOWN'); assert.equal(h.fields.province.writes, 1); assert.equal(h.nodes.submit.clicks, 0);
  const x = harness(); const { province } = nativeCascade(x); province.append(x.document.create('option', address.province, { value: 'P2' })); await x.start(); assert.equal(province.writes, 0); assert.equal(x.nodes.submit.clicks, 0);
});

test('unknown required address control and duplicate semantic fields stop before personal-data entry', async () => {
  for (const kind of ['required', 'duplicate']) {
    const h = harness(); h.b.config.steps[1].fields = Object.entries(fieldMap).map(([key, autocomplete]) => ({ key, autocomplete }));
    h.main.append(h.document.create('input', '', kind === 'required' ? { type: 'text', name: 'unmapped-personal-field', required: '' } : { type: 'text', autocomplete: 'name', 'aria-label': 'fullName' }));
    await h.start(); assert.equal(Object.values(h.fields).reduce((sum, node) => sum + node.writes, 0), 0); assert.equal(h.nodes.submit.clicks, 0);
  }
});

test('split-markup charge commitments and negated no-charge promises never bypass blockers', async () => {
  const h = harness(), paragraph = h.document.create('p', 'Your card is charged '); paragraph.append(h.document.create('strong', 'when you submit.')); h.main.append(paragraph);
  await h.start(); assert.equal(h.nodes.add.clicks, 0);
  for (const declaration of ['This is not without payment. Creates an unpaid order.', 'There is no no charge option.', '并非不会扣款，订单先显示未付款', '不保证不会扣款']) {
    const x = harness(); x.nodes['no-charge'].ownText = x.b.config.steps[3].noChargeText = declaration; await x.start(); assert.equal(x.nodes.submit.clicks, 0, declaration);
  }
});

function duoConfiguration(h, { reflect = true, selected = false } = {}) {
  const path = '/shop/buy-iphone/iphone-duo/mk2n4ch/a';
  h.b.config.model = 'iPhone Duo'; h.b.config.color = '星光白色'; h.nodes.model.ownText = 'iPhone Duo'; h.nodes.color.ownText = '星光白色';
  const setup = addConfiguration(h, { selected });
  h.b.config.url = ROOT + path; h.context.location.href = ROOT + path;
  for (const step of h.b.config.steps) step.path = path;
  for (const step of h.b.config.steps.slice(0, 2)) { step.adapter = 'apple-duo'; step.confirm = { kind: 'apple-selection' }; step.evidence = {}; }
  const heading = h.document.create('h1', 'iPhone Duo'), summary = h.document.create('span', selected ? 'iPhone Duo 256GB 星光白色' : 'iPhone Duo', { 'data-autom': 'summary-productName' });
  h.nodes['item-price'].setAttribute('data-autom', 'full-price'); h.nodes['item-price'].ownText = 'RMB 100.00';
  h.main.append(heading, summary);
  setup.radios[1].disabled = !selected;
  setup.radios[0].onClick = () => { setup.radios[0].checked = true; if (reflect) { setup.radios[1].disabled = false; summary.ownText = 'iPhone Duo 星光白色'; } };
  setup.radios[1].onClick = () => { setup.radios[1].checked = true; if (reflect) summary.ownText = 'iPhone Duo 256GB 星光白色'; };
  return { ...setup, summary };
}

test('known Duo adapter performs color and capacity in unified flow using observed application evidence', async () => {
  const h = harness(), { radios } = duoConfiguration(h); await h.start(); assert.equal(h.b.state, 'DONE');
  assert.deepEqual(radios.map(node => node.clicks), [1, 1]); assert.equal(h.nodes.submit.clicks, 1);
  for (const result of h.b.sent.filter(m => m.type === 'PURCHASE_RESULT').slice(0, 2)) { assert.equal(result.evidence.confirmation.kind, 'apple-selection'); assert.equal(result.evidence.selectionApplied, true); }
});

test('Duo checked-only state cannot advance; already selected application-confirmed SKU can no-op', async () => {
  const h = harness(), { radios } = duoConfiguration(h, { reflect: false }); await h.start(); assert.equal(radios[0].checked, true); assert.equal(h.nodes.add.clicks, 0);
  h.setNow(17000); h.mutate(); await h.settle(); assert.equal(h.b.state, 'UNKNOWN'); assert.equal(radios[0].clicks, 1);
  const x = harness(), complete = duoConfiguration(x, { selected: true }); await x.start(); assert.equal(x.b.state, 'DONE'); assert.deepEqual(complete.radios.map(node => node.clicks), [0, 0]);
});

test('installed local fixture gate runs the same engine only at exact extension-owned URL', async () => {
  const id = 'a'.repeat(32), fixtureURL = `chrome-extension://${id}/workflow-fixture.html`;
  for (const actual of [fixtureURL, fixtureURL + '?extra=1', ROOT + '/shop/fixture', 'https://example.invalid/workflow-fixture.html']) {
    const c = plan(); c.url = ROOT + '/shop/fixture'; c.testMode = true; c.fixtureURL = fixtureURL;
    for (const step of c.steps) step.path = '/shop/fixture';
    const h = harness({ b: backend(c) }); h.context.chrome.runtime.getURL = path => `chrome-extension://${id}/${path}`; h.context.location.href = actual;
    const response = await h.start(); assert.equal(response.ok, actual === fixtureURL); assert.equal(h.nodes.submit.clicks, actual === fixtureURL ? 1 : 0);
    if (actual === fixtureURL) { assert.equal(h.b.state, 'DONE'); assert.ok(h.b.sent.filter(m => m.evidence).every(m => m.evidence.url === ROOT + '/shop/fixture')); }
  }
});

test('local fixture never permits mapped outbound navigation even to Apple', async () => {
  const id = 'a'.repeat(32), fixtureURL = `chrome-extension://${id}/workflow-fixture.html`, c = plan(); c.url = ROOT + '/shop/fixture'; c.testMode = true; c.fixtureURL = fixtureURL;
  for (const step of c.steps) step.path = '/shop/fixture';
  const h = harness({ b: backend(c) }); h.context.chrome.runtime.getURL = path => `chrome-extension://${id}/${path}`; h.context.location.href = fixtureURL;
  h.nodes.add.setAttribute('formaction', ROOT + '/shop/fixture'); await h.start(); assert.equal(h.nodes.add.clicks, 0); assert.equal(h.b.state, 'PAUSED');
});

test('same-route final confirmation can replace old checkout DOM without repeating submit', async () => {
  const h = harness(); h.nodes.submit.onClick = () => {
    for (const key of ['model', 'storage', 'color', 'quantity', 'total', 'selected-address', 'no-charge']) h.nodes[key].remove();
    h.nodes['order-done'].hidden = false;
  };
  await h.start(); assert.equal(h.b.state, 'DONE'); assert.equal(h.nodes.submit.clicks, 1);
  assert.equal(h.b.sent.at(-1).evidence.unpaidOrder, true);
});

test('fixture runtime delivery verifies exact current tab before START or HALT', async () => {
  const id = 'a'.repeat(32), fixtureURL = `chrome-extension://${id}/workflow-fixture.html`, c = plan(); c.url = ROOT + '/shop/fixture'; c.testMode = true; c.fixtureURL = fixtureURL;
  for (const step of c.steps) step.path = '/shop/fixture';
  const h = harness({ b: backend(c) }); h.context.chrome.runtime.getURL = path => `chrome-extension://${id}/${path}`; h.context.location.href = fixtureURL; h.context.chrome.tabs = { getCurrent: async () => ({ id: 7 }) };
  assert.equal(await h.deliver({ type: 'START_PURCHASE_FIXTURE', targetTabId: 8, taskId: 'task', config: c }), undefined); assert.equal(h.b.sent.length, 0);
  let release; h.b.custom = m => m.type === 'PURCHASE_CLAIM' ? new Promise(resolve => { release = resolve; }) : undefined;
  assert.equal((await h.deliver({ type: 'START_PURCHASE_FIXTURE', targetTabId: 7, taskId: 'task', config: c })).ok, true);
  assert.equal(await h.deliver({ type: 'HALT_PURCHASE_FIXTURE', targetTabId: 8, taskId: 'task' }), undefined);
  assert.equal((await h.deliver({ type: 'HALT_PURCHASE_FIXTURE', targetTabId: 7, taskId: 'task' })).ok, true);
  release({ ok: true, action: 'purchase-act', claimToken: 'late', deadline: 50000 }); await h.settle(); assert.equal(h.nodes.add.clicks, 0); assert.equal(h.timers.size, 0);
});

test('final unpaid result requires completed creation and rejects negation, failure and future states', () => {
  const { context } = harness();
  const policy = context.PurchasePolicy;
  for (const text of [
    'No unpaid order was created.', 'Unpaid order was not created.', 'Unpaid order was never created.',
    'Unpaid order creation failed.', 'Unpaid order created, but submission failed.', 'Unpaid order created with an error.',
    'An unpaid order will be created.', 'An unpaid order is being created.', 'Unpaid order creation is pending.',
    'Unpaid order received, awaiting confirmation.', '未付款订单创建失败', '未付款订单未创建', '订单尚未创建，待付款',
    '未付款订单即将创建', '未付款订单正在创建', '未付款订单等待创建', '未付款订单创建中', '未付款订单已创建，但提交失败', '未付款订单成功支付'
  ]) assert.equal(policy.unpaidOrderResult(text), false, text);
  for (const text of [
    'Unpaid order created', 'An unpaid order has been created.', 'Unpaid order placed.', 'Unpaid order received, payment pending.',
    'Unpaid order created. Your card will not be charged.', '未付款订单已创建', '订单创建成功，待付款', '已生成未付款订单', '订单提交成功，待支付'
  ]) assert.equal(policy.unpaidOrderResult(text), true, text);
});

test('failed or pending creation result never completes the runner final claim', async () => {
  for (const text of ['Unpaid order was not created.', '未付款订单创建失败', '未付款订单正在创建']) {
    const h = harness(); h.b.config.steps[3].confirm.text = text; h.nodes['order-done'].ownText = text;
    // Exercise the runner even with a deliberately unvalidated mock plan.
    // Production validation rejects these same mappings before START.
    h.b.custom = message => {
      if (message.type === 'PURCHASE_RESULT' && message.stepIndex === 3) {
        assert.equal(message.evidence.unpaidOrder, false);
        h.b.state = 'UNKNOWN'; return { ok: true, state: 'UNKNOWN' };
      }
    };
    await h.start(); assert.equal(h.b.state, 'UNKNOWN'); assert.equal(h.nodes.submit.clicks, 1);
  }
});


test('deferred or conditional automatic charge contradicts a no-immediate-charge statement', async () => {
  for (const statement of [
    'No immediate charge; your card may be charged when shipped.',
    'Creates an unpaid order, no immediate payment. Card charged upon dispatch.',
    '创建待付款订单，不会立即扣款，发货时扣款。'
  ]) {
    const h = harness(); assert.equal(h.context.PurchasePolicy.positiveNoCharge(statement), false, statement); assert.equal(h.context.PurchasePolicy.paymentCommitment(statement), true, statement);
    h.nodes['no-charge'].ownText = h.b.config.steps[3].noChargeText = statement;
    await h.start(); assert.equal(h.nodes.submit.clicks, 0); assert.equal(h.nodes.add.clicks, 0);
  }
});
