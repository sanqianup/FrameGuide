import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import { validatePurchase, validatePurchaseAddress } from '../extension/purchase-config.js';
const source = fs.readFileSync(new URL('../extension/workflow-fixture.js', import.meta.url), 'utf8');
const html = fs.readFileSync(new URL('../extension/workflow-fixture.html', import.meta.url), 'utf8');
function api() { const context = vm.createContext({ URL, Date }); vm.runInContext(source, context); return context.WorkflowFixture; }
const clone = value => JSON.parse(JSON.stringify(value));
const url = 'chrome-extension://fixture-test/workflow-fixture.html';

test('fixture plan validates against the actual production schema and complete fictional address', () => {
  const fixture = api();
  for (const scenario of fixture.SCENARIOS) {
    const raw = clone(fixture.buildConfig(url, scenario));
    const config = validatePurchase(raw);
    assert.equal(config.url, 'https://www.apple.com.cn/shop/fixture');
    assert.equal(raw.testMode, undefined, 'Only the backend may mint testMode');
    assert.equal(raw.fixtureURL, undefined, 'Only the backend may mint fixtureURL');
    assert.equal(config.steps.length, 6);
    assert.deepEqual(config.steps.map(step => step.stage), ['configure', 'configure', 'add-to-bag', 'address', 'review', 'submit-unpaid']);
    assert.deepEqual(validatePurchaseAddress(clone(fixture.ADDRESS), config), clone(fixture.ADDRESS));
    assert.ok(config.steps.every(step => step.origin === 'https://www.apple.com.cn' && step.path === '/shop/fixture' && !step.adapter && !step.query && !step.confirm.nextPath));
    assert.equal(config.steps.at(-1).timeoutMs, scenario === 'unknown' ? 1500 : 7000);
  }
});

test('fixture config rejects web URLs, near-match extension paths, queries and fragments', () => {
  const fixture = api();
  for (const candidate of ['https://www.apple.com.cn/shop/fixture', 'http://localhost/workflow-fixture.html', 'chrome-extension://fixture-test/workflow-fixture.html?test=true', 'chrome-extension://fixture-test/workflow-fixture.html#demo', 'chrome-extension://fixture-test/nested/workflow-fixture.html', 'chrome-extension://fixture-test/workflow-fixture.html.evil']) {
    assert.throws(() => fixture.buildConfig(candidate), /exact extension page/);
  }
  assert.throws(() => fixture.buildConfig(url, 'invented'), /Unknown fixture scenario/);
});

test('sanitized measured metrics preserve timings and duplicate counts without address/config/task data', () => {
  const fixture = api();
  const run = { scenario: 'normal', execution: 'standalone-page-demo', runtimeSeen: false, status: 'DONE', started: 100, ended: 1000, clock: () => 1100, orderResults: 1, replacements: 2, addressCompleteMs: 321.456, actions: { color: { ready: 10.1234, reaction: 20.5678, completed: 25, count: 2 }, submit: { ready: 500, reaction: 510, completed: 900, count: 1 } }, events: [{ event: 'completed:submit', atMs: 900 }], address: clone(fixture.ADDRESS), config: { private: 'not exported' }, taskId: 'never-export-task-id' };
  const result = clone(fixture.sanitizedMetrics(run));
  assert.equal(result.elapsedMs, 900);
  assert.equal(result.installedExtensionVerified, false);
  assert.equal(result.duplicateActions, 1);
  assert.equal(result.orderSubmissions, 1);
  assert.equal(result.actions[0].readinessToReactionMs, 10.44);
  assert.equal(result.addressCompleteMs, 321.46);
  const json = JSON.stringify(result);
  for (const value of [...Object.values(fixture.ADDRESS), 'never-export-task-id', 'not exported']) assert.equal(json.includes(value), false);
  assert.match(result.limitations.join(' '), /未安装扩展/);
  run.execution = 'extension-runtime'; run.runtimeSeen = true;
  assert.equal(fixture.sanitizedMetrics(run).installedExtensionVerified, true);
});

test('fixture is inert until explicit interaction, has no network transport, and labels standalone limits', () => {
  assert.equal(api().sanitizedMetrics(null).status, 'NOT_RUN');
  assert.doesNotMatch(source, /\b(?:fetch|XMLHttpRequest|WebSocket|EventSource|sendBeacon)\s*\(/u);
  assert.doesNotMatch(source, /chrome\.runtime\s*=|chrome\s*=|\.sendMessage\s*=/u);
  assert.match(source, /location\.href === chrome\.runtime\.getURL\('workflow-fixture\.html'\)/u);
  assert.match(source, /type: 'PURCHASE_FIXTURE_START'/u);
  assert.match(source, /type: 'PURCHASE_FIXTURE_RESET', confirmedReset: true/u);
  assert.doesNotMatch(source, /type: 'START'/u);
  assert.match(source, /未安装扩展，仅模拟网页交互/u);
  assert.match(source, /performance\.now\(\)/u);
  assert.match(source, /Object\.getOwnPropertyDescriptor\(prototype, 'value'\)\.set\.call/u);
  assert.match(source, /control\.dispatchEvent\(new Event\('input'/u);
  assert.match(source, /control\.dispatchEvent\(new Event\('change'/u);
  assert.match(html, /空白待命；没有自动开始/u);
  assert.match(html, /id="fixture-run"/u);
  assert.match(html, /id="fixture-copy"/u);
  assert.match(html, /id="fixture-download"/u);
  assert.doesNotMatch(html, /https?:\/\//u);
});

test('all declared fixture selectors are unique markup or explicitly generated controls', () => {
  const fixture = api(), config = fixture.buildConfig(url);
  const literalIds = [...html.matchAll(/\bid="([^"]+)"/gu)].map(match => match[1]);
  assert.equal(literalIds.length, new Set(literalIds).size);
  for (const selector of Object.values(config.steps[2].evidence)) assert.equal(literalIds.includes(selector.slice(1)), true, selector);
  for (const step of config.steps.filter(step => step.addressConfirmation)) assert.deepEqual(clone(step.addressConfirmation.keys), Object.keys(clone(fixture.ADDRESS)));
  assert.equal(fixture.EXPECTED_ACTIONS.length, 11);
});

// A deterministic DOM-event test, not a browser or installation claim. The real
// browser is still required to validate native layout and Chrome integration.
function pageHarness(scenario) {
  let now = 0, timerId = 0;
  const timers = new Map();
  class Element {
    constructor(tag) { this.tagName = tag.toUpperCase(); this.attributes = new Map(); this.children = []; this.listeners = new Map(); this.parentElement = null; this._text = ''; this.disabled = false; this.checked = false; this._value = ''; }
    setAttribute(key, value) { this.attributes.set(key, String(value)); }
    getAttribute(key) { return this.attributes.get(key) ?? null; }
    get id() { return this.getAttribute('id') || ''; }
    get textContent() { return this._text + this.children.map(child => child.textContent).join(''); }
    set textContent(value) { this._text = String(value); this.replaceChildren(); }
    append(...children) { for (const child of children) { child.remove(); this.children.push(child); child.parentElement = this; } }
    replaceChildren(...children) { for (const child of this.children) child.parentElement = null; this.children = []; this.append(...children); }
    replaceWith(other) { const parent = this.parentElement, index = parent.children.indexOf(this); other.remove(); parent.children[index] = other; other.parentElement = parent; this.parentElement = null; }
    remove(index) { if (Number.isInteger(index) && this.tagName === 'SELECT') { this.children[index]?.remove(); return; } if (!this.parentElement) return; const parent = this.parentElement; parent.children = parent.children.filter(child => child !== this); this.parentElement = null; }
    addEventListener(type, listener) { const listeners = this.listeners.get(type) || []; listeners.push(listener); this.listeners.set(type, listeners); }
    dispatchEvent(event) { for (const listener of this.listeners.get(event.type) || []) listener(event); return true; }
    click() { if (this.disabled) return; if (this.getAttribute('type') === 'radio') { this.checked = true; this.dispatchEvent({ type: 'input' }); this.dispatchEvent({ type: 'change' }); } this.dispatchEvent({ type: 'click' }); }
    walk() { return [this, ...this.children.flatMap(child => child.walk())]; }
  }
  class Input extends Element { get value() { return this._value; } set value(value) { this._value = String(value); } }
  class Select extends Element {
    get options() { return this.children; }
    get value() { return this._value; }
    set value(value) { this._value = String(value); }
    get selectedOptions() { return this.children.filter(option => option.value === this._value).slice(0, 1); }
  }
  class Option extends Element { get value() { return this.getAttribute('value') || ''; } }
  const body = new Element('body'), head = new Element('head');
  const document = { body, head, createElement(tag) { return new (tag === 'input' ? Input : tag === 'select' ? Select : tag === 'option' ? Option : Element)(tag); }, getElementById(id) { return [...body.walk(), ...head.walk()].find(element => element.id === id) || null; } };
  for (const match of html.matchAll(/<(\w+)\b[^>]*\bid="([^"]+)"[^>]*>/gu)) { const element = document.createElement(match[1]); element.setAttribute('id', match[2]); body.append(element); }
  document.getElementById('fixture-scenario').value = scenario;
  const context = vm.createContext({ document, location: { href: 'http://127.0.0.1:8765/workflow-fixture.html' }, URL, Date, performance: { now: () => now }, HTMLInputElement: Input, HTMLSelectElement: Select, Event: class { constructor(type) { this.type = type; } }, setTimeout(callback, delay) { const id = ++timerId; timers.set(id, { callback, due: now + delay }); return id; }, clearTimeout(id) { timers.delete(id); } });
  vm.runInContext(source, context);
  function result() { return JSON.parse(document.getElementById('fixture-metrics').textContent); }
  function advance() { let count = 0; while (timers.size && count++ < 3000) { const [id, timer] = [...timers].sort((a, b) => a[1].due - b[1].due)[0]; if (timer.due > 30000) throw Error('Fixture did not finish'); timers.delete(id); now = timer.due; timer.callback(); } assert.ok(count < 3000, 'No unbounded page loop'); }
  return { document, timers, result, advance, run() { document.getElementById('fixture-run').click(); advance(); return result(); } };
}

test('standalone DOM demo runs every scenario using real registered fake-page event handlers', () => {
  for (const scenario of ['normal', 'rerender', 'cascade', 'stopped', 'unknown', 'delayed-final']) {
    const page = pageHarness(scenario);
    assert.equal(page.timers.size, 0, 'No automatic start');
    assert.match(page.document.getElementById('fixture-mode').textContent, /未安装扩展，仅模拟网页交互/);
    const result = page.run();
    assert.equal(result.installedExtensionVerified, false);
    assert.equal(result.execution, 'standalone-page-demo');
    assert.equal(result.duplicateActions, 0, scenario);
    assert.equal(result.status, scenario === 'stopped' ? 'STOPPED' : scenario === 'unknown' ? 'UNKNOWN' : 'DONE', scenario);
    assert.equal(result.orderSubmissions, scenario === 'stopped' ? 0 : 1, scenario);
    assert.equal(result.orderResults, ['stopped', 'unknown'].includes(scenario) ? 0 : 1, scenario);
    if (scenario !== 'stopped') {
      assert.equal(result.observedActions, 11, scenario);
      assert.ok(result.addressCompleteMs > 0);
      assert.ok(result.actions.every(action => action.readinessToReactionMs >= 0 && action.readinessToReactionMs !== null));
      assert.ok(result.events.some(event => event.event === 'change:province'));
      assert.ok(result.events.some(event => event.event === 'change:city'));
      assert.ok(result.events.some(event => event.event === 'change:district'));
    }
    if (['rerender', 'cascade'].includes(scenario)) assert.ok(result.replacements >= 2);
    if (scenario === 'delayed-final') assert.equal(result.actions.at(-1).completedMs - result.actions.at(-1).reactionMs, 2500);
  }
});
